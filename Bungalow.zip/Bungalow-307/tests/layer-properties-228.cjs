const assert=require('node:assert/strict');
const core=require('../src/engine-layer-edit-231.js');
const clone=v=>JSON.parse(JSON.stringify(v));
for(const key of ['vis','locked','alphaLock','inheritAlpha','reference']){
 const records=[{id:'a',value:true},{id:'b',value:false}],saved=clone(records);
 const command=core.command(key,records,{type:'toggle'});
 assert.deepEqual(clone(command),{version:1,undo:[{id:'a',key,value:true},{id:'b',key,value:false}],redo:[{id:'a',key,value:false},{id:'b',key,value:true}]});
 assert.deepEqual(records,saved);
 assert.equal(core.command(key,records,{type:'set',value:true}).redo.length,1);
 for(const bad of [0,1,'true',null,undefined])assert.throws(()=>core.command(key,records,{type:'set',value:bad}));
 assert.deepEqual(records,saved);
}
assert.equal(core.command('vis',[{id:'a'}],{type:'set',value:true}).redo.length,0);
assert.equal(core.command('locked',[{id:'a'}],{type:'set',value:false}).redo.length,0);
assert.deepEqual(core.command('name',[{id:'a',value:'Old'}],{type:'set',value:'New'}).undo,[{id:'a',key:'name',value:'Old'}]);
for(const name of ['', '  ', 7, null])assert.throws(()=>core.command('name',[{id:'a',value:'Old'}],{type:'set',value:name}));
assert.throws(()=>core.command('name',[{id:'a',value:'Old'}],{type:'toggle'}));
assert.throws(()=>core.command('locked',[{id:'a',value:false},{id:'a',value:true}],{type:'toggle'}));
assert.throws(()=>core.command('collapsed',[],{type:'set',value:true}));
assert.throws(()=>core.command('vis',[],{type:'unknown'}));
console.log('PASS: flag/name commands, mixed originals, JSON patches, defaults, no-ops and validation');
