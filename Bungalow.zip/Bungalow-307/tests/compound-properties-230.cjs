const assert=require('node:assert/strict'),core=require('../src/engine-layer-edit-231.js'),clone=x=>JSON.parse(JSON.stringify(x));
const records=[{id:'a',value:'First'},{id:'b',value:'Second'},{id:'c',value:'Third'}];
const command=core.command('name',records,{type:'setEach',values:[{id:'a',value:'Art 01'},{id:'b',value:'Art 02'}]});
assert.deepEqual(clone(command),{version:1,undo:[{id:'a',key:'name',value:'First'},{id:'b',key:'name',value:'Second'}],redo:[{id:'a',key:'name',value:'Art 01'},{id:'b',key:'name',value:'Art 02'}]});
const edit=core.begin('name',records),saved=clone(edit);
for(const values of [[{id:'a',value:'Changed'},{id:'z',value:'Unknown'}],[{id:'a',value:'Changed'},{id:'b',value:'  '}],[{id:'a',value:'Changed'},{id:'a',value:'Again'}]]){assert.throws(()=>core.updateEach(edit,values));assert.deepEqual(edit,saved)}
assert.deepEqual(core.command('name',records,{type:'setEach',values:records}).redo,[]);
assert.deepEqual(core.command('vis',[{id:'a',value:true}],{type:'set',value:true}).redo,[]);
console.log('PASS: heterogeneous commands, partial updates, JSON round trip, no-ops and atomic validation');
