/* v304: also opens the document from a file first and parks straight away (layers still decoding in the core). Each
 * display tile is requested once until it arrives.
 * v303: zooming (across levels of detail) and flipping the view with parked layers must not hang, and must refine to
 * the same picture as with every layer local (desktop: freezes on zoom/flip, layers left pixellated after zooming). */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore=lazy']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(line[0]==='R'?line.slice(1):JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  const invokeRaw=b64=>new Promise(r=>{pending.push(r);bytes+=b64.length*3/4;requests++;per.raw=(per.raw||0)+b64.length*3/4;proc.stdin.write('R'+b64+'\n')});
  if(mode.includes('lazy')){await p.exposeFunction('__bungalowRawB64',invokeRaw);await p.addInitScript(()=>{const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};window.__bungalowNativeInvokeRaw=u=>window.__bungalowRawB64(b64(u)).then(t=>{const s=atob(t),o=new Uint8Array(s.length);for(let i=0;i<o.length;i++)o[i]=s.charCodeAt(i);return o.buffer})})}
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+mode);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  const step=async(name,fn,ms=20000)=>{const t0=Date.now();const r=await Promise.race([p.evaluate(fn),new Promise(res=>setTimeout(()=>res({hang:true}),ms))]);const out={name,ms:Date.now()-t0,...(r||{})};console.log(JSON.stringify(out));if(out.hang)throw Error('page hung at '+name);return out};
  await step('setup',async()=>{window.__parkTripwireThrow=false;closeLanding();projectDirty=false;await createDocumentFromOptions({width:4000,height:2500,dpi:72,white:false});
   const list=[AL];for(let i=1;i<6;i++){const L=newLayer('P'+i,null,{w:DW,h:DH});insertLayer(L,layers.length);list.push(L)}
   list.forEach((L,i)=>{const g=document.createElement('canvas');g.width=g.height=1200;const q=g.getContext('2d');for(let k=0;k<30;k++){q.fillStyle=`hsla(${(k*41+i*60)%360},70%,50%,.8)`;q.beginPath();q.arc(80+k*36,90+(k*53)%1000,60+k*3,0,7);q.fill()}RasterResources.composeRegion(L.rasterId,{x:200+i*450,y:150+i*180,w:1200,h:1200},g,200+i*450,150+i*180,'source-over',1)});
   doH({undo(){},redo(){}});await NativeShadow.flush(true);
   // v304: reopen from a file and park straight away: layers still being decoded by the core must not be parked (or read)
   const blob=await encodeProject();projectDirty=false;await loadProjectFile(new File([blob],'t.bung'));list.length=0;list.push(...layers);
   LayerParking.setLimitGiB(0.0001);LayerParking.tick();LayerParking.setLimitGiB(0);window.__earlyParked=LayerParking.parkedCount();await NativeShadow.whenIdle();
   select(list[list.length-1]);renderLayers();await NativeShadow.flush(true);window.__list=list;
   LayerParking.setLimitGiB(0.0001);for(let i=0;i<10&&LayerParking.parkedCount()<5;i++)LayerParking.tick();LayerParking.setLimitGiB(0);return {parked:LayerParking.parkedCount(),earlyParked:window.__earlyParked}});
  const settle=`(async()=>{const t0=performance.now();for(let i=0;i<300;i++){await new Promise(r=>requestAnimationFrame(r));await new Promise(r=>setTimeout(r,20));const d=maskDisplay?.debugInfo?.()||{};if(i>5&&!d.pendingTiles&&!d.refinementPending)break}return {settleMs:Math.round(performance.now()-t0),pending:maskDisplay?.debugInfo?.()?.pendingTiles,lod:LayerParking.stats().lodTiles,lodMB:LayerParking.stats().lodMB,lodRequests:LayerParking.stats().lodRequests}})()`;
  const shot=k=>p.evaluate(k=>{const c=document.createElement('canvas'),v=maskDisplay.cv;c.width=v.width;c.height=v.height;const g=c.getContext('2d',{willReadFrequently:true});g.drawImage(v,0,0);window[k]=g.getImageData(0,0,c.width,c.height).data},k);
  const actions=[['zoom in',`for(let k=0;k<4;k++)zoomAt(wr.left+wr.width/2,wr.top+wr.height/2,2)`],['flip',`toggleFlip()`],['zoom out',`for(let k=0;k<3;k++)zoomAt(wr.left+wr.width/2,wr.top+wr.height/2,.5)`],['flip back',`toggleFlip()`],['zoom in 2',`zoomAt(wr.left+wr.width/3,wr.top+wr.height/3,4)`]];
  const results=[];
  for(const [name,code] of actions){await step(name,new Function(code));const s1=await step(name+' settle',new Function('return '+settle),60000);await shot('__A');
   // reference: same view with every layer back in the browser
   await step(name+' ref',async()=>{await LayerParking.ensureAll();for(const L of window.__list)L.maskRevision=(L.maskRevision||0)+1;scheduleLayerMasks()});await step(name+' ref settle',new Function('return '+settle),60000);await shot('__B');
   const diff=await p.evaluate(()=>{const A=window.__A,B=window.__B;if(A.length!==B.length)return 999;let s=0;for(let i=0;i<A.length;i+=4)for(let k=0;k<3;k++)s+=Math.abs(A[i+k]-B[i+k]);return s/(A.length*.75)});
   results.push({name,settleMs:s1.settleMs,diff});
   await step(name+' repark',async()=>{LayerParking.setLimitGiB(0.0001);for(let i=0;i<10&&LayerParking.parkedCount()<5;i++)LayerParking.tick();LayerParking.setLimitGiB(0);for(const L of window.__list)L.maskRevision=(L.maskRevision||0)+1;scheduleLayerMasks();return {parked:LayerParking.parkedCount()}});await step(name+' repark settle',new Function('return '+settle),60000)}
  console.log(JSON.stringify(results));const st=await p.evaluate(()=>LayerParking.stats());
  assert.deepEqual(errors,[]);assert.deepEqual(st.errors,[]);const st2=st;assert.ok((st2.lodKeys||0)<=(st2.lodTiles||0)+(st2.lodEmpty||0)+8,'each display tile requested once until it arrives: '+st2.lodKeys+' keys for '+st2.lodTiles+'+'+st2.lodEmpty);for(const x of results){assert.ok(x.settleMs<15000,x.name+' settles: '+x.settleMs);if(x.diff>=0)assert.ok(x.diff<3,x.name+': parked layers drawn like local ones (mean diff '+x.diff+')')}
  await context.close();proc.stdin.end()}
  console.log('PASS: v303 zoom and flip with parked layers: no hang, every level of detail refines to the same picture')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exit(1)});
