/* v271: paint-mask compositor scenario: masks targeted at a layer or a group, legacy (untargeted) masks, mask
 * opacity, masks inside groups, isolated groups, hidden masks, combined with blend/opacity/inherit alpha.
 * Standalone it checks the app compositor responds to each setting; under tests/native-composite-shadow-271.cjs the
 * Rust compositor must match it at every step (NativeShadow.verifyComposite). */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
const result=await p.evaluate(async()=>{
 const check=(v,m)=>{if(!v)throw Error(m)};closeLanding();projectDirty=false;await createDocumentFromOptions({width:96,height:64,dpi:72,white:false});
 const W=DW,H=DH,ramp=f=>{const im=new ImageData(W,H);for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=(y*W+x)*4,c=f(x/(W-1),y/(H-1));im.data.set(c.map(v=>Math.max(0,Math.min(255,Math.round(v)))),i)}return im};
 const fill=(L,f)=>RasterResources.putPixels(L.rasterId,ramp(f),0,0);
 const add=(name,f)=>{const L=newLayer(name,null,{w:W,h:H});insertLayer(L,layers.length);fill(L,f);thumb(L);return L};
 // A mask layer: grey ramp with varying alpha (white/transparent = visible, black = hidden)
 const addMask=(name,f,target=null)=>{const M=add(name,f);M.mask=true;M.maskKind='paint';M.maskTarget=target;thumb(M);return M};
 const base=AL;fill(base,(u,v)=>[255*u,180*v,90+120*(1-u),255]);thumb(base);
 const mid=add('Mid',(u,v)=>[40+200*v,255*(1-u),255*u*v,255]);
 const top=add('Top',(u,v)=>[255*(1-v),120+100*u,255*v,220]);
 const shadow=typeof NativeShadow!=='undefined'&&NativeShadow.enabled(),steps=[],hashes=new Set();
 const step=async label=>{renderLayers();const c=flat(true),d=c.getContext('2d').getImageData(0,0,W,H).data;let h=0;for(let i=0;i<d.length;i++)h=(h*31+d[i])|0;hashes.add(h);steps.push(label);if(shadow)await NativeShadow.verifyComposite(label)};
 await step('no masks');
 const m1=addMask('Mask legacy',(u,v)=>[255*u,255*u,255*u,u<.5?255:90+(1-v)*120]);await step('legacy mask above all');
 m1.op=.5;await step('legacy mask opacity');m1.op=1;
 m1.maskTarget=top;await step('mask targeted at top');
 m1.maskTarget=mid;await step('mask targeted at mid');
 m1.vis=false;await step('hidden mask');m1.vis=true;m1.maskTarget=null;
 const m2=addMask('Mask 2',(u,v)=>[0,0,0,255*Math.abs(Math.sin(u*9+v*3))]);await step('two legacy masks');
 m2.maskTarget=base;await step('second mask targeted at base');
 top.blend='multiply';await step('mask + blend');top.blend='normal';
 top.inheritAlpha=true;await step('mask + inherit alpha');top.inheritAlpha=false;
 top.op=.6;await step('mask + opacity');top.op=1;
 m1.vis=false;m2.vis=false;
 setStackSelection([mid,top],{active:top,anchor:mid});createLayerGroup();renderLayers();const G=top.group;check(G&&mid.group===G,'group made');await step('group, masks hidden');
 m1.vis=true;m2.vis=true;m2.maskTarget=null;await step('legacy masks above group');
 m1.maskTarget=G;await step('mask targeted at group');
 G.op=.6;await step('masked group + opacity');G.op=1;G.blend='screen';await step('masked group + blend');G.blend='normal';
 G.isolate=true;await step('isolated masked group');G.isolate=false;
 m1.maskTarget=null;commitStackTree({parents:new Map([[m1,G]])});check(m1.group===G&&auditStackTree(),'mask moved into group');await step('mask inside group (legacy)');
 m1.maskTarget=mid;await step('mask inside group targeted at layer');
 commitStackTree({parents:new Map([[m1,null]])});m1.maskTarget=null;
 const outside=add('Outside',(u,v)=>[255*v,255*v,255*u,200]);await step('layer above masks');
 await undo();await step('undo');await redoF();await step('redo');
 return {steps:steps.length,distinct:hashes.size,shadow};
});
assert.ok(result.distinct>=result.steps-8,'masks change the composite: '+JSON.stringify(result));
assert.deepEqual(errors,[]);console.log('PASS: paint-mask composite: '+result.steps+' configurations, '+result.distinct+' distinct results ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
