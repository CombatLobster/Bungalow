/* v307: a clone's source layer can be parked; moving the clone brings the source back and redraws the clone exactly.
 * Tripwire on. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore=lazy']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(line[0]==='R'?line.slice(1):JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  const invokeRaw=b64=>new Promise(r=>{pending.push(r);bytes+=b64.length*3/4;requests++;per.raw=(per.raw||0)+b64.length*3/4;proc.stdin.write('R'+b64+'\n')});
  if(mode.includes('lazy')){await p.exposeFunction('__bungalowRawB64',invokeRaw);await p.addInitScript(()=>{const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};window.__bungalowNativeInvokeRaw=u=>window.__bungalowRawB64(b64(u)).then(t=>{const s=atob(t),o=new Uint8Array(s.length);for(let i=0;i<o.length;i++)o[i]=s.charCodeAt(i);return o.buffer})})}
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+mode);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  const r=await p.evaluate(async()=>{window.__parkTripwireThrow=true;closeLanding();projectDirty=false;await createDocumentFromOptions({width:2400,height:1600,dpi:72,white:false});
   const wait=ms=>new Promise(r=>setTimeout(r,ms));
   const src=AL;const g=document.createElement('canvas');g.width=g.height=600;const q=g.getContext('2d');for(let k=0;k<15;k++){q.fillStyle=`hsla(${k*29},70%,50%,.8)`;q.beginPath();q.arc(60+k*35,80+(k*47)%440,40+k*3,0,7);q.fill()}
   RasterResources.composeRegion(src.rasterId,{x:300,y:200,w:600,h:600},g,300,200,'source-over',1);doH({undo(){},redo(){}});
   const C=newLayer('Clone',null,false);C.instance={type:'clone',src,flipH:false,flipV:false,dx:700,dy:100,xf:null};insertLayer(C,layers.length);renderClone(C);
   const other=newLayer('Other',null,{w:DW,h:DH});insertLayer(other,layers.length);select(other);renderLayers();await NativeShadow.flush(true);
   const hash=L=>{const q=peekLayerCanvas(L);try{const d=q.cv.getContext('2d').getImageData(0,0,DW,DH).data;let h=2166136261;for(let i=0;i<d.length;i+=4)h=Math.imul(h^(d[i]|d[i+1]<<8|d[i+2]<<16|d[i+3]<<24),16777619)>>>0;return h}finally{q.release()}};
   LayerParking.setLimitGiB(0.0001);for(let i=0;i<10&&!LayerParking.isParked(src);i++)LayerParking.tick();LayerParking.setLimitGiB(0);const parked=LayerParking.isParked(src);
   // move the clone: its source is parked, so it comes back and the clone redraws afterwards
   const h0=hash(C);C.instance.dx=900;renderClone(C);
   for(let i=0;i<100&&LayerParking.isParked(src);i++)await wait(50);for(let i=0;i<60&&hash(C)===h0;i++)await wait(50);const moved=hash(C);
   // reference: the same clone drawn with the source local
   renderClone(C);const ref=hash(C);
   return {h0,moved,ref,parked,back:!LayerParking.isParked(src),same:moved===ref,stats:LayerParking.stats(),errs:NativeShadow.stats().errors}});
  console.log(JSON.stringify({...r,stats:{...r.stats,trips:r.stats.trips.slice(0,6)}}));
  assert.deepEqual(errors,[]);assert.deepEqual(r.errs,[]);assert.deepEqual(r.stats.errors,[]);
  assert.ok(r.parked,'a clone source parks');assert.ok(r.back,'moving the clone brings its source back');assert.ok(r.same,'the clone redraws exactly once its source is back');
  assert.equal(r.stats.tripwires,0,'no direct reads of parked tiles: '+JSON.stringify(r.stats.trips));
  await context.close();proc.stdin.end()}
  console.log('PASS: v307 clone sources park; a clone of a parked source redraws exactly once the source is back')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exit(1)});
