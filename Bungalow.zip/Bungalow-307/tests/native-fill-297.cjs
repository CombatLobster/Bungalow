/* v297 (F): a large bucket fill on a tiled layer in lazy core mode runs entirely in the core (raster.fillTiles: flood,
 * blend, changed tiles back). Compared with the app's own fill on an identical layer: same pixels apart from
 * low-alpha edge rounding; undo is exact. Skips when the native server is not built. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore=lazy']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(line[0]==='R'?line.slice(1):JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  const invokeRaw=b64=>new Promise(r=>{pending.push(r);bytes+=b64.length*3/4;requests++;per.raw=(per.raw||0)+b64.length*3/4;proc.stdin.write('R'+b64+'\n')});
  if(mode.includes('lazy')){await p.exposeFunction('__bungalowRawB64',invokeRaw);await p.addInitScript(()=>{const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};window.__bungalowNativeInvokeRaw=u=>window.__bungalowRawB64(b64(u)).then(t=>{const s=atob(t),o=new Uint8Array(s.length);for(let i=0;i<o.length;i++)o[i]=s.charCodeAt(i);return o.buffer})})}
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+(mode==='app'?'':mode));await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:3000,height:2000,dpi:72,white:false});tool(false);setSize(30);Object.assign(TP,{kind:'round',hrd:.6,flow:.7,sp:.1})});
  const stroke=async pts=>{const c=await p.evaluate(pts=>{const r=wrap.getBoundingClientRect();return {hp,pts:pts.map(([x,y])=>{const o=docToOverlay({x,y});return [r.left+o.x,r.top+o.y]})}},pts);await p.mouse.move(...c.pts[0]);await p.mouse.down();for(const q of c.pts.slice(1))await p.mouse.move(...q,{steps:5});await p.mouse.up();await p.waitForFunction(h=>hp===h+1&&!drawing,c.hp,{timeout:10000})};
  const r=await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:2400,height:1500,dpi:72,white:false});
   let seed=11;const rnd=()=>(seed=(seed*1103515245+12345)%2147483648)/2147483648;const g=document.createElement('canvas');g.width=2400;g.height=1500;const q=g.getContext('2d');for(let k=0;k<60;k++){q.fillStyle=`hsla(${k*37%360},70%,50%,${.4+.6*rnd()})`;q.beginPath();q.arc(rnd()*2400,rnd()*1500,20+rnd()*140,0,7);q.fill()}
   RasterResources.composeRegion(AL.rasterId,{x:0,y:0,w:2400,h:1500},g,0,0,'source-over',1);doH({undo(){},redo(){}});const A=AL;dupLayer();const B=AL;await NativeShadow.flush(true);
   const read=L=>{const p=peekLayerCanvas(L);try{return p.cv.getContext('2d').getImageData(0,0,DW,DH).data}finally{p.release()}};const before=read(B);
   // find a transparent seed
   let sx=5,sy=5;const d0=read(A);for(let i=0;i<2000;i++){const x=Math.floor(rnd()*2400),y=Math.floor(rnd()*1500);if(!d0[(y*2400+x)*4+3]){sx=x;sy=y;break}}
   $('fillThreshold').value=10;
   window.__noCoreFill=true;select(A);let t=performance.now();bucketFill(A,sx,sy,'#3366cc',1);const jsMs=Math.round(performance.now()-t);window.__noCoreFill=false;
   select(B);t=performance.now();bucketFill(B,sx,sy,'#3366cc',1);await new Promise(r=>{const w=()=>projectIOBusy?setTimeout(w,10):r();w()});const coreMs=Math.round(performance.now()-t);
   const a=read(A),b=read(B);let n=0,md=0,px=0;for(let i=0;i<a.length;i+=4){let d=Math.abs(a[i+3]-b[i+3]);for(let k=0;k<3;k++)d=Math.max(d,Math.abs(a[i+k]*a[i+3]-b[i+k]*b[i+3])/255);if(d>md)md=d;if(d>2)n++;if(a[i+3]!==before[i+3])px++}
   await undo();const u=read(B);let undoOk=true;for(let i=0;i<u.length;i++)if(u[i]!==before[i]){undoOk=false;break}
   return {jsMs,coreMs,md:Math.round(md),over2:n,changed:px,undoOk,coreFills:window.__coreFills||0,errors:NativeShadow.stats().errors}});
  console.log(JSON.stringify(r));assert.deepEqual(errors,[]);assert.deepEqual(r.errors,[]);assert.equal(r.coreFills,1,'filled by the core');assert.ok(r.changed>100000,'large fill');
  assert.ok(r.over2<=r.changed*0.002,'core fill matches the app fill (edge rounding only): '+JSON.stringify(r));assert.ok(r.undoOk,'undo restores the layer exactly');
  await context.close();proc.stdin.end()}
  console.log('PASS: v297 bucket fill in the core: matches the app fill, exact undo')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
