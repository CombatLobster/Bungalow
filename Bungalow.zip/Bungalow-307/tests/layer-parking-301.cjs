/* v301: layer parking (stages 0-2 of PLAN-CORE-OWNED-LAYERS-300.md). Lazy core mode, 4 layers, a tiny limit: the
 * inactive layers are parked one per tick, drawn from core LOD tiles, restored exactly when selected, before undo/redo
 * of a step that wrote them and before a gated command (merge down). Saving with parked layers round-trips. Tripwire
 * on (window.__parkTripwireThrow): no code path may read a parked layer's tiles directly. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore=lazy']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(line[0]==='R'?line.slice(1):JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  const invokeRaw=b64=>new Promise(r=>{pending.push(r);bytes+=b64.length*3/4;requests++;per.raw=(per.raw||0)+b64.length*3/4;proc.stdin.write('R'+b64+'\n')});
  if(mode.includes('lazy')){await p.exposeFunction('__bungalowRawB64',invokeRaw);await p.addInitScript(()=>{const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};window.__bungalowNativeInvokeRaw=u=>window.__bungalowRawB64(b64(u)).then(t=>{const s=atob(t),o=new Uint8Array(s.length);for(let i=0;i<o.length;i++)o[i]=s.charCodeAt(i);return o.buffer})})}
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+mode);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  const r=await p.evaluate(async()=>{window.__parkTripwireThrow=true;closeLanding();projectDirty=false;await createDocumentFromOptions({width:3000,height:2000,dpi:72,white:false});
   const wait=ms=>new Promise(r=>setTimeout(r,ms)),frames=async n=>{for(let i=0;i<n;i++)await new Promise(r=>requestAnimationFrame(r))};
   const list=[AL];for(let i=1;i<4;i++){const L=newLayer('P'+i,null,{w:DW,h:DH});insertLayer(L,layers.length);list.push(L)}
   list.forEach((L,i)=>{const g=document.createElement('canvas');g.width=g.height=700;const q=g.getContext('2d');for(let k=0;k<20;k++){q.fillStyle=`hsla(${(k*41+i*80)%360},70%,50%,.8)`;q.beginPath();q.arc(80+k*30,90+(k*53)%520,40+k*3,0,7);q.fill()}RasterResources.composeRegion(L.rasterId,{x:300+i*500,y:200+i*300,w:700,h:700},g,300+i*500,200+i*300,'source-over',1)});
   doH({undo(){},redo(){}});select(list[3]);renderLayers();await NativeShadow.flush(true);await frames(10);
   const hash=L=>{const q=peekLayerCanvas(L);try{const d=q.cv.getContext('2d').getImageData(0,0,DW,DH).data;let h=2166136261;for(let i=0;i<d.length;i+=4)h=Math.imul(h^(d[i]|d[i+1]<<8|d[i+2]<<16|d[i+3]<<24),16777619)>>>0;return h}finally{q.release()}};
   const before=list.map(hash),resident0=LayerParking.residentBytes();
   const shot=()=>{const c=document.createElement('canvas'),v=maskDisplay.cv;c.width=v.width;c.height=v.height;const g=c.getContext('2d',{willReadFrequently:true});g.drawImage(v,0,0);return g.getImageData(0,0,c.width,c.height).data};
   renderLayers();await frames(10);await wait(300);const view0=shot();
   // park everything but the active layer, one per tick (the policy, with a tiny limit)
   const parkUntil=done=>{LayerParking.setLimitGiB(0.0001);for(let i=0;i<10&&!done();i++)LayerParking.tick();LayerParking.setLimitGiB(0)}; // ticks driven here; limit 0 in between so the timer never parks mid-check
   parkUntil(()=>LayerParking.parkedCount()>=3);
   const parked=list.map(L=>LayerParking.isParked(L)),resident1=LayerParking.residentBytes();
   // display: parked tiles arrive from the core and are drawn
   for(const L of list)if(LayerParking.isParked(L))L.maskRevision=(L.maskRevision||0)+1; // force a re-upload: textures from before parking would otherwise be reused
   for(const L of list)L.compositeDirty=null;renderLayers();scheduleLayerMasks();for(let i=0;i<200;i++){await frames(2);await wait(50);const d=maskDisplay?.debugInfo?.();if(i>8&&LayerParking.stats().lodTiles>0&&d&&!d.pendingTiles)break}
   await frames(10);await wait(300);const lod=LayerParking.stats(),view1=shot();let diff=0,n=0;for(let i=0;i<view0.length;i+=4){for(let k=0;k<3;k++)diff+=Math.abs(view0[i+k]-view1[i+k]);n+=3}const viewDiff=diff/n;
   // save with parked layers (the core encodes them), reopen: identical pixels
   const blob=await encodeProject();
   // selecting a parked layer brings it back exactly
   select(list[1]);await LayerParking.ensure([list[1]]);const back1=hash(list[1])===before[1]&&!LayerParking.isParked(list[1]);
   // history: paint on list[1], park it again, undo restores it (the step's layer comes back first)
   invertActiveLayer();await wait(50);const painted=hash(list[1]);
   const sparse=list[1]._sparse;await NativeShadow.flush(true);select(list[3]);parkUntil(()=>LayerParking.isParked(list[1]));const reparked=LayerParking.isParked(list[1]);
   await undo();const undone=hash(list[1])===before[1];await redoF();const redone=hash(list[1])===painted;
   // a gated command (merge down onto a parked layer) waits for it
   select(list[3]);await NativeShadow.flush(true);parkUntil(()=>LayerParking.isParked(list[2]));const p2=LayerParking.isParked(list[2]);
   await mergeDown();await wait(200);const merged=layers.length===3&&!LayerParking.isParked(layers[2]);
   LayerParking.setLimitGiB(0);await LayerParking.ensureAll();projectDirty=false;await loadProjectFile(new File([blob],'t.bung'));await NativeShadow.whenIdle();
   const reopened=layers.map(hash);
   return {viewDiff,parked,resident0,resident1,lod:{tiles:lod.lodTiles,requests:lod.lodRequests},back1,reparked,undone,redone,p2,merged,reopened,before,stats:LayerParking.stats(),errs:NativeShadow.stats().errors}});
  console.log(JSON.stringify({...r,stats:{...r.stats,trips:r.stats.trips.slice(0,8)}}));
  assert.deepEqual(errors,[]);assert.deepEqual(r.errs,[]);assert.deepEqual(r.stats.errors,[]);
  assert.deepEqual(r.parked,[true,true,true,false],'inactive layers parked, the active one kept');assert.ok(r.resident1<r.resident0/2,'browser layer memory freed: '+r.resident0+' -> '+r.resident1);
  assert.ok(r.lod.tiles>0,'parked tiles drawn from the core at the display level');assert.ok(r.viewDiff<2,'the display looks the same with parked layers: mean diff '+r.viewDiff);
  assert.ok(r.back1,'selecting a parked layer restores its exact pixels');
  assert.ok(r.reparked&&r.undone&&r.redone,'undo/redo of a step on a parked layer brings it back first and is exact');
  assert.ok(r.p2&&r.merged,'merge down onto a parked layer waits for it');
  assert.deepEqual(r.reopened,r.before,'saved with parked layers: the reopened file has the same pixels');
  assert.equal(r.stats.tripwires,0,'no direct reads of parked tiles: '+JSON.stringify(r.stats.trips));
  await context.close();proc.stdin.end()}
  console.log('PASS: v301 layer parking: inactive layers kept only in the core over the limit, drawn from core LOD tiles, restored exactly on select/undo/merge, saved by the core')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exit(1)});
