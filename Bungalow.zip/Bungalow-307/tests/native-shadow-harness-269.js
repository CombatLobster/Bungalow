/* v268: shared harness for native shadow tests. Runs an existing UI test (tests/<name>.cjs) unchanged except that
 * the page opens with ?nativeShadow and gets window.__bungalowNativeInvoke wired to bungalow-core-server (stdio
 * stand-in for the Tauri command). Before each page closes, all surfaces are verified and NativeShadow.stats()
 * is passed to check(stats, source, page). Not a test file itself (runall only runs *.cjs). */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),{spawn}=require('node:child_process');
const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
function runShadowed(name,check,done){
 if(!fs.existsSync(bin)){console.log('SKIP: native shadow '+name+' (bungalow-core-server not built; run tests/native-core-269.cjs)');return}
 const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',served=0;
 proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(JSON.parse(line))}});
 const key='__bungalowShadowHooks_'+name.replace(/\W/g,'_'),hooks=global[key]={invoke:req=>new Promise(r=>{pending.push(r);served++;proc.stdin.write(JSON.stringify(req)+'\n')}),check,end:()=>proc.stdin.end()};
 const file=path.join(__dirname,name+'.cjs');let src=fs.readFileSync(file,'utf8');const sub=(re,to)=>{assert.ok(re.test(src),name+': scenario hook '+re);src=src.replace(re,to)};
 sub(/await p\.goto\((.*?)\);await p\.waitForFunction/,"await p.exposeFunction('__bungalowNativeInvoke',global["+JSON.stringify(key)+"].invoke);await p.goto(($1)+(process.env.BUNGALOW_SHADOW_MODE?'?nativeShadow='+process.env.BUNGALOW_SHADOW_MODE:'?nativeShadow=1'));await p.waitForFunction");
 sub(/await context\.close\(\)/,"await global["+JSON.stringify(key)+"].check(await p.evaluate(async()=>{await NativeShadow.verifyRasters('end');await NativeShadow.whenIdle();return NativeShadow.stats()}),source,p);await context.close()");
 sub(/finally\{await browser\.close\(\);server\.close\(\)\}/,"finally{await browser.close();server.close();global["+JSON.stringify(key)+"].end()}");
 const m=new Module(file,module);m.filename=file;m.paths=Module._nodeModulePaths(__dirname);m._compile(src,file);
 process.on('exit',c=>{if(c===0&&!process.exitCode)done(served)});
}
// Common assertions: shadow on, no transport errors, no divergences.
function assertClean(s,label){assert.equal(s.enabled,true,label+': shadow mode enabled');assert.deepEqual(s.errors,[],label+': transport errors');assert.deepEqual(s.divergences,[],label+': JS/native divergences')}
module.exports={runShadowed,assertClean};
