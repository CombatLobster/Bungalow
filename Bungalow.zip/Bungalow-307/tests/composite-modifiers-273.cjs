/* v273 (stage 7): modifier-layer compositor scenario: colour overlays, transforms (integer, fractional, scale,
 * rotation), point adjustments (brightness/contrast, curves, HSV, alpha, saturation curves) and filter layers;
 * targeted at a layer or group, stack-scoped (untargeted), maskDirect, isolated groups, modifier opacity and blend,
 * chains of several modifiers, plus one unsupported kind (mirror: the native side must report it and skip).
 * Standalone it checks the app compositor responds to each setting; under tests/native-composite-shadow-273.cjs the
 * Rust compositor must match it at every supported step (NativeShadow.verifyComposite). */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
const result=await p.evaluate(async()=>{
 const check=(v,m)=>{if(!v)throw Error(m)};closeLanding();projectDirty=false;await createDocumentFromOptions({width:96,height:64,dpi:72,white:false});
 const W=DW,H=DH,ramp=f=>{const im=new ImageData(W,H);for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=(y*W+x)*4,c=f(x/(W-1),y/(H-1));im.data.set(c.map(v=>Math.max(0,Math.min(255,Math.round(v)))),i)}return im};
 const fill=(L,f)=>RasterResources.putPixels(L.rasterId,ramp(f),0,0);
 const add=(name,f)=>{const L=newLayer(name,null,{w:W,h:H});insertLayer(L,layers.length);fill(L,f);thumb(L);return L};
 // A modifier layer: kind + config key, optional target (null = stack-scoped)
 const addMod=(name,kind,key,cfg,target=null)=>{const M=add(name,()=>[0,0,0,0]);M.mask=true;M.maskKind=kind;if(key)M[key]=cfg;M.maskTarget=target;thumb(M);return M};
 const adjust=(params)=>({type:'adjust',params:{...ADJUST_DEFAULTS,...params}});
 const base=AL;fill(base,(u,v)=>[255*u,180*v,90+120*(1-u),255]);thumb(base);
 const mid=add('Mid',(u,v)=>[40+200*v,255*(1-u),255*u*v,u>.8?0:255]);
 const top=add('Top',(u,v)=>[255*(1-v),120+100*u,255*v,(u-.5)**2+(v-.5)**2<.12?230:0]);
 const shadow=typeof NativeShadow!=='undefined'&&NativeShadow.enabled(),steps=[],hashes=new Set();
 const step=async label=>{renderLayers();const c=flat(true),d=c.getContext('2d').getImageData(0,0,W,H).data;let h=0;for(let i=0;i<d.length;i++)h=(h*31+d[i])|0;hashes.add(h);steps.push(label);if(shadow)await NativeShadow.verifyComposite(label)};
 await step('no modifiers');
 // colour overlay
 const col=addMod('Colour','colour','maskColour',{colour:'#20c040',amount:.7},top);await step('colour targeted at top');
 col.op=.5;await step('colour at half opacity');col.op=1;
 col.blend='multiply';await step('colour multiply');col.blend='hue';await step('colour hue blend');col.blend='linear-dodge';await step('colour custom blend name');col.blend='normal';
 col.maskTarget=null;await step('colour stack-scoped (all below)');
 col.maskDirect=true;await step('colour direct (nearest below)');col.maskDirect=false;
 col.vis=false;
 // transforms
 const xf=addMod('Transform','transform','maskTransform',{xf:[1,0,0,1,7,-3]},mid);await step('transform integer translate');
 xf.maskTransform={xf:[1,0,0,1,6.5,2.25]};await step('transform fractional translate');
 xf.maskTransform={xf:[.5,0,0,.75,10,4]};await step('transform scale');
 const a=Math.PI/7;xf.maskTransform={xf:[Math.cos(a),Math.sin(a),-Math.sin(a),Math.cos(a),20,-6]};await step('transform rotate');
 xf.op=.6;await step('transform at opacity');xf.op=1;
 col.vis=true;col.maskTarget=mid;await step('transform then colour chain');
 xf.vis=false;col.vis=false;
 // adjustments (filter modifiers targeted at a layer)
 const adj=addMod('Adjust','filter','maskFilter',adjust({type:'brightness',brightness:25,contrast:-30}),base);await step('brightness/contrast');
 adj.maskFilter=adjust({type:'brightness',brightness:-10,contrast:60});await step('contrast up');
 adj.maskFilter=adjust({type:'curves',curvePoints:{rgb:[[0,0],[.3,.45],[1,1]],r:[[0,.1],[1,.9]],g:[[0,0],[1,1]],b:[[0,0],[.5,.3],[1,1]]}});await step('curves');
 adj.maskFilter=adjust({type:'hsv',hue:75,sat:-40,val:15});await step('hsv');
 adj.maskFilter=adjust({type:'alpha',alphaColour:'#ff8040',alphaThreshold:30,alphaValue:20});await step('alpha from colour');
 adj.maskFilter=adjust({type:'saturationCurves',saturationPoints:[[0,.5],[.5,.9],[1,.3]],saturationChannels:{r:[[0,.5],[1,.7]],g:[[0,.5],[1,.5]],b:[[0,.4],[1,.5]]}});await step('saturation curves');
 adj.maskFilter=adjust({type:'hsv',hue:-120,sat:30,val:0});adj.op=.4;adj.blend='screen';await step('hsv at opacity + screen');adj.op=1;adj.blend='normal';
 adj.maskTarget=null;adj.maskDirect=true;await step('adjust direct');
 adj.maskDirect=false;await step('filter layer (wraps below)');
 adj.op=.5;await step('filter layer at opacity');adj.op=1;
 adj.vis=false;
 // groups
 setStackSelection([mid,top],{active:top,anchor:mid});createLayerGroup();renderLayers();const G=top.group;check(G&&mid.group===G,'group made');await step('group');
 col.vis=true;col.maskTarget=G;col.maskColour={colour:'#ff2050',amount:.5};await step('colour targeted at group');
 xf.vis=true;xf.maskTarget=G;xf.maskTransform={xf:[1,0,0,1,-9,5]};await step('group colour + transform');
 col.vis=false;xf.vis=false;
 const inner=addMod('Inner adjust','filter','maskFilter',adjust({type:'hsv',hue:40,sat:0,val:-20}),null);commitStackTree({parents:new Map([[inner,G]])});check(inner.group===G,'inner in group');await step('filter layer inside group');
 inner.vis=false;
 const outerCol=addMod('Outer colour','colour','maskColour',{colour:'#4040ff',amount:.6},null);await step('stack-scoped colour above group');
 G.isolate=true;await step('isolated group ignores outside modifier');G.isolate=false;
 // unsupported kind: native must report it and skip
 const mir=addMod('Mirror','mirror','maskMirror',MirrorKit.defaults(),base);await step('mirror (unsupported natively)');mir.vis=false;await step('mirror hidden');
 await undo();await step('undo');await redoF();await step('redo');
 return {steps:steps.length,distinct:hashes.size,shadow};
});
assert.ok(result.distinct>=result.steps-8,'modifiers change the composite: '+JSON.stringify(result));
assert.deepEqual(errors,[]);console.log('PASS: modifier composite: '+result.steps+' configurations, '+result.distinct+' distinct results ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
