/* v270: native compositor parity. v271: + paint masks (tests/composite-masks-271.cjs). v273: + modifier layers (tests/composite-modifiers-273.cjs). v274: + blur family (tests/composite-filters-274.cjs). Runs the compositor coverage scenario (every blend mode, opacity, inherit alpha,
 * pass-through / opacity / blend / isolated / nested / hidden groups, undo/redo) plus the pointer painting and
 * group UI scenarios with ?nativeShadow=full: at each step the Rust compositor renders the document from its own
 * store and surfaces and must match the app's CPU compositor. Skips when the native server is not built. */
process.env.BUNGALOW_SHADOW_MODE='full';
const assert=require('node:assert/strict'),{runShadowed,assertClean}=require('./native-shadow-harness-269.js');
const scenarios={'composite-coverage-270':30,'composite-masks-271':18,'composite-modifiers-273':30,'composite-filters-274':22,'paint-workflow-269':5,'group-ui-233':10};
for(const [name,min] of Object.entries(scenarios))runShadowed(name,async(s,source,p)=>{
 assertClean(s,name);assert.ok(s.composite.compared>=min,name+': composites compared '+JSON.stringify(s.composite));
 console.log('composite shadow '+name+' '+(source?'source':'standalone')+': '+s.composite.compared+' compared, '+s.composite.skipped+' skipped'+(s.composite.reasons.length?' ('+s.composite.reasons.map(r=>r.replace(/: node_\w+/,'')).join(', ')+')':'')+', max diff '+s.composite.maxDiff+', near misses '+s.composite.nearMisses);
 if(name==='composite-coverage-270'){ // negative control: change a layer's opacity in the native store only
  const d=await p.evaluate(async()=>{const L=layers.at(-1);await window.__bungalowNativeInvoke({method:'setProp',args:[L.engineId,'op',.2]});await NativeShadow.verifyComposite('probe');return NativeShadow.stats().divergences});
  assert.ok(d.some(x=>x.kind==='composite'),'composite probe detected: '+JSON.stringify(d));
  const img=await p.evaluate(async()=>{const im=await NativeShadow.nativeComposite();return im&&[im.width,im.height,im.data.some(v=>v>0)]});assert.deepEqual(img,[96,64,true],'nativeComposite returns the document image');
 }
},n=>console.log('PASS: native compositor matched the app compositor ('+name+', '+n+' requests)'));
