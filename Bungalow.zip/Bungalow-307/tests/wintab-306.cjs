/* v306: WinTab input (src/wintab-input-306.js) without a tablet: batches are fed to ingest() and fake pointer events read
 * their samples. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html');await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  const r=await p.evaluate(async()=>{const W=WinTabInput;W.cfg.on=true;const out={};const now=()=>performance.now();
   // 1. a batch of 4 samples: events at different times get different (interpolated) pressures
   await new Promise(r=>setTimeout(r,20));W.ingest([{p:.1,alt:90},{p:.2,alt:90},{p:.3,alt:90},{p:.4,alt:90}]);const t=now();
   out.interp=[t-25,t-12,t-5,t+5].map(ts=>+W.sample({pointerType:'mouse',timeStamp:ts,buttons:1}).pressure.toFixed(3));
   // 2. latest = last sample for events newer than it
   out.newest=W.sample({pointerType:'mouse',timeStamp:t+50,buttons:1}).pressure;
   // 3. zero-pressure contact before the batch with pressure arrives: last contact pressure is used
   W.ingest([{p:.6,alt:90}]);W.ingest([{p:0,alt:90}]);out.zeroContact=W.sample({pointerType:'mouse',timeStamp:now(),buttons:1}).pressure;out.zeroHover=W.sample({pointerType:'mouse',timeStamp:now(),buttons:0}).pressure;
   // 4. held still in contact: no packets for 500 ms, still fresh; at zero pressure it goes stale after 90 ms
   W.ingest([{p:.5,alt:90}]);await new Promise(r=>setTimeout(r,500));out.heldFresh=W.fresh();W.ingest([{p:0,alt:90}]);await new Promise(r=>setTimeout(r,150));out.hoverStale=!W.fresh();
   // 5. eraser end
   W.ingest([{p:.5,alt:90,erase:true}]);out.eraser=W.eraser({pointerType:'mouse',timeStamp:now(),buttons:1});out.app=tabletPressure({pointerType:'mouse',timeStamp:now(),buttons:1});
   // 6. touch never uses WinTab; out of proximity is not fresh
   out.touch=W.sample({pointerType:'touch',timeStamp:now()});W.ingest([{p:.5,prox:false}]);out.prox=W.fresh();
   return out});
  console.log(JSON.stringify(r));assert.deepEqual(errors,[]);
  for(let i=1;i<r.interp.length;i++)assert.ok(r.interp[i]>=r.interp[i-1],'pressure follows event time: '+r.interp);assert.ok(r.interp[0]<r.interp[3],'events in one batch get different pressures: '+r.interp);
  assert.equal(r.newest,.4);assert.equal(r.zeroContact,.6,'contact before the pressure batch keeps the last contact pressure');assert.equal(r.zeroHover,0);
  assert.ok(r.heldFresh,'holding the pen still in contact stays WinTab');assert.ok(r.hoverStale,'hover without packets goes stale');
  assert.ok(r.eraser,'eraser end reported');assert.ok(r.app>0,'app pressure from WinTab');assert.equal(r.touch,null);assert.equal(r.prox,false);
  console.log('PASS: v306 WinTab: per-event interpolated samples, held contact stays fresh, zero-pressure contact, eraser end');
 }finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exit(1)});
