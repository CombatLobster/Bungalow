const assert=require('node:assert/strict');const {dispatch}=require('../src/engine-references-238.js');
const ids=Object.freeze(['a','b']);assert.deepEqual(dispatch(ids,'a',{type:'remove'}),{ids:['b'],selected:'b',changed:true});assert.deepEqual(dispatch(ids,'a',{type:'duplicate',id:'c'}),{ids:['a','b','c'],selected:'c',changed:true});assert.equal(dispatch(ids,'b',{type:'reorder',front:true}).changed,false);assert.deepEqual(dispatch(ids,'b',{type:'reorder',front:false}).ids,['b','a']);
for(const cmd of [null,{}, {type:'reorder',front:1},{type:'duplicate',id:'a'}])assert.throws(()=>dispatch([],null,cmd?.type==='duplicate'?{type:'duplicate',id:''}:cmd));
assert.throws(()=>dispatch(['a','a'],'a',{type:'remove'}));console.log('PASS reference command validation and immutable ordering');
