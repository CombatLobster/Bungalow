const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
console.log(await p.evaluate(async()=>{
 const check=(v,m)=>{if(!v)throw Error(m)};closeLanding();projectDirty=false;await createDocumentFromOptions({width:640,height:480,dpi:72,white:false});
 const first=AL,second=newLayer('Second',null,{w:DW,h:DH});insertLayer(second,layers.length);AL=first;selectedStack=new Set([first,second]);renderLayers();
 const stores=[first._sparse,second._sparse],unpacked=sparseLayerMetrics.unpacked;
 first.op=.8;second.op=.4;const start=hp;
 for(let i=0;i<20;i++)changeLayerControl('op',i/100,true);
 changeLayerControl('op',.25,true);commitLayerControlHistory();
 check(hp===start+1,'One history entry per drag');check(first.op===.25&&second.op===.25,'Multi-selection updates');
 await undo();check(first.op===.8&&second.op===.4,'Distinct values restored');await redoF();check(first.op===.25&&second.op===.25,'Redo');
 const same=hp;changeLayerControl('op',.25,true);commitLayerControlHistory();check(hp===same,'No-op has no history');
 changeLayerControl('op',.5,false);AL=second;selectedStack=new Set([second]);changeLayerControl('op',.6,false);commitLayerControlHistory();
 await undo();check(second.op===.25&&first.op===.5,'Selection switch commits previous gesture');await undo();check(first.op===.25,'First gesture undo');
 AL=first;selectedStack=new Set([first]);$('lbl').value='multiply';$('lbl').dispatchEvent(new Event('change'));check(first.blend==='multiply','Real blend UI');await undo();check(first.blend==='normal','Blend undo');await redoF();check(first.blend==='multiply','Blend redo');
 $('lop').value=37;$('lop').dispatchEvent(new Event('input'));$('lop').dispatchEvent(new Event('change'));check(first.op===.37,'Real opacity UI');await undo();check(first.op===.25,'Opacity UI undo');
 first.locked=true;check(!changeLayerControl('blend','screen',false),'Locked blend rejected');check(changeLayerControl('op',.7,false),'Locked raster opacity behaviour retained');commitLayerControlHistory();first.locked=false;
 check(first._sparse===stores[0]&&second._sparse===stores[1]&&sparseLayerMetrics.unpacked===unpacked,'No pixel conversion');
 selectedStack=new Set([first,second]);createLayerGroup();const G=soloSelectedGroup();check(G,'Group created');
 changeLayerControl('op',.3,false);commitLayerControlHistory();check(G.op===.3,'Group opacity');await undo();check(G.op===1,'Group opacity undo');
 const old=[first.op,second.op];changeLayerControl('op',.2,true);commitLayerControlHistory();check(G.op===.2&&first.op===.2&&second.op===.2,'Group with contents');await undo();check(G.op===1&&first.op===old[0]&&second.op===old[1],'Group contents undo');
 changeLayerControl('op',.6,false);changeLayerControl('blend','screen',false);commitLayerControlHistory();await undo();check(G.blend==='normal'&&G.op===.6,'Property switch commits opacity');await undo();check(G.op===1,'Previous property undo');
 return {history:true,selectionSwitch:true,ui:true,sparse:true};
}));
assert.deepEqual(errors,[]);console.log('PASS: engine adapter real controls, multi-selection, gesture history, locking and sparse storage ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
