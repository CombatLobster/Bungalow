const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
await p.evaluate(async()=>{
 const check=(v,m)=>{if(!v)throw Error(m)};
 BackgroundTicker.add('linked-files',3600000,()=>{});
 closeLanding();projectDirty=false;await createDocumentFromOptions({width:64,height:64,dpi:72,white:false});
 const originalDecode=decodeFileLayerSource,originalDraw=drawFileLayer;
 let reads=0,decodes=0,draws=0,readHook=null,decodeHook=null;
 const file={name:'linked.png',lastModified:2,size:100},handle={getFile:async()=>{reads++;if(readHook)await readHook();return file}};
 const img=document.createElement('canvas');img.width=img.height=8;
 const I={type:'file',id:'test-linked',handle,name:file.name,mtime:1,size:90,img};AL.instance=I;
 const second=newLayer('second');second.instance={...I,id:'second'};insertLayer(second,layers.length);
 decodeFileLayerSource=async()=>{decodes++;if(decodeHook)await decodeHook();return img};drawFileLayer=()=>{draws++};
 const idle=()=>{fileLayerQuietUntil=0;viewNavigationUntil=0};
 try{
 idle();const states=['panning','zoomDrag','rotateDrag','annotationDrag','artboardDrag','referenceDrag','vectorDrag','assistDrag','mirrorDrag','szDrag','sampling','layerSelecting'];
 for(const name of states){const before=eval(name);eval(name+'=true');check(fileLayerReloadBlocked(),name+' blocks checks');await pollFileLayers({force:true});eval(name+'=before');}
 check(reads===0,'Busy gestures do no file IO');
 wrap.dispatchEvent(new WheelEvent('wheel',{deltaY:0,bubbles:true}));await pollFileLayers({force:true});check(reads===0,'Wheel starts quiet period');
 await new Promise(r=>setTimeout(r,300));check(!fileLayerReloadBlocked(),'Resumes after quiet period');
 await pollFileLayers({force:true});check(reads===1&&decodes===0,'Metadata shared, changed file settles before decode');
 await pollFileLayers({force:true});check(reads===2&&decodes===1&&draws===2,'Resumed poll refreshes both layers with shared decode');
 await pollFileLayers({force:true});check(reads===3&&decodes===1,'Unchanged files are not decoded');
 idle();const before=reads;readHook=async()=>{panning=true};await pollFileLayers({force:true});panning=false;readHook=null;check(reads===before+1,'Interaction after await stops subsequent file reads');
 file.lastModified=3;idle();await pollFileLayers({force:true});const committed=I.mtime;decodeHook=async()=>{panning=true};await pollFileLayers({force:true});check(I.mtime===committed,'Decode completing during interaction cannot commit');panning=false;decodeHook=null;await pollFileLayers({force:true});check(I.mtime===3,'Deferred changed file commits after interaction');
 idle();wrap.dispatchEvent(new PointerEvent('pointermove',{buttons:0,bubbles:true}));check(!fileLayerReloadBlocked(),'Hover does not starve updates');
 wrap.dispatchEvent(new PointerEvent('pointerup',{bubbles:true}));check(fileLayerReloadBlocked(),'Gesture release retains quiet period');
 }finally{decodeFileLayerSource=originalDecode;drawFileLayer=originalDraw;panning=false;idle()}
});
assert.deepEqual(errors,[]);console.log('PASS: linked-file idle gate, metadata sharing, resumed refresh and async interaction races ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
