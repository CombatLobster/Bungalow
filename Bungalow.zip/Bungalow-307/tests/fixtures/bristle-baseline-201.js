function createBristleRenderer(width,height,previewScale=1){
 const W=width,H=height,cv=document.createElement('canvas');cv.width=W;cv.height=H;
 const ctx=cv.getContext('2d',{alpha:true});ctx.lineCap='butt';ctx.lineJoin='round';   // butt caps: consecutive pen events do not double up their soft edges into beads
 const TAU=Math.PI*2,D2R=Math.PI/180,gauss=bristleGauss,paper=bristlePaper;
 let Q=readBristleParams(previewScale),scale=previewScale,layer=null;
 let B=[],C=[],wear=0,lx=0,ly=0,lp=0,ax=1,ay=0,pax=1,pay=0,dbx=1,dby=0,curA=0,ltx=0,lty=0,lux=0,luy=0,lastE=null,pspd=0,lt=0,spdS=0,spdI=0;
 const LV={size:40,splay:.6,opacity:.85,chaos:.25,spl:0,wm:0},bb={x0:W,y0:H,x1:0,y1:0},fx=[],fy=[],fp=[],fax=[],fay=[],ftx=[],fty=[];
 const grow=(x,y,r)=>{bb.x0=Math.min(bb.x0,x-r);bb.y0=Math.min(bb.y0,y-r);bb.x1=Math.max(bb.x1,x+r);bb.y1=Math.max(bb.y1,y+r)};
 // ---- colour mirror: a coarse, lazily loaded copy of the layer under the stroke, for pickup / smudge / smear ----
 const CELL=3,MW=Math.ceil(W/CELL),MH=Math.ceil(H/CELL),BLK=32,BX=Math.ceil(MW/BLK);let mir=null,mirLoaded=null,scrA=null,scrB=null;
 function mirInit(){
  if(!(Q.pickup>0||Q.smudge>0||Q.smear>0)||!layer){mir=null;return}
  if(!mir){mir=new Float32Array(MW*MH*4);mirLoaded=new Uint8Array(BX*Math.ceil(MH/BLK))}else{mir.fill(0);mirLoaded.fill(0)}
 }
 function mirLoad(bi,bj){
  const px=bi*BLK*CELL,py=bj*BLK*CELL,bw=Math.min(BLK*CELL,W-px),bh=Math.min(BLK*CELL,H-py);if(bw<=0||bh<=0)return;
  scrA=scrA||document.createElement('canvas');scrB=scrB||document.createElement('canvas');scrA.width=bw;scrA.height=bh;
  const g=scrA.getContext('2d');g.clearRect(0,0,bw,bh);g.save();g.translate(-px,-py);try{drawLayerRegion(g,layer,{x:px,y:py,w:bw,h:bh})}catch(_){}g.restore();
  const cw=Math.ceil(bw/CELL),ch=Math.ceil(bh/CELL);scrB.width=cw;scrB.height=ch;const sg=scrB.getContext('2d',{willReadFrequently:true});sg.clearRect(0,0,cw,ch);sg.drawImage(scrA,0,0,bw,bh,0,0,cw,ch);
  const d=sg.getImageData(0,0,cw,ch).data;
  for(let j=0;j<ch;j++)for(let i=0;i<cw;i++){const o=((bj*BLK+j)*MW+bi*BLK+i)*4,s=(j*cw+i)*4;mir[o]=d[s];mir[o+1]=d[s+1];mir[o+2]=d[s+2];mir[o+3]=d[s+3]/255}
 }
 function mirIdx(x,y){
  if(!mir)return -1;const i=x/CELL|0,j=y/CELL|0;if(x<0||y<0||i>=MW||j>=MH)return -1;
  const bi=i/BLK|0,bj=j/BLK|0,k=bj*BX+bi;if(!mirLoaded[k]){mirLoaded[k]=1;mirLoad(bi,bj)}return (j*MW+i)*4;
 }
 function mirDeposit(x,y,rgb,a){const o=mirIdx(x,y);if(o<0)return;mir[o]+=(rgb[0]-mir[o])*a;mir[o+1]+=(rgb[1]-mir[o+1])*a;mir[o+2]+=(rgb[2]-mir[o+2])*a;mir[o+3]+=(1-mir[o+3])*a}
 function mirSplat(x,y,rgb,a,rw){mirDeposit(x,y,rgb,a);if(rw>CELL){const r=rw*.6;a*=.8;mirDeposit(x+r,y,rgb,a);mirDeposit(x-r,y,rgb,a);mirDeposit(x,y+r,rgb,a);mirDeposit(x,y-r,rgb,a)}}
 function mixFrom(k,rand){for(const b of B){const o=mirIdx(b.x,b.y);if(o<0)continue;const al=mir[o+3];if(al<.02)continue;const m=(rand?k*(.5+.5*Math.random()):k)*al;b.rgb[0]+=(mir[o]-b.rgb[0])*m;b.rgb[1]+=(mir[o+1]-b.rgb[1])*m;b.rgb[2]+=(mir[o+2]-b.rgb[2])*m;setCss(b)}}
 // ---- bristles ----
 const hexRgb=h=>{const n=parseInt(h.slice(1),16);return[n>>16&255,n>>8&255,n&255]};
 const setCss=b=>{const c=t=>Math.max(0,Math.min(255,t|0));b.css='rgb('+c(b.rgb[0])+','+c(b.rgb[1])+','+c(b.rgb[2])+')'};
 function mkPoly(){const n=5,p=[];for(let i=0;i<n;i++)p.push([(i+Math.random()*.6-.3)/n*TAU,.55+Math.random()*.6]);return p}
 function baseColours(){const [r,g,bl]=hexRgb(Q.col);for(const b of B){const v=1+gauss()*Q.cjit*.35,j=Q.cjit*40;b.rgb=[r*v+gauss()*j,g*v+gauss()*j,bl*v+gauss()*j];setCss(b)}}
 function genBristles(){
  wear=0;const n=Q.count|0,c=Q.clump,nc=Math.max(3,Math.round(n+(4-n)*c)),sd=.25*c;C=[];
  for(let i=0;i<nc;i++){const r=Math.sqrt(Math.random())*(1-.3*c),a=Math.random()*TAU;C.push({x:Math.cos(a)*r,y:Math.sin(a)*r,sep:Math.random()*2-1,jx:0,jy:0,pjx:0,pjy:0})}
  B=[];
  for(let i=0;i<n;i++){const k=C[i%nc];let ox=k.x+gauss()*sd,oy=k.y+gauss()*sd;const d=Math.hypot(ox,oy);if(d>1){ox/=d;oy/=d}
   const r=Math.hypot(ox,oy),ink0=Q.load*(.6+.8*Math.random());
   B.push({ox,oy,k,thr:Q.tip*(r*.8+Math.random()*.15)*.92,te:0,c:0,acc:0,ph:0,pv:false,rdx:1,rdy:0,rot:Math.random()*2-1,kind:Math.random()<.5?0:1,poly:mkPoly(),w:.5+Math.random(),ink0,ink:ink0,dox:0,doy:0,vx:0,vy:0,x:0,y:0,jx:0,jy:0,pjx:0,pjy:0,pp:1,rgb:[0,0,0],css:'#000'})}
  baseColours();
 }
 function refill(){if(!B.length)genBristles();Q=readBristleParams(scale);for(const b of B)b.ink=b.ink0=Q.load*(.6+.8*Math.random());baseColours()}
 // ---- pen input ----
 const pressureOf=e=>penMouse(e)?.6:Math.max(.01,e.pressure||0);
 const NOTILT={nx:0,ny:0,amt:0,deg:0,az:0};
 function tiltOf(e){if(!e||!penLike(e))return NOTILT;const tx=penAxis(e,'tiltX')||0,ty=penAxis(e,'tiltY')||0,m=Math.hypot(tx,ty);if(m<1)return NOTILT;const az=Math.atan2(Math.tan(ty*D2R),Math.tan(tx*D2R));return{nx:Math.cos(az),ny:Math.sin(az),amt:Math.min(1,m/60),deg:m,az}}
 function updateLive(sN){
  const cl=(v,a,b)=>Math.max(a,Math.min(b,v));
  LV.size=cl(Q.size*(1+Q.spdSize*sN),3,600);LV.opacity=cl(Q.density*(1+Q.spdOpacity*sN),.02,1);LV.chaos=cl(Q.chaos+Q.spdChaos*sN*.6,0,1.2);LV.spl=Q.split*sN;LV.wm=wear*Q.memory;
  LV.splay=cl(Q.splay+Q.spdSplay*sN*.8+LV.wm*.9,0,2.2);
 }
 function orient(e,dx,dy,dist){
  const m=Q.rot;
  if(m==='dir'){if(dist>0)curA=followStrokeAngle(curA,Math.atan2(dy,dx),dist,Q.size)}
  else if(m==='tilt'||m==='twist'){const input=e&&penLike(e)?penInputDocumentAngle({pointerType:'pen',twist:penAxis(e,'twist'),tiltX:penAxis(e,'tiltX'),tiltY:penAxis(e,'tiltY')}):undefined;curA=input??0}
  else curA=0;
  const a=curA+Q.angle*D2R;ax=Math.cos(a);ay=Math.sin(a);
 }
 function target(b,cx,cy,p,vx,vy,tx,ty,t){
  const R=LV.size*.5,Rs=R*(.35+.65*p),Ru=Rs*Q.aspect,Rv=Rs*(1+LV.splay*p*p),m1=Math.min(1,LV.spl*.6+LV.wm*.5),
   bx=b.ox+(b.k.x-b.ox)*m1+b.dox*LV.wm*.8,by=b.oy+(b.k.y-b.oy)*m1+b.doy*LV.wm*.8,u=bx*Ru,v=by*Rv+b.k.sep*LV.spl*Rv*.6;
  let wx=vx*u-vy*v,wy=vy*u+vx*v,te=b.thr;const ta=Math.hypot(tx,ty);
  if(ta>1e-3&&Q.tiltShape>0){const nx=tx/ta,ny=ty/ta,k=ta*Q.tiltShape,al=wx*nx+wy*ny,s=1.6*k;wx+=nx*al*s-nx*R*k*.8;wy+=ny*al*s-ny*R*k*.8;te=b.thr*(1-.5*k)+.25*k*Math.max(-1,Math.min(1,al/(Rs+1e-3)))}
  b.te=te;
  const jx=(b.k.pjx+(b.k.jx-b.k.pjx)*t+b.pjx+(b.jx-b.pjx)*t)*R,jy=(b.k.pjy+(b.k.jy-b.k.pjy)*t+b.pjy+(b.jy-b.pjy)*t)*R;
  return[cx+wx+jx,cy+wy+jy];
 }
 // ---- element shapes ----
 function stampShape(b,x,y,vx,vy,ux,uy,r,spd){
  const l=Math.hypot(vx,vy);let dx=ux,dy=uy;if(l>.05){dx=vx/l;dy=vy/l}
  const el=1+Q.stretch*4*spd,sq=1/Math.sqrt(el),a=Math.atan2(dy,dx)+b.rot*Math.PI*Q.spin,ca=Math.cos(a),sa=Math.sin(a),sv=Q.shape,kind=sv==='blob'?0:sv==='shard'||sv==='chalk'?1:sv==='sponge'?2:b.kind;
  if(kind===2){const n=1+(Math.random()*3|0);for(let i=0;i<n;i++){const o=r*(.4+Math.random()*1.4),oa=Math.random()*TAU,px=x+Math.cos(oa)*o,py=y+Math.sin(oa)*o;if(paper(px,py)<.3+Q.grain*.25)continue;const dr=Math.max(.6,r*(.18+Math.random()*.3));ctx.moveTo(px+dr,py);ctx.arc(px,py,dr,0,TAU)}}
  else if(sv==='chalk'){
   const dry=Q.infink?0:1-Math.max(0,b.ink/b.ink0),cr=Math.min(1,Math.max(dry,(1-b.pp)*.9)*Q.crumble*1.6),n=1+Math.round(cr*4),rr=r*(1-.55*cr)/Math.sqrt(n),q=b.poly;
   for(let f=0;f<n;f++){if(f&&Math.random()<cr*.45)continue;const o=f?r*cr*(.3+Math.random()*1.3):0,oa=Math.random()*TAU,cx0=x+Math.cos(oa)*o,cy0=y+Math.sin(oa)*o,ra=a+(Math.random()-.5)*cr*3,cs=Math.cos(ra),sn=Math.sin(ra);
    for(let i=0;i<q.length;i++){const px=Math.cos(q[i][0])*q[i][1]*rr*el*1.3,py=Math.sin(q[i][0])*q[i][1]*rr*sq*1.3,wx=cx0+px*cs-py*sn,wy=cy0+px*sn+py*cs;i?ctx.lineTo(wx,wy):ctx.moveTo(wx,wy)}ctx.closePath()}}
  else if(kind===0){const rx=r*el,ry=r*sq;ctx.moveTo(x+rx*ca,y+rx*sa);ctx.ellipse(x,y,rx,ry,a,0,TAU)}
  else{const q=b.poly;for(let i=0;i<q.length;i++){const px=Math.cos(q[i][0])*q[i][1]*r*el*1.3,py=Math.sin(q[i][0])*q[i][1]*r*sq*1.3,wx=x+px*ca-py*sa,wy=y+px*sa+py*ca;i?ctx.lineTo(wx,wy):ctx.moveTo(wx,wy)}ctx.closePath()}
 }
 function ribbonStep(b,ox,oy,ux,uy,r,sLen){
  let dx=b.x-ox,dy=b.y-oy;const l=Math.hypot(dx,dy);if(l>.05){dx/=l;dy/=l}else{dx=ux;dy=uy}
  b.rdx=b.pv?b.rdx*.7+dx*.3:dx;b.rdy=b.pv?b.rdy*.7+dy*.3:dy;
  const rl=Math.hypot(b.rdx,b.rdy)||1,nx=-b.rdy/rl,ny=b.rdx/rl,pen=lastE&&typeof lastE.twist==='number'?(Q.rev?-1:1)*lastE.twist*D2R:0;
  b.ph+=sLen*Q.spin*.12;
  const f=Math.abs(Math.cos(pen+b.ph+b.rot*3)),hw=r*1.4*(.12+.88*f),lxp=b.x+nx*hw,lyp=b.y+ny*hw,rxp=b.x-nx*hw,ryp=b.y-ny*hw;
  if(b.pv){ctx.moveTo(b.plx,b.ply);ctx.lineTo(lxp,lyp);ctx.lineTo(rxp,ryp);ctx.lineTo(b.prx,b.pry);ctx.closePath()}
  b.plx=lxp;b.ply=lyp;b.prx=rxp;b.pry=ryp;b.pv=true;
 }
 function fling(dist,dx,dy,pux,puy,ps0,wScale){
  if(!pux&&!puy)return;const turn=Math.max(0,1-(dx*pux+dy*puy)),decel=Math.max(0,(ps0-dist)/(ps0+2)),I=Math.min(1,turn*1.6+decel*1.2)*Math.min(1,ps0/4);if(I<.25)return;
  const n=Math.round(I*Q.fling*6);
  for(let i=0;i<n;i++){
   const b=B[Math.random()*B.length|0];if(!b||b.c<.3)continue;
   let vx=pux+(Math.random()-.5)*.9,vy=puy+(Math.random()-.5)*.9;const vl=Math.hypot(vx,vy)||1;vx/=vl;vy/=vl;
   const Ld=Q.size*(.25+Math.random()*Q.fling*2.4)*(.4+.6*Math.min(1,ps0/8)),tx=b.x+vx*Ld,ty=b.y+vy*Ld,r=Math.max(.8,wScale*b.w*.22*(.4+Math.random()*.9)),el=1+Math.min(2.5,Ld/Q.size*1.4),a=Math.atan2(vy,vx);
   ctx.beginPath();ctx.moveTo(tx+r*el*Math.cos(a),ty+r*el*Math.sin(a));ctx.ellipse(tx,ty,r*el,r/Math.sqrt(el),a,0,TAU);
   if(Math.random()<.5){const o=r*(1.5+Math.random()*2.5),sa=Math.random()*TAU,sr=Math.max(.6,r*.35),sx=tx+Math.cos(sa)*o,sy=ty+Math.sin(sa)*o;ctx.moveTo(sx+sr,sy);ctx.arc(sx,sy,sr,0,TAU)}
   ctx.fillStyle=b.css;ctx.globalAlpha=Q.density*.9;ctx.fill();mirSplat(tx,ty,b.rgb,.5,r);grow(tx,ty,r*el*3+4);
  }
  ctx.globalAlpha=1;
 }
 // ---- the wet finish: bleed, edge pooling and granulation, run over the stroke once the pen lifts ----
 const WS=.5;let wetC=null,wctx=null,wb=null,ditherPat=null;
 const HAS_FILTER='filter' in ctx;
 function wetEnsure(){if(wetC)return;wetC=document.createElement('canvas');wetC.width=Math.ceil(W*WS);wetC.height=Math.ceil(H*WS);wctx=wetC.getContext('2d');wctx.lineCap=wctx.lineJoin='round';wctx.strokeStyle='#000'}
 function wetAdd(x0,y0,x1,y1,p){
  if(!(Q.wet>0))return;wetEnsure();const fw=(LV.size*(.35+.65*p)*1.1+Q.bleed*14)*WS,a=Math.min(1,.25+.6*Q.wet);
  wctx.beginPath();wctx.moveTo(x0*WS,y0*WS);wctx.lineTo(x1*WS,y1*WS);wctx.globalAlpha=a*.5;wctx.lineWidth=fw;wctx.stroke();wctx.lineWidth=fw*.6;wctx.stroke();wctx.globalAlpha=1;
  const m=fw/WS*.5+6+Q.bleed*14;wb=wb?{x0:Math.min(wb.x0,x0,x1)-m,y0:Math.min(wb.y0,y0,y1)-m,x1:Math.max(wb.x1,x0,x1)+m,y1:Math.max(wb.y1,y0,y1)+m}:{x0:Math.min(x0,x1)-m,y0:Math.min(y0,y1)-m,x1:Math.max(x0,x1)+m,y1:Math.max(y0,y1)+m};
 }
 function noiseRegion(sw,sh,mx,my,octaves){
  const c=document.createElement('canvas');c.width=sw;c.height=sh;const g=c.getContext('2d'),im=g.createImageData(sw,sh),d=im.data;
  for(let y=0;y<sh;y++)for(let x=0;x<sw;x++){let a=0;for(const [div,wt] of octaves)a=1-(1-a)*(1-wt*bristleNoise((mx+x)/div,(my+y)/div));d[(y*sw+x)*4+3]=a*255}
  g.putImageData(im,0,0);return c;
 }
 function wetPass(){
  const box=wb;wb=null;if(!(wetC&&box&&Q.wet>0))return;
  const x0=Math.max(0,Math.floor(box.x0/2)*2),y0=Math.max(0,Math.floor(box.y0/2)*2),x1=Math.min(W,Math.ceil(box.x1/2)*2),y1=Math.min(H,Math.ceil(box.y1/2)*2),w=x1-x0,h=y1-y0;
  const clearMask=()=>wctx.clearRect(x0*WS,y0*WS,w*WS,h*WS);if(w<4||h<4||w*h>16e6){clearMask();return}
  const sw=Math.round(w*WS),sh=Math.round(h*WS),mx=x0*WS,my=y0*WS,mk=()=>{const c=document.createElement('canvas');c.width=sw;c.height=sh;return [c,c.getContext('2d')]};
  const [wcM,wM]=mk(),[wcN,wN]=mk(),[wcA,wA]=mk(),[wcB,wB]=mk(),[wcC,wC]=mk(),[wcE,wE]=mk(),[wcF,wF]=mk(),[wcG,wG]=mk(),[wcS,wS]=mk();
  wA.imageSmoothingQuality='high';
  const gA=noiseRegion(sw,sh,mx,my,[[24,.55],[7,.5],[2,.5]]),gB=noiseRegion(sw,sh,mx,my,[[40,.5],[12,.5],[3,.45]]);
  if(!ditherPat){const t=document.createElement('canvas');t.width=t.height=256;const g=t.getContext('2d'),im=g.createImageData(256,256),d=im.data;for(let i=0;i<d.length;i+=4)d[i+3]=Math.random()*255;g.putImageData(im,0,0);ditherPat=ctx.createPattern(t,'repeat')}
  const blurTo=(dst,src,r)=>{if(HAS_FILTER){dst.filter='blur('+r.toFixed(2)+'px)';dst.drawImage(src,0,0,sw,sh,0,0,sw,sh);dst.filter='none';return}const f=Math.max(1,Math.round(r)),w2=Math.max(1,Math.ceil(sw/f)),h2=Math.max(1,Math.ceil(sh/f));wS.clearRect(0,0,w2,h2);wS.drawImage(src,0,0,sw,sh,0,0,w2,h2);dst.drawImage(wcS,0,0,w2,h2,0,0,sw,sh)};
  const maskTo=g=>{g.globalCompositeOperation='destination-in';g.drawImage(wcN,0,0,sw,sh,0,0,sw,sh);g.globalCompositeOperation='source-over'};
  const holes=(g,nc,amt)=>{if(amt<.01)return;g.save();g.globalCompositeOperation='destination-out';g.globalAlpha=Math.min(1,amt);g.drawImage(nc,0,0);g.restore()};
  const ditherOut=(g,amt)=>{const ox=Math.random()*256|0,oy=Math.random()*256|0;g.save();g.globalCompositeOperation='destination-out';g.globalAlpha=amt;g.translate(-ox,-oy);g.fillStyle=ditherPat;g.fillRect(ox,oy,sw,sh);g.restore()};
  const dt=.06,steps=Math.min(40,Math.max(4,Math.round(Q.wetTime*7*Math.min(1,3e6/(w*h))))),rb=(1.5+Q.bleed*6)*WS,rm=(3+Q.bleed*8)*WS,gr=Q.wgrain;   // the prototype's ticker, run to completion: the mask is dry after about 0.4 x wet time
  wM.drawImage(wetC,mx,my,sw,sh,0,0,sw,sh);
  for(let step=0;step<steps;step++){
   const k=Math.min(.6,1-Math.exp(-dt*Q.wet*4));
   wN.clearRect(0,0,sw,sh);blurTo(wN,wcM,rm);
   wA.clearRect(0,0,sw,sh);wA.drawImage(cv,x0,y0,w,h,0,0,sw,sh);
   wB.clearRect(0,0,sw,sh);blurTo(wB,wcA,rb);maskTo(wB);holes(wB,gA,gr*.7);ditherOut(wB,.35);
   wC.clearRect(0,0,sw,sh);blurTo(wC,wcA,rb*2.6);maskTo(wC);holes(wC,gB,gr);ditherOut(wC,.35);
   ctx.save();ctx.globalAlpha=k*.8;ctx.drawImage(wcB,0,0,sw,sh,x0,y0,w,h);ctx.globalAlpha=k*.55;ctx.drawImage(wcC,0,0,sw,sh,x0,y0,w,h);ctx.globalCompositeOperation='multiply';
   if(Q.pool>0){
    wE.clearRect(0,0,sw,sh);blurTo(wE,wcM,rm*.35);wE.globalCompositeOperation='destination-out';wE.drawImage(wcN,0,0,sw,sh,0,0,sw,sh);wE.globalCompositeOperation='source-over';
    holes(wE,gB,.3+gr*.65);ditherOut(wE,.3);
    wF.clearRect(0,0,sw,sh);wF.drawImage(wcA,0,0,sw,sh,0,0,sw,sh);wF.globalCompositeOperation='destination-in';wF.drawImage(wcE,0,0,sw,sh,0,0,sw,sh);wF.globalCompositeOperation='source-over';
    ctx.globalAlpha=Math.min(1,Q.pool*dt*1.6);ctx.drawImage(wcF,0,0,sw,sh,x0,y0,w,h);
   }
   if(Q.gran>0){
    wG.clearRect(0,0,sw,sh);wG.drawImage(wcN,0,0,sw,sh,0,0,sw,sh);wG.globalCompositeOperation='destination-in';wG.drawImage(gA,0,0);wG.drawImage(gA,0,0);wG.globalCompositeOperation='source-over';
    wF.clearRect(0,0,sw,sh);wF.drawImage(wcA,0,0,sw,sh,0,0,sw,sh);wF.globalCompositeOperation='destination-in';wF.drawImage(wcG,0,0,sw,sh,0,0,sw,sh);wF.globalCompositeOperation='source-over';
    ctx.globalAlpha=Math.min(1,Q.gran*dt*.6);ctx.drawImage(wcF,0,0,sw,sh,x0,y0,w,h);
   }
   ctx.restore();
   wM.globalCompositeOperation='destination-out';wM.globalAlpha=Math.min(1,dt/Q.wetTime*2.5);wM.fillRect(0,0,sw,sh);wM.globalCompositeOperation='source-over';wM.globalAlpha=1;
  }
  clearMask();grow(x0,y0,0);grow(x1,y1,0);
 }
 // ---- one pen event ----
 function beginStroke(x,y,p,e){
  const fresh=Q.reload||!B.length;if(fresh)genBristles();else baseColours();
  orient(e,0,0,0);pax=ax;pay=ay;lt=(e&&e.timeStamp)||performance.now();spdS=spdI=0;updateLive(0);
  const T=tiltOf(e);ltx=T.nx*T.amt;lty=T.ny*T.amt;
  for(const k of C){k.jx=k.jy=k.pjx=k.pjy=0}
  for(const b of B){b.c=0;b.acc=0;b.pv=false;b.vx=b.vy=0;b.jx=b.jy=b.pjx=b.pjy=0;const t=target(b,x,y,p,ax,ay,ltx,lty,1);b.x=t[0];b.y=t[1]}
  mirInit();if(mir&&Q.pickup>0)mixFrom(Q.pickup,true);
  lx=x;ly=y;lp=p;lux=luy=0;pspd=0;lastE=e;
 }
 function seg(x,y,p,e){
  const dx=x-lx,dy=y-ly,dist=Math.hypot(dx,dy);if(dist<.3)return;
  const pux=lux,puy=luy,ps0=pspd;lux=dx/dist;luy=dy/dist;lastE=e;pspd=ps0*.6+dist*.4;
  const tNow=(e&&e.timeStamp)||performance.now(),dtm=tNow-lt;lt=tNow;if(dtm>.3)spdI=dist/Math.min(dtm,80);
  const flick=spdI>1.2*Q.spdRange&&spdS<.6*spdI;spdS=spdS*.7+spdI*.3;const sN=Math.min(1,spdS/Q.spdRange);
  if(p>.12)wear=Math.min(1,wear+dist/(Q.size*30+300));
  if(flick&&wear>.02){wear=0;for(const b of B){b.dox=b.doy=0}}
  updateLive(sN);pax=ax;pay=ay;orient(e,dx,dy,dist);
  const T=tiltOf(e),ntx=T.nx*T.amt,nty=T.ny*T.amt,ch=Q.shape==='sponge'?Math.max(LV.chaos,.7):LV.chaos,kd=Math.min(1,dist/20);
  for(const k of C){k.pjx=k.jx;k.pjy=k.jy;k.jx=k.jx*(1-.15*kd)+gauss()*ch*.12*kd;k.jy=k.jy*(1-.15*kd)+gauss()*ch*.12*kd}
  for(const b of B){b.pjx=b.jx;b.pjy=b.jy;b.jx=b.jx*(1-.3*kd)+gauss()*ch*.05*kd;b.jy=b.jy*(1-.3*kd)+gauss()*ch*.05*kd;b.dox+=gauss()*.03*kd;b.doy+=gauss()*.03*kd;const dl=Math.hypot(b.dox,b.doy);if(dl>.8){b.dox*=.8/dl;b.doy*=.8/dl}}
  if(mir&&Q.smudge>0)mixFrom(1-Math.pow(1-Q.smudge*.6,dist/Math.max(4,Q.size*.15)),false);
  const steps=Math.max(1,Math.ceil(dist/1.5)),sLen=dist/steps;
  for(let s=0;s<steps;s++){const t=(s+1)/steps;fx[s]=lx+dx*t;fy[s]=ly+dy*t;fp[s]=lp+(p-lp)*t;let vx=pax+(ax-pax)*t,vy=pay+(ay-pay)*t;const l=Math.hypot(vx,vy)||1;fax[s]=vx/l;fay[s]=vy/l;ftx[s]=ltx+(ntx-ltx)*t;fty[s]=lty+(nty-lty)*t}
  const st=Q.shape==='sponge'?1:1-Math.pow(1-Q.stiff,1.5),mom=Q.shape==='sponge'?0:Q.inertia*.88,g=Q.grain,smr=Q.smear,inf=Q.infink,wScale=Q.thick*(Q.scalew?LV.size/40:1),sf=Q.soft,fi=.5+Q.fadeIn*Q.size*1.5,fo=.5+Q.fadeOut*Q.size*1.5,shp=Q.shape,stamp=shp!=='line'&&shp!=='droplets',spd=sN;
  const reach=LV.size*(.6+LV.splay*.6)+wScale*2+6;
  for(const b of B){
   const inkF0=inf?1:Math.max(0,b.ink/b.ink0),mA=Math.min(1,LV.opacity*(inkF0>0?.3+.7*Math.sqrt(inkF0):.5*smr)*Math.min(1,b.w*wScale/CELL));
   ctx.beginPath();let drawing=false,psum=0,cnt=0,csum=0;
   for(let s=0;s<steps;s++){
    const t=(s+1)/steps,pp=fp[s],tg=target(b,fx[s],fy[s],pp,fax[s],fay[s],ftx[s],fty[s],t),ox=b.x,oy=b.y;
    if(mom>0){b.vx=b.vx*mom+(tg[0]-b.x)*st;b.vy=b.vy*mom+(tg[1]-b.y)*st;b.x+=b.vx;b.y+=b.vy}else{b.x+=(tg[0]-b.x)*st;b.y+=(tg[1]-b.y)*st}
    let dep=false;
    if(pp>b.te&&(inf||b.ink>0||smr>0)){const dry=inf?0:(b.ink>0?1-b.ink/b.ink0:1),score=(1-g)+g*(paper(b.x,b.y)*.9+pp*.25);dep=score>dry*(1-smr*.7)}
    b.c=dep?Math.min(1,b.c+sLen/fi):Math.max(0,b.c-sLen/fo);
    if(b.c>.01){
     if(shp==='ribbon')ribbonStep(b,ox,oy,fax[s],fay[s],wScale*b.w*(.5+.8*pp)*(.35+.65*b.c)*.5,sLen);
     else if(stamp){b.acc+=sLen;const r=wScale*b.w*(.5+.8*pp)*(.35+.65*b.c)*.5,sp=Math.max(1.5,r*2*Q.spacing);if(b.acc>=sp){b.acc%=sp;b.pp=pp;stampShape(b,b.x,b.y,b.x-ox,b.y-oy,fax[s],fay[s],r,spd)}}
     else{if(!drawing){ctx.moveTo(ox,oy);drawing=true}ctx.lineTo(b.x,b.y)}
     if(dep&&!inf&&b.ink>0)b.ink-=sLen*(.5+pp);
     if(mir)mirSplat(b.x,b.y,b.rgb,mA*b.c,b.w*wScale*.5);psum+=pp;csum+=b.c;cnt++;grow(b.x,b.y,reach);
    }else{drawing=false;b.pv=false}
   }
   if(cnt){
    const pm=psum/cnt,ca=csum/cnt,inkF=inf?1:Math.max(0,b.ink/b.ink0),lw=wScale*b.w*(.5+.8*pm)*(.35+.65*ca),al=LV.opacity*(inkF>0?.3+.7*Math.sqrt(inkF):.5*smr)*ca;
    if(stamp){ctx.fillStyle=ctx.strokeStyle=b.css;if(sf>.02){ctx.lineWidth=lw*sf*.6;ctx.globalAlpha=al*.3;ctx.stroke()}ctx.globalAlpha=al;ctx.fill();continue}
    ctx.strokeStyle=b.css;
    if(sf>.02){ctx.lineWidth=lw*(1+sf*1.4);ctx.globalAlpha=al*.22;ctx.stroke();ctx.lineWidth=lw*(1+sf*.5);ctx.globalAlpha=al*.32;ctx.stroke();ctx.lineWidth=lw*(1-sf*.3);ctx.globalAlpha=al*.6;ctx.stroke()}
    else{ctx.lineWidth=lw;ctx.globalAlpha=al;ctx.stroke()}
   }
  }
  if(shp==='droplets')fling(dist,dx/dist,dy/dist,pux,puy,ps0,wScale);
  ctx.globalAlpha=1;wetAdd(lx,ly,x,y,p);
  lx=x;ly=y;lp=p;ltx=ntx;lty=nty;
 }
 function tail(){
  if(Q.fadeOut<.05||(!lux&&!luy))return;
  const Ld=Q.fadeOut*Q.size*.8,n=Math.max(2,Math.ceil(Ld/4)),x0=lx,y0=ly,p0=lp,ux=lux,uy=luy,e=lastE;
  for(let i=1;i<=n;i++){const k=i/n;seg(x0+ux*Ld*k,y0+uy*Ld*k,p0*(1-k*k),e)}
 }
 return {cv,
  setScale(v){scale=v;Q=readBristleParams(v)},
  begin(e){Q=readBristleParams(scale);layer=typeof AL!=='undefined'?AL:null;ctx.clearRect(0,0,W,H);ctx.globalAlpha=1;bb.x0=W;bb.y0=H;bb.x1=0;bb.y1=0;wb=null;wetC&&wctx.clearRect(0,0,wetC.width,wetC.height);beginStroke(e.clientX,e.clientY,pressureOf(e),e);grow(e.clientX,e.clientY,Q.size)},
  move(e){for(const c of e.samples||[e])seg(c.clientX,c.clientY,pressureOf(c),c)},
  finish(){tail();wetPass();ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over'},
  bounds(){const m=Q.wet>0?(6+Q.bleed*14)*3:0;return {x0:Math.max(0,bb.x0-m),y0:Math.max(0,bb.y0-m),x1:Math.min(W,bb.x1+m),y1:Math.min(H,bb.y1+m)}},
  clear(){ctx.clearRect(0,0,W,H);bb.x0=W;bb.y0=H;bb.x1=0;bb.y1=0;wetC&&wctx.clearRect(0,0,wetC.width,wetC.height)},
  reloadInk(){refill()},
  dispose(){mir=null;wetC=null;wctx=null;scrA=scrB=null}};
}
