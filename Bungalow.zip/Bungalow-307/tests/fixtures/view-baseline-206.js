function view(){window.Frame3D?.schedule();
 window.BungalowVectors?.scheduleGizmo();
 const co=Math.cos(rotation),si=Math.sin(rotation),flip=flipped?-1:1,a=z*co*flip,b=z*si*flip,c=-z*si,d=z*co;
 const e=tx+DW*z/2-a*DW/2-c*DH/2,f=ty+DH*z/2-b*DW/2-d*DH/2,det=a*d-b*c;
 viewMatrix={a,b,c,d,e,f};inverseView={a:d/det,b:-b/det,c:-c/det,d:a/det,e:(c*f-d*e)/det,f:(b*e-a*f)/det};
 stage.style.transform=`matrix(${a},${b},${c},${d},${e},${f})`;updateArtboardWorkspace();syncSaturationPreviewBounds();ringSize();if(cursorBoundsReady)updateCursorBounds({clientX:cx,clientY:cy});
 if(referenceGizmoReady&&referenceEditing){const ref=selectedReference();if(ref)updateReferenceGizmo(ref)}
 pixelSettle();updateDocumentOutline();drawLayoutOverlay();syncSelectionView();drawMirrorGizmo();if(textSession)syncTextEditor();if(transformSession)drawTransformHandles();
 updateContinuationPreview();$('rotationReset').textContent='Reset rotation · '+Math.round(rotation*180/Math.PI)+'°';
 if(maskDisplay?.kind==='tiled-gpu'&&!maskDisplay.cv.hidden)scheduleTiledViewportPresentation();
}
