function drawBristleStrokePreview(){
 const canvas=$('strokePreview'),g=canvas.getContext('2d');
 try{
  if(!bristlePreviewRenderer||bristlePreviewRenderer.cv.width!==canvas.width||bristlePreviewRenderer.cv.height!==canvas.height){bristlePreviewRenderer?.dispose();bristlePreviewRenderer=createBristleRenderer(canvas.width,canvas.height)}
  bristlePreviewRenderer.setScale(Math.min(1,64/Math.max(1,P.size)));
  const events=Array.from({length:181},(_,i)=>{const t=i/180;return {clientX:44+552*t,clientY:90+32*Math.sin(t*Math.PI*2),pressure:.12+.88*Math.sin(Math.PI*t),pointerType:'pen',timeStamp:i*4}});
  bristlePreviewRenderer.begin(events[0]);bristlePreviewRenderer.move({...events.at(-1),samples:events.slice(1)});bristlePreviewRenderer.finish();
  g.clearRect(0,0,canvas.width,canvas.height);g.fillStyle='#8b8b8b';g.fillRect(0,0,canvas.width,canvas.height);
  g.save();g.globalAlpha=OP;g.globalCompositeOperation=erase?'destination-out':$('brushBlend').value==='normal'?'source-over':$('brushBlend').value;g.drawImage(bristlePreviewRenderer.cv,0,0);g.restore();
 }catch(error){g.clearRect(0,0,canvas.width,canvas.height)}
}
