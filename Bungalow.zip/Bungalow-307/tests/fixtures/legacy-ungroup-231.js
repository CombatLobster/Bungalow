function legacyStackEdit235(change,bytes=0,reveal=true,selectionAfter=undefined){const before=stackState(),selectionBefore=selectionMask;change();const after=stackState(),apply=(state,mask)=>{restoreStack(state,reveal);if(selectionAfter!==undefined)installSelection(mask)};apply(after,selectionAfter);if(selectionAfter!==undefined)bytes+=rasterBytes([...new Set([selectionBefore,selectionAfter].filter(Boolean))]);doH({bytes,undo:()=>apply(before,selectionBefore),redo:()=>apply(after,selectionAfter)})}
// Legacy behavioural baseline, v231; loaded only by tests.
function legacyUngroup232(target){
 if(editBlocked())return;
 const targets=topStackNodes([...new Set(Array.isArray(target)?target:[target])].filter(G=>layerGroups.includes(G)));
 if(!targets.length)return;
 if(targets.some(groupLocked)){toast('Unlock the selected groups first');return}
 const children=new Map(targets.map(G=>[G,[...layers,...layerGroups].filter(node=>node.group===G)]));
 legacyStackEdit235(()=>{
  for(const G of targets)for(const node of children.get(G)){node.group=G.group||null;if(!G.vis)node.vis=false}
  layerGroups=layerGroups.filter(G=>!targets.includes(G));
  selectedStack=new Set([...selectedStack].flatMap(node=>children.get(node)||[node]));
  if(targets.includes(stackSelectionAnchor))stackSelectionAnchor=selectedStack.has(AL)?AL:[...selectedStack].at(-1)||null;
 });
 uiNotice(targets.length===1?'Group ungrouped':targets.length+' groups ungrouped');
}
