function drawAssistOverlay(){
 if(!wrap||typeof DW==='undefined'||!canvasCoordinates)return;
 const c=canvasCoordinates,vps=c.vanishing||[],hz=c.horizon,mode=assistMode(),finderOn=assistFinderOn(),wants=assisting||(assistantsVisible&&(vps.length>0||!!hz||c.grids.length>0||c.points.length>0||c.finder.length>0));
 if(!assistOverlay){
  if(!wants)return;
  const svg=document.createElementNS(ASSIST_NS,'svg');svg.setAttribute('aria-hidden','true');svg.style.cssText='position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:4;overflow:hidden';
  svg.replaceChildren(svgFragment([svgNode("defs",{},[svgNode("clipPath",{"id":"assistClip"},[svgNode("rect",{"x":"0","y":"0","width":"1","height":"1"},[])])]),svgNode("g",{"class":"assist-doc"},[svgNode("g",{"clip-path":"url(#assistClip)"},[svgNode("g",{"class":"assist-rays"},[]),svgNode("path",{"class":"assist-hz","fill":"none","stroke":"#ffd54f","stroke-width":"1.5","stroke-opacity":".95","vector-effect":"non-scaling-stroke"},[])]),svgNode("g",{"class":"assist-finder"},[]),svgNode("path",{"class":"assist-hl","fill":"none","stroke":"#fff","stroke-width":"2","stroke-opacity":".9","vector-effect":"non-scaling-stroke"},[])]),svgNode("g",{"class":"assist-screen"},[])]));
  assistOverlay=svg;svg._doc=svg.querySelector('.assist-doc');svg._rays=svg.querySelector('.assist-rays');svg._grids=document.createElementNS(ASSIST_NS,'g');svg._grids.setAttribute('class','assist-grids');svg._rays.parentNode.insertBefore(svg._grids,svg._rays);svg._hz=svg.querySelector('.assist-hz');svg._finder=svg.querySelector('.assist-finder');svg._hl=svg.querySelector('.assist-hl');svg._screen=svg.querySelector('.assist-screen');svg._clip=svg.querySelector('#assistClip rect');wrap.append(svg);
 }
 assistOverlay.style.display=wants?'':'none';if(!wants)return;
 setOverlayView(assistOverlay._doc);
 const clip=assistOverlay._clip;if(clip.getAttribute('width')!==String(DW)||clip.getAttribute('height')!==String(DH)){clip.setAttribute('width',DW);clip.setAttribute('height',DH)}
 const mk=(tag,attrs)=>{const el=document.createElementNS(ASSIST_NS,tag);for(const k in attrs)el.setAttribute(k,attrs[k]);return el};
 drawAssistantGrids(assistOverlay._grids,mk);
 const showRays=assistantsVisible,key=JSON.stringify([DW,DH,showRays,vps,hz]);
 if(assistOverlay._key!==key){
  assistOverlay._key=key;const rays=assistOverlay._rays;rays.replaceChildren();
  if(showRays)vps.forEach((v,i)=>{if(!assistantItemVisible('vp',v))return;const cx=v.x*DW,cy=v.y*DH,R=Math.hypot(Math.max(Math.abs(cx),Math.abs(cx-DW)),Math.max(Math.abs(cy),Math.abs(cy-DH)))+16,n=Math.max(2,Math.min(128,Math.round(v.lines)||16));let d='';for(let k=0;k<n;k++){const a=k*Math.PI*2/n;d+='M'+cx+' '+cy+'L'+(cx+Math.cos(a)*R)+' '+(cy+Math.sin(a)*R)}rays.append(mk('path',{d,fill:'none',stroke:assistantItemColour(v,ASSIST_COLOURS[i%ASSIST_COLOURS.length]),'stroke-opacity':assistantItemOpacity('vp',v)*.6,'stroke-width':'1','vector-effect':'non-scaling-stroke'}))});
 }
 // horizon line (clipped to the canvas)
 let hd='';if(hz&&assistantsVisible&&assistantItemVisible('horizon',hz)){const d=AssistMath.dir(hz),ax=hz.x*DW,ay=hz.y*DH,R=Math.hypot(Math.max(Math.abs(ax),Math.abs(ax-DW)),Math.max(Math.abs(ay),Math.abs(ay-DH)))+16;hd='M'+(ax-d.x*R)+' '+(ay-d.y*R)+'L'+(ax+d.x*R)+' '+(ay+d.y*R)}
 assistOverlay._hz.setAttribute('d',hd);assistOverlay._hz.setAttribute('stroke',assistantItemColour(hz,'#ffd54f'));assistOverlay._hz.setAttribute('stroke-opacity',hz?.opacity??1);
 // find-horizon lines (doc space, dashed extensions so the crossing is visible)
 const fin=assistOverlay._finder;fin.replaceChildren();
 if(assistantsVisible)for(const l of c.finder||[]){if(l.visible===false)continue;
  const ax=l.a.x*DW,ay=l.a.y*DH,bx=l.b.x*DW,by=l.b.y*DH,len=Math.hypot(bx-ax,by-ay)||1,R=(DW+DH)*6,ux=(bx-ax)/len,uy=(by-ay)/len;
  fin.append(mk('path',{d:'M'+(ax-ux*R)+' '+(ay-uy*R)+'L'+(ax+ux*R)+' '+(ay+uy*R),fill:'none',stroke:assistantItemColour(l,'#ff80ab'),'stroke-opacity':(l.opacity??1)*.45,'stroke-width':'1','stroke-dasharray':'6 5','vector-effect':'non-scaling-stroke'}));
  fin.append(mk('path',{d:'M'+ax+' '+ay+'L'+bx+' '+by,fill:'none',stroke:assistantItemColour(l,'#ff80ab'),'stroke-opacity':l.opacity??1,'stroke-width':'2.5','vector-effect':'non-scaling-stroke'}));
 }
 // hover highlight for guides
 let gd='';if(assisting&&assistHoverTarget?.kind==='guide'){const g=c.guides.find(x=>x.id===assistHoverTarget.id);if(g){const pos=g.position*(g.axis==='x'?DW:DH);gd=g.axis==='x'?'M'+pos+' 0L'+pos+' '+DH:'M0 '+pos+'L'+DW+' '+pos}}
 assistOverlay._hl.setAttribute('d',gd);
 // handles (screen space)
 const screen=assistOverlay._screen;screen.replaceChildren();
 drawCubeOverlay(screen,mk);if(assistantsVisible)for(const p of c.points){if(p.visible===false)continue;const q=docToOverlay({x:p.x*DW,y:p.y*DH});screen.append(mk('circle',{cx:q.x,cy:q.y,r:4,fill:assistantItemColour(p,'#4fc3f7'),opacity:p.opacity??1}))}
 if(!assisting||!assistantsVisible)return;
 const perspective=mode==='vanishing'&&assistType()==='perspective';
 vps.forEach((v,i)=>{
  if(!assistantItemVisible('vp',v))return;const q=docToOverlay({x:v.x*DW,y:v.y*DH}),colour=assistantItemColour(v,ASSIST_COLOURS[i%ASSIST_COLOURS.length]),hot=assistHoverTarget?.kind==='vp'&&assistHoverTarget.id===v.id;
  if(assistSnapId===v.id)screen.append(mk('circle',{cx:q.x,cy:q.y,r:14,fill:'none',stroke:'#fff','stroke-width':2}));
  if(perspective){
   if(v.id===assistVP)screen.append(mk('circle',{cx:q.x,cy:q.y,r:12,fill:'none',stroke:colour,'stroke-width':2}));
   screen.append(mk('circle',{cx:q.x,cy:q.y,r:hot?8:6,fill:colour,stroke:'#fff','stroke-width':2}));
   if(v.h)screen.append(mk('path',{d:'M'+(q.x-3)+' '+q.y+'h6',stroke:'#fff','stroke-width':2}));
  }else screen.append(mk('circle',{cx:q.x,cy:q.y,r:4,fill:colour,stroke:'#fff','stroke-width':1.5}));
 });
 if(mode==='horizon'&&hz&&assistantItemVisible('horizon',hz)&&!hz.locked){
  const g=assistHorizonGeom(),hot=assistHoverTarget?.kind==='horizon'?assistHoverTarget.id:'';
  screen.append(mk('path',{d:'M'+g.minus.x+' '+g.minus.y+'L'+g.plus.x+' '+g.plus.y,stroke:'#ffd54f','stroke-width':3,'stroke-opacity':.55,'stroke-linecap':'round'}));
  for(const [pt,name] of [[g.minus,'rotate-'],[g.plus,'rotate+']])screen.append(mk('circle',{cx:pt.x,cy:pt.y,r:hot===name?8:6,fill:'#fff',stroke:'#ffb300','stroke-width':2.5}));
  screen.append(mk('circle',{cx:g.q.x,cy:g.q.y,r:hot==='centre'?9:7,fill:'#ffd54f',stroke:'#fff','stroke-width':2}));
 }
 if(finderOn){
  for(const l of (c.finder||[]).filter(l=>l.visible!==false&&!l.locked))for(const pt of assistFinderScreen(l))screen.append(mk('circle',{cx:pt.x,cy:pt.y,r:6,fill:'#ff80ab',stroke:'#fff','stroke-width':2}));
  const P=finderPointPx(c);if(P){const q=docToOverlay(P);screen.append(mk('circle',{cx:q.x,cy:q.y,r:9,fill:'none',stroke:'#fff','stroke-width':2}),mk('path',{d:'M'+(q.x-14)+' '+q.y+'h28M'+q.x+' '+(q.y-14)+'v28',stroke:'#ff80ab','stroke-width':2}))}
 }
}
