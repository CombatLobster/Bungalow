/* v286: in core mode, clone layers are drawn by the core from their source layer's surface (raster.cloneFrom) under
 * the clone's transform, and redrawn when the source changes, instead of their pixels being uploaded. Translations,
 * fractional moves, flips and downscales match the app; rotations and upscales match apart from a few edge pixels. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+mode+'');await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:800,height:600,dpi:72,white:false});tool(false);setSize(30);Object.assign(TP,{kind:'round',hrd:.6,flow:.7,sp:.1})});
  const r=await p.evaluate(async()=>{
   const src=newLayer('Source',null,{w:DW,h:DH});insertLayer(src,layers.length);setStackSelection([src],{active:src,anchor:src});
   const paint=(c,x,y,w,h)=>{RasterResources.fillRegion(src.rasterId,{x,y,w,h},c);const g=document.createElement('canvas');g.width=120;g.height=120;const q=g.getContext('2d');q.fillStyle='rgba(30,120,220,.6)';q.beginPath();q.arc(60,60,50,0,7);q.fill();RasterResources.composeRegion(src.rasterId,{x:x+20,y:y+10,w:120,h:120},g,x+20,y+10,'source-over',1)};
   paint('#cc4422',100,80,160,110);doH({undo(){},redo(){}});
   const variants=[['identity',{}],['translate',{dx:37,dy:-12}],['fraction',{dx:10.5,dy:3.25}],['flip',{flipH:true}],['flipV move',{flipV:true,dx:20}],['scale',{xf:[.5,0,0,.5,0,0]}],['scale up',{xf:[1.5,0,0,1.25,-50,-20]}],['rotate',{xf:[Math.cos(.3),Math.sin(.3),-Math.sin(.3),Math.cos(.3),40,-60]}]];
   const clones=[];for(const [name,v] of variants){const C=newLayer(name,null,false);C.instance={type:'clone',src,flipH:false,flipV:false,dx:0,dy:0,xf:null,...v};insertLayer(C,layers.length);renderClone(C);clones.push([name,C])}
   renderLayers();doH({undo(){},redo(){}});await NativeShadow.whenIdle();
   paint('#22aa66',420,300,180,140);syncClones(src);doH({undo(){},redo(){}});await NativeShadow.whenIdle(); // the source changes: clones follow
   const out=[];for(const [name,L] of clones){const js=RasterResources.readRegion(L.rasterId),resp=await NativeShadow.request({method:'raster.read',args:[L.rasterId]});if(!resp.ok){out.push({name,error:resp.error});continue}
    const bin=atob(resp.result.data);let max=0,over=0,painted=0;for(let i=0;i<js.data.length;i+=4){const a=js.data[i+3],b=bin.charCodeAt(i+3);if(a||b)painted++;let d=0;for(let k=0;k<4;k++){const x=js.data[i+k]*(k<3?a/255:1),y=bin.charCodeAt(i+k)*(k<3?b/255:1);d=Math.max(d,Math.abs(x-y))}if(d>max)max=d;if(d>8)over++}
    out.push({name,max:Math.round(max),over,painted})}
   return {out,stats:NativeShadow.stats().raster,errors:NativeShadow.stats().errors}});
  for(const o of r.out)console.log(JSON.stringify(o));
  assert.deepEqual(errors,[]);assert.deepEqual(r.errors,[]);assert.ok(r.stats.cloneLayers>=r.out.length,'clones drawn in the core '+r.stats.cloneLayers);
  for(const o of r.out){assert.ok(!o.error,o.name+' '+o.error);assert.ok(o.painted>1000,o.name+' painted');
   if(o.name==='rotate'||o.name==='scale up')assert.ok(o.max<=16&&o.over<=o.painted*0.003,o.name+': edges approximate ('+o.max+', '+o.over+')');else assert.ok(o.max<=2,o.name+': matches the app (max diff '+o.max+')')}
  await context.close();proc.stdin.end()}
  console.log('PASS: v286 clone layers drawn in the core from their source surface follow source edits and match the app')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
