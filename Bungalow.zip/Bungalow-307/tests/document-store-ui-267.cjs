const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
console.log(await p.evaluate(async()=>{
 const check=(v,m)=>{if(!v)throw Error(m)},ok=m=>check(auditStackSelection()&&documentStoreDrift===0,'Projection drifted from store after '+m);
 closeLanding();projectDirty=false;await createDocumentFromOptions({width:640,height:480,dpi:72,white:false});
 const first=AL,second=newLayer('Second',null,{w:DW,h:DH});insertLayer(second,layers.length);const third=newLayer('Third',null,{w:DW,h:DH});insertLayer(third,layers.length);
 const st=()=>documentStore.get(),ids=ns=>ns.map(n=>n.engineId);
 setStackSelection([first],{active:first,anchor:first});renderLayers();ok('new doc select');
 check(st().active===first.engineId&&st().selected.length===1,'Store holds active/selection');
 // layer-list click, shift range, ctrl toggle through the real selection path
 selectStackNode(second,{});ok('click');check(AL===second&&st().active===second.engineId,'Click sets active');
 selectStackNode(first,{ctrlKey:true});ok('ctrl');check(selectedStack.size===2&&st().selected.length===2,'Ctrl toggles');
 selectStackNode(third,{shiftKey:true});ok('shift');check(st().selected.length>=2,'Shift range');
 // group, undo/redo restore selection through the store
 setStackSelection([first,second],{active:second,anchor:first});createLayerGroup();renderLayers();ok('group');
 const afterGroup=st().selected.join();await undo();ok('undo group');await redoF();ok('redo group');
 // delete active layer, history restore
 setStackSelection([third],{active:third,anchor:third});const before=hp;delLayer();ok('delete');check(AL!==third&&!layers.includes(third),'Delete moves active');
 await undo();ok('undo delete');check(layers.includes(third),'Undo restores layer');
 // artboards: switch boards, selection is per board
 const boardsBefore=artboards.length;
 // new document resets store
 projectDirty=false;await createDocumentFromOptions({width:320,height:200,dpi:72,white:false});renderLayers();ok('second new doc');
 check(st().selected.length===1&&st().active===AL.engineId&&layers.length===1,'New doc resets selection');
 // unknown / stale nodes are pruned on render and never leak ids
 const stale=newLayer('Stale',null,{w:DW,h:DH});setStackSelection([AL,stale],{active:AL});renderLayers();check(!selectedStack.has(stale),'Stale pruned');ok('prune');
 // ---- v249 tree authority ----
 const treeOk=m=>{ok(m);check(documentStore.verify().length===0,'Tree issues after '+m+': '+JSON.stringify(documentStore.verify()))};
 const tr=()=>documentStore.tree(),A=AL,B=newLayer('B',null,{w:DW,h:DH});insertLayer(B,layers.length);const C=newLayer('C',null,{w:DW,h:DH});insertLayer(C,layers.length);treeOk('insert');
 check(tr().layers.join()===layers.map(n=>n.engineId).join(),'Store order = projection');
 setStackSelection([B,C],{active:C,anchor:B});createLayerGroup();renderLayers();const G=layerGroups.at(-1);treeOk('group');check(B.group===G&&tr().parents[B.engineId]===G.engineId,'Parent owned by store');
 setStackSelection([A],{active:A,anchor:A});createLayerGroup();renderLayers();const G2=layerGroups.find(g=>g!==G);treeOk('second group');
 moveStackNode(G,G2,null,true);renderLayers();treeOk('nest group');check(tr().parents[G.engineId]===G2.engineId,'Nested parent');
 await undo();treeOk('undo nest');check(tr().parents[G.engineId]===null,'Undo restores parent');await redoF();treeOk('redo nest');
 setStackSelection([G],{active:C,anchor:G});ungroupSelectedLayers();renderLayers();treeOk('ungroup');check(B.group===G2,'Children lifted to parent');
 await undo();treeOk('undo ungroup');check(B.group===G,'Undo ungroup');
 const order=tr().layers.join();setStackSelection([C],{active:C,anchor:C});dupLayer();renderLayers();treeOk('duplicate');check(tr().layers.length===layers.length,'Dup order');await undo();treeOk('undo dup');check(tr().layers.join()===order,'Undo dup order');
 setStackSelection([C],{active:C,anchor:C});delLayer();renderLayers();treeOk('delete');check(!tr().layers.includes(C.engineId)&&C.group===G,'Detached keeps parent data');await undo();treeOk('undo delete');check(tr().parents[C.engineId]===G.engineId,'Restored parent');
 // direct legacy write to a live node is detected
 const drift0=documentStoreDrift;B.group=null;check(!auditStackTree(),'Audit detects direct parent write');documentStoreDrift=drift0;commitStackTree({parents:new Map([[B,G]])});check(auditStackTree(),'Explicit commit repairs');
 // artboards: per-board trees replace the store tree on switch
 const firstBoard=activeArtboardId,treeA=tr().layers.join();createArtboard({width:200,height:100,white:false,name:'Second'});renderLayers();treeOk('create board');
 const secondBoard=activeArtboardId;check(secondBoard!==firstBoard&&tr().layers.join()!==treeA,'Board switch replaced tree');
 activateArtboard(firstBoard);renderLayers();treeOk('switch back');check(tr().layers.join()===treeA,'Board tree restored');check(B.group===G,'Board parents restored');
 activateArtboard(secondBoard);renderLayers();treeOk('switch again');activateArtboard(firstBoard);renderLayers();
 // native save/open replaces the tree from the file
 const savedOrder=layers.map(n=>n.name).join(),savedParents=layers.map(n=>n.group?.name||'').join();const blob=await encodeProject();projectDirty=false;await loadProjectFile(new File([blob],'tree.bung'));renderLayers();treeOk('open');
 check(layers.map(n=>n.name).join()===savedOrder&&layers.map(n=>n.group?.name||'').join()===savedParents,'Open restores order and parents via store');
 // ---- v250 reference + artboard collections ----
 const colOk=m=>{treeOk(m);check(auditCollections(),'Collections drift after '+m);check(documentStore.verifyCollections().length===0,'Collection issues after '+m+': '+JSON.stringify(documentStore.verifyCollections()))};
 projectDirty=false;await createDocumentFromOptions({width:96,height:96,dpi:72,white:false});renderLayers();colOk('fresh doc');
 const P=AL;P.ctx.fillStyle='#0f0';P.ctx.fillRect(4,4,30,30);setStackSelection([P],{active:P,anchor:P});renderLayers();
 check(await convertLayersToReferences(),'convert to reference');renderReferences();colOk('convert');const refs=()=>documentStore.references();
 check(refs().ids.length===1&&refs().selected===referenceImages[0].id,'Store owns reference collection');
 duplicateReference();renderReferences();colOk('duplicate ref');check(refs().ids.length===2&&refs().selected===referenceImages[1].id,'Duplicate selected');
 const ord=refs().ids.join();referenceReorder(false);renderReferences();colOk('reorder ref');check(refs().ids.join()!==ord,'Reordered');await undo();colOk('undo reorder');check(refs().ids.join()===ord,'Undo reorder');
 $('referenceShow').click();colOk('hide refs');check(refs().shown===false&&referenceShown===false,'Shown flag owned');$('referenceShow').click();colOk('show refs');
 removeReference();renderReferences();colOk('remove ref');check(refs().ids.length===1,'Removed');await undo();colOk('undo remove');check(refs().ids.length===2,'Undo remove');
 const refBlob=await encodeProject();projectDirty=false;await loadProjectFile(new File([refBlob],'refs.bung'));renderReferences();colOk('reopen refs');check(refs().ids.length===2&&refs().selected===referenceImages.at(-1).id,'References reopened through store');
 clearFloatingReferences();colOk('clear refs');check(refs().ids.length===0&&refs().selected===null,'Cleared');
 // artboards
 projectDirty=false;await createDocumentFromOptions({width:120,height:80,dpi:72,white:false});renderArtboards();colOk('board doc');
 const b0=activeArtboardId;createArtboard({width:60,height:40,white:false,name:'Two'});const b1=activeArtboardId;createArtboard({width:60,height:40,white:false,name:'Three'});const b2=activeArtboardId;renderArtboards();colOk('create boards');
 const boards=()=>documentStore.boards();check(boards().active===b2&&boards().ids.length===artboards.length&&artboards.length>=3,'Store owns boards');
 selectArtboard(b0,{});renderArtboards();colOk('select board');check(boards().active===b0,'Board activation through store');
 selectArtboard(b2,{shiftKey:true});renderArtboards();colOk('range boards');check(boards().selected.length>=2,'Range selection');
 selectArtboard(b1,{});renderArtboards();const count=artboards.length;await deleteSelectedArtboards({prompt:false});renderArtboards();colOk('delete board');check(artboards.length===count-1&&!boards().ids.includes(b1),'Deleted board');
 await undo();renderArtboards();colOk('undo delete board');check(boards().ids.includes(b1),'Undo board delete');await redoF();renderArtboards();colOk('redo delete board');
 activateArtboard(b0);renderArtboards();colOk('activate b0');
 // ---- v251 document dimensions ----
 const docOk=m=>{colOk(m);check(auditDocumentSize(),'Document size drift after '+m)},dim=()=>documentStore.document();
 projectDirty=false;await createDocumentFromOptions({width:200,height:120,dpi:96,white:false});renderLayers();docOk('dims new doc');check(dim().width===200&&dim().height===120&&dim().dpi===96&&DW===200,'Store owns dimensions');
 $('canvasWidth').value=300;$('canvasHeight').value=150;$('canvasDPI').value=96;resizeCanvas();renderLayers();docOk('resize');check(dim().width===300&&dim().height===150,'Resize through store');
 await undo();renderLayers();docOk('undo resize');check(dim().width===200&&dim().height===120,'Undo resize');await redoF();renderLayers();docOk('redo resize');
 $('canvasWidth').value=DW;$('canvasHeight').value=DH;$('canvasDPI').value=150;resizeCanvas();renderLayers();docOk('dpi');check(dim().dpi===150,'DPI through store');await undo();renderLayers();docOk('undo dpi');check(dim().dpi===96,'Undo DPI');
 const b0d=activeArtboardId;createArtboard({width:64,height:48,dpi:300,white:false,name:'Dims'});renderLayers();docOk('board dims');check(dim().width===64&&dim().dpi===300,'Board switch dims');activateArtboard(b0d);renderLayers();docOk('back dims');check(dim().width===DW&&DW!==64,'Original board dims');
 // ---- v252 live node properties ----
 const propOk=m=>{docOk(m);check(documentPropRejects===0,'Property rejects after '+m+': '+JSON.stringify(documentPropRejectLog));check(auditLiveProps(),'Props audit after '+m)},pv=(n,k)=>documentStore.prop(n.engineId,k);
 projectDirty=false;await createDocumentFromOptions({width:128,height:96,dpi:72,white:true});renderLayers();propOk('props new doc');
 const X=AL,Y=newLayer('Y',null,{w:DW,h:DH});insertLayer(Y,layers.length);renderLayers();propOk('props insert');
 check(pv(X,'op')===X.op&&pv(Y,'name')==='Y','Store holds props');
 X.op=.4;check(pv(X,'op')===.4&&X.op===.4,'Assignment commits to store');Object.assign(Y,{vis:false,blend:'multiply'});check(pv(Y,'vis')===false&&pv(Y,'blend')==='multiply','Object.assign commits');Y.vis=true;Y.blend='normal';
 setStackSelection([X],{active:X,anchor:X});changeLayerControl('op',.7,false);commitLayerControlHistory();propOk('control');check(pv(X,'op')===.7,'Layer control via store');await undo();propOk('undo control');check(pv(X,'op')===.4,'Undo restores store prop');await redoF();check(pv(X,'op')===.7,'Redo');
 $('lbl').value='screen';$('lbl').dispatchEvent(new Event('change'));propOk('blend ui');check(pv(X,'blend')==='screen','Blend UI via store');await undo();check(pv(X,'blend')==='normal','Blend undo');
 X.locked=1;check(pv(X,'locked')===true,'Truthy normalised to boolean');X.locked=false;
 X.op=NaN;check(documentPropRejects===1&&pv(X,'op')===.7,'Invalid value rejected, store unchanged');documentPropRejects=0;documentPropRejectLog.length=0;
 // groups: collapsed/isolate through accessors and structural history
 setStackSelection([X,Y],{active:Y,anchor:X});createLayerGroup();renderLayers();const PG=layerGroups.at(-1);propOk('props group');check(pv(PG,'collapsed')===PG.collapsed&&typeof Object.getOwnPropertyDescriptor(PG,'collapsed').get==='function','Group props live');
 PG.isolate=true;check(pv(PG,'isolate')===true,'Isolate via store');PG.isolate=false;
 // leaving the tree turns props into plain resource data; rejoining restores them
 setStackSelection([Y],{active:Y,anchor:Y});Y.op=.33;delLayer();renderLayers();propOk('props delete');const d=Object.getOwnPropertyDescriptor(Y,'op');check(d&&'value' in d&&d.value===.33&&!(Y.engineId in documentStore.props()),'Detached node keeps plain data');
 await undo();renderLayers();propOk('props undo delete');check(pv(Y,'op')===.33&&typeof Object.getOwnPropertyDescriptor(Y,'op').get==='function','Rejoined node live again');
 // rename via real path, save/open round-trip
 X.name='Renamed';const pBlob=await encodeProject();projectDirty=false;await loadProjectFile(new File([pBlob],'props.bung'));renderLayers();propOk('props reopen');check(layers.some(L=>L.name==='Renamed'&&pv(L,'name')==='Renamed'),'Reopened props live in store');
 // board switch detaches the old board's nodes and attaches the new board's
 const pb0=activeArtboardId,pNode=layers.at(-1);createArtboard({width:50,height:50,white:false,name:'Props'});renderLayers();propOk('props board');check(!(pNode.engineId in documentStore.props())&&typeof Object.getOwnPropertyDescriptor(pNode,'op').get==='function'&&documentStore.parkedRecord(pb0,'props',pNode.engineId,'op')===pNode.op,'Inactive board nodes are parked in the store');
 pNode.op=.5;activateArtboard(pb0);renderLayers();propOk('props board back');check(pv(pNode,'op')===.5,'Inactive edits picked up on rejoin');
 // ---- v253 artboard + reference records ----
 const recOk=m=>{propOk(m);check(auditCollectionRecords(),'Records audit after '+m+': '+JSON.stringify(documentStore.verifyRecords())+JSON.stringify(documentStoreDriftLog.slice(-2)))},bv=(b,k)=>documentStore.record('boardProps',b.id,k),rv=(r,k)=>documentStore.record('referenceProps',r.id,k);
 projectDirty=false;await createDocumentFromOptions({width:100,height:80,dpi:72,white:false});renderArtboards();recOk('records doc');
 const RB=artboards.find(b=>b.id===activeArtboardId);renameArtboard('Main');renderArtboards();recOk('rename board');check(bv(RB,'name')==='Main'&&RB.name==='Main','Board rename via store');await undo();renderArtboards();check(bv(RB,'name')!=='Main','Board rename undo');await redoF();
 setArtboardCoordinate('x',240);renderArtboards();recOk('board x');check(bv(RB,'x')===240&&RB.x===240,'Board coordinate via store');await undo();renderArtboards();recOk('undo board x');check(bv(RB,'x')!==240,'Board coordinate undo');
 toggleArtboardLock(RB.id);renderArtboards();recOk('lock board');check(bv(RB,'locked')===true,'Board lock via store');await undo();renderArtboards();check(!bv(RB,'locked'),'Board lock undo');
 createArtboard({width:40,height:40,white:false,name:'Peer'});const PB=artboards.find(b=>b.id===activeArtboardId);commitBoards({selected:[RB.id,PB.id]});groupArtboards();renderArtboards();recOk('group boards');check(typeof bv(RB,'group')==='string'&&bv(RB,'group')===bv(PB,'group'),'Board group via store');
 ungroupArtboards();renderArtboards();recOk('ungroup boards');check(bv(RB,'group')===undefined&&RB.group===undefined,'Ungroup clears group');await undo();renderArtboards();recOk('undo ungroup');check(typeof bv(RB,'group')==='string','Undo ungroup');
 toggleArtboardVisibility(PB.id);renderArtboards();recOk('board visibility');check(bv(PB,'visible')===false,'Board visibility via store');await undo();renderArtboards();
 const bBlob=await encodeProject();projectDirty=false;await loadProjectFile(new File([bBlob],'boards.bung'));renderArtboards();recOk('reopen boards');check(artboards.some(b=>bv(b,'name')==='Main'),'Board records reopened');
 // references
 const QL=AL;QL.ctx.fillStyle='#00f';QL.ctx.fillRect(2,2,20,20);setStackSelection([QL],{active:QL,anchor:QL});renderLayers();check(await convertLayersToReferences(),'convert for records');renderReferences();recOk('ref records');
 const RR=referenceImages[0];check(rv(RR,'w')===RR.w&&rv(RR,'name')===RR.name,'Reference record in store');
 const refBefore=referenceState();RR.x+=15;RR.matrix=[1,.2,0,1];referenceCommit(refBefore);renderReferences();recOk('ref move');check(rv(RR,'x')===RR.x&&rv(RR,'matrix')[1]===.2&&Object.isFrozen(RR.matrix),'Reference geometry via store');
 await undo();renderReferences();recOk('undo ref move');const RR2=referenceImages[0];check(rv(RR2,'x')===RR2.x&&RR2.x===refBefore[0].x,'Reference geometry undo');
 duplicateReference();renderReferences();recOk('ref dup');check(referenceImages[1].matrix!==referenceImages[0].matrix||Object.isFrozen(referenceImages[0].matrix),'Duplicate matrix independent');
 const dRef=referenceImages[1];removeReference();renderReferences();recOk('ref remove');check(!(dRef.id in documentStore.records('referenceProps'))&&'value' in Object.getOwnPropertyDescriptor(dRef,'x'),'Removed reference is plain data');
 // ---- v254 guides/layout ----
 const coOk=m=>{recOk(m);check(auditCoordinates(),'Coordinates pending after '+m)},co=()=>documentStore.coordinates();
 projectDirty=false;await createDocumentFromOptions({width:200,height:100,dpi:72,white:false});coOk('coords new doc');check(co().guides.length===0,'Empty guides');
 const next=structuredClone(canvasCoordinates);next.guides.push({id:'g1',axis:'x',position:.25});check(updateCanvasCoordinates(next),'update accepted');coOk('add guide');check(co().guides.length===1&&Object.isFrozen(co().guides[0]),'Guide committed to store');
 check(canvasCoordinates!==co()&&!Object.isFrozen(canvasCoordinates),'Working copy is a mutable clone');
 await undo();coOk('undo guide');check(co().guides.length===0,'Undo guide');await redoF();coOk('redo guide');check(co().guides[0].position===.25,'Redo guide');
 const vis=co().layout.visible;toggleGuides();coOk('toggle guides');check(co().layout.visible===!vis,'Toggle commits');toggleGuides();
 // preview edits are pending until committed; assistRestore discards them
 const start=structuredClone(canvasCoordinates);canvasCoordinates.guides[0].position=.6;check(coordinatesPending(),'In-place preview is pending');assistRestore(start);coOk('assist restore');check(co().guides[0].position===.25&&canvasCoordinates.guides[0].position===.25,'Restore discards preview');
 canvasCoordinates.guides[0].position=.7;assistCommit(start);coOk('assist commit');check(co().guides[0].position===.7,'assistCommit commits preview');await undo();coOk('undo assist');check(co().guides[0].position===.25,'Undo assist commit');
 const cBlob=await encodeProject();projectDirty=false;await loadProjectFile(new File([cBlob],'coords.bung'));coOk('reopen coords');check(co().guides.length===1&&co().guides[0].id==='g1','Guides reopened through store');
 const cb0=activeArtboardId;createArtboard({width:50,height:50,white:false,name:'Coords'});coOk('coords board');check(co().guides.length===0,'New board has own guides');activateArtboard(cb0);coOk('coords back');check(co().guides.length===1,'Board guides restored');
 // ---- v255 parked (inactive) artboard documents ----
 const pkOk=m=>{coOk(m);check(auditParkedBoards(),'Parked audit after '+m+': '+JSON.stringify(documentStore.verifyParked().slice(0,3))+JSON.stringify(documentPropRejectLog.slice(0,3)))},pd=id=>documentStore.parked(id);
 projectDirty=false;await createDocumentFromOptions({width:90,height:60,dpi:72,white:true});renderArtboards();pkOk('park doc');
 const KA=activeArtboardId,ka=AL;ka.name='Alpha layer';createArtboard({width:40,height:30,dpi:150,white:false,name:'Beta'});const KB=activeArtboardId;renderArtboards();pkOk('park second');
 check(pd(KA)&&!pd(KB),'Inactive board parked, active not');check(pd(KA).document.width===90&&pd(KA).tree.layers.length===2,'Parked document captured');
 const SA=artboards.find(b=>b.id===KA).state;check(SA.width===90&&SA.layers.includes(ka)&&typeof Object.getOwnPropertyDescriptor(SA,'layers').get==='function','Inactive state reads from store');
 check(ArtboardWorkspace.state(KA).layers.length===2&&ArtboardWorkspace.dimensions(artboards.find(b=>b.id===KA)).width===90,'Workspace boundary reads parked data');
 // edits to an inactive board go to its parked document
 ka.op=.3;ka.vis=false;check(documentStore.parkedRecord(KA,'props',ka.engineId,'op')===.3,'Inactive prop write parked');
 const kg=SA.layers[0];check(kg.group===null,'Inactive parent via store');
 SA.referenceShown=false;check(pd(KA).references.shown===false,'Inactive state field write parked');SA.referenceShown=true;
 const pushed=newLayer('Pushed',null,{w:90,h:60});const SL=SA.layers;check(SL===SA.layers,'Inactive list is stable');SL.push(pushed);pkOk('push inactive');check(pd(KA).tree.layers.includes(pushed.engineId)&&documentStore.parkedRecord(KA,'props',pushed.engineId,'name')==='Pushed'&&SA.layers.includes(pushed),'In-place push parks new layer');
 SA.layers=SA.layers.filter(x=>x!==pushed);pkOk('assign inactive');check(!pd(KA).tree.layers.includes(pushed.engineId)&&'value' in Object.getOwnPropertyDescriptor(pushed,'op'),'Assigned list releases removed layer');
 const thumbsKey=artboardPreviewKey(ArtboardWorkspace.state(KA));check(Array.isArray(thumbsKey)&&thumbsKey.includes(.3),'Previews read parked props');
 // activation releases and loads the parked document
 activateArtboard(KA);renderArtboards();renderLayers();pkOk('activate parked');check(!pd(KA)&&pd(KB),'Swapped parked boards');check(AL===ka||layers.includes(ka),'Active layers loaded');check(documentStore.prop(ka.engineId,'op')===.3&&ka.vis===false,'Parked edits survive activation');ka.vis=true;
 // a third board, delete an inactive one (released), undo re-parks
 createArtboard({width:30,height:30,white:false,name:'Gamma'});const KC=activeArtboardId;renderArtboards();pkOk('third');check(pd(KA)&&pd(KB)&&!pd(KC),'Two parked');
 commitBoards({selected:[KB]});await deleteSelectedArtboards({prompt:false});renderArtboards();pkOk('delete inactive');check(!pd(KB)&&!artboards.some(b=>b.id===KB),'Deleted board unparked');
 await undo();renderArtboards();pkOk('undo delete inactive');check(pd(KB)&&artboards.some(b=>b.id===KB),'Undo re-parks board');
 // duplicate (cloned resources) and save/open with several boards
 activateArtboard(KA);renderArtboards();await duplicateSelectedArtboards();renderArtboards();pkOk('duplicate board');check(Object.keys(documentStore.state().parked).length===artboards.length-1,'All inactive boards parked');
 const mBlob=await encodeProject();projectDirty=false;await loadProjectFile(new File([mBlob],'multi.bung'));renderArtboards();renderLayers();pkOk('reopen multi');check(Object.keys(documentStore.state().parked).length===artboards.length-1&&artboards.length>=4,'Reopened boards parked');
 const snapAll=documentStore.snapshotDocument();check(Object.keys(snapAll.parked).length===artboards.length-1&&JSON.stringify(JSON.parse(JSON.stringify(snapAll)))===JSON.stringify(snapAll),'Whole multi-board document is plain JSON');
 // merge boards: parked nodes move into the active board
 const others=artboards.filter(b=>b.id!==activeArtboardId).slice(0,1).map(b=>b.id);commitBoards({selected:[activeArtboardId,...others]});const layersBeforeMerge=layers.length;mergeSelectedArtboards();renderArtboards();renderLayers();pkOk('merge boards');check(layersBeforeMerge>0&&!others.some(id=>pd(id))&&!artboards.some(b=>others.includes(b.id))&&layers.some(L=>L.name==='Merged'),'Merged boards removed and unparked');
 await undo();renderArtboards();renderLayers();pkOk('undo merge');check(others.every(id=>pd(id)),'Undo merge re-parks');
 // ---- v256 session (dirty/save state) ----
 const ss=()=>documentStore.session();projectDirty=false;check(ss().dirty===false&&projectDirty===false,'Dirty flag via store');
 const serial0=editSerial;const sv=newLayer('Session',null,{w:DW,h:DH});insertLayer(sv,layers.length);sv.op=.5;setStackSelection([sv],{active:sv,anchor:sv});changeLayerControl('op',.8,false);commitLayerControlHistory();
 check(ss().dirty===true&&ss().editSerial>serial0&&editSerial===ss().editSerial,'Edits mark dirty and bump serial in store');
 projectDirty=0;check(ss().dirty===false,'Loose dirty value normalised');projectFilename='session-test.bung';check(ss().filename==='session-test.bung','Filename via store');
 const sBlob=await encodeProject();projectDirty=false;await loadProjectFile(new File([sBlob],'session.bung'));check(ss().filename==='session.bung'&&ss().dirty===false&&ss().hasFile===projectHasFile,'Open sets session in store');
 check(documentPropRejects===0,'No session rejects '+JSON.stringify(documentPropRejectLog));
 // ---- v263 mask/modifier content in the store ----
 projectDirty=false;await createDocumentFromOptions({width:120,height:90,dpi:72,white:true});renderLayers();const cOk=m=>{check(auditLiveProps()&&documentPropRejects===0,'Content audit after '+m+': '+JSON.stringify(documentPropRejectLog.slice(0,2))+JSON.stringify(documentStoreDriftLog.slice(-1)))};
 const kinds=['filterMask','transformMask','mirrorMask','colourMask','gradientMask','strokeMask','shadowMask'];const made=[];
 for(const k of kinds){setStackSelection([layers.find(n=>!n.mask)],{});addLayer(k);renderLayers();const M=AL;made.push(M);check(M.mask===true&&documentStore.prop(M.engineId,'mask')===true&&documentStore.prop(M.engineId,'maskKind')===M.maskKind,'Modifier '+k+' kind in store');}
 cOk('add modifiers');
 for(const M of made)for(const key of ['maskFilter','maskTransform','maskMirror','maskColour','maskGradient','maskStroke','maskShadow']){const v=M[key],s=documentStore.prop(M.engineId,key);check(JSON.stringify(v??null)===JSON.stringify(s??null),'Config '+key+' mirrors store for '+M.maskKind);if(s&&typeof s==='object')check(Object.isFrozen(s)&&!Object.isFrozen(v),'Store copy frozen, view mutable')}
 const F=made[0];const cfg={...(F.maskFilter||{}),type:'blur',radius:7};F.maskFilter=cfg;check(F.maskFilter===cfg&&documentStore.prop(F.engineId,'maskFilter').radius===7,'Assigned config is the view; store has copy');
 cfg.radius=9;check(!auditLiveProps(),'In-place config mutation detected as drift');documentStoreDrift=0;F.maskFilter={...cfg};check(auditLiveProps()&&documentStore.prop(F.engineId,'maskFilter').radius===9,'Reassignment commits');
 const modBlob=await encodeProject();projectDirty=false;await loadProjectFile(new File([modBlob],'mods.bung'));renderLayers();cOk('reopen modifiers');
 check(kinds.every(k=>layers.some(n=>n.mask&&documentStore.prop(n.engineId,'maskKind')===n.maskKind)),'Modifiers reopened with store content');const F2=layers.find(n=>n.maskKind===F.maskKind&&n.maskFilter?.radius===9);check(F2,'Filter config round-trips');
 // board switch parks content
 const cb=activeArtboardId;createArtboard({width:40,height:40,white:false,name:'Mods'});renderLayers();check(documentStore.parkedRecord(cb,'props',F2.engineId,'maskFilter')?.radius===9&&F2.maskFilter.radius===9,'Parked modifier config');activateArtboard(cb);renderLayers();cOk('content board back');check(documentStore.prop(F2.engineId,'maskFilter').radius===9,'Config back in active store');
 // ---- v264 layer content (instance data) in the store ----
 projectDirty=false;await createDocumentFromOptions({width:200,height:150,dpi:72,white:false});renderLayers();
 const ci=n=>documentStore.prop(n.engineId,'instance'),srcCv=document.createElement('canvas');srcCv.width=12;srcCv.height=8;
 const T=newLayer('Text',null,{w:DW,h:DH});T.instance={type:'text',str:'Hello',font:'sans-serif',size:24,x:10,y:20,w:120,colour:'#123456',_cache:{x:1}};insertLayer(T,layers.length);
 const Fl=newLayer('File',null,{w:DW,h:DH});Fl.instance={type:'file',id:'f1',name:'pic.png',img:srcCv,xf:[1,0,0,1,0,0],mode:'original'};insertLayer(Fl,layers.length);
 const Cl=newLayer('Clone',null,{w:DW,h:DH});Cl.instance={type:'clone',src:T,from:null};insertLayer(Cl,layers.length);renderLayers();
 check(ci(T).str==='Hello'&&!('_cache' in ci(T))&&Object.isFrozen(ci(T)),'Text content encoded in store (caches dropped)');
 check(ci(Fl).img.$ref==='image'&&RasterResources.ledger.get(ci(Fl).img.id)?.kind==='image','File image stored as image resource reference');
 check(ci(Cl).src.$ref==='node'&&ci(Cl).src.id===T.engineId,'Clone source stored as node reference');
 check(Fl.instance.img===srcCv&&Cl.instance.src===T,'Views keep live objects');
 // in-place edit + history step commits; undo/redo closures mutate in place and are committed after the step
 const I=T.instance,cBefore={str:I.str,size:I.size},cAfter={str:'World',size:30};Object.assign(I,cAfter);doH({undo:()=>Object.assign(T.instance,cBefore),redo:()=>Object.assign(T.instance,cAfter)});
 check(ci(T).str==='World'&&ci(T).size===30&&T.instance===I,'History step commits in-place content edit; view identity kept');
 await undo();check(ci(T).str==='Hello'&&T.instance.str==='Hello','Undo commits content');await redoF();check(ci(T).str==='World','Redo commits content');check(auditContentViews(),'Content views match store after steps');
 // reassignment and null
 Fl.instance={...Fl.instance,mode:'fit'};check(ci(Fl).mode==='fit'&&Fl.instance.img===srcCv,'Reassigned content');
 // inactive board: content parked, edits on the inactive node are committed at the next step
 const cb2=activeArtboardId;createArtboard({width:40,height:40,white:false,name:'Content'});renderLayers();
 check(documentStore.parkedRecord(cb2,'props',T.engineId,'instance')?.str==='World'&&T.instance.str==='World','Parked content');
 T.instance.size=40;doH({undo(){},redo(){}});check(documentStore.parkedRecord(cb2,'props',T.engineId,'instance').size===40,'Inactive content edit committed at history step');
 activateArtboard(cb2);renderLayers();check(ci(T).size===40&&Fl.instance.img===srcCv&&Cl.instance.src===T,'Content and references back in active store');
 // save/open round trip (synthetic file/clone layers removed: they are not loadable records)
 commitStackTree({layers:layers.filter(n=>n!==Fl&&n!==Cl&&n!==T)});renderLayers();
 const contentBlob=await encodeProject();projectDirty=false;await loadProjectFile(new File([contentBlob],'content.bung'));renderLayers();
 check(layers.every(n=>!n.instance||BungalowContentCodec.valid(ci(n))),'Reopened content valid in store');
 // a real text layer through the app path
 setStackSelection([layers.at(-1)],{});check(fillerNewTextLayer('Store text')!==false,'Real text layer');renderLayers();const RT=layers.find(n=>n.instance?.type==='text');check(RT&&ci(RT)?.type==='text','Real text content in store');
 const rtBlob=await encodeProject();projectDirty=false;await loadProjectFile(new File([rtBlob],'text.bung'));renderLayers();const RT2=layers.find(n=>n.instance?.type==='text');check(RT2&&JSON.stringify(ci(RT2))===JSON.stringify(BungalowContentCodec.encode(RT2.instance,ContentRefs)),'Real text content round-trips through save/open and store');
 check(documentPropRejects===0,'No content rejects '+JSON.stringify(documentPropRejectLog.slice(0,3)));
 // ---- v265 modifier targets, retained pixels, reference payloads ----
 projectDirty=false;await createDocumentFromOptions({width:120,height:90,dpi:72,white:true});renderLayers();const pv5=(n,k)=>documentStore.prop(n.engineId,k);
 const base5=layers.find(n=>!n.mask);setStackSelection([base5],{active:base5,anchor:base5});addLayer('mask');renderLayers();const MK=AL;
 if(MK.maskTarget&&MK.maskTarget.engineId){check(pv5(MK,'maskTarget')===MK.maskTarget.engineId,'Mask target stored as node ID');}
 MK.maskTarget=base5;check(pv5(MK,'maskTarget')===base5.engineId&&MK.maskTarget===base5,'Target resolves to the node');
 MK.maskTarget={orphan:true};check(pv5(MK,'maskTarget')==='orphan'&&MK.maskTarget.orphan===true,'Orphan target');MK.maskTarget=null;check(pv5(MK,'maskTarget')===null,'No target');MK.maskTarget=base5;
 const rcv=document.createElement('canvas');rcv.width=6;rcv.height=4;base5.retained={x:-3,y:-2,cv:rcv};check(pv5(base5,'retained')?.cv?.$ref==='image'&&base5.retained.cv===rcv,'Retained pixels stored with image reference');
 base5.retained.x=-5;doH({undo(){},redo(){}});check(pv5(base5,'retained').x===-5,'Retained in-place edit committed at history step');base5.retained=null;
 const cb5=activeArtboardId;createArtboard({width:40,height:40,white:false,name:'Targets'});renderLayers();check(documentStore.parkedRecord(cb5,'props',MK.engineId,'maskTarget')===base5.engineId&&MK.maskTarget===base5,'Parked target');activateArtboard(cb5);renderLayers();check(MK.maskTarget===base5,'Target back in active store');
 const P5=AL;P5.ctx&&setStackSelection([base5],{active:base5,anchor:base5});check(await convertLayersToReferences(),'Reference for payload');renderReferences();const RR5=referenceImages.at(-1),rp=documentStore.record('referenceProps',RR5.id,'src');
 check(typeof rp==='string'&&rp===RR5.src&&/^data:image\//.test(rp)&&documentStore.record('referenceProps',RR5.id,'nw')===RR5.nw,'Reference payload owned by store');
 check(documentPropRejects===0,'No v265 rejects '+JSON.stringify(documentPropRejectLog.slice(0,3)));
 // store snapshot is plain JSON
 const snap=documentStore.snapshot();check(JSON.stringify(snap)===JSON.stringify(JSON.parse(JSON.stringify(snap))),'Serialisable');
 return {store:true,ok:true,drift:documentStoreDrift};
}));
assert.deepEqual(errors,[]);console.log('PASS: document store authority: selection, tree, references, artboards, dimensions, properties, board and reference records, guides/layout, parked artboards, session, modifier and layer content, targets, retained, reference payloads (' +(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
