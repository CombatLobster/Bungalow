/* v300: the save preview comes from what is already rendered (the tiled GPU display's whole-document overview), then
 * the document's last preview, then the CPU fallback. Saving never composites the document for it. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html');await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  const r=await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:3000,height:2000,dpi:72,white:false});
   RasterResources.fillRegion(AL.rasterId,{x:0,y:0,w:1500,h:2000},'#ff0000');RasterResources.fillRegion(AL.rasterId,{x:1500,y:0,w:1500,h:2000},'#0000ff');AL.maskRevision=(AL.maskRevision||0)+1;doH({undo(){},redo(){}});renderLayers();
   const t0=performance.now();while(!maskDisplay.overviewReady?.()&&performance.now()-t0<20000)await new Promise(r=>setTimeout(r,200));const ready=maskDisplay.overviewReady();
   const sample=async th=>{const im=new Image();im.src=th.png;await im.decode();const c=document.createElement('canvas');c.width=th.width;c.height=th.height;const g=c.getContext('2d');g.drawImage(im,0,0);const px=(x,y)=>[...g.getImageData(Math.floor(x*th.width),Math.floor(y*th.height),1,1).data];return {w:th.width,h:th.height,left:px(.25,.5),right:px(.75,.5)}};
   let t=performance.now();const blob=await encodeProject();const saveMs=performance.now()-t;
   const u=new Uint8Array(await blob.arrayBuffer()),n=new DataView(u.buffer).getUint32(12,true),meta=JSON.parse(new TextDecoder().decode(u.subarray(16,16+n)));
   t=performance.now();const direct=savePreview(captureArtboardState());const previewMs=performance.now()-t;
   const saved=await sample(meta.thumbnail);
   // reopen: until the overview is rebuilt, the file's own preview is reused
   projectDirty=false;await loadProjectFile(new File([blob],'t.bung'));const afterLoad={ready:maskDisplay.overviewReady(),same:savePreview(captureArtboardState())?.png===meta.thumbnail.png};
   // a new document never gets the previous document's preview
   projectDirty=false;await createDocumentFromOptions({width:800,height:600,dpi:72,white:false});const fresh=savePreview(captureArtboardState());
   return {ready,saveMs,previewMs,saved,afterLoad,freshDiffers:fresh?.png!==meta.thumbnail.png}});
  console.log(JSON.stringify(r));
  assert.deepEqual(errors,[]);assert.ok(r.ready,'GPU overview built');
  assert.ok(r.saved.w===256&&r.saved.h===171,'preview fits 256px: '+r.saved.w+'x'+r.saved.h);
  assert.ok(r.saved.left[0]>200&&r.saved.left[2]<60&&r.saved.right[2]>200&&r.saved.right[0]<60,'preview shows the document (red | blue): '+JSON.stringify(r.saved));
  assert.ok(r.previewMs<60,'preview from the overview is quick: '+r.previewMs.toFixed(1)+' ms');
  if(!r.afterLoad.ready)assert.ok(r.afterLoad.same,'reopened document reuses its file preview until the overview is ready');
  assert.ok(r.freshDiffers,'a new document does not inherit the previous preview');
  console.log('PASS: v300 save preview from the GPU overview (no core composite), file preview reused after opening, none carried to a new document')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
