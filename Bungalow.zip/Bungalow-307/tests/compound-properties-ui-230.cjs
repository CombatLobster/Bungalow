const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
console.log(await p.evaluate(async()=>{
 const check=(v,m)=>{if(!v)throw Error(m)};closeLanding();projectDirty=false;await createDocumentFromOptions({width:640,height:480,dpi:72,white:false});
 const first=AL,second=newLayer('Second',null,{w:DW,h:DH});insertLayer(second,layers.length);AL=first;selectedStack=new Set([first,second]);createLayerGroup();const G=soloSelectedGroup();
 first.reference=true;first.vis=false;G.vis=false;second.vis=true;selectedStack=new Set([second]);AL=second;renderLayers();
 const solo={kind:'layer',target:second};isolation=solo;referenceLayersVisible=false;
 const store=second._sparse,unpacked=sparseLayerMetrics.unpacked;
 let start=hp;jumpToLastSketch();check(hp===start+1&&first.vis&&G.vis&&isolation===null&&referenceLayersVisible&&AL===first,'Jump combines reveal/view/selection');
 check(hist[hp-1].layerEdit.redo.length===2&&hist[hp-1].layerEdit.redo.every(p=>p.key==='vis'),'Only document flags in JSON command');
 await undo();check(!first.vis&&!G.vis&&isolation===solo&&!referenceLayersVisible,'Jump restores prior visibility and exact solo target');await redoF();check(first.vis&&G.vis&&isolation===null&&referenceLayersVisible,'Jump redo');
 isolation=solo;referenceLayersVisible=false;start=hp;jumpToLastSketch();check(hp===start+1&&hist[hp-1].layerEdit.redo.length===0,'View-only jump retains one undo with empty document patches');await undo();check(isolation===solo&&!referenceLayersVisible&&first.vis&&G.vis,'View-only undo leaves document visibility');await redoF();
 start=hp;jumpToLastSketch();check(hp===start,'Jump no-op creates no history');
 // A queued property drag must commit before the jump, including view-only jumps.
 AL=first;selectedStack=new Set([first]);first.vis=false;G.vis=false;isolation=null;referenceLayersVisible=true;start=hp;changeLayerControl('op',.4,false);jumpToLastSketch();check(hp===start+2,'Pending opacity precedes jump');await undo();check(first.op===.4&&!first.vis&&!G.vis,'Jump undo first');await undo();check(first.op===1,'Opacity undo second');
 first.vis=true;G.vis=true;isolation=null;referenceLayersVisible=true;AL=first;selectedStack=new Set([first]);renderLayers();
 toggleLayerPropsPanel(true);LayerPanel.sync(true);const f=$('layerPropsPanel').f,old=first.name;
 f.name.value='Panel name';f.name.dispatchEvent(new Event('change'));check(first.name==='Panel name'&&hist[hp-1].layerEdit.redo[0].key==='name','F3 name command');await undo();check(first.name===old&&first.th.title==='Thumbnail: '+old,'F3 name undo');
 start=hp;f.name.value=old;f.name.dispatchEvent(new Event('change'));check(hp===start,'F3 no-op');toggleLayerPropsPanel(false);
 // Real batch dialog: numbered names, locked skipping, one undo command.
 AL=first;selectedStack=new Set([G]);second.locked=true;renderLayers();openBatchRename();$('renameContents').checked=true;$('renameReplace').checked=true;$('renameBase').value='Artwork';$('renamePrefix').value='';$('renameSuffix').value='';$('renameFind').value='';$('renameNumbering').value='suffix';$('renameStart').value=1;$('renameStep').value=1;$('renameDigits').value=2;$('renameSep').value=' ';
 const candidates=renameCandidates(true).filter(n=>n._canvas?!layerLocked(n):!groupLocked(n)),before=candidates.map(n=>n.name),expected=computeBatchNames(candidates,renameOptions()),secondName=second.name;start=hp;
 $('renameForm').dispatchEvent(new Event('submit',{cancelable:true}));check(!$('renameDialog').open&&hp===start+1,'Batch submits as one history entry');check(candidates.every(n=>n.name===expected.get(n))&&second.name===secondName,'Batch values and locked skip');check(hist[hp-1].layerEdit.redo.length===candidates.length,'Batch JSON command');await undo();check(candidates.every((n,i)=>n.name===before[i]),'Distinct batch originals');await redoF();check(candidates.every(n=>n.name===expected.get(n)),'Batch redo');await undo();second.locked=false;
 check(second._sparse===store&&sparseLayerMetrics.unpacked===unpacked,'No sparse conversion in property paths');
 // Conversion hides originals within its existing grouped structural undo.
 projectDirty=false;await createDocumentFromOptions({width:160,height:120,dpi:72,white:false});const original=AL;original.name='Original';selectedStack=new Set([original]);renderLayers();
 openConvertDialog(original);$('convertEmbedded').checked=true;$('convertBung').checked=false;$('convertKeep').checked=true;start=hp;
 check(await runConvert(),'Embedded conversion succeeds');$('convertDialog').close();const converted=AL;check(converted!==original&&!original.vis&&hp===start+1,'Conversion/hide grouped together');await undo();check(layers.includes(original)&&!layers.includes(converted)&&original.vis,'Conversion undo restores original visibility');await redoF();check(layers.includes(converted)&&!original.vis,'Conversion redo');
 return {compoundJump:true,viewOnlyUndo:true,noOps:true,historyOrder:true,panelNames:true,batchNames:true,conversion:true,sparse:true};
}));
assert.deepEqual(errors,[]);console.log('PASS: compound jump, view effects, panel/batch rename and conversion history ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
