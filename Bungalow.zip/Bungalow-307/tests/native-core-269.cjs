// v266: native core conformance. v267: also builds bungalow-core-server (used by the native shadow tests) and runs the dispatch tests. Regenerates the deterministic JS fixtures, then runs the Rust conformance tests
// (native/bungalow-core) when cargo is installed. Raster fixtures come from Chromium via
// tests/native-raster-fixtures-266.cjs and are committed with the crate.
const {execFileSync}=require('node:child_process'),path=require('node:path'),root=path.resolve(__dirname,'..');
execFileSync(process.execPath,[path.join(__dirname,'native-fixtures-266.cjs')],{stdio:'inherit'});
let cargo=null;try{execFileSync('cargo',['--version'],{stdio:'ignore'});cargo='cargo'}catch(_){}
if(!cargo){console.log('SKIP native core: cargo not installed');process.exit(0)}
const crate=path.join(root,'native/bungalow-core');execFileSync(cargo,['build','--release','-q','--bin','bungalow-core-server'],{cwd:crate,stdio:['ignore','ignore','inherit']});
const out=execFileSync(cargo,['test','-q'],{cwd:path.join(root,'native/bungalow-core'),encoding:'utf8',stdio:['ignore','pipe','pipe']});
const passed=[...out.matchAll(/test result: ok\. (\d+) passed/g)].reduce((n,m)=>n+Number(m[1]),0);
if(!/test result: ok/.test(out)||/FAILED/.test(out))throw Error(out);
console.log('PASS native core conformance ('+passed+' Rust tests: store, ledger, tiles, codec, raster parity, command dispatch); server built');
