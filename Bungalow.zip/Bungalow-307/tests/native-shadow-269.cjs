/* v267/v268: native shadow mode, document store. Replays the full document-store UI scenario with every store call
 * mirrored into the Rust core and documents compared at each history step; asserts zero divergences, plus a negative
 * control (a native-only change must be reported). Skips when the native server is not built. */
const assert=require('node:assert/strict'),{runShadowed,assertClean}=require('./native-shadow-harness-269.js');
runShadowed('document-store-ui-267',async(s,source,p)=>{
 assertClean(s,'store');assert.ok(s.calls>500&&s.compares>20,'shadow exercised: '+s.calls+' calls, '+s.compares+' compares');
 console.log('shadow '+(source?'source':'standalone')+': '+s.calls+' store calls, '+s.compares+' document compares, '+s.raster.mirrored+' raster ops replayed, '+s.raster.compared+' surface compares (max diff '+s.raster.maxDiff+'), 0 divergences');
 // Negative control
 const d=await p.evaluate(async()=>{const d=documentStore.document();await window.__bungalowNativeInvoke({method:'commitDocument',args:[{...d,width:d.width+1}]});NativeShadow.checkpoint('probe');await NativeShadow.whenIdle();return NativeShadow.stats().divergences});
 assert.equal(d.length,1,'probe divergence detected');assert.equal(d[0].kind,'state');assert.match(d[0].path,/document/);
},n=>console.log('PASS: native shadow (store): Rust core matched the JS document store through the full UI scenario ('+n+' requests)'));
