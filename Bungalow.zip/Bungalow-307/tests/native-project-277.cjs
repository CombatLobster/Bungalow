/* v277: native project files (native/bungalow-core/src/project.rs). In shadow mode (native surfaces mirror the
 * layers): the app saves a .bung and the core decodes every layer from the file to the same pixels; the core writes a
 * .bung from its own surfaces around the app's metadata and the app opens it to the same document (names, structure,
 * pixels). Skips when the native server is not built. */
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native project (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',served=0;const dir=fs.mkdtempSync(path.join(os.tmpdir(),'bung-'));
 proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(JSON.parse(line))}});
 const invoke=req=>new Promise(r=>{pending.push(r);served++;proc.stdin.write(JSON.stringify(req)+'\n')});
 const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  await p.exposeFunction('__writeFile',(name,b64)=>{const f=path.join(dir,name);fs.writeFileSync(f,Buffer.from(b64,'base64'));return f});
  await p.exposeFunction('__readFile',name=>fs.readFileSync(path.join(dir,name)).toString('base64'));
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?nativeShadow=1');await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  const r=await p.evaluate(async()=>{
   const check=(v,m)=>{if(!v)throw Error(m)};closeLanding();projectDirty=false;await createDocumentFromOptions({width:600,height:420,dpi:72,white:false});
   const W=DW,H=DH,ramp=f=>{const im=new ImageData(W,H);for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=(y*W+x)*4,c=f(x/(W-1),y/(H-1));im.data.set(c.map(v=>Math.max(0,Math.min(255,Math.round(v)))),i)}return im};
   const add=(name,f)=>{const L=newLayer(name,null,{w:W,h:H});insertLayer(L,layers.length);RasterResources.putPixels(L.rasterId,ramp(f),0,0);thumb(L);return L};
   RasterResources.putPixels(AL.rasterId,ramp((u,v)=>[255*u,180*v,90,255]),0,0);thumb(AL);
   add('Disc',(u,v)=>[200,40*u,255*v,(u-.5)**2+(v-.5)**2<.08?200:0]);add('Corner',(u,v)=>[10,250,30,u>.7&&v>.6?255:0]);const M=add('Mask',(u,v)=>[255*u,255*u,255*u,255]);M.mask=true;M.maskKind='paint';
   add('Empty',()=>[0,0,0,0]);setStackSelection([layers[1],layers[2]],{active:layers[2],anchor:layers[1]});createLayerGroup();renderLayers();doH({undo(){},redo(){}});
   const hashOf=L=>{const q=peekLayerCanvas(L);try{const d=q.cv.getContext('2d').getImageData(0,0,DW,DH).data;let h=2166136261,n=0;for(let i=0;i<d.length;i++){h=Math.imul(h^d[i],16777619)>>>0;if(i%4===3&&d[i])n++}return [h,n]}finally{q.release()}};
   const before=layers.map(L=>({name:L.name,hash:hashOf(L),group:L.group?L.group.name:null,mask:!!L.mask}));
   // 1. app save → native decode
   const blob=await encodeProject(),bytes=new Uint8Array(await blob.arrayBuffer());let bin='';for(let i=0;i<bytes.length;i+=32768)bin+=String.fromCharCode(...bytes.subarray(i,i+32768));
   const jsPath=await __writeFile('app.bung',btoa(bin));
   const ins=await __bungalowNativeInvoke({method:'project.inspect',args:[jsPath]});check(ins.ok,'inspect '+JSON.stringify(ins.error));
   const nat=ins.result.documents[0].layers;check(nat.length===before.length,'layer count');
   // pixels: decode into fresh native surfaces and compare with the live layers (premultiplied; ±1 is the browser's own
   // premultiply rounding on PNG decode, the app's reload of the same file is exact)
   const ids=layers.map((L,i)=>'res_'+(0xa0+i).toString(16).padStart(32,'0'));
   const ld=await __bungalowNativeInvoke({method:'project.load',args:[jsPath,ids.map((id,i)=>[0,i,id])]});check(ld.ok&&ld.result.loaded===layers.length,'load '+JSON.stringify(ld));
   let worst=0;for(const [i,L] of layers.entries()){check(nat[i].name===before[i].name&&nat[i].painted===before[i].hash[1],'native decode of '+L.name+': '+JSON.stringify([nat[i],before[i]]));
    const q=peekLayerCanvas(L);let im;try{im=q.cv.getContext('2d').getImageData(0,0,DW,DH)}finally{q.release()}let s='';for(let k=0;k<im.data.length;k+=32768)s+=String.fromCharCode(...im.data.subarray(k,k+32768));
    const c=await __bungalowNativeInvoke({method:'raster.compare',args:[ids[i],{width:DW,height:DH,data:btoa(s)},{tolerance:1}]});check(c.ok&&c.result.over===0,'pixels of '+L.name+': '+JSON.stringify(c.result));worst=Math.max(worst,c.result.maxDiff);
    await __bungalowNativeInvoke({method:'raster.release',args:[ids[i]]})}
   // 2. native write from its own surfaces → app open
   await NativeShadow.verifyRasters('before native write');await NativeShadow.whenIdle();
   const enc=captureDocumentEncoding(captureArtboardState(),'Artboard 1'),meta=enc.p;meta.tileSize=256;meta.selection=null;
   const natPath=jsPath.replace(/app\.bung$/,'native.bung');
   const w=await __bungalowNativeInvoke({method:'project.write',args:[natPath,meta,layers.map((L,i)=>[0,i,L.rasterId])]});check(w.ok,'write '+JSON.stringify(w.error));
   const back=Uint8Array.from(atob(await __readFile('native.bung')),c=>c.charCodeAt(0));projectDirty=false;await loadProjectFile(new File([back],'native.bung'));
   const after=layers.map(L=>({name:L.name,hash:hashOf(L),group:L.group?L.group.name:null,mask:!!L.mask}));
   check(JSON.stringify(after)===JSON.stringify(before),'app opens the native file to the same document: '+JSON.stringify({before,after}));
   // 3. native PNG export of the composite vs the app's flatten
   await NativeShadow.verifyRasters('before export');await NativeShadow.whenIdle();const pngPath=jsPath.replace(/app\.bung$/,'export.png');const ex=await __bungalowNativeInvoke({method:'project.export',args:[pngPath,{white:true}]});check(ex.ok,'export '+JSON.stringify(ex.error));
   const img=new Image();img.src='data:image/png;base64,'+await __readFile('export.png');await img.decode();const cv=document.createElement('canvas');cv.width=img.width;cv.height=img.height;const g=cv.getContext('2d');g.drawImage(img,0,0);
   const nd=g.getImageData(0,0,cv.width,cv.height).data,fd=flat(false).getContext('2d').getImageData(0,0,DW,DH).data;let exportDiff=0;for(let i=0;i<fd.length;i++)exportDiff=Math.max(exportDiff,Math.abs(nd[i]-fd[i]));check(cv.width===DW&&exportDiff<=3,'native export matches the app flatten: '+exportDiff);
   const tiles=ins.result.documents[0].layers.reduce((n,l)=>n+l.tiles,0);
   return {decodeMaxDiff:worst,exportDiff,exportBytes:ex.result.bytes,layers:before.length,appBytes:bytes.length,nativeBytes:w.result.bytes,tiles,shadow:NativeShadow.stats().divergences.length};
  });
  assert.deepEqual(errors,[]);console.log('native project: '+JSON.stringify(r));
  console.log('PASS: native project: core decodes app-saved .bung to identical layers; app opens core-written .bung to the same document; native PNG export matches the flatten ('+served+' requests)');await context.close()}
 finally{await browser.close();server.close();proc.stdin.end();fs.rmSync(dir,{recursive:true,force:true})}})().catch(e=>{console.error(e);process.exitCode=1});
