/* v292: + the flush's own UI-thread work stays below 8 ms per slice (tiles read back in a worker) and request bodies
 *       below 30 ms to build.
 * v291 (A-C): lazy core mode over the raw transport vs per-op (eager) core mode, 3000x2000 with the app's brush:
 * while painting, lazy mode sends next to nothing; once input pauses, changed tiles reach the core (raster.writeTiles,
 * raw attachments), the core then holds the same pixels (verifyRasters), and saving goes through the core
 * (project.encodeTiles after one flush) and reopens identically. Skips when the native server is not built. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore=lazy']){ /* v299: eager core mode removed; lazy is the only core mode */
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(line[0]==='R'?line.slice(1):JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  const invokeRaw=b64=>new Promise(r=>{pending.push(r);bytes+=b64.length*3/4;requests++;per.raw=(per.raw||0)+b64.length*3/4;proc.stdin.write('R'+b64+'\n')});
  if(mode.includes('lazy')){await p.exposeFunction('__bungalowRawB64',invokeRaw);await p.addInitScript(()=>{const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};window.__bungalowNativeInvokeRaw=u=>window.__bungalowRawB64(b64(u)).then(t=>{const s=atob(t),o=new Uint8Array(s.length);for(let i=0;i<o.length;i++)o[i]=s.charCodeAt(i);return o.buffer})})}
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+mode);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:3000,height:2000,dpi:72,white:false});tool(false);setSize(30);Object.assign(TP,{kind:'round',hrd:.6,flow:.7,sp:.1})});
  const stroke=async pts=>{const c=await p.evaluate(pts=>{const r=wrap.getBoundingClientRect();return {hp,pts:pts.map(([x,y])=>{const o=docToOverlay({x,y});return [r.left+o.x,r.top+o.y]})}},pts);await p.mouse.move(...c.pts[0]);await p.mouse.down();for(const q of c.pts.slice(1))await p.mouse.move(...q,{steps:5});await p.mouse.up();await p.waitForFunction(h=>hp===h+1&&!drawing,c.hp,{timeout:10000})};
  const info=await p.evaluate(()=>({core:NativeShadow.coreMode(),lazy:NativeShadow.lazy(),transport:NativeShadow.transport()}));
  await p.evaluate(async()=>{await NativeShadow.whenIdle()});
  await p.evaluate(()=>{window.__long=[];try{new PerformanceObserver(l=>{for(const e of l.getEntries())window.__long.push(Math.round(e.duration))}).observe({type:'longtask'})}catch(_){}});
  const b0=bytes,r0=requests;
  await stroke([[100,100],[1500,400],[2800,1800]]);await stroke([[200,1800],[1400,300]]);
  await p.evaluate(()=>{const L=newLayer('Paint 2',null,{w:DW,h:DH});insertLayer(L,layers.length);setStackSelection([L],{active:L,anchor:L});renderLayers()});
  await stroke([[300,300],[2500,1500]]);await p.evaluate(()=>bucketFill(AL,2900,100,'#3366cc',1));await p.evaluate(()=>new Promise(r=>{const w=()=>projectIOBusy?setTimeout(w,10):r();w()})); // v297: in lazy mode the fill runs in the core ("Filling…" holds input)
  await p.evaluate(async()=>{await undo();await redoF()});
  const during={bytes:bytes-b0,requests:requests-r0};
  await p.evaluate(()=>new Promise(r=>setTimeout(r,900)));await p.evaluate(async()=>{await NativeShadow.whenIdle()});
  const after={bytes:bytes-b0,requests:requests-r0};
  const save=await p.evaluate(async()=>{const hashOf=L=>{const q=peekLayerCanvas(L);try{const d=q.cv.getContext('2d').getImageData(0,0,DW,DH).data;let h=2166136261;for(let i=0;i<d.length;i++)h=Math.imul(h^d[i],16777619)>>>0;return h}finally{q.release()}};
   const before=layers.map(hashOf),n0=window.__nativeTileLayers||0,blob=await encodeProject(),native=(window.__nativeTileLayers||0)-n0;projectDirty=false;await loadProjectFile(new File([blob],'t.bung'));const after=layers.map(hashOf);return {native,same:JSON.stringify(before)===JSON.stringify(after),size:blob.size}});
  const v=await p.evaluate(async()=>{await NativeShadow.whenIdle();await NativeShadow.verifyRasters('end');await NativeShadow.whenIdle();const s=NativeShadow.stats();return {divergences:s.divergences,errors:s.errors,lazyTiles:s.raster.lazyTiles||0,lazyFull:s.raster.lazyFull||0,maxDiff:s.raster.maxDiff,maxSliceMs:s.raster.maxSliceMs,maxBodyMs:s.raster.maxBodyMs}});
  const long=await p.evaluate(()=>window.__long||[]);
  results[mode]={info,during,after,save,v,long:{n:long.length,max:Math.max(0,...long)}};console.log(mode,JSON.stringify(results[mode]));
  assert.deepEqual(errors,[]);assert.deepEqual(v.errors,[],mode+' transport errors');assert.deepEqual(v.divergences,[],mode+': the core holds the same pixels');assert.ok(save.same&&save.native>=2,mode+': saved through the core and reopened identically '+JSON.stringify(save));
  await context.close();proc.stdin.end()}
  const l=results['nativeCore=lazy'];console.log('during painting:',l.during.bytes,'bytes');
  assert.ok(l.info.lazy&&l.info.transport==='raw','modes '+JSON.stringify(l.info));
  assert.ok(l.during.bytes<32*1024*1024,'lazy mode sends little while painting (v298: ~15 MB, mostly tiles flushed during the scenario\'s pauses; eager mode sent over 5x that): '+l.during.bytes);
  assert.ok(l.v.lazyTiles>0,'tiles reach the core once input pauses');assert.ok(l.v.maxSliceMs<8&&l.v.maxBodyMs<30,'flush work on the UI thread stays small per task: '+JSON.stringify(l.v));
  console.log('PASS: v292 lazy core mode: nothing heavy while painting, changed tiles after a pause over the raw transport, saves through the core')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
