/* v268: native shadow mode, raster pixels. v269: + real pointer painting (tests/paint-workflow-269.cjs), native
 * tile snapshots/swaps and surface restores. Runs the resource-interface UI scenario (tests/resources-ui-262.cjs:
 * fills, clears, selections, masks, sparse/dense, undo/redo) plus the sparse action audit and structural lifecycle
 * scenarios (layout shifts, tile-swap history, duplicate/cut/paste) with RasterResources writes replayed in the
 * Rust core; every surface written in a history step is compared with Chromium's pixels (premultiplied, ±3).
 * Skips when the native server is not built. */
const assert=require('node:assert/strict'),{runShadowed,assertClean}=require('./native-shadow-harness-269.js');
runShadowed('resources-ui-262',async(s,source,p)=>{
 assertClean(s,'raster');assert.ok(s.raster.mirrored>0&&s.raster.compared>0,'raster shadow exercised');
 console.log('raster shadow '+(source?'source':'standalone')+': replayed '+s.raster.mirrored+', synced '+s.raster.synced+', '+s.raster.compared+' surface compares, max premultiplied diff '+s.raster.maxDiff+'; ops '+JSON.stringify(s.raster.ops));
 // Negative control: paint one pixel natively only; the next full verify must report it.
 const d=await p.evaluate(async()=>{const id=(AL&&AL.rasterId)||layers.find(L=>L.rasterId).rasterId; /* a surface in the document: deleted layers' surfaces are skipped until collected */await window.__bungalowNativeInvoke({method:'raster.fillRegion',args:[id,{x:0,y:0,w:1,h:1},[255,0,255],'source-over',1]});await NativeShadow.verifyRasters('probe');return NativeShadow.stats().divergences});
 assert.ok(d.length>=1&&d[0].kind==='raster'&&d[0].over>0,'raster probe divergence detected: '+JSON.stringify(d));
},n=>console.log('PASS: native shadow (raster): Rust pixel operations matched Chromium at every history step ('+n+' requests)'));
// Further scenarios (run concurrently, each with its own native server): every write passes the registry.
for(const name of ['sparse-action-audit','lifecycle-ui-235','paint-workflow-269'])runShadowed(name,async(s,source)=>{assertClean(s,name);assert.ok(s.raster.compared>0,name+': surfaces compared');console.log('raster shadow '+name+' '+(source?'source':'standalone')+': replayed '+s.raster.mirrored+', synced '+s.raster.synced+', '+s.raster.compared+' compares, max diff '+s.raster.maxDiff)},n=>console.log('PASS: native shadow (raster, '+name+'): no divergences ('+n+' requests)'));
