const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
console.log(await p.evaluate(async()=>{
 const check=(v,m)=>{if(!v)throw Error(m)};closeLanding();projectDirty=false;await createDocumentFromOptions({width:640,height:480,dpi:72,white:false});
 const first=AL,second=newLayer('Second',null,{w:DW,h:DH});insertLayer(second,layers.length);AL=first;selectedStack=new Set([first,second]);createLayerGroup();const G=soloSelectedGroup();
 selectedStack=new Set([second]);createLayerGroup();const H=soloSelectedGroup();check(H&&H!==G&&H.group===G,'Nested group fixture');
 selectedStack=new Set([G]);AL=first;renderLayers();
 const store=second._sparse,unpacked=sparseLayerMetrics.unpacked;
 G.op=.8;H.op=.6;first.op=.2;second.op=.4;
 openGroupMenu(G,200,200);
 const input=value=>{$('groupOpacity').value=value;$('groupOpacity').dispatchEvent(new Event('input'))};
 let start=hp;input(70);check(G.op===.7&&first.op===.2,'Before Alt only group');layerControlsAlt=true;input(50);layerControlsAlt=false;input(30);$('groupOpacity').dispatchEvent(new Event('change'));
 check(hp===start+1&&[G,H,first,second].every(n=>n.op===.3),'One gesture including late Alt descendants');check(hist[hp-1].layerEdit.redo.length===4,'Group opacity uses JSON patches');await undo();check(G.op===.8&&H.op===.6&&first.op===.2&&second.op===.4,'Late enrolment originals');await redoF();check([G,H,first,second].every(n=>n.op===.3),'Group opacity redo');await undo();
 start=hp;input(80);$('groupOpacity').dispatchEvent(new Event('change'));check(hp===start,'Opacity no-op');
 first.locked=true;H.locked=true;input(55);layerControlsAlt=true;input(45);layerControlsAlt=false;commitGroupOpacityHistory();check(G.op===.45&&first.op===.45&&H.op===.6&&second.op===.45,'Opacity preserves locked-paint / locked-group policy');await undo();first.locked=false;H.locked=false;
 $('groupBlend').value='multiply';$('groupBlend').dispatchEvent(new Event('change'));check(G.blend==='multiply'&&hist[hp-1].layerEdit.redo[0].key==='blend','Group blend uses command');await undo();check(G.blend==='normal'&&$('groupBlend').value==='normal','Blend undo UI');
 first.locked=true;changeGroupNumber(G,'blend','screen',true);check(G.blend==='screen'&&first.blend==='normal'&&second.blend==='screen','Alt blend lock policy');await undo();check(G.blend==='normal'&&second.blend==='normal','Alt blend undo');first.locked=false;
 const priorIsolate=[G.isolate,H.isolate];toggleGroupIsolate(G,true);check(G.isolate===!priorIsolate[0]&&H.isolate===G.isolate,'Group isolate Alt');await undo();check(G.isolate===!!priorIsolate[0]&&H.isolate===!!priorIsolate[1],'Isolate originals restored');
 G.locked=true;const unchanged=hp;input(20);changeGroupNumber(G,'blend','screen');toggleGroupIsolate(G);check(hp===unchanged&&G.op===.8&&G.blend==='normal','Locked group rejects menu edits');G.locked=false;
 // A following discrete command must commit the slider before capturing its own state.
 start=hp;input(65);toggleLayerVisibility(first);check(hp===start+2&&G.op===.65&&!first.vis,'Group gesture precedes discrete command');await undo();check(first.vis&&G.op===.65,'Undo visibility first');await undo();check(G.op===.8,'Undo group gesture second');
 input(25);closeGroupMenu();check(!groupOpacityEdit&&G.op===.25,'Closing menu commits');await undo();check(G.op===.8,'Close commit undo');
 layerMenuTarget=first;$('layerMask').click();check(first.mask&&hist[hp-1].layerEdit.redo[0].key==='mask','Mask menu command');await undo();check(!first.mask,'Mask undo');await redoF();check(first.mask,'Mask redo');await undo();
 first.reference=true;second.reference=true;first.vis=true;second.vis=false;toggleReferenceLayers();check(!first.vis&&!second.vis,'Sketch-wide hide');await undo();check(first.vis&&!second.vis,'Sketch mixed visibility restored');first.vis=false;toggleReferenceLayers();check(first.vis&&second.vis,'Sketch-wide show');await undo();check(!first.vis&&!second.vis,'Sketch show undo');
 check(second._sparse===store&&sparseLayerMetrics.unpacked===unpacked,'No sparse conversion');
 return {lateAlt:true,groupMenus:true,locks:true,mask:true,sketchVisibility:true,historyOrder:true,sparse:true};
}));
assert.deepEqual(errors,[]);console.log('PASS: group property commands, late Alt, lock policy, mask/sketch visibility and history ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
