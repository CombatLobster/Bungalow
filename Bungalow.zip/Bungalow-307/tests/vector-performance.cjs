const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
const result=await p.evaluate(async baseline=>{
 closeLanding();projectDirty=false;await createDocumentFromOptions({width:1200,height:600,dpi:300,white:false});
 const old=eval('('+baseline+')'),original=textWrapObstacles;
 const I={type:'text',...textDefaults(),str:'Performance testing with repeated text wrapping words. '.repeat(40),x:0,y:0,w:1200,h:600,size:16,ls:1.2,wrapMode:'around',wrapSide:'both',wrapOffset:8,wrapMinWidth:25};
 const obstacles=[];for(let i=0;i<18;i++){const x=30+i*64,y=20+(i%3)*60,path=new Path2D();path.ellipse(x+10,y+70,10,70,0,0,Math.PI*2);obstacles.push({path,rule:'nonzero',x0:x,x1:x+20,y0:y,y1:y+140})}
 textWrapObstacles=()=>obstacles;
 const native=textMeasure.isPointInPath;let calls=0;textMeasure.isPointInPath=function(...args){calls++;return native.apply(this,args)};
 const run=fn=>{calls=0;const t=performance.now(),layout=fn(I,{});return {ms:performance.now()-t,calls,layout}};
 let before,after;try{before=run(old);after=run(measureWrappedTextLayout);if(JSON.stringify(before.layout)!==JSON.stringify(after.layout))throw Error('Wrapping layout changed');if(after.calls>=before.calls*.2)throw Error('Insufficient spatial culling');
 for(const gap of [0,3,20])for(const side of ['both','left','right']){I.wrapOffset=gap;I.wrapSide=side;if(JSON.stringify(old(I,{}))!==JSON.stringify(measureWrappedTextLayout(I,{})))throw Error('Wrap mismatch '+gap+' '+side)}
 }finally{textWrapObstacles=original;textMeasure.isPointInPath=native}
 vectorTool();BungalowVectors.defaults.fillMode='gradient';BungalowVectors.defaults.gradient=defaultVectorGradient();BungalowVectors.sync();const bar=document.querySelector('.vg-bar'),ctx=bar.getContext('2d'),fill=ctx.fillRect;let paints=0;ctx.fillRect=function(...args){paints++;return fill.apply(this,args)};
 for(let i=0;i<30;i++)BungalowVectors.sync();if(paints)throw Error('Unchanged gradient repainted');BungalowVectors.defaults.gradient={...BungalowVectors.defaults.gradient,space:'srgb'};BungalowVectors.sync();if(!paints)throw Error('Changed gradient did not repaint');ctx.fillRect=fill;
 return {beforeMs:before.ms,afterMs:after.ms,beforeChecks:before.calls,afterChecks:after.calls};
},fs.readFileSync(path.join(root,'tests/fixtures/wrap-baseline-189.js'),'utf8'));console.log(JSON.stringify(result));
assert.deepEqual(errors,[]);console.log('PASS: performance and layout equivalence ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
