const assert=require('node:assert/strict');
const core=require('../src/engine-layer-edit-231.js');
const roundtrip=v=>JSON.parse(JSON.stringify(v));
const edit=core.begin('op',[{id:'a',value:.8},{id:'b',value:.4}]);
for(let i=0;i<100;i++)core.update(edit,i/100);
core.update(edit,.25);
assert.deepEqual(roundtrip(core.finish(roundtrip(edit))),{version:1,undo:[{id:'a',key:'op',value:.8},{id:'b',key:'op',value:.4}],redo:[{id:'a',key:'op',value:.25},{id:'b',key:'op',value:.25}]});
core.update(edit,.8);assert.equal(core.finish(edit).redo.length,1);
const noOp=core.begin('blend',[{id:'g',value:'multiply'}]);core.update(noOp,'normal');core.update(noOp,'multiply');assert.deepEqual(core.finish(noOp).redo,[]);
assert.equal(core.finish(core.begin('op',[{id:'x'}])).redo.length,0);
for(const bad of [NaN,Infinity,-.1,1.1,'0.5']){const before=roundtrip(edit);assert.throws(()=>core.update(edit,bad));assert.deepEqual(edit,before)}
assert.throws(()=>core.begin('op',[{id:'x'},{id:'x'}]));assert.throws(()=>core.begin('pixels',[]));
console.log('PASS: DOM-free transactions, serialisation, gesture coalescing, no-ops and atomic validation');
