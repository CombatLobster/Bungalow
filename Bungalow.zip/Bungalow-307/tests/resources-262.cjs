const a=require('node:assert/strict'),R=require('../src/engine-resources-262.js');
const rid=R.allocateResourceId(),sid=R.allocateSnapshotId();a.ok(R.validResource(rid)&&R.validSnapshot(sid)&&!R.validResource(sid));
const det=R.allocator('res_',(()=>{let i=0;return ()=>((i++%16)+.5)/16})());a.ok(R.validResource(det()));
// tile planner parity with legacy sparseTileList
const legacy=(store,rect)=>{const s=store.tileSize,out=[],x0=Math.max(0,Math.floor(rect.x/s)*s),y0=Math.max(0,Math.floor(rect.y/s)*s),x1=Math.min(store.width,rect.x+rect.w),y1=Math.min(store.height,rect.y+rect.h);for(let y=y0;y<y1;y+=s)for(let x=x0;x<x1;x+=s)out.push({k:x+':'+y,x,y});return out};
for(const [W,H,T] of [[640,480,256],[1000,700,256],[257,1,128],[4096,4096,512]])for(const r of [{x:0,y:0,w:W,h:H},{x:-50,y:-50,w:100,h:100},{x:255,y:255,w:2,h:2},{x:W-1,y:H-1,w:10,h:10},{x:W+5,y:0,w:5,h:5},{x:10.5,y:3.2,w:300.7,h:2}]){
 const got=R.tiles(r,W,H,T),exp=legacy({width:W,height:H,tileSize:T},r);a.deepEqual(got.map(t=>t.k),exp.map(t=>t.k));for(const t of got){a.ok(t.w>0&&t.h>0&&t.x+t.w<=W&&t.y+t.h<=H)}}
a.throws(()=>R.tiles({x:0,y:0,w:NaN,h:1},10,10,8),/rect/);a.throws(()=>R.tiles({x:0,y:0,w:1,h:1},0,10,8),/surface/);
// ledger
const L=R.createLedger();L.register(rid,{kind:'raster',width:640,height:480,storage:'sparse',tileSize:256,bytes:0});
a.throws(()=>L.register(rid,{kind:'raster',width:1,height:1,storage:'dense',tileSize:null,bytes:4}),/already/);a.throws(()=>L.register('x',{}),/Invalid resource ID/);
a.throws(()=>L.register(R.allocateResourceId(),{kind:'raster',width:0,height:1,storage:'dense',tileSize:null,bytes:0}),/size/);a.throws(()=>L.update(rid,{storage:'other'}),/storage/);
a.equal(L.get(rid).storage,'sparse','atomic update');L.update(rid,{storage:'dense',tileSize:null,bytes:640*480*4});a.equal(L.totals().resourceBytes,640*480*4);
L.addSnapshot(sid,{resource:rid,keys:['0:0','256:0'],bytes:256*256*8});a.equal(L.totals().snapshotBytes,256*256*8);a.throws(()=>L.addSnapshot(R.allocateSnapshotId(),{resource:rid,keys:['0:0','0:0'],bytes:0}),/keys/);a.throws(()=>L.addSnapshot(R.allocateSnapshotId(),{resource:rid,keys:['a'],bytes:0}),/keys/);
L.updateSnapshot(sid,{bytes:10});a.equal(L.snapshot(sid).bytes,10);a.ok(Object.isFrozen(L.snapshot(sid).keys));
L.release(rid,{keepSnapshots:true});a.deepEqual(L.verify(),[{snapshot:sid,issue:'snapshot-of-released-resource'}]);L.dropSnapshot(sid);
{const r9=R.allocateResourceId(),s9=R.allocateSnapshotId();L.register(r9,{kind:'raster',width:1,height:1,storage:'dense',tileSize:null,bytes:4});L.addSnapshot(s9,{resource:r9,keys:[],bytes:0});L.release(r9);a.equal(L.snapshot(s9),null,'release cascades to snapshots')}a.deepEqual(L.totals(),{resources:0,resourceBytes:0,snapshots:0,snapshotBytes:0});
a.deepEqual(JSON.parse(JSON.stringify(L.toJSON())),{resources:{},snapshots:{}});
// v258 region snapshots
{const L2=R.createLedger(),r2=R.allocateResourceId(),s2=R.allocateSnapshotId();L2.register(r2,{kind:'raster',width:64,height:64,storage:'dense',tileSize:null,bytes:64*64*4});
L2.addSnapshot(s2,{resource:r2,kind:'region',rect:{x:-3,y:4,w:10,h:20},bytes:1600});a.deepEqual(L2.snapshot(s2).rect,{x:-3,y:4,w:10,h:20});a.equal(L2.snapshot(L2.snapshot(s2)&&s2).kind,'region');
a.throws(()=>L2.addSnapshot(R.allocateSnapshotId(),{resource:r2,kind:'region',rect:{x:0,y:0,w:0,h:1},bytes:0}),/rect/);a.throws(()=>L2.addSnapshot(R.allocateSnapshotId(),{resource:r2,kind:'region',rect:{x:.5,y:0,w:1,h:1},bytes:0}),/rect/);a.throws(()=>L2.addSnapshot(R.allocateSnapshotId(),{resource:r2,kind:'other',bytes:0}),/kind/);
const s3=R.allocateSnapshotId();L2.addSnapshot(s3,{resource:r2,keys:['0:0'],bytes:4});a.equal(L2.snapshot(s3).kind,'tiles','default kind tiles')}
// v259 masks + surface snapshots
{const L3=R.createLedger(),m=R.allocateResourceId();L3.register(m,{kind:'mask',width:10,height:10,storage:'dense',tileSize:null,bytes:400});a.equal(L3.get(m).kind,'mask');a.throws(()=>L3.register(R.allocateResourceId(),{kind:'video',width:1,height:1,storage:'dense',tileSize:null,bytes:0}),/kind/);
const s=R.allocateSnapshotId();L3.addSnapshot(s,{resource:m,kind:'surface',storage:'sparse',width:640,height:480,bytes:99});a.equal(L3.snapshot(s).storage,'sparse');a.throws(()=>L3.addSnapshot(R.allocateSnapshotId(),{resource:m,kind:'surface',storage:'x',width:1,height:1,bytes:0}),/storage/);a.throws(()=>L3.addSnapshot(R.allocateSnapshotId(),{resource:m,kind:'surface',storage:'dense',width:0,height:1,bytes:0}),/size/)}
{const L4=R.createLedger(),im=R.allocateResourceId();L4.register(im,{kind:'image',width:5,height:6,storage:'dense',tileSize:null,bytes:120});a.equal(L4.get(im).kind,'image')}
console.log('PASS resource ledger, IDs, tile planner, region/surface snapshots, masks and images');
