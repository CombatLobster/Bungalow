/* v274 (stage 7): blur-family modifier scenario: Gaussian blur (adjust and legacy filter layer), blur with preserved
 * edges, sharpen, bloom, drop shadow (modifier layer and legacy filter), at opacity/blend, on groups, as filter layers,
 * chained with v273 modifiers; mirror (vertical, both axes, clipped sides, offset pivot, angled); stroke (positions, joins, offset,
 * variation, smoothing, no antialias); gradient (types, repeats, colour spaces, stop shaping, blend, Replace, alpha lock); random colour overlays (targeted, and per-layer for untargeted); legacy CSS filter layers; fractional shadow offsets. 
 * Under tests/native-composite-shadow-274.cjs the Rust compositor must match the app at every supported step. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
const result=await p.evaluate(async()=>{
 const check=(v,m)=>{if(!v)throw Error(m)};closeLanding();projectDirty=false;await createDocumentFromOptions({width:96,height:64,dpi:72,white:false});
 const W=DW,H=DH,ramp=f=>{const im=new ImageData(W,H);for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=(y*W+x)*4,c=f(x/(W-1),y/(H-1));im.data.set(c.map(v=>Math.max(0,Math.min(255,Math.round(v)))),i)}return im};
 const fill=(L,f)=>RasterResources.putPixels(L.rasterId,ramp(f),0,0);
 const add=(name,f)=>{const L=newLayer(name,null,{w:W,h:H});insertLayer(L,layers.length);fill(L,f);thumb(L);return L};
 const addMod=(name,kind,key,cfg,target=null)=>{const M=add(name,()=>[0,0,0,0]);M.mask=true;M.maskKind=kind;if(key)M[key]=cfg;M.maskTarget=target;thumb(M);return M};
 const adjust=(params)=>({type:'adjust',params:{...ADJUST_DEFAULTS,...params}});
 const base=AL;fill(base,(u,v)=>[255*u,180*v,90+120*(1-u),255]);thumb(base);
 const mid=add('Mid',(u,v)=>[40+200*v,255*(1-u),255*u*v,u>.8?0:255]);
 const top=add('Top',(u,v)=>[255*(1-v),120+100*u,255*v,(u-.5)**2+(v-.5)**2<.12?230:0]);
 const shadow=typeof NativeShadow!=='undefined'&&NativeShadow.enabled(),steps=[],hashes=new Set();
 const step=async label=>{renderLayers();const c=flat(true),d=c.getContext('2d').getImageData(0,0,W,H).data;let h=0;for(let i=0;i<d.length;i++)h=(h*31+d[i])|0;hashes.add(h);steps.push(label);if(shadow)await NativeShadow.verifyComposite(label)};
 await step('no filters');
 const f=addMod('Blur','filter','maskFilter',adjust({type:'blur',blur:3}),top);await step('blur 3 on top');
 f.maskFilter=adjust({type:'blur',blur:9});await step('blur 9');
 f.maskFilter=adjust({type:'blur',blur:0.6});await step('blur 0.6');
 f.maskFilter=adjust({type:'blur',blur:5,blurPreserveEdges:true});await step('blur preserve edges');
 f.maskFilter=adjust({type:'sharpen',sharpenAmount:150,sharpenRadius:2,sharpenThreshold:2});f.maskTarget=base;await step('sharpen base');
 f.maskFilter=adjust({type:'bloom',bloomThreshold:40,bloomRadius:6,bloomIntensity:140});await step('bloom (intensity > 1)');
 f.maskFilter=adjust({type:'blur',blur:4});f.op=.5;await step('blur at half opacity');f.blend='multiply';await step('blur multiply');f.op=1;f.blend='normal';
 f.maskTarget=null;await step('blur filter layer (wraps below)');f.op=.6;await step('blur filter layer at opacity');f.op=1;
 f.maskFilter={type:'blur',radius:4};f.maskTarget=mid;await step('legacy blur filter');
 f.vis=false;
 const sh=addMod('Shadow','shadow','maskShadow',{colour:'#102040',opacity:.6,radius:4,offsetX:5,offsetY:3},top);await step('drop shadow on top');
 sh.maskShadow={colour:'#ff0000',opacity:1,radius:0,offsetX:-6,offsetY:4};await step('hard shadow');
 sh.maskShadow={colour:'#000000',opacity:.5,radius:6,offsetX:0,offsetY:-12};sh.maskTarget=mid;await step('shadow mid upward (edge spill)');
 sh.maskShadow={colour:'#000000',opacity:.5,radius:6,offsetX:2.5,offsetY:1};await step('fractional shadow offset');
 sh.maskShadow={colour:'#203040',opacity:.7,radius:3,offsetX:4,offsetY:4};sh.op=.5;await step('shadow at opacity');sh.op=1;
 const col=addMod('Colour','colour','maskColour',{colour:'#20c040',amount:.5},mid);await step('shadow then colour chain');col.vis=false;
 setStackSelection([mid,top],{active:top,anchor:mid});createLayerGroup();renderLayers();const G=top.group;check(G&&mid.group===G,'group made');
 sh.maskTarget=G;await step('shadow on group');
 f.vis=true;f.maskFilter=adjust({type:'blur',blur:2});f.maskTarget=G;await step('group shadow + blur');
 sh.vis=false;f.vis=false;
  const mir=addMod('Mirror','mirror','maskMirror',MirrorKit.defaults(),top);await step('mirror vertical');
 mir.maskMirror={...MirrorKit.defaults(),h:true};await step('mirror both axes');
 mir.maskMirror={...MirrorKit.defaults(),sideV:'right',clip:true};await step('mirror keep right');
 mir.maskMirror={...MirrorKit.defaults(),h:true,v:false,sideH:'bottom',clip:true,cy:.4};await step('mirror keep bottom, offset pivot');
 mir.maskMirror={...MirrorKit.defaults(),cx:.37,angle:90};mir.maskTarget=base;await step('mirror angle 90 on base');
 mir.maskMirror={...MirrorKit.defaults(),angle:30,h:true};await step('mirror angled (approximate)');
 mir.maskMirror={...MirrorKit.defaults(),angle:-20,clip:true,sideV:'left'};await step('mirror angled clipped');
 mir.maskTarget=null;mir.maskMirror=MirrorKit.defaults();await step('mirror stack-scoped');mir.vis=false;
 const st=addMod('Stroke','stroke','maskStroke',StrokeMod.defaults(),top);await step('stroke outside square');
 st.maskStroke={...StrokeMod.defaults(),join:'round',width:6,colour:'#ff3300'};await step('stroke round');
 st.maskStroke={...StrokeMod.defaults(),position:'inside',width:3};await step('stroke inside');
 st.maskStroke={...StrokeMod.defaults(),position:'centre',width:5,join:'round',offset:2};await step('stroke centre + offset');
 st.maskStroke={...StrokeMod.defaults(),width:5,variation:.6,variationScale:40,join:'round'};await step('stroke variation');
 st.maskStroke={...StrokeMod.defaults(),width:6,smoothing:3,opacity:.7};await step('stroke smoothing');
 st.maskStroke={...StrokeMod.defaults(),width:2,antialias:false,offset:-1,position:'inside'};st.maskTarget=mid;await step('stroke no-AA on mid');
 st.op=.5;st.blend='screen';await step('stroke at opacity + blend');st.op=1;st.blend='normal';st.vis=false;
 const gd=(o)=>({...BungalowGradient.defaults(W,H,'#d02040','#20a0f0'),dither:false,...o});
 const gr=addMod('Gradient','gradient','maskGradient',gd({}),top);await step('gradient linear oklab');
 gr.maskGradient=gd({type:'radial',repeat:'repeat',space:'linear',a:{x:30,y:30},b:{x:60,y:40}});await step('gradient radial repeat linear');
 gr.maskGradient=gd({type:'angle',space:'srgb',stops:[{t:0,v:[1,0,0,1],mid:.3,interp:'smooth'},{t:.5,v:[0,1,0,.5],mid:.5,interp:'easeIn'},{t:1,v:[0,0,1,1],mid:.5,interp:'linear'}]});await step('gradient angle, shaped stops');
 gr.maskGradient=gd({type:'reflected',repeat:'mirror',aspect:2});await step('gradient reflected mirror');
 gr.maskGradient=gd({type:'diamond',mode:'multiply'});await step('gradient diamond multiply');
 gr.maskGradient=gd({mode:'replace',opacity:.6});await step('gradient replace');
 gr.maskGradient=gd({mode:'hue',alphaLock:true});gr.maskTarget=mid;await step('gradient hue alpha-locked on mid');
 gr.maskGradient=gd({mode:'lock',stops:[{t:0,v:[1,1,0,1],mid:.5,interp:'step'},{t:1,v:[0,0,0,0],mid:.5,interp:'linear'}]});await step('gradient legacy lock, step stop');
 gr.maskGradient=gd({dither:true});await step('gradient dithered (default)');
 gr.op=.5;gr.blend='overlay';await step('gradient at opacity + blend');gr.op=1;gr.blend='normal';gr.vis=false;
 const rnd={base:'#3080c0',hue:true,saturation:true,lightness:false,strength:.8,seed:12345,index:0};
 const rc=addMod('Random colour','colour','maskColour',{colour:'#3080c0',amount:.8,random:rnd},top);await step('random colour targeted');
 rc.maskTarget=null;await step('random colour untargeted (per layer)');
 rc.maskColour={colour:'#3080c0',amount:.6,random:{...rnd,seed:999,lightness:true,index:3}};await step('random colour other seed');rc.vis=false;
 const css=addMod('CSS filter','filter','maskFilter',{type:'invert',value:100},top);await step('legacy invert');
 for(const [type,value] of [['brightness',140],['contrast',60],['saturate',180],['hue-rotate',70],['grayscale',80]]){css.maskFilter={type,value};await step('legacy '+type)}
 css.maskTarget=null;css.maskDirect=true;await step('legacy filter direct');css.vis=false;
 const lf=addMod('Legacy shadow','filter','maskFilter',{type:'shadow',colour:'#000000',opacity:.8,radius:3,offsetX:3,offsetY:3},top);await step('legacy shadow filter');
 await undo();await step('undo');await redoF();await step('redo');
 return {steps:steps.length,distinct:hashes.size,shadow};
});
assert.ok(result.distinct>=result.steps-8,'filters change the composite: '+JSON.stringify(result));
assert.deepEqual(errors,[]);console.log('PASS: blur-family composite: '+result.steps+' configurations, '+result.distinct+' distinct results ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
