const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
const result=await p.evaluate(async baseline=>{
 const check=(v,m)=>{if(!v)throw Error(m)};closeLanding();projectDirty=false;await createDocumentFromOptions({width:100,height:80,dpi:300,white:false});
 const originalRaster=eval('(()=>{'+baseline+';return '+Deformation.raster.toString()+'})()');
 const image=new ImageData(127,113);for(let i=0;i<image.data.length;i++)image.data[i]=(i*71+(i>>>7)*31)%256;
 const times={};for(const mode of ['nearest','smooth','bicubic']){
  const points=[{x:-8.3,y:7.1,u:0,v:0,q:1.1},{x:360.4,y:-4.2,u:1,v:0,q:.8},{x:340.3,y:350.9,u:1,v:1,q:1.3},{x:22.2,y:370.1,u:0,v:1,q:.9}],mesh={points,triangles:[[points[0],points[1],points[2]],[points[0],points[2],points[3]]]};
  let before,after;const b=[],a=[];for(let run=0;run<5;run++){let t=performance.now();before=originalRaster(image,mesh,384,384,mode);b.push(performance.now()-t);t=performance.now();after=Deformation.raster(image,mesh,384,384,mode);a.push(performance.now()-t)}
  check(before.data.length===after.data.length&&before.data.every((v,i)=>v===after.data[i]),mode+' pixels differ');times[mode]={beforeMs:b.sort((a,b)=>a-b)[2],afterMs:a.sort((a,b)=>a-b)[2]};
 }
 // Shared handles are read once per poll; decodes are shared even for independent source IDs.
 let reads=0,decodes=0,ui=0,fail=null,modified=2;
 const img=document.createElement('canvas');img.width=100;img.height=80;img.getContext('2d').fillStyle='#00ff00';img.getContext('2d').fillRect(0,0,100,80);
 const handle={getFile:async()=>{reads++;if(fail)throw fail;return new File(['new'],'linked.png',{lastModified:modified})}},items=[];
 for(let i=0;i<12;i++){const L=newLayer('File '+i);L.instance={type:'file',id:'shared-handle-'+i,name:'linked.png',handle,img,mtime:1,size:3,mode:'original'};insertLayer(L,layers.length);drawFileLayer(L);items.push(L)}
 const decodeBefore=decodeFileLayerSource,renderBefore=renderLayers;decodeFileLayerSource=async()=>{decodes++;return img};renderLayers=function(...args){ui++;return renderBefore(...args)};
 try{
 await pollFileLayers({force:true});check(reads===1&&decodes===0,'One shared read on stability pass');check(items.every(L=>L.instance.pending==='2:3'),'All copies wait for stable metadata');
 reads=0;await pollFileLayers({force:true});check(reads===1&&decodes===1,'One shared read/decode on reload');check(ui===1,'Layer list refresh batched');check(items.every(L=>L.instance.mtime===2&&L.ctx.getImageData(10,10,1,1).data[1]===255),'All copies updated');
 reads=0;await pollFileLayers({force:true});check(reads===1&&decodes===1,'Fresh metadata but no unchanged decode');
 fail=new DOMException('Missing','NotFoundError');reads=0;ui=0;await pollFileLayers({force:true});check(reads===1&&ui===1&&items.every(L=>L.instance.missing),'Missing shared file marks every copy once');fail=null;ui=0;await pollFileLayers({force:true});check(ui===1&&items.every(L=>!L.instance.missing),'Recovered file clears missing badges without redecoding');
 // Changing a source while awaiting decoding must not install stale pixels.
 modified=3;await pollFileLayers({force:true});let finish;decodeFileLayerSource=()=>new Promise(r=>finish=r);const pending=pollFileLayers({force:true});while(!finish)await Promise.resolve();const replacement=document.createElement('canvas');replacement.width=replacement.height=2;for(const L of items)L.instance.img=replacement;finish(img);await pending;check(items[0].instance.img===replacement,'Stale decode rejected');
 // Prevent later copies from retrying in background after the controlled test.
 for(const L of items)L.instance.handle=null;
 // An async file stat from a previous document cannot update its old layer.
 let resolveRead;const stale=items[0],oldTime=stale.instance.mtime;stale.instance.handle={getFile:()=>new Promise(r=>resolveRead=r)};
 const reading=pollFileLayers({force:true});while(!resolveRead)await Promise.resolve();projectDirty=false;await createDocumentFromOptions({width:90,height:70,dpi:300,white:false});resolveRead(new File(['abc'],'late.png',{lastModified:99}));await reading;check(stale.instance.mtime===oldTime,'Old-document metadata rejected');

 }finally{decodeFileLayerSource=decodeBefore;renderLayers=renderBefore}
 return times;
},fs.readFileSync(path.join(root,'tests/fixtures/file-sampling-baseline-190.js'),'utf8'));console.log(JSON.stringify(result));
assert.deepEqual(errors,[]);console.log('PASS: file-layer sampling pixels, shared polling/decoding, batched UI and stale decode ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
