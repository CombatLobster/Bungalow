const assert=require('node:assert/strict'),core=require('../src/engine-layer-edit-231.js');
const clone=x=>JSON.parse(JSON.stringify(x));
const edit=core.begin('op',[{id:'g',value:.8}]);core.update(edit,.6);
core.include(edit,[{id:'a',value:.2},{id:'b',value:.4}]);core.update(edit,.3);
core.include(edit,[{id:'a',value:.9}]);core.update(edit,.5);
assert.deepEqual(clone(core.finish(edit)).undo,[{id:'g',key:'op',value:.8},{id:'a',key:'op',value:.2},{id:'b',key:'op',value:.4}]);
const saved=clone(edit);assert.throws(()=>core.include(edit,[{id:'new',value:.7},{id:'bad',value:NaN}]));assert.deepEqual(edit,saved);
assert.throws(()=>core.include(edit,[{id:'dup',value:.2},{id:'dup',value:.3}]));assert.deepEqual(edit,saved);
for(const key of ['isolate','mask']){
 const command=core.command(key,[{id:'g'},{id:'a',value:true}],{type:'toggle'});
 assert.deepEqual(command.redo,[{id:'g',key,value:true},{id:'a',key,value:false}]);
 assert.throws(()=>core.command(key,[{id:'a',value:false}],{type:'set',value:1}));
}
console.log('PASS: late gesture enrolment, original preservation, atomic validation and isolate/mask flags');
