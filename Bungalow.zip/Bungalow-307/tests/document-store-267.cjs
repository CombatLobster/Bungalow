const a=require('node:assert/strict'),S=require('../src/engine-document-store-267.js');
const n=i=>'node_'+i.toString(16).padStart(32,'0');
const st=S.create();a.deepEqual(st.get().selected,[]);a.equal(st.get().revision,0);
let seen=0;st.subscribe(()=>seen++);
let r=st.commit({selected:[n(1),n(2),n(1)],anchor:n(1),active:n(2)});
a.deepEqual(r.selected,[n(1),n(2)]);a.equal(r.revision,1);a.equal(seen,1);
a.equal(st.commit({selected:[n(1),n(2)]}),r,'no-op keeps state');a.equal(seen,1);
a.throws(()=>st.commit({selected:['bad']}),/Invalid/);a.throws(()=>st.commit({active:'x'}),/Invalid/);a.throws(()=>st.commit({selected:[null]}),/Invalid/);a.throws(()=>st.commit(null),/Invalid/);
a.deepEqual(st.get().selected,[n(1),n(2)],'failed commit is atomic');
a.throws(()=>{st.get().selected.push(n(9))},TypeError);
r=st.commit({active:n(3)});a.equal(r.active,n(3));a.deepEqual(r.selected,[n(1),n(2)],'partial patch keeps selection');
r=st.prune(new Set([n(2)]));a.deepEqual(r.selected,[n(2)]);a.equal(r.anchor,null);a.equal(r.active,null);
const snap=st.snapshot();const st2=S.create(snap);a.deepEqual(st2.snapshot(),snap);a.deepEqual(JSON.parse(JSON.stringify(snap)),snap);
st.reset();a.deepEqual(st.get().selected,[]);a.equal(st.get().active,null);
// large selections stay ordered and fast
const big=Array.from({length:50000},(_,i)=>n(i+1));const t=Date.now();const b=S.create();b.commit({selected:big,anchor:big[0],active:big.at(-1)});a.equal(b.get().selected.length,50000);a.ok(Date.now()-t<500);
console.log('PASS document store selection authority');

// ---- v249 tree slice ----
{const T=S.create();const L1=n(101),L2=n(102),G1=n(201),G2=n(202);
let tr=T.commitTree({layers:[L1,L2],groups:[G1,G2],parents:{[L1]:G1,[G2]:G1}});
a.deepEqual(tr.layers,[L1,L2]);a.equal(tr.parents[L1],G1);a.equal(tr.parents[L2],null,'new node defaults to root');a.equal(tr.parents[G2],G1);
const r0=T.state().revision;a.equal(T.commitTree({layers:[L1,L2]}),tr,'no-op tree');a.equal(T.state().revision,r0);
tr=T.commitTree({layers:[L2,L1]});a.equal(tr.parents[L1],G1,'reorder keeps parent');
tr=T.commitTree({layers:[L2]});a.ok(!(L1 in tr.parents),'removed node parent dropped');
tr=T.commitTree({layers:[L2,L1]});a.equal(tr.parents[L1],null,'re-added node has no stale parent unless supplied');
a.throws(()=>T.commitTree({layers:[L1,L1]}),/Duplicate/);a.throws(()=>T.commitTree({groups:[G1,L1]}),/Duplicate/);
a.throws(()=>T.commitTree({parents:{[G1]:G2,[G2]:G1}}),/cycle/);a.throws(()=>T.commitTree({parents:{[G1]:G1}}),/itself/);a.throws(()=>T.commitTree({layers:['x']}),/Invalid/);
a.deepEqual(T.tree().layers,[L2,L1],'failed tree commit is atomic');
T.commitTree({parents:{[L2]:n(999)}});a.deepEqual(T.verify(),[{id:L2,issue:'dangling-parent'}]);
T.commitTree({parents:{[L2]:L1}});a.equal(T.verify()[0].issue,'layer-parent');
tr=T.commitTree({layers:[L1],groups:[],parents:{}},{replace:true});a.deepEqual(tr.parents,{[L1]:null},'replace starts fresh');
a.throws(()=>{tr.layers.push(L2)},TypeError);
T.commit({selected:[L1],active:L1,anchor:L1});const doc=T.snapshotDocument();const T2=S.create();T2.restoreDocument(doc);a.deepEqual(T2.snapshotDocument(),doc);a.deepEqual(JSON.parse(JSON.stringify(doc)),doc);
T.reset();a.deepEqual(T.tree().layers,[]);a.deepEqual(T.get().selected,[]);
const many=Array.from({length:20000},(_,i)=>n(5000+i)),t0=Date.now();const B=S.create();B.commitTree({layers:many,groups:[]});for(let i=0;i<20;i++)B.commitTree({layers:[...many.slice(1),many[0]]});a.ok(Date.now()-t0<2000,'tree commits scale');
console.log('PASS document store tree authority')}

// ---- v250 references + boards ----
{const R=S.create(),u=i=>'00000000-0000-4000-8000-'+String(i).padStart(12,'0');
let s=R.commitReferences({ids:[u(1),u(2)],selected:u(2)});a.deepEqual(s,{ids:[u(1),u(2)],selected:u(2),shown:true});
a.equal(R.commitReferences({ids:[u(1),u(2)]}),s,'no-op refs');
a.throws(()=>R.commitReferences({ids:[u(1),u(1)]}),/Duplicate/);a.throws(()=>R.commitReferences({shown:'yes'}),/shown/);a.throws(()=>R.commitReferences({ids:[3]}),/Invalid/);a.throws(()=>R.commitReferences({selected:''}),/Invalid/);
a.deepEqual(R.references().ids,[u(1),u(2)],'atomic refs');
s=R.commitReferences({ids:[u(1)]});a.deepEqual(R.verifyCollections(),[{slice:'references',issue:'selected-missing'}]);R.commitReferences({selected:u(1),shown:false});a.deepEqual(R.verifyCollections(),[]);
let b=R.commitBoards({ids:[u(10),u(11)],active:u(10),selected:[u(10),u(11),u(10)],anchor:u(10)});a.deepEqual(b.selected,[u(10),u(11)],'board selection deduped');
a.throws(()=>R.commitBoards({ids:[u(10),u(10)]}),/Duplicate/);a.throws(()=>R.commitBoards({active:5}),/Invalid/);
R.commitBoards({ids:[u(11)]});a.equal(R.verifyCollections().length,2);
const doc=R.snapshotDocument(),R2=S.create();R2.restoreDocument(doc);a.deepEqual(R2.snapshotDocument(),doc);a.ok(Object.isFrozen(R.boards().ids));
R.reset();a.deepEqual(R.references(),{ids:[],selected:null,shown:true});a.deepEqual(R.boards().ids,[]);
console.log('PASS document store reference and artboard collections')}

// ---- v251 document slice ----
{const D=S.create();a.deepEqual(D.document(),{width:1920,height:1080,dpi:72});const d=D.commitDocument({width:640,height:480});a.deepEqual(d,{width:640,height:480,dpi:72});
a.equal(D.commitDocument({width:640}),d,'no-op document');a.throws(()=>D.commitDocument({width:0}),/width/);a.throws(()=>D.commitDocument({dpi:NaN}),/dpi/);a.throws(()=>D.commitDocument({height:'4'}),/height/);
a.deepEqual(D.document(),d,'atomic document');const snap=D.snapshotDocument();a.deepEqual(snap.document,d);const D2=S.create();D2.restoreDocument(snap);a.deepEqual(D2.document(),d);
console.log('PASS document store dimensions')}

// ---- v252 props slice ----
{const P=S.create(),L1=n(301),L2=n(302);P.commitTree({layers:[L1,L2],groups:[]});
a.deepEqual(P.verifyProps().map(x=>x.issue),['node-without-props','node-without-props']);
P.commitProps({set:{[L1]:{vis:true,op:.5,name:'A',blend:'normal'},[L2]:{vis:false,op:1,name:'B'}}});a.deepEqual(P.verifyProps(),[]);
a.equal(P.prop(L1,'op'),.5);a.equal(P.prop(L2,'blend'),undefined);
const r1=P.state().revision;P.setProp(L1,'op',.5);a.equal(P.state().revision,r1,'no-op prop');P.setProp(L1,'op',.25);a.equal(P.prop(L1,'op'),.25);
P.setProp(L1,'blend',undefined);a.ok(!('blend' in P.props()[L1]),'undefined deletes key');
a.throws(()=>P.setProp(L1,'op',NaN),/Invalid/);a.throws(()=>P.setProp(L1,'vis',1),/Invalid/);a.throws(()=>P.setProp(L1,'bogus',1),/Unknown/);a.throws(()=>P.setProp(n(999),'op',1),/outside/);
a.throws(()=>P.commitProps({set:{[L1]:{op:.9},[L2]:{op:'x'}}}),/Invalid/);a.equal(P.prop(L1,'op'),.25,'atomic props');
a.ok(Object.isFrozen(P.props()[L1])&&Object.isFrozen(P.props()),'props frozen');
P.commitProps({remove:[L2]});a.deepEqual(P.verifyProps(),[{id:L2,issue:'node-without-props'}]);
const doc=P.snapshotDocument(),P2=S.create();P2.restoreDocument(doc);a.deepEqual(P2.snapshotDocument(),doc);
const many={};for(let i=0;i<2000;i++)many[n(10000+i)]={vis:true,op:1,name:'L'+i};const B=S.create(),t0=Date.now();B.commitProps({set:many});for(let i=0;i<500;i++)B.setProp(n(10000+i),'op',.5);a.ok(Date.now()-t0<3000,'prop writes scale');
console.log('PASS document store properties')}

// ---- v253 board + reference records ----
{const R=S.create(),u=i=>'00000000-0000-4000-8000-'+String(i).padStart(12,'0');
R.commitBoards({ids:[u(1)],active:u(1)});a.deepEqual(R.verifyRecords(),[{slice:'boardProps',id:u(1),issue:'member-without-record'}]);
R.commitRecords('boardProps',{set:{[u(1)]:{name:'A',x:0,y:10,visible:true,locked:false,group:null}}});a.deepEqual(R.verifyRecords(),[]);
R.setRecord('boardProps',u(1),'x',25);a.equal(R.record('boardProps',u(1),'x'),25);a.throws(()=>R.setRecord('boardProps',u(1),'x',Infinity),/Invalid/);a.throws(()=>R.setRecord('boardProps',u(1),'group',''),/Invalid/);a.throws(()=>R.setRecord('boardProps',u(1),'state',{}),/Unknown/);
R.commitReferences({ids:[u(5)],selected:u(5)});R.commitRecords('referenceProps',{set:{[u(5)]:{name:'R',x:1,y:2,w:3,h:4,angle:0,op:1,vis:true,matrix:[1,0,0,1]}}});
const m=R.record('referenceProps',u(5),'matrix');a.ok(Object.isFrozen(m));const rev=R.state().revision;R.setRecord('referenceProps',u(5),'matrix',[1,0,0,1]);a.equal(R.state().revision,rev,'equal matrix is a no-op');
R.setRecord('referenceProps',u(5),'matrix',[2,0,0,1]);a.deepEqual([...R.record('referenceProps',u(5),'matrix')],[2,0,0,1]);a.throws(()=>R.setRecord('referenceProps',u(5),'matrix',[1,0]),/Invalid/);a.throws(()=>R.setRecord('referenceProps',u(5),'src','data:'),/Invalid/);R.setRecord('referenceProps',u(5),'src','data:image/png;base64,AAAA');a.throws(()=>R.setRecord('referenceProps',u(5),'pixels',1),/Unknown/);
a.throws(()=>R.commitRecords('nope',{}),/Unknown/);a.throws(()=>R.setRecord('referenceProps',u(9),'x',1),/outside/);
const doc=R.snapshotDocument(),R2=S.create();R2.restoreDocument(doc);a.deepEqual(R2.snapshotDocument(),doc);
console.log('PASS document store board and reference records')}

// ---- v254 coordinates ----
{const C=S.create();a.deepEqual(C.coordinates(),{});const c=C.commitCoordinates({version:1,guides:[{id:'g',axis:'x',position:.5}],horizon:null,layout:{visible:true,skip:undefined}});
a.ok(Object.isFrozen(c.guides[0])&&!('skip' in c.layout),'deep frozen, undefined dropped');const rev=C.state().revision;C.commitCoordinates(JSON.parse(JSON.stringify(c)));a.equal(C.state().revision,rev,'equal coordinates no-op');
a.throws(()=>C.commitCoordinates({a:NaN}),/number/);a.throws(()=>C.commitCoordinates({a:new Date()}),/plain/);a.throws(()=>C.commitCoordinates([]),/Invalid/);a.throws(()=>C.commitCoordinates({f:()=>1}),/plain/);
a.equal(C.coordinates(),c,'atomic coordinates');const doc=C.snapshotDocument(),C2=S.create();C2.restoreDocument(doc);a.deepEqual(C2.coordinates(),c);
console.log('PASS document store coordinates')}

// ---- v255 parked documents ----
{const Pk=S.create(),u=i=>'00000000-0000-4000-8000-'+String(i).padStart(12,'0'),A=n(501),B=n(502),G=n(601);
Pk.commitBoards({ids:[u(1),u(2)],active:u(1)});
const d=Pk.park(u(2),{tree:{layers:[A,B],groups:[G],parents:{[A]:G}},selection:{selected:[A],active:A,anchor:A},references:{ids:[u(9)],selected:u(9),shown:false},document:{width:64,height:32,dpi:300},props:{[A]:{vis:true,op:.5,name:'A'},[B]:{vis:true,op:1,name:'B'},[G]:{vis:true,collapsed:false,name:'G'}},referenceProps:{[u(9)]:{x:1,y:2,w:3,h:4,angle:0,op:1,vis:true,name:'r'}},coordinates:{version:1,guides:[]}});
a.equal(d.document.dpi,300);a.ok(Object.isFrozen(d.tree));a.deepEqual(Pk.verifyParked(),[]);
a.equal(Pk.parkedRecord(u(2),'props',A,'op'),.5);Pk.setParkedRecord(u(2),'props',A,'op',.25);a.equal(Pk.parkedRecord(u(2),'props',A,'op'),.25);
a.throws(()=>Pk.setParkedRecord(u(2),'props',A,'op','x'),/Invalid/);a.throws(()=>Pk.setParkedRecord(u(2),'props',n(777),'op',1),/outside/);a.throws(()=>Pk.setParkedRecord(u(3),'props',A,'op',1),/not parked/);
Pk.setParkedParent(u(2),B,G);a.equal(Pk.parked(u(2)).tree.parents[B],G);a.throws(()=>Pk.setParkedParent(u(2),G,G),/itself/);
Pk.commitParked(u(2),{document:{width:128,height:32,dpi:300}});a.equal(Pk.parked(u(2)).document.width,128);a.equal(Pk.parked(u(2)).props[A].op,.25,'other parts kept');
a.throws(()=>Pk.park(u(2),{bogus:1}),/Unknown parked part/);a.throws(()=>Pk.park(u(2),{tree:{layers:[A,A]}}),/Duplicate/);a.equal(Pk.parked(u(2)).document.width,128,'atomic park');
Pk.park(u(1),{});a.deepEqual(Pk.verifyParked().map(x=>x.issue),['active-board-parked']);Pk.unpark(u(1));
Pk.commitParked(u(2),{props:{[A]:{vis:true}}});a.deepEqual(Pk.verifyParked().map(x=>x.issue),['node-without-props','node-without-props']);
const doc=Pk.snapshotDocument(),P2=S.create();P2.restoreDocument(doc);a.deepEqual(P2.snapshotDocument(),doc);a.ok(doc.parked[u(2)]);
a.equal(Pk.unpark(u(2)).document.width,128);a.equal(Pk.parked(u(2)),null);
console.log('PASS document store parked artboard documents')}

// ---- v256 session ----
{const Se=S.create();a.deepEqual(Se.session(),{dirty:false,editSerial:0,filename:'painting.bung',hasFile:false});
const s=Se.commitSession({dirty:true,editSerial:3});a.equal(s.editSerial,3);const rev=Se.state().revision;Se.commitSession({dirty:true});a.equal(Se.state().revision,rev,'no-op session');
Se.commitSession({filename:null});a.equal(Se.session().filename,null);a.throws(()=>Se.commitSession({dirty:1}),/dirty/);a.throws(()=>Se.commitSession({editSerial:-1}),/editSerial/);a.throws(()=>Se.commitSession({editSerial:1.5}),/editSerial/);a.throws(()=>Se.commitSession({x:1}),/Unknown/);
a.equal(Se.session().editSerial,3,'atomic session');const doc=Se.snapshotDocument(),S2=S.create();S2.restoreDocument(doc);a.deepEqual(S2.session(),Se.session());
console.log('PASS document store session')}

// ---- v263 mask/modifier content ----
{const M=S.create(),L1=n(901);M.commitTree({layers:[L1],groups:[]});M.commitProps({set:{[L1]:{vis:true,mask:true,maskKind:'filter',maskFilter:{type:'blur',radius:4,nested:{a:[1,2]}}}}});
const f=M.prop(L1,'maskFilter');a.ok(Object.isFrozen(f)&&Object.isFrozen(f.nested)&&Object.isFrozen(f.nested.a),'config deep-frozen');
const rev=M.state().revision;M.setProp(L1,'maskFilter',{type:'blur',radius:4,nested:{a:[1,2]}});a.equal(M.state().revision,rev,'equal config is a no-op');
M.setProp(L1,'maskFilter',null);a.equal(M.prop(L1,'maskFilter'),null);a.throws(()=>M.setProp(L1,'maskFilter',{f:()=>1}),/Invalid/);a.throws(()=>M.setProp(L1,'maskFilter',{x:NaN}),/Invalid/);M.setProp(L1,'maskTransform',[1,2]);a.deepEqual([...M.prop(L1,'maskTransform')],[1,2],'JSON arrays allowed');
a.throws(()=>M.setProp(L1,'maskKind',5),/Invalid/);const doc=M.snapshotDocument(),M2=S.create();M2.restoreDocument(doc);a.deepEqual(M2.snapshotDocument(),doc);
console.log('PASS document store mask/modifier content')}

// ---- v264 encoded layer content ----
{const Cn=S.create(),L1=n(950);Cn.commitTree({layers:[L1],groups:[]});Cn.commitProps({set:{[L1]:{vis:true,instance:{type:'file',name:'a',img:{$ref:'image',id:'res_x'},xf:[1,0,0,1,0,0]}}}});
a.equal(Cn.prop(L1,'instance').img.$ref,'image');a.ok(Object.isFrozen(Cn.prop(L1,'instance').xf));a.throws(()=>Cn.setProp(L1,'instance',{img:{$ref:'image'}}),/Invalid/);a.throws(()=>Cn.setProp(L1,'instance',[1]),/Invalid/);
Cn.setProp(L1,'instance',null);a.equal(Cn.prop(L1,'instance'),null);console.log('PASS document store encoded layer content')}
