/* v296: two artboards in lazy core mode. Saving while a background flush is part-way through used to deadlock: the flush
 * waited for idle input, and a save counts as busy (desktop: frozen on "Preparing project…"). Both boards save and
 * reopen. Skips when the native server is not built. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore=lazy']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(line[0]==='R'?line.slice(1):JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.text().startsWith('STEP'))console.log(m.text())});
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  const invokeRaw=b64=>new Promise(r=>{pending.push(r);bytes+=b64.length*3/4;requests++;per.raw=(per.raw||0)+b64.length*3/4;proc.stdin.write('R'+b64+'\n')});
  if(mode.includes('lazy')){await p.exposeFunction('__bungalowRawB64',invokeRaw);await p.addInitScript(()=>{const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};window.__bungalowNativeInvokeRaw=u=>window.__bungalowRawB64(b64(u)).then(t=>{const s=atob(t),o=new Uint8Array(s.length);for(let i=0;i<o.length;i++)o[i]=s.charCodeAt(i);return o.buffer})})}
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+mode);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:3000,height:2000,dpi:72,white:false});tool(false);setSize(30);Object.assign(TP,{kind:'round',hrd:.6,flow:.7,sp:.1})});
  const stroke=async pts=>{const c=await p.evaluate(pts=>{const r=wrap.getBoundingClientRect();return {hp,pts:pts.map(([x,y])=>{const o=docToOverlay({x,y});return [r.left+o.x,r.top+o.y]})}},pts);await p.mouse.move(...c.pts[0]);await p.mouse.down();for(const q of c.pts.slice(1))await p.mouse.move(...q,{steps:5});await p.mouse.up();await p.waitForFunction(h=>hp===h+1&&!drawing,c.hp,{timeout:10000})};
  const r=await p.evaluate(async()=>{const T=async(f,ms=20000)=>{const t=performance.now();const v=await Promise.race([f(),new Promise(r=>setTimeout(()=>r('TIMEOUT'),ms))]);return [Math.round(performance.now()-t),v]};
   const paint=(L,n)=>{const g=document.createElement('canvas');g.width=g.height=1024;const q=g.getContext('2d');for(let k=0;k<n;k++){q.fillStyle=`hsla(${k*37%360},70%,50%,.8)`;q.beginPath();q.arc(Math.random()*1024,Math.random()*1024,30+Math.random()*90,0,7);q.fill()}for(let y=0;y<DH;y+=1000)for(let x=0;x<DW;x+=1000)RasterResources.composeRegion(L.rasterId,{x,y,w:1024,h:1024},g,x,y,'source-over',1)};
   console.log('STEP paint1');paint(AL,30);doH({undo(){},redo(){}});await NativeShadow.flush();console.log('STEP flushed');
   await createArtboard({width:3000,height:2000,dpi:72,white:false,name:'Second'});console.log('STEP board2');paint(AL,30);doH({undo(){},redo(){}});console.log('STEP paint2');
   const out={boards:artboards.length};
   // save while a background flush is part-way through (it waits for idle input between batches)
   await new Promise(r=>setTimeout(r,560));out.pending=NativeShadow.pending();
   console.log('STEP save');setProjectBusy(true,'Preparing project…');try{const [ms,blob]=await T(()=>encodeProject());out.save1=ms;out.timedOut=blob==='TIMEOUT';out.size=blob?.size}finally{setProjectBusy(false)}
   if(out.timedOut)return out;
   const [ms2]=await T(()=>encodeProject());out.save2=ms2;
   const blob=await encodeProject();projectDirty=false;const [ms3]=await T(()=>loadProjectFile(new File([blob],'two.bung')));out.load=ms3;out.boardsAfter=artboards.length;
   const errs=NativeShadow.stats().errors;out.errors=errs;return out});
  console.log(JSON.stringify(r));
  assert.deepEqual(errors,[]);assert.ok(!r.timedOut,'saving with a background flush in progress completes '+JSON.stringify(r));assert.equal(r.boardsAfter,2,'both artboards saved and reopened');assert.deepEqual(r.errors,[],'no core errors');
  await context.close();proc.stdin.end()}
  console.log('PASS: v296 two artboards in lazy core mode: saving during a background flush completes, saves and reopens both boards')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
