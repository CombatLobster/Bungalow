/* v298: + 'direct': precomputed bicubic results (as from the GPU preview or the core) are written straight into tiles,
 *       no document-sized canvas; same pixels.
 * v297: transforming many layers at 5000x3000. The committed result is packed into tiles only inside the transform's
 * output bounds, without reading every tile back; the pixels must equal the full-scan packing exactly, undo/redo
 * must be exact, and the bounded commit must be faster. Runs on the source page. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{const out={};for(const mode of ['full','bounded','direct']){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html');await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  out[mode]=await p.evaluate(async mode=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:5000,height:3000,dpi:72,white:false});
   let seed=7;const rnd=()=>(seed=(seed*1103515245+12345)%2147483648)/2147483648;const list=[];
   for(let i=0;i<6;i++){const L=i?newLayer('P'+i,null,{w:DW,h:DH}):AL;if(i)insertLayer(L,layers.length);list.push(L);const g=document.createElement('canvas');g.width=g.height=900;const q=g.getContext('2d');for(let k=0;k<25;k++){q.fillStyle=`hsla(${(k*41+i*60)%360},70%,50%,.85)`;q.beginPath();q.arc(rnd()*900,rnd()*900,30+rnd()*120,0,7);q.fill()}RasterResources.composeRegion(L.rasterId,{x:300+i*600,y:400+i*250,w:900,h:900},g,300+i*600,400+i*250,'source-over',1)}
   doH({undo(){},redo(){}});renderLayers();
   const hash=()=>list.map(L=>{const q=peekLayerCanvas(L);try{const d=q.cv.getContext('2d').getImageData(0,0,DW,DH).data;let h=2166136261;for(let i=0;i<d.length;i+=4)h=Math.imul(h^(d[i]|d[i+1]<<8|d[i+2]<<16|d[i+3]<<24),16777619)>>>0;return h}finally{q.release()}}).join(',');
   const h0=hash();if(mode==='full')window.transformOutputRect=()=>null;$('transformSampling').value='bicubic';
   setStackSelection(list,{active:list[0],anchor:list[0]});renderLayers();beginTransform();const t=transformSession;t.cx+=180;t.cy-=90;t.angle=.25;t.scaleX=.8;t.scaleY=.85;
   if(mode==='direct'){$('transformSampling').value='bicubic';const key=TransformSampling.key(t);for(const item of t.items){const img=TransformSampling.source(item.source,t),plan=TransformSampling.plan(img,t,DW,DH);item.bicubicResult={key,plan,result:TransformSampling.cpu(img,plan)}}}
   const t0=performance.now();commitTransform();const ms=Math.round(performance.now()-t0);
   const h1=hash();await undo();const hu=hash();await redoF();const hr=hash();
   return {ms,h1,undo:hu===h0,redo:hr===h1,tiles:list.reduce((n,L)=>n+(L._sparse?.tiles.size||0),0)}},mode);
  assert.deepEqual(errors,[]);await context.close()}
  console.log(JSON.stringify(out));
  assert.equal(out.bounded.h1,out.full.h1,'bounded packing gives the same pixels as the full scan');assert.equal(out.direct.h1,out.full.h1,'v298: bicubic results packed straight into tiles give the same pixels');assert.ok(out.direct.ms<out.full.ms,'direct packing is faster (sampling done beforehand, as by the GPU preview or the core)');
  for(const m of ['full','bounded','direct'])assert.ok(out[m].undo&&out[m].redo,m+': undo/redo exact');
  assert.ok(out.bounded.ms<out.full.ms,'bounded commit is faster: '+out.bounded.ms+' vs '+out.full.ms);
  console.log('PASS: multi-layer transform commit: bounded tile packing, identical pixels, exact undo/redo ('+out.full.ms+' -> '+out.bounded.ms+' ms)');
 }finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
