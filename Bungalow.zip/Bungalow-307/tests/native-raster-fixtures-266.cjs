// v266: browser-generated raster fixtures for the native core. Runs the app's RasterResources operations on
// dense layers in Chromium and records inputs and getImageData results; native/bungalow-core replays them.
const fs=require('node:fs'),path=require('node:path'),{chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{const p=await browser.newPage();const errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
const cases=await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:48,height:32,dpi:72,white:false});
 let seed=7;const rnd=()=>{seed=(seed*1103515245+12345)%2147483648;return seed/2147483648};const W=DW,H=DH;
 const img=(w,h,mode)=>{const d=new Uint8ClampedArray(w*h*4);for(let i=0;i<w*h;i++){const a=mode==='opaque'?255:mode==='clear'?0:[0,0,1,64,128,200,255,255][Math.floor(rnd()*8)];d[i*4]=Math.floor(rnd()*256);d[i*4+1]=Math.floor(rnd()*256);d[i*4+2]=Math.floor(rnd()*256);d[i*4+3]=a}return d};
 const canvasOf=(w,h,data)=>{const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(data),w,h),0,0);return c};
 const read=L=>Array.from(L.ctx.getImageData(0,0,W,H).data);const out=[];
 const ops=['source-over','destination-out','source-atop','source-over'];
 for(let n=0;n<120;n++){const dst=img(W,H,n%5===0?'opaque':'mixed'),sw=8+Math.floor(rnd()*30),sh=6+Math.floor(rnd()*20),src=img(sw,sh,n%7===0?'opaque':'mixed');
  const cv=document.createElement('canvas');cv.width=W;cv.height=H;const L=newLayer('fx',cv);RasterResources.putPixels(L.rasterId,new ImageData(new Uint8ClampedArray(dst),W,H),0,0);const dstStored=read(L);
  const kind=['compose','compose','compose','fill','clear','write'][n%6];const rect={x:Math.floor(rnd()*20)-4,y:Math.floor(rnd()*14)-3,w:5+Math.floor(rnd()*30),h:4+Math.floor(rnd()*20)};const op=ops[n%4];let alpha=[1,.5,.25,1,.8][n%5],ox=Math.floor(rnd()*30)-6,oy=Math.floor(rnd()*20)-4,colour='rgb('+Math.floor(rnd()*256)+','+Math.floor(rnd()*256)+','+Math.floor(rnd()*256)+')';
  // 'copy' is excluded from Chromium parity: in this Chromium/SwiftShader build drawImage with 'copy' ignores the clip
  // and resamples small sources. The app only uses copy over a full-document source (gradient apply), and
  // region replacement goes through writeRegion, which is covered here.
  const c={kind,width:W,height:H,dst:dstStored,src:null,sw,sh,rect,op,alpha,ox,oy,colour};
  if(kind==='compose'){const s=canvasOf(sw,sh,src);c.src=Array.from(s.getContext('2d').getImageData(0,0,sw,sh).data);RasterResources.composeRegion(L.rasterId,rect,s,ox,oy,op,alpha)}
  else if(kind==='fill'){RasterResources.fillRegion(L.rasterId,rect,colour,op==='copy'?'source-over':op,alpha)}
  else if(kind==='clear'){RasterResources.clearRegion(L.rasterId,rect)}
  else {const s=canvasOf(sw,sh,src);c.src=Array.from(s.getContext('2d').getImageData(0,0,sw,sh).data);RasterResources.writeRegion(L.rasterId,s,ox,oy)}
  if(kind==='fill')c.op=op==='copy'?'source-over':op;
  c.result=read(L);out.push(c)}
 return out});
if(errors.length)throw Error(errors.join('; '));
fs.writeFileSync(path.join(root,'native/bungalow-core/tests/fixtures/raster.json'),JSON.stringify({generator:'tests/native-raster-fixtures-266.cjs',cases}));console.log('PASS raster fixtures: '+cases.length+' cases');
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});
