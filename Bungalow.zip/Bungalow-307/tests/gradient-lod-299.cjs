/* v299: gradient modifiers at reduced levels of detail. The tiled GPU compositor evaluated the gradient over TILE document
 * pixels per tile even when a tile spans TILE*scale pixels (zoomed out), so each tile showed one flat colour until zoomed
 * in. A horizontal gradient across a 6000px document, fitted to the window, must vary smoothly within tiles. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html');await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  const info=await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:6000,height:1200,dpi:72,white:false});
   RasterResources.fillRegion(AL.rasterId,{x:0,y:0,w:DW,h:DH},'#ffffff');AL.maskRevision=(AL.maskRevision||0)+1;doH({undo(){},redo(){}});
   addLayer('gradientMask');const G=AL;G.maskGradient={...G.maskGradient,type:'linear',a:{x:0,y:600},b:{x:6000,y:600},stops:[{t:0,v:[0,0,0,1],mid:.5,interp:'linear'},{t:1,v:[1,1,1,1],mid:.5,interp:'linear'}],space:'srgb',dither:false,opacity:1};gradientModifierTouched(G);renderLayers();
   for(let i=0;i<40;i++){await new Promise(r=>requestAnimationFrame(r));const d=maskDisplay?.debugInfo?.();if(i>10&&d&&!d.pendingTiles&&!d.refinementPending)break}
   await new Promise(r=>setTimeout(r,400));select(layers[0]);renderLayers();await new Promise(r=>setTimeout(r,300));const r=wrap.getBoundingClientRect(),a=docToOverlay({x:300,y:250}),b=docToOverlay({x:5700,y:250});
   return {renderer:maskDisplay?.debugInfo?.().lod,y:Math.round(r.top+a.y),x0:Math.round(r.left+a.x),x1:Math.round(r.left+b.x),kind:G.maskKind}});
  const shot=await p.screenshot({clip:{x:info.x0,y:info.y,width:info.x1-info.x0,height:1}});
  const {PNG}=(()=>{try{return require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/pngjs')}catch(_){return {PNG:null}}})();
  let px;if(PNG){px=PNG.sync.read(shot).data}else{const b64=shot.toString('base64');px=await p.evaluate(async b=>{const img=new Image();img.src='data:image/png;base64,'+b;await img.decode();const c=document.createElement('canvas');c.width=img.width;c.height=1;const g=c.getContext('2d');g.drawImage(img,0,0);return [...g.getImageData(0,0,img.width,1).data]},b64)}
  let run=1,maxRun=1,distinct=new Set();for(let i=4;i<px.length;i+=4){distinct.add(px[i]+','+px[i+1]+','+px[i+2]);if(px[i]===px[i-4]&&px[i+1]===px[i-3]&&px[i+2]===px[i-2]){run++;maxRun=Math.max(maxRun,run)}else run=1}
  // inside the ramp (R between 30 and 230): share of pixels unchanged 12 px further on. Flat tiles give long equal runs.
  const R=[];for(let i=0;i<px.length;i+=4)R.push(px[i]);let n=0,eq=0;for(let i=0;i+12<R.length;i++)if(R[i]>30&&R[i]<230&&R[i+12]>30&&R[i+12]<230){n++;if(Math.abs(R[i+12]-R[i])<=1)eq++}const flat=n?eq/n:1;
  const width=px.length/4;console.log(JSON.stringify({...info,width,maxRun,distinct:distinct.size,ramp:n,flat:+flat.toFixed(3)}));
  assert.deepEqual(errors,[]);assert.equal(info.kind,'gradient');assert.ok(info.renderer>=2,'zoomed out to a reduced level of detail: '+info.renderer);
  assert.ok(n>200&&flat<0.1,'gradient varies within tiles (flat share '+flat.toFixed(3)+' over '+n+' ramp pixels)');
  console.log('PASS: gradient modifiers render smoothly at reduced levels of detail');
 }finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
