/* v287: in core mode, opening a .bung sends the file bytes once (project.loadData) and the core decodes every layer
 * itself, instead of the app uploading decoded pixels. The reopened layers match the app's (verifyRasters). */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+mode+'');await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:800,height:600,dpi:72,white:false});tool(false);setSize(30);Object.assign(TP,{kind:'round',hrd:.6,flow:.7,sp:.1})});
  const blob64=await p.evaluate(async()=>{
   for(let i=0;i<4;i++){const L=newLayer('Paint '+i,null,{w:DW,h:DH});insertLayer(L,layers.length);const g=document.createElement('canvas');g.width=g.height=300;const q=g.getContext('2d');const gr=q.createRadialGradient(150,150,10,150,150,150);gr.addColorStop(0,'rgba(255,'+(60*i)+',40,1)');gr.addColorStop(1,'rgba(20,90,200,0)');q.fillStyle=gr;q.fillRect(0,0,300,300);RasterResources.composeRegion(L.rasterId,{x:60+i*120,y:40+i*90,w:300,h:300},g,60+i*120,40+i*90,'source-over',1)}
   doH({undo(){},redo(){}});await NativeShadow.whenIdle();const b=await encodeProject();const u=new Uint8Array(await b.arrayBuffer());let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)});
  const b0=bytes,p0={...per};
  const r=await p.evaluate(async b64=>{const bin=atob(b64),u=new Uint8Array(bin.length);for(let i=0;i<u.length;i++)u[i]=bin.charCodeAt(i);projectDirty=false;await loadProjectFile(new File([u],'reopen.bung'));doH({undo(){},redo(){}});await NativeShadow.whenIdle();window.__loaded=true;
   return {size:u.length}},blob64);
  const loadBytes=bytes-b0;Object.assign(r,await p.evaluate(async()=>{const raster=NativeShadow.stats().raster.projectLayers||0;await NativeShadow.verifyRasters('reopen');await NativeShadow.whenIdle();const s=NativeShadow.stats();return {raster,layers:layers.length,divergences:s.divergences,errors:s.errors}}));console.log(JSON.stringify(r),'open sent '+loadBytes+' bytes for a '+r.size+' byte file');
  assert.deepEqual(errors,[]);assert.deepEqual(r.errors,[]);assert.ok(r.raster>=4,'layers decoded by the core from the file '+r.raster);assert.deepEqual(r.divergences,[],'core layers equal the app\'s after opening');
  assert.ok(loadBytes<r.size*1.5+60000,'opening sends about the file size, not decoded pixels ('+loadBytes+')');
  await context.close();proc.stdin.end()}
  console.log('PASS: v287 opening a .bung in core mode: the core decodes the layers from the file bytes and matches the app')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
