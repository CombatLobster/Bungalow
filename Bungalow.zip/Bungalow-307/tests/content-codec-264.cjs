const a=require('node:assert/strict'),C=require('../src/engine-content-codec-264.js');
class Img{constructor(w){this.width=w}}const objs=new Map(),ids=new WeakMap();let n=0;
const refs={idOf(o){if(!ids.has(o)){const id='r'+(++n);ids.set(o,id);objs.set(id,o)}return {kind:o instanceof Img?'image':'object',id:ids.get(o)}},resolve:(k,id)=>objs.get(id)??null};
const img=new Img(5),node={engineId:'node_x'};Object.setPrototypeOf(node,{});
const I={type:'file',name:'a.png',img,src:node,xf:[1,0,0,1,0,0],nested:{list:[{a:1},{b:img}],skip:undefined,fn:()=>1,_cache:{big:1}},n:null};
const j=C.encode(I,refs);a.ok(C.valid(j));a.deepEqual(j.img,{$ref:'image',id:'r1'});a.equal(j.nested._cache,undefined);a.equal('fn' in j.nested,false);
const back=C.decode(j,refs);a.equal(back.img,img);a.equal(back.src,node);a.equal(back.nested.list[1].b,img);a.deepEqual(back.xf,I.xf);a.ok(C.same(I,back,refs));
a.throws(()=>C.encode({x:NaN},refs),/finite/);a.ok(!C.valid({$ref:'x'}));a.ok(!C.valid({a:Infinity}));a.ok(!C.valid({a:new Img(1)}));
a.deepEqual(JSON.parse(JSON.stringify(j)),j);
{const nodeLike={engineId:'node_1',name:'n'};const r2={...refs,isReference:o=>typeof o.engineId==='string'};const e=C.encode({src:nodeLike},r2);a.equal(e.src.$ref,'object');a.equal(C.decode(e,r2).src,nodeLike)}
console.log('PASS content codec: plain JSON with resource/node references, reversible');
