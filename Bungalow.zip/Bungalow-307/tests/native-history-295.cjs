/* v295 (E): undo history in the core. Lazy core mode, 10 strokes: once idle, the tiles of steps more than 3 from the
 * cursor are kept by the core (raster.stash) and freed in the app; undoing all 10 and redoing all 10 brings them back
 * (raster.unstash) and restores the exact pixels each way; the core holds the same pixels afterwards. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore=lazy']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(line[0]==='R'?line.slice(1):JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  const invokeRaw=b64=>new Promise(r=>{pending.push(r);bytes+=b64.length*3/4;requests++;per.raw=(per.raw||0)+b64.length*3/4;proc.stdin.write('R'+b64+'\n')});
  if(mode.includes('lazy')){await p.exposeFunction('__bungalowRawB64',invokeRaw);await p.addInitScript(()=>{const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};window.__bungalowNativeInvokeRaw=u=>window.__bungalowRawB64(b64(u)).then(t=>{const s=atob(t),o=new Uint8Array(s.length);for(let i=0;i<o.length;i++)o[i]=s.charCodeAt(i);return o.buffer})})}
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+mode);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:3000,height:2000,dpi:72,white:false});tool(false);setSize(30);Object.assign(TP,{kind:'round',hrd:.6,flow:.7,sp:.1})});
  const stroke=async pts=>{const c=await p.evaluate(pts=>{const r=wrap.getBoundingClientRect();return {hp,pts:pts.map(([x,y])=>{const o=docToOverlay({x,y});return [r.left+o.x,r.top+o.y]})}},pts);await p.mouse.move(...c.pts[0]);await p.mouse.down();for(const q of c.pts.slice(1))await p.mouse.move(...q,{steps:5});await p.mouse.up();await p.waitForFunction(h=>hp===h+1&&!drawing,c.hp,{timeout:10000})};
  const hashAll=()=>p.evaluate(()=>layers.map(L=>{const q=peekLayerCanvas(L);try{const d=q.cv.getContext('2d').getImageData(0,0,DW,DH).data;let h=2166136261;for(let i=0;i<d.length;i+=4)h=Math.imul(h^(d[i]|d[i+1]<<8|d[i+2]<<16|d[i+3]<<24),16777619)>>>0;return h}finally{q.release()}}).join(','));
  await p.evaluate(async()=>{await NativeShadow.whenIdle()});const h0=await hashAll();
  for(let k=0;k<10;k++)await stroke([[150+k*250,200],[300+k*250,1700],[500+k*250,900]]);
  const h1=await hashAll();
  await p.evaluate(()=>new Promise(r=>setTimeout(r,1200)));await p.evaluate(async()=>{await NativeShadow.whenIdle();for(let i=0;i<20&&!(NativeShadow.stats().raster.stashedSteps>=6);i++){await NativeShadow.offloadHistory();await new Promise(r=>setTimeout(r,200))}});
  const mid=await p.evaluate(()=>({s:{...NativeShadow.stats().raster},hp,mem:hist.reduce((n,e)=>n+(e?.bytes||0),0)}));
  await p.evaluate(async()=>{for(let i=0;i<10;i++)await undo()});const hu=await hashAll();
  await p.evaluate(async()=>{for(let i=0;i<10;i++)await redoF()});const hr=await hashAll();
  const end=await p.evaluate(async()=>{await NativeShadow.whenIdle();await NativeShadow.verifyRasters('end');await NativeShadow.whenIdle();const s=NativeShadow.stats();return {divergences:s.divergences,errors:s.errors,restored:s.raster.restoredSteps||0,stashed:s.raster.stashedSteps||0}});
  console.log(JSON.stringify({mid:{stashedSteps:mid.s.stashedSteps,stashedBytes:mid.s.stashedBytes,histBytes:mid.mem,hp:mid.hp},end,undoOk:hu===h0,redoOk:hr===h1}));
  assert.deepEqual(errors,[]);assert.deepEqual(end.errors,[]);assert.ok(mid.s.stashedSteps>=5,'older steps kept by the core: '+mid.s.stashedSteps);
  assert.ok(hu===h0,'undoing every step restores the original pixels');assert.ok(hr===h1,'redoing every step restores the painted pixels');assert.ok(end.restored>=5,'stashed steps came back from the core');assert.deepEqual(end.divergences,[],'the core holds the same pixels afterwards');
  await context.close();proc.stdin.end()}
  console.log('PASS: v295 undo history kept by the core: older steps freed in the app, undo/redo exact')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
