/* v297 (F): committing a bicubic transform of 6 layers at 2400x1500 (smaller than the desktop case: the test transport is slow base64). In lazy core mode the core samples its own copy of
 * each layer (raster.transform, a port of TransformSampling with the same arithmetic, in parallel). Its output must match the
 * app sampler's to within 2 levels in premultiplied terms. Only very low-alpha pixels differ, because the core's copy
 * of a layer can differ there by one level after the premultiply round trip. Undo/redo must be exact. Skips when the native server is not built. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore=lazy']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(line[0]==='R'?line.slice(1):JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  const invokeRaw=b64=>new Promise(r=>{pending.push(r);bytes+=b64.length*3/4;requests++;per.raw=(per.raw||0)+b64.length*3/4;proc.stdin.write('R'+b64+'\n')});
  if(mode.includes('lazy')){await p.exposeFunction('__bungalowRawB64',invokeRaw);await p.addInitScript(()=>{const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};window.__bungalowNativeInvokeRaw=u=>window.__bungalowRawB64(b64(u)).then(t=>{const s=atob(t),o=new Uint8Array(s.length);for(let i=0;i<o.length;i++)o[i]=s.charCodeAt(i);return o.buffer})})}
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+(mode==='app'?'':mode));await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:3000,height:2000,dpi:72,white:false});tool(false);setSize(30);Object.assign(TP,{kind:'round',hrd:.6,flow:.7,sp:.1})});
  const stroke=async pts=>{const c=await p.evaluate(pts=>{const r=wrap.getBoundingClientRect();return {hp,pts:pts.map(([x,y])=>{const o=docToOverlay({x,y});return [r.left+o.x,r.top+o.y]})}},pts);await p.mouse.move(...c.pts[0]);await p.mouse.down();for(const q of c.pts.slice(1))await p.mouse.move(...q,{steps:5});await p.mouse.up();await p.waitForFunction(h=>hp===h+1&&!drawing,c.hp,{timeout:10000})};
  const r=await p.evaluate(async mode=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:2400,height:1500,dpi:72,white:false});
   let seed=7;const rnd=()=>(seed=(seed*1103515245+12345)%2147483648)/2147483648;const list=[];
   for(let i=0;i<6;i++){const L=i?newLayer('P'+i,null,{w:DW,h:DH}):AL;if(i)insertLayer(L,layers.length);list.push(L);const g=document.createElement('canvas');g.width=g.height=900;const q=g.getContext('2d');for(let k=0;k<25;k++){q.fillStyle=`hsla(${(k*41+i*60)%360},70%,50%,.85)`;q.beginPath();q.arc(rnd()*900,rnd()*900,30+rnd()*120,0,7);q.fill()}RasterResources.composeRegion(L.rasterId,{x:100+i*250,y:100+i*90,w:900,h:900},g,100+i*250,100+i*90,'source-over',1)}
   doH({undo(){},redo(){}});renderLayers();
   const hash=()=>list.map(L=>{const q=peekLayerCanvas(L);try{const d=q.cv.getContext('2d').getImageData(0,0,DW,DH).data;let h=2166136261;for(let i=0;i<d.length;i+=4)h=Math.imul(h^(d[i]|d[i+1]<<8|d[i+2]<<16|d[i+3]<<24),16777619)>>>0;return h}finally{q.release()}}).join(',');
   const h0=hash();$('transformSampling').value='bicubic';if(typeof NativeShadow!=='undefined'&&NativeShadow.lazy?.())await NativeShadow.flush(true);
   setStackSelection(list,{active:list[0],anchor:list[0]});renderLayers();beginTransform();const t=transformSession;t.cx+=180;t.cy-=90;t.angle=.25;t.scaleX=.8;t.scaleY=.85;
   const cmp=[];for(const item of t.items){const b=t.bounds;let lx=0,ly=0,w=b.width,h=b.height;while(w>1&&Math.abs(t.scaleX)*b.width/w<.5){lx++;w=Math.ceil(w/2)}while(h>1&&Math.abs(t.scaleY)*b.height/h<.5){ly++;h=Math.ceil(h/2)}const img=TransformSampling.source(item.source,t),plan=TransformSampling.plan(img,t,DW,DH),js=TransformSampling.cpu(img,plan).data;const u=await NativeShadow.binary({method:'raster.transform',args:[item.layer.rasterId,{x:b.x,y:b.y,w:b.width,h:b.height},[lx,ly],plan]});
    let md=0,n=0,px=0;for(let i=0;i<js.length;i+=4){const a=js[i+3],c=u[i+3];let d=Math.abs(a-c);for(let k=0;k<3;k++)d=Math.max(d,Math.abs(js[i+k]*a-u[i+k]*c)/255);if(a||c)px++;if(d>md)md=d;if(d>1)n++}cmp.push({md:+md.toFixed(2),over1:n,px})}
   const t0=performance.now();commitTransform();await new Promise(r=>{const w=()=>transformSession?setTimeout(w,20):r();w()});const ms=Math.round(performance.now()-t0);
   // v302: transformed non-active layers are parked at the commit (only tile positions come back); bring them back to compare
   const parkedOnCommit=typeof LayerParking!=='undefined'?LayerParking.stats().parkedOnCommit||0:0;if(typeof LayerParking!=='undefined')await LayerParking.ensureAll();
   // v301: the commit happened in the core: nothing is left to flush back, and the core holds the app's pixels (premultiplied, within 1 level)
   let pendingAfter=null,coreDiff=null;if(NativeShadow.lazy?.()){pendingAfter=NativeShadow.pending().tiles+NativeShadow.pending().full;coreDiff=0;for(const L of list){const js=RasterResources.readRegion(L.rasterId).data,resp=await NativeShadow.request({method:'raster.read',args:[L.rasterId]}),bin=atob(resp.result.data);
     for(let i=0;i<js.length;i+=4){const a=js[i+3],c=bin.charCodeAt(i+3);let d=Math.abs(a-c);for(let k=0;k<3;k++)d=Math.max(d,Math.abs(js[i+k]*a-bin.charCodeAt(i+k)*c)/255);if(d>coreDiff)coreDiff=d}}coreDiff=+coreDiff.toFixed(2)}
   const h1=hash();await undo();const hu=hash();await redoF();const hr=hash();
   return {parkedOnCommit,pendingAfter,coreDiff,ms,h1,cmp,undo:hu===h0,redo:hr===h1,core:window.__coreTransforms||0,errors:typeof NativeShadow!=='undefined'?NativeShadow.stats().errors:[]}},mode);
  results[mode]=r;console.log(mode,JSON.stringify({...r,h1:undefined}));assert.deepEqual(errors,[]);
  await context.close();proc.stdin.end()}
  const c=results['nativeCore=lazy'];
  for(const x of c.cmp)assert.ok(x.md<=2&&x.over1<=x.px*0.001,'core sampler matches the app sampler (premultiplied, low-alpha rounding only): '+JSON.stringify(c.cmp));
  assert.ok(c.core>=6,'all layers transformed by the core: '+c.core);assert.ok(c.undo&&c.redo,'undo/redo exact');assert.deepEqual(c.errors,[]);assert.equal(c.parkedOnCommit,5,'v302: the 5 non-active layers parked at the commit');assert.equal(c.pendingAfter,0,'v301: a core commit leaves nothing to flush back');assert.ok(c.coreDiff<=2,'v301: the core holds the committed pixels: max premultiplied diff '+c.coreDiff);
  console.log('PASS: v297 multi-layer bicubic transform commit in the core: matches the app sampler, exact undo/redo')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
