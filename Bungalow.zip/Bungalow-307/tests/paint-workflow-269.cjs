/* v269: real pointer painting workflow. Brush and eraser strokes driven through the mouse on a raster layer and a
 * new layer, with undo/redo; strokes must commit through the RasterResources interface (named writes) and history
 * must restore pixels exactly. Also run under native shadow mode by tests/native-raster-shadow-269.cjs. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:400,height:300,dpi:72,white:false});tool(false);window.paint269={hash:L=>{const q=peekLayerCanvas(L);try{const d=q.cv.getContext('2d').getImageData(0,0,DW,DH).data;let h=0,n=0;for(let i=0;i<d.length;i+=4){h=(h*31+d[i]+d[i+1]*3+d[i+2]*7+d[i+3]*11)|0;if(d[i+3])n++}return h+':'+n}finally{q.release()}},ops:()=>Object.values(RasterResources.opCounts).reduce((a,b)=>a+b,0)}});
// Drag along document points with the real mouse; waits for the history step.
const stroke=async pts=>{const c=await p.evaluate(pts=>{const r=wrap.getBoundingClientRect();return {hp,pts:pts.map(([x,y])=>{const o=docToOverlay({x,y});return [r.left+o.x,r.top+o.y]})}},pts);await p.mouse.move(...c.pts[0]);await p.mouse.down();for(const q of c.pts.slice(1))await p.mouse.move(...q,{steps:6});await p.mouse.up();await p.waitForFunction(h=>hp===h+1&&!drawing,c.hp,{timeout:10000})};
const state=()=>p.evaluate(()=>({hash:paint269.hash(AL),ops:paint269.ops(),hp}));
const s0=await state();
await stroke([[40,40],[200,60],[300,200]]);const s1=await state();assert.notEqual(s1.hash,s0.hash,'brush stroke painted');assert.ok(s1.ops>s0.ops,'stroke committed through RasterResources');
await stroke([[60,250],[180,120],[350,80]]);const s2=await state();assert.notEqual(s2.hash,s1.hash,'second stroke');
await p.evaluate(()=>tool(true));await stroke([[100,50],[250,150]]);const s3=await state();assert.notEqual(s3.hash,s2.hash,'eraser stroke');
await p.evaluate(()=>undo());assert.equal((await state()).hash,s2.hash,'undo eraser');
await p.evaluate(()=>undo());assert.equal((await state()).hash,s1.hash,'undo stroke');
await p.evaluate(()=>redoF());assert.equal((await state()).hash,s2.hash,'redo stroke');
// a second layer: paint, erase, undo
await p.evaluate(()=>{tool(false);const L=newLayer('Paint 2',null,{w:DW,h:DH});insertLayer(L,layers.length);setStackSelection([L],{active:L,anchor:L});renderLayers()});
const t0=await state();await stroke([[20,280],[380,20]]);const t1=await state();assert.notEqual(t1.hash,t0.hash,'layer 2 stroke');
await p.evaluate(()=>tool(true));await stroke([[200,20],[200,280]]);await p.evaluate(()=>undo());assert.equal((await state()).hash,t1.hash,'layer 2 undo erase');
await p.evaluate(()=>tool(false));
assert.deepEqual(errors,[]);console.log('PASS: pointer painting: brush/eraser strokes through RasterResources, undo/redo pixel restore, two layers ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
