/* v270: compositor coverage scenario. Two to four raster layers with colour/alpha ramps through every blend mode,
 * opacity, inherit alpha (layers and groups), pass-through / opacity / blend / isolated / nested / hidden groups.
 * Standalone it checks the app compositor responds to each setting; under tests/native-composite-shadow-270.cjs the
 * Rust compositor must match it at every step (NativeShadow.verifyComposite). */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
const result=await p.evaluate(async()=>{
 const check=(v,m)=>{if(!v)throw Error(m)};closeLanding();projectDirty=false;await createDocumentFromOptions({width:96,height:64,dpi:72,white:false});
 const W=DW,H=DH,ramp=(f)=>{const im=new ImageData(W,H);for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=(y*W+x)*4,c=f(x/(W-1),y/(H-1));im.data.set(c.map(v=>Math.max(0,Math.min(255,Math.round(v)))),i)}return im};
 const fill=(L,f)=>RasterResources.putPixels(L.rasterId,ramp(f),0,0); // through the registry, so native surfaces follow
 const add=(name,f)=>{const L=newLayer(name,null,{w:W,h:H});insertLayer(L,layers.length);fill(L,f);thumb(L);return L};
 const base=AL;fill(base,(u,v)=>[255*u,180*v,90+120*(1-u),200+55*v]);thumb(base);
 const mid=add('Mid',(u,v)=>[40+200*v,255*(1-u),255*u*v,255*(.3+.7*Math.abs(u-.5)*2)]);
 const top=add('Top',(u,v)=>[255*(1-v),120+100*u,255*v,255*u]);
 const shadow=typeof NativeShadow!=='undefined'&&NativeShadow.enabled(),steps=[];
 const hashes=new Set(),step=async label=>{renderLayers();const c=flat(true),d=c.getContext('2d').getImageData(0,0,W,H).data;let h=0;for(let i=0;i<d.length;i++)h=(h*31+d[i])|0;hashes.add(h);steps.push(label);if(shadow)await NativeShadow.verifyComposite(label)};
 await step('plain');
 for(const mode of ['multiply','screen','overlay','darken','lighten','color-dodge','color-burn','hard-light','soft-light','difference','exclusion','hue','saturation','color','luminosity','linear-dodge','linear-burn','vivid-light','subtract','divide','glow']){top.blend=mode;await step('blend '+mode)}
 top.blend='normal';top.op=.5;await step('opacity');top.op=1;
 top.inheritAlpha=true;await step('inherit normal');top.blend='multiply';await step('inherit multiply');top.blend='glow';await step('inherit glow');top.blend='normal';top.inheritAlpha=false;
 mid.vis=false;await step('hidden layer');mid.vis=true;top.op=0;await step('zero opacity');top.op=1;
 setStackSelection([mid,top],{active:top,anchor:mid});createLayerGroup();renderLayers();const G=top.group;check(G&&mid.group===G,'group made');await step('pass-through group');
 G.op=.6;await step('group opacity');G.op=1;G.blend='screen';await step('group screen');G.blend='difference';await step('group difference');G.blend='normal';
 top.blend='multiply';await step('blend inside pass-through');G.isolate=true;await step('isolated group');G.isolate=false;top.blend='normal';
 G.inheritAlpha=true;await step('group inherit');G.blend='overlay';await step('group inherit overlay');G.blend='normal';G.inheritAlpha=false;
 top.inheritAlpha=true;await step('inherit inside group');top.inheritAlpha=false;
 const extra=add('Extra',(u,v)=>[255*u*u,255*v*v,128,160]);setStackSelection([G,extra],{active:extra,anchor:G});createLayerGroup();renderLayers();const outer=extra.group;check(outer&&G.group===outer,'nested group');
 outer.op=.7;G.op=.8;G.blend='color-burn';await step('nested groups');G.vis=false;await step('hidden nested group');G.vis=true;outer.blend='luminosity';await step('outer luminosity');
 await undo();await step('undo');await redoF();await step('redo');
 return {steps:steps.length,distinct:hashes.size,shadow};
});
assert.ok(result.distinct>=result.steps-6,'compositor responds to settings: '+JSON.stringify(result));
assert.deepEqual(errors,[]);console.log('PASS: composite coverage: '+result.steps+' configurations, '+result.distinct+' distinct results ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
