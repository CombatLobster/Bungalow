/* v305: with parked layers, the flattened export is composited by the core (no layer loaded) and matches the app's
 * composite; merge down loads only the layer it merges into, the other parked layers stay parked. Tripwire on. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore=lazy']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(line[0]==='R'?line.slice(1):JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  const invokeRaw=b64=>new Promise(r=>{pending.push(r);bytes+=b64.length*3/4;requests++;per.raw=(per.raw||0)+b64.length*3/4;proc.stdin.write('R'+b64+'\n')});
  if(mode.includes('lazy')){await p.exposeFunction('__bungalowRawB64',invokeRaw);await p.addInitScript(()=>{const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};window.__bungalowNativeInvokeRaw=u=>window.__bungalowRawB64(b64(u)).then(t=>{const s=atob(t),o=new Uint8Array(s.length);for(let i=0;i<o.length;i++)o[i]=s.charCodeAt(i);return o.buffer})})}
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+mode);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  const r=await p.evaluate(async()=>{window.__parkTripwireThrow=true;closeLanding();projectDirty=false;await createDocumentFromOptions({width:3000,height:2000,dpi:72,white:false});
   const wait=ms=>new Promise(r=>setTimeout(r,ms));
   const list=[AL];for(let i=1;i<5;i++){const L=newLayer('P'+i,null,{w:DW,h:DH});insertLayer(L,layers.length);list.push(L)}
   list.forEach((L,i)=>{const g=document.createElement('canvas');g.width=g.height=800;const q=g.getContext('2d');for(let k=0;k<20;k++){q.fillStyle=`hsla(${(k*41+i*70)%360},70%,50%,.75)`;q.beginPath();q.arc(80+k*32,90+(k*53)%600,50+k*3,0,7);q.fill()}RasterResources.composeRegion(L.rasterId,{x:200+i*450,y:150+i*250,w:800,h:800},g,200+i*450,150+i*250,'source-over',1)});
   list[2].blend='multiply';list[3].op=.7;doH({undo(){},redo(){}});select(list[4]);renderLayers();await NativeShadow.flush(true);
   const pix=c=>c.getContext('2d',{willReadFrequently:true}).getImageData(0,0,DW,DH).data;
   const cmp=(a,b)=>{let m=0,s=0;for(let i=0;i<a.length;i+=4){const aa=a[i+3],bb=b[i+3];let d=Math.abs(aa-bb);for(let k=0;k<3;k++)d=Math.max(d,Math.abs(a[i+k]*aa-b[i+k]*bb)/255);if(d>m)m=d;s+=d}return {max:+m.toFixed(1),mean:+(s/(a.length/4)).toFixed(4)}};
   const ref=pix(flat(true));
   const parkUntil=done=>{LayerParking.setLimitGiB(0.0001);for(let i=0;i<10&&!done();i++)LayerParking.tick();LayerParking.setLimitGiB(0)};
   parkUntil(()=>LayerParking.parkedCount()>=4);const parked0=LayerParking.parkedCount(),un0=LayerParking.stats().unparked;
   // export with parked layers: composited by the core, nothing loaded
   const core=pix(await flatForExport(true)),exportLoaded=LayerParking.stats().unparked-un0,coreExports=window.__coreFlatExports||0,exportCmp=cmp(core,ref);
   // merge down onto a parked layer: only that layer is loaded
   select(list[2]);await LayerParking.ensure([list[2]]);parkUntil(()=>LayerParking.isParked(list[1])&&LayerParking.isParked(list[0]));
   const un1=LayerParking.stats().unparked,parkedBefore=LayerParking.parkedCount();await mergeDown();for(let i=0;i<100&&layers.length===5;i++)await wait(50);const mergeLoaded=LayerParking.stats().unparked-un1,stillParked=LayerParking.parkedCount(),layerCount=layers.length;
   await LayerParking.ensureAll();const after=cmp(pix(flat(true)),ref);
   return {parked0,exportLoaded,coreExports,exportCmp,parkedBefore,mergeLoaded,stillParked,layerCount,after,stats:LayerParking.stats(),errs:NativeShadow.stats().errors}});
  console.log(JSON.stringify({...r,stats:{...r.stats,trips:r.stats.trips.slice(0,6)}}));
  assert.deepEqual(errors,[]);assert.deepEqual(r.errs,[]);assert.deepEqual(r.stats.errors,[]);
  assert.equal(r.parked0,4);assert.equal(r.exportLoaded,0,'export loads no parked layer');assert.equal(r.coreExports,1,'composited by the core');
  assert.ok(r.exportCmp.max<=4&&r.exportCmp.mean<0.05,'core export matches the app composite: '+JSON.stringify(r.exportCmp));
  assert.equal(r.mergeLoaded,1,'merge down loads only the layer below');assert.equal(r.layerCount,4);assert.ok(r.stillParked>=1,'other parked layers stay parked: '+r.stillParked);
  assert.ok(r.after.max<=2,'the merged document looks the same: '+JSON.stringify(r.after));
  assert.equal(r.stats.tripwires,0,'no direct reads of parked tiles: '+JSON.stringify(r.stats.trips));
  await context.close();proc.stdin.end()}
  console.log('PASS: v305 PNG/JPEG export composited by the core with parked layers (none loaded); merge loads only the layers it merges')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exit(1)});
