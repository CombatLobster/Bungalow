/* v302: a multi-layer transform committed in the core parks every transformed layer but the active one (only their
 * tile positions come back). Their thumbnails come from a coarse core copy; undo brings them back first and is exact;
 * redo re-applies the transform. Tripwire on: nothing reads the parked tiles directly. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore=lazy']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(line[0]==='R'?line.slice(1):JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  const invokeRaw=b64=>new Promise(r=>{pending.push(r);bytes+=b64.length*3/4;requests++;per.raw=(per.raw||0)+b64.length*3/4;proc.stdin.write('R'+b64+'\n')});
  if(mode.includes('lazy')){await p.exposeFunction('__bungalowRawB64',invokeRaw);await p.addInitScript(()=>{const b64=u=>{let s='';for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};window.__bungalowNativeInvokeRaw=u=>window.__bungalowRawB64(b64(u)).then(t=>{const s=atob(t),o=new Uint8Array(s.length);for(let i=0;i<o.length;i++)o[i]=s.charCodeAt(i);return o.buffer})})}
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+mode);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  const r=await p.evaluate(async()=>{window.__parkTripwireThrow=true;closeLanding();projectDirty=false;await createDocumentFromOptions({width:3000,height:2000,dpi:72,white:false});
   const wait=ms=>new Promise(r=>setTimeout(r,ms)),frames=async n=>{for(let i=0;i<n;i++)await new Promise(r=>requestAnimationFrame(r))};
   const list=[AL];for(let i=1;i<4;i++){const L=newLayer('P'+i,null,{w:DW,h:DH});insertLayer(L,layers.length);list.push(L)}
   list.forEach((L,i)=>{const g=document.createElement('canvas');g.width=g.height=700;const q=g.getContext('2d');for(let k=0;k<20;k++){q.fillStyle=`hsla(${(k*41+i*80)%360},70%,50%,.8)`;q.beginPath();q.arc(80+k*30,90+(k*53)%520,40+k*3,0,7);q.fill()}RasterResources.composeRegion(L.rasterId,{x:300+i*500,y:200+i*300,w:700,h:700},g,300+i*500,200+i*300,'source-over',1)});
   doH({undo(){},redo(){}});renderLayers();await NativeShadow.flush(true);await frames(5);
   const hash=L=>{const q=peekLayerCanvas(L);try{const d=q.cv.getContext('2d').getImageData(0,0,DW,DH).data;let h=2166136261;for(let i=0;i<d.length;i+=4)h=Math.imul(h^(d[i]|d[i+1]<<8|d[i+2]<<16|d[i+3]<<24),16777619)>>>0;return h}finally{q.release()}};
   const before=list.map(hash);LayerParking.setLimitGiB(4); // parking available, nowhere near the limit
   $('transformSampling').value='bicubic';setStackSelection(list,{active:list[3],anchor:list[3]});renderLayers();beginTransform();const t=transformSession;t.cx+=120;t.cy-=60;t.angle=.3;t.scaleX=.9;t.scaleY=.8;
   commitTransform();while(transformSession)await wait(20);const s1=LayerParking.stats(),parked=list.map(L=>LayerParking.isParked(L));
   // previews of parked layers: a coarse copy from the core, drawn without touching the parked tiles
   for(const L of list)refreshLayerThumbPixels(L);for(let i=0;i<100&&!(LayerParking.stats().previews>=3);i++)await wait(50);for(const L of list)refreshLayerThumbPixels(L);const previews=LayerParking.stats().previews||0;
   const thumbInk=(()=>{const L=list[0],d=L.th.getContext('2d').getImageData(0,0,L.th.width,L.th.height).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i])n++;return n})();
   await undo();const undone=list.map(hash);await redoF();const r1=list.map(hash);await undo();await redoF();const r2=list.map(hash);
   LayerParking.setLimitGiB(0);
   return {parked,s1:{parkedOnCommit:s1.parkedOnCommit},previews,thumbInk,undoExact:JSON.stringify(undone)===JSON.stringify(before),redoChanged:r1.some((h,i)=>h!==before[i]),redoStable:JSON.stringify(r1)===JSON.stringify(r2),stats:LayerParking.stats(),errs:NativeShadow.stats().errors}});
  console.log(JSON.stringify({...r,stats:{...r.stats,trips:r.stats.trips.slice(0,6)}}));
  assert.deepEqual(errors,[]);assert.deepEqual(r.errs,[]);assert.deepEqual(r.stats.errors,[]);
  assert.deepEqual(r.parked,[true,true,true,false],'v302: transformed layers other than the active one are parked at the commit');assert.equal(r.s1.parkedOnCommit,3);
  assert.ok(r.previews>=3&&r.thumbInk>0,'parked layers get coarse thumbnails from the core: '+r.previews+' previews, '+r.thumbInk+' painted thumbnail pixels');
  assert.ok(r.undoExact,'undo of a parked commit brings the layers back first and restores them exactly');assert.ok(r.redoChanged&&r.redoStable,'redo re-applies the transform, the same each time');
  assert.equal(r.stats.tripwires,0,'no direct reads of parked tiles: '+JSON.stringify(r.stats.trips));
  await context.close();proc.stdin.end()}
  console.log('PASS: v302 transform commit parks the non-active layers (no result transfer), coarse previews from the core, exact undo/redo')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exit(1)});
