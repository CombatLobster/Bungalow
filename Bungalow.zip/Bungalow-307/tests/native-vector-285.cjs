/* v285: in core mode, retained vector layers are rendered by the core from recorded geometry (src/native-vector-285.js,
 * vector.layer → tiny-skia) instead of their pixels being uploaded. Shapes of every kind, imported SVG paths, stroke alignments, gradients,
 * opacity, rotation and flips match the app's canvas rendering apart from anti-aliased edge pixels: total coverage within
 * 1.5% and opaque interiors within 3 levels apart from the anti-aliased fill/stroke boundary. Edge pixels differ because the browser canvas rasterises on the GPU. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..'),bin=path.join(root,'native/bungalow-core/target/release/bungalow-core-server');
if(!fs.existsSync(bin)){console.log('SKIP: native core mode (bungalow-core-server not built; run tests/native-core-269.cjs)');process.exit(0)}
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const results={};
 try{for(const mode of ['nativeCore']){
  const proc=spawn(bin,[],{stdio:['pipe','pipe','inherit']}),pending=[];let buf='',bytes=0,requests=0;const per={};
  proc.stdout.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);const r=pending.shift();if(r)r(JSON.parse(line))}});
  const invoke=req=>new Promise(r=>{pending.push(r);const s=JSON.stringify(req);bytes+=s.length;requests++;const m=req.method||'batch';per[m]=(per[m]||0)+s.length;proc.stdin.write(s+'\n')});
  const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.exposeFunction('__bungalowNativeInvoke',invoke);
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html?'+mode+'');await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
  await p.evaluate(async()=>{closeLanding();projectDirty=false;await createDocumentFromOptions({width:800,height:600,dpi:72,white:false});tool(false);setSize(30);Object.assign(TP,{kind:'round',hrd:.6,flow:.7,sp:.1})});
  const r=await p.evaluate(async()=>{
   const D=BungalowVectors.defaults,grad={type:'linear',a:{x:0,y:0},b:{x:1,y:1},space:'oklab',stops:[{t:0,v:'#ff3300'},{t:1,v:'#2244ff'}]},rad={...grad,type:'radial',a:{x:.5,y:.5},b:{x:1,y:.5}};
   const specs=[['rect fill',{kind:'rectangle',paint:'fill',x:40,y:40,w:120,h:80}],['rect both',{kind:'rectangle',paint:'both',strokeWidth:6,x:200,y:40,w:120,h:80}],
    ['ellipse stroke',{kind:'ellipse',paint:'stroke',strokeWidth:5,x:360,y:40,w:150,h:90}],['rounded inside',{kind:'rounded',paint:'both',strokeAlign:'inside',strokeWidth:10,radius:20,x:540,y:40,w:140,h:100}],
    ['star outside',{kind:'star',paint:'both',strokeAlign:'outside',strokeWidth:8,sides:5,inner:.45,x:40,y:200,w:140,h:140}],['polygon',{kind:'polygon',paint:'fill',sides:7,x:220,y:200,w:120,h:120}],
    ['heart',{kind:'heart',paint:'both',strokeWidth:3,x:380,y:200,w:120,h:110}],['line',{kind:'line',paint:'stroke',strokeWidth:7,x:540,y:200,w:160,h:90}],
    ['arrow gradient',{kind:'arrow',paint:'fill',fillMode:'gradient',gradient:grad,x:40,y:380,w:180,h:90}],['ellipse radial',{kind:'ellipse',paint:'fill',fillMode:'gradient',gradient:rad,x:260,y:380,w:140,h:120}],
    ['grid',{kind:'grid',paint:'stroke',strokeWidth:2,xDivisions:4,yDivisions:3,x:440,y:380,w:160,h:120}],['cross alpha',{kind:'cross',paint:'both',fillOpacity:.5,strokeOpacity:.7,strokeWidth:4,x:620,y:380,w:120,h:120}],
    ['rotated',{kind:'rectangle',paint:'both',strokeWidth:5,x:300,y:250,w:100,h:60},{xf:[Math.cos(.4),Math.sin(.4),-Math.sin(.4),Math.cos(.4),0,0]}],['flipped tri',{kind:'triangle',paint:'both',strokeWidth:4,x:100,y:500,w:100,h:80},{flipH:true}],['svg path',{kind:'path',paint:'both',strokeWidth:3,d:'M10 10 C 40 0 60 40 90 20 A 20 20 0 0 1 90 60 q -40 30 -80 0 s -10 -20 0 -30 Z m 30 20 h 20 v 10 h -20 z',evenodd:true,m:[1,0,0,1,0,0],bx:0,by:5,bw:100,bh:85,x:420,y:500,w:150,h:120}],['svg gradient',{kind:'path',paint:'fill',fillMode:'gradient',gradient:grad,d:'M0 0 L100 0 L50 80 Z',m:[1,0,0,1,0,0],bx:0,by:0,bw:100,bh:80,x:620,y:520,w:120,h:70}]];
   const made=[];for(const [name,shape,extra] of specs){const L=newLayer(name,null,{w:DW,h:DH});L.instance={type:'shape',shape:{...D,colour:'#33aa66',strokeColour:'#222288',...shape},flipH:false,flipV:false,dx:0,dy:0,xf:null,...extra};L._vecRect=undefined;insertLayer(L,layers.length);drawVectorLayer(L);made.push([name,L])}
   renderLayers();doH({undo(){},redo(){}});await NativeShadow.whenIdle();
   const out=[];for(const [name,L] of made){const js=RasterResources.readRegion(L.rasterId),resp=await NativeShadow.request({method:'raster.read',args:[L.rasterId]});if(!resp.ok){out.push({name,error:resp.error});continue}
    const bin=atob(resp.result.data);let max=0,over=0,painted=0,sa=0,sb=0,inner=0,innerBad=0;for(let i=0;i<js.data.length;i+=4){const a=js.data[i+3],b=bin.charCodeAt(i+3);if(a||b)painted++;sa+=a;sb+=b;let d=0;for(let k=0;k<4;k++){const x=js.data[i+k]*(k<3?a/255:1),y=bin.charCodeAt(i+k)*(k<3?b/255:1);d=Math.max(d,Math.abs(x-y))}if(d>max)max=d;if(d>16)over++;if(a===255&&b===255){inner++;if(d>3)innerBad++}}
    out.push({name,max:Math.round(max),over,painted,cov:+(sb/Math.max(1,sa)).toFixed(4),inner,innerBad})}
   return {out,vec:NativeVector.stats(),stats:NativeShadow.stats().raster,errors:NativeShadow.stats().errors}});
  const b0=bytes;await p.evaluate(async()=>{for(const L of layers.filter(L=>L.instance?.type==='shape').slice(0,6)){L.instance.dx=(L.instance.dx||0)+15;L.instance.shape={...L.instance.shape,colour:'#aa3366'};drawVectorLayer(L)}doH({undo(){},redo(){}});await NativeShadow.whenIdle()});const editBytes=bytes-b0;console.log('edit of 6 vector layers: '+editBytes+' bytes');assert.ok(editBytes<60000,'vector edits send geometry, not pixels ('+editBytes+')');
  for(const o of r.out)console.log(JSON.stringify(o));console.log(JSON.stringify(r.vec),r.stats.vectorLayers);
  assert.deepEqual(errors,[]);assert.deepEqual(r.errors,[]);assert.ok(r.stats.vectorLayers>=r.out.length&&r.vec.fallbacks===0,'vector layers rendered in the core '+JSON.stringify(r.vec));
  for(const o of r.out){assert.ok(!o.error,o.name+' '+o.error);assert.ok(o.painted>100,o.name+' painted');assert.ok(Math.abs(o.cov-1)<0.015,o.name+': same coverage within anti-aliasing ('+o.cov+')');assert.ok(o.innerBad<=o.inner*0.06,o.name+': interior colour matches (fill/stroke boundary pixels aside) ('+o.innerBad+' of '+o.inner+')')}
  await context.close();proc.stdin.end()}
  console.log('PASS: v285 vector layers rendered in the core (tiny-skia) from recorded geometry match the app within anti-aliasing')}
 finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
