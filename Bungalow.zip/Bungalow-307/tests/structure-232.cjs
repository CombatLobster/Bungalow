const assert=require('node:assert/strict'),core=require('../src/engine-structure-235.js'),clone=x=>JSON.parse(JSON.stringify(x));
const L=(id,parent=null,vis=true)=>({id,kind:'layer',parent,vis});
const G=(id,parent=null,vis=true)=>({id,kind:'group',parent,vis,collapsed:false,emptyPosition:null});
const state={version:1,layers:['a','b','c'],groups:['g','h','empty'],nodes:[L('a','g'),L('b','h',false),L('c'),G('g',null,false),G('h','g'),G('empty','g')],selection:['g'],anchor:'g',active:'a'},original=clone(state);
const command=core.dispatch(state,{type:'ungroup',ids:['g','h','g']});assert.deepEqual(state,original);assert.equal(command.changed,true);assert.deepEqual(command.redo.groups,['h','empty']);assert.deepEqual(command.redo.selection,['a','h','empty']);assert.equal(command.redo.anchor,'a');assert.equal(command.redo.nodes.find(n=>n.id==='a').vis,false);assert.equal(command.redo.nodes.find(n=>n.id==='h').vis,false);assert.equal(command.redo.nodes.find(n=>n.id==='h').parent,null);assert.equal(command.redo.nodes.find(n=>n.id==='b').parent,'h');
assert.deepEqual(core.stateFor(clone(command),'undo'),core.snapshot(state));assert.deepEqual(core.stateFor(clone(command),'redo'),command.redo);
const copied=core.stateFor(command,'undo');copied.nodes[0].vis=false;assert.deepEqual(command.undo,core.snapshot(state));
const empty=core.dispatch({...state,selection:['empty'],anchor:'empty'},{type:'ungroup',ids:['empty']});assert.deepEqual(empty.redo.selection,[]);assert.equal(empty.redo.anchor,null);assert.equal(empty.redo.active,'a');
const several=core.dispatch(state,{type:'ungroup',ids:['h','empty']});assert.deepEqual(several.redo.groups,['g']);assert.equal(several.redo.nodes.find(n=>n.id==='b').parent,'g');
assert.equal(core.dispatch(state,{type:'ungroup',ids:[]}).changed,false);
for(const request of [{type:'unknown',ids:[]},{type:'ungroup',ids:['a']},{type:'ungroup',ids:['missing']}])assert.throws(()=>core.dispatch(state,request));
for(const edit of [s=>s.nodes[0].parent='missing',s=>s.nodes.find(n=>n.id==='g').parent='h',s=>s.layers.push('a'),s=>s.selection.push('missing'),s=>s.active='g',s=>s.nodes[0].vis=1,s=>s.nodes.find(n=>n.id==='g').emptyPosition=NaN]){const invalid=clone(state);edit(invalid);assert.throws(()=>core.snapshot(invalid));assert.deepEqual(state,original)}
const split=clone(state);split.layers=['a','c','b'];assert.throws(()=>core.snapshot(split));
assert.throws(()=>core.stateFor(command,'invalid'));
const decorated=clone(state);decorated.nodes[0].canvas={secret:'resource'};assert.equal(JSON.stringify(core.dispatch(decorated,{type:'ungroup',ids:['g']})).includes('secret'),false);
console.log('PASS: structural ungroup planning, hierarchy/selection/visibility, JSON undo/redo and invalid-input atomicity');
