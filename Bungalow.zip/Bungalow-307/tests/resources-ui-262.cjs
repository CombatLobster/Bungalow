const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');const root=path.resolve(__dirname,'..');
(async()=>{const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404);res.end();return}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(file))});await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.BUNGALOW_CHROMIUM||path.resolve('test_runtime/chromium/chromium'),headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{for(const source of [false,true]){const context=await browser.newContext({viewport:{width:1500,height:1100}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(source?'http://127.0.0.1:'+server.address().port+'/index.html':require('node:url').pathToFileURL(path.join(root,'Bungalow-native-307.html')).href);await p.waitForFunction(()=>typeof SourceLayerUI!=='undefined'&&presetReady);
console.log(await p.evaluate(async()=>{
 const check=(v,m)=>{if(!v)throw Error(m)};closeLanding();projectDirty=false;await createDocumentFromOptions({width:640,height:480,dpi:72,white:false});
 const pix=L=>{const p=peekLayerCanvas(L);try{return Array.from(p.cv.getContext('2d').getImageData(0,0,DW,DH).data.filter((_,i)=>i%97===0)).join()}finally{p.release()}};
 // every layer owns a registered raster resource; node fields are views of the registry payload
 const L=newLayer('Res',null,{w:DW,h:DH});insertLayer(L,layers.length);setStackSelection([L],{active:L,anchor:L});renderLayers();
 check(BungalowResources.validResource(L.rasterId)&&documentStore.prop(L.engineId,'rasterId')===L.rasterId,'Resource ID in node and store');
 const P=RasterResources.payload(L.rasterId);check(P&&P.sparse===L._sparse&&P.canvas===L._canvas&&RasterResources.owner(L._sparse)===L.rasterId,'Payload owned by registry');
 check(RasterResources.ledger.get(L.rasterId).storage==='sparse','Ledger records sparse storage');
 // tile history goes through RasterSnapshot handles
 const blank=pix(L);sparseFillRect(L,{x:10,y:10,w:300,h:200},'#ff0000','source-over',1);const saved=sparseSnapshot(L._sparse,{x:0,y:0,w:DW,h:DH});
 check(saved instanceof RasterSnapshot&&saved.resource===L.rasterId&&RasterResources.ledger.snapshot(saved.id),'Snapshot handle registered');
 sparseFillRect(L,{x:200,y:100,w:200,h:200},'#0000ff','source-over',1);const entry=sparseRecord(L,{x:0,y:0,w:DW,h:DH},saved);const filled=pix(L);
 check(entry.resource===L.rasterId&&entry.snapshot===saved.id&&entry.bytes===RasterResources.ledger.snapshot(saved.id).bytes,'History entry holds plain resource/snapshot IDs');
 await undo();check(pix(L)!==filled,'Undo swaps tiles');await redoF();check(pix(L)===filled,'Redo restores tiles');
 // legacy Map producers are adopted (clear, invert, fill)
 const before=hp;sparseClearLayer(L);check(hp===before+1&&pix(L)===blank,'Clear recorded');await undo();check(pix(L)===filled,'Clear undo');
 check(sparseInvertLayer(L),'Invert ran');const inv=pix(L);await undo();check(pix(L)===filled,'Invert undo');await redoF();check(pix(L)===inv,'Invert redo');await undo();
 // ledger accounting and storage transitions
 const st=RasterResources.stats();check(st.resources>=layers.length&&st.snapshots>=1&&st.issues.length===0,'Ledger totals '+JSON.stringify(st));
 const cv=L.cv;check(RasterResources.ledger.get(L.rasterId).storage==='dense'||!L._sparse,'Thaw switches storage');check(RasterResources.refresh(L.rasterId).storage==='dense'&&RasterResources.payload(L.rasterId).canvas===cv,'Dense payload after thaw');
 await undo();await redoF();
 // duplicate gets its own resource; save/open keeps one resource per layer
 setStackSelection([L],{active:L,anchor:L});dupLayer();const D=AL;check(D!==L&&D.rasterId!==L.rasterId&&RasterResources.payload(D.rasterId),'Duplicate owns a new resource');
 const blob=await encodeProject();projectDirty=false;await loadProjectFile(new File([blob],'res.bung'));const ids=layers.map(n=>n.rasterId);check(ids.every(BungalowResources.validResource)&&new Set(ids).size===ids.length,'Opened layers have unique resources');
 check(layers.every(n=>RasterResources.payload(n.rasterId)&&(n._sparse||n._canvas)===(RasterResources.payload(n.rasterId).sparse||RasterResources.payload(n.rasterId).canvas)),'Opened payloads in registry');
 check(documentStoreDrift===0&&documentPropRejects===0,'No store drift/rejects '+JSON.stringify(documentStoreDriftLog.slice(0,2))+JSON.stringify(documentPropRejectLog.slice(0,2)));
 const json=RasterResources.ledger.toJSON();check(JSON.stringify(JSON.parse(JSON.stringify(json)))===JSON.stringify(json)&&Object.keys(json.resources).length>=layers.length,'Ledger is plain JSON');
 // ---- v258 dense region history through the resource interface ----
 projectDirty=false;await createDocumentFromOptions({width:320,height:240,dpi:72,white:false});
 const cvD=document.createElement('canvas');cvD.width=DW;cvD.height=DH;const D2=newLayer('Dense',cvD);insertLayer(D2,layers.length);setStackSelection([D2],{active:D2,anchor:D2});renderLayers();
 check(!D2._sparse&&RasterResources.ledger.get(D2.rasterId).storage==='dense','Dense resource');
 D2.ctx.fillStyle='#336699';D2.ctx.fillRect(20,20,120,80);const base=pix(D2);invertActiveLayer();const invD=pix(D2);const e=hist[hp-1];
 check(invD!==base&&e.resource===D2.rasterId&&BungalowResources.validSnapshot(e.snapshot)&&RasterResources.ledger.snapshot(e.snapshot).kind==='region','Invert recorded as region snapshot');
 await undo();check(pix(D2)===base,'Region undo via writeRegion');await redoF();check(pix(D2)===invD,'Region redo');await undo();
 // writeRegion is the region primitive for both storages
 const p=document.createElement('canvas');p.width=p.height=16;p.getContext('2d').fillStyle='#ff00ff';p.getContext('2d').fillRect(0,0,16,16);RasterResources.writeRegion(D2.rasterId,p,4,4);check(D2.ctx.getImageData(10,10,1,1).data[0]===255,'writeRegion dense');
 const S2=newLayer('Sp',null,{w:DW,h:DH});insertLayer(S2,layers.length);RasterResources.writeRegion(S2.rasterId,p,300,200);check(S2._sparse&&S2._sparse.tiles.size>0,'writeRegion sparse');
 // rasterRegionEdit used by composite entries (adjustments, mirror, modifier bake, cut)
 const b=patch(D2.cv,0,0,DW,DH);D2.ctx.clearRect(0,0,DW,DH);const a2=patch(D2.cv,0,0,DW,DH);const edit=rasterRegionEdit(D2,b,a2,0,0);check(edit.resource===D2.rasterId&&RasterResources.ledger.snapshot(edit.snapshot).rect.w===DW,'rasterRegionEdit snapshot');edit.undo();check(D2.ctx.getImageData(10,10,1,1).data[0]===255,'rasterRegionEdit undo');edit.redo();check(D2.ctx.getImageData(10,10,1,1).data[3]===0,'rasterRegionEdit redo');
 check(RasterResources.stats().issues.length===0,'Ledger clean');
 // ---- v259 selection mask resource and surface snapshots ----
 const m=document.createElement('canvas');m.width=DW;m.height=DH;m.getContext('2d').fillRect(10,10,50,50);installSelection(m);
 const mid=RasterResources.selectionMaskId();check(selectionMask===m&&BungalowResources.validResource(mid)&&RasterResources.ledger.get(mid).kind==='mask','Selection mask is a mask resource');
 installSelection(null);check(selectionMask===null&&RasterResources.selectionMaskId()===null&&!RasterResources.ledger.get(mid),'Clearing selection releases mask resource');installSelection(m);check(RasterResources.selectionMaskId()===mid,'Same mask canvas keeps its ID');installSelection(null);
 const sizeBefore=[DW,DH],pxS=pix(S2),pxD=pix(D2),snapsBefore=RasterResources.stats().snapshots;
 $('canvasWidth').value=400;$('canvasHeight').value=300;$('canvasDPI').value=72;resizeCanvas();renderLayers();
 check(DW===400&&DH===300,'Resized');const st2=RasterResources.stats();check(st2.snapshots>snapsBefore&&st2.issues.length===0,'Document geometry states registered as surface snapshots');
 check(layers.every(n=>RasterResources.payload(n.rasterId)&&(n._sparse?RasterResources.owner(n._sparse)===n.rasterId:RasterResources.payload(n.rasterId).canvas===n._canvas)),'Resized surfaces owned by registry');
 await undo();renderLayers();check(DW===sizeBefore[0]&&pix(S2)===pxS&&pix(D2)===pxD,'Resize undo restores surfaces');await redoF();check(DW===400,'Resize redo');await undo();
 // ---- v260 compositing primitive: dense and sparse resources give identical pixels ----
 const src=document.createElement('canvas');src.width=120;src.height=90;const sg=src.getContext('2d');sg.fillStyle='rgba(200,40,90,.8)';sg.beginPath();sg.arc(60,45,40,0,7);sg.fill();
 const dc=document.createElement('canvas');dc.width=DW;dc.height=DH;const dl=newLayer('CD',dc),sl=newLayer('CS',null,{w:DW,h:DH});insertLayer(dl,layers.length);insertLayer(sl,layers.length);
 for(const n of [dl,sl]){RasterResources.composeRegion(n.rasterId,{x:0,y:0,w:DW,h:DH},src,200,100,'source-over',.7);RasterResources.composeRegion(n.rasterId,{x:250,y:120,w:30,h:30},src,200,100,'destination-out',1)}
 check(sl._sparse&&pix(dl)===pix(sl),'Dense and sparse composeRegion match');
 RasterResources.composeRegion(dl.rasterId,{x:0,y:0,w:10,h:10},src,0,0,'source-over',1);check(dl.ctx.getImageData(50,50,1,1).data[3]===0,'Compose clipped to rect');
 // ---- v261 named write operations and registered transform surfaces ----
 const pair=()=>{const dc=document.createElement('canvas');dc.width=DW;dc.height=DH;const a=newLayer('OpD',dc),b=newLayer('OpS',null,{w:DW,h:DH});insertLayer(a,layers.length);insertLayer(b,layers.length);return [a,b]};
 const [od,os]=pair(),img=document.createElement('canvas');img.width=40;img.height=30;img.getContext('2d').fillStyle='#0a8';img.getContext('2d').fillRect(0,0,40,30);
 const imgData=new ImageData(DW,DH);for(let i=0;i<imgData.data.length;i+=4){imgData.data[i]=(i/4)%255;imgData.data[i+3]=((i/4)%7)?255:0}
 const region={kind:'polygon',points:[{x:20,y:20},{x:180,y:40},{x:90,y:150}],fillRule:'evenodd'};let geomOk=true;
 for(const n of [od,os]){RasterResources.fillRegion(n.rasterId,{x:5,y:5,w:200,h:120},'#3366cc','source-over',.8);RasterResources.clearRegion(n.rasterId,{x:30,y:30,w:40,h:40});RasterResources.putPixels(n.rasterId,imgData,0,0,{x:150,y:100,w:60,h:50});RasterResources.placeImage(n.rasterId,img,250,10,80,60)}
 check(os._sparse&&pix(od)===pix(os),'Named ops: dense and sparse identical');
 // geometry onto empty pixels is identical; over existing pixels antialiased edges may round differently (as before v261)
 {const [gd,gs]=pair();for(const n of [gd,gs])try{RasterResources.fillGeometry(n.rasterId,region,{x:0,y:0,w:200,h:160},'#ff0','source-over',1)}catch(e){geomOk=false}check(pix(gd)===pix(gs),'fillGeometry dense and sparse identical')}
 const c0={...RasterResources.opCounts};setStackSelection([od],{active:od,anchor:od});clearLayer();check(RasterResources.opCounts.clearRegion===(c0.clearRegion||0)+1,'Clear uses clearRegion');await undo();
 fillActiveLayer();check(RasterResources.opCounts.fillRegion>(c0.fillRegion||0),'Fill uses fillRegion');await undo();
 // layout move on dense layers registers before/after surfaces and restores them on undo
 const la=pair()[0],lb=pair()[0];RasterResources.fillRegion(la.rasterId,{x:10,y:10,w:30,h:30},'#f00');RasterResources.fillRegion(lb.rasterId,{x:200,y:150,w:30,h:30},'#0f0');setStackSelection([la,lb],{active:lb,anchor:la});
 const s0=RasterResources.stats().snapshots,pa=pix(la),pb=pix(lb),rs0=RasterResources.opCounts.replaceSurface||0;layoutSelectedObjects('left');
 const moved=pix(la)!==pa||pix(lb)!==pb;check(moved,'Layout moved a layer');{check(RasterResources.stats().snapshots>=s0+2&&RasterResources.opCounts.replaceSurface>rs0,'Layout surfaces registered and restored through replaceSurface');await undo();check(pix(la)===pa&&pix(lb)===pb,'Layout undo restores surfaces')}
 check(geomOk,'fillGeometry accepted RegionGeometry data');
 // ---- v262 image resources and memory summary ----
 const srcImg=document.createElement('canvas');srcImg.width=33;srcImg.height=21;const IL=newLayer('Img',null,{w:DW,h:DH});insertLayer(IL,layers.length);IL.instance={type:'file',id:'t',img:srcImg};
 const st3=RasterResources.stats(),iid=RasterResources.imageId(srcImg),rec=RasterResources.ledger.get(iid);check(rec&&rec.kind==='image'&&rec.width===33&&rec.height===21&&st3.issues.length===0,'Source image registered as image resource');
 check(RasterResources.imageId(srcImg)===iid,'Image identity stable');IL.instance=null;
 resourceMemoryCache.at=-1e9;syncStatusBar();check(/Pixel resources/.test($('statusBar').title),'Memory tooltip lists pixel resources');
 return {resources:true};
}));
assert.deepEqual(errors,[]);console.log('PASS: raster resource registry, tile/region/surface snapshots, named write ops, compositing, selection mask, transform surfaces, image resources ('+(source?'source':'standalone')+')');await context.close();}}
finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
