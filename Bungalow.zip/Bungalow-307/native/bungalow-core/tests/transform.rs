//! v301: the optimised bicubic sampler (empty-block skip, hoisted horizontal weights) is identical to the v297 kernel.
use bungalow_core::transform::{bicubic, Img, Plan};
use bungalow_core::modifiers::u8c;
fn cubic(v: f64) -> f64 { let x = v.abs(); if x < 1.0 { (1.5 * x - 2.5) * x * x + 1.0 } else if x < 2.0 { ((-0.5 * x + 2.5) * x - 4.0) * x + 2.0 } else { 0.0 } }
fn reference(img: &Img, p: &Plan) -> Vec<u8> {
    let (sw, sh) = (img.w as i64, img.h as i64); let src = &img.d; let mut out = vec![0u8; p.width * p.height * 4];
    let (fx, fy) = (if p.fx != 0.0 { p.fx } else { 1.0 }, if p.fy != 0.0 { p.fy } else { 1.0 }); let (rx, ry) = ((2.0 * fx).ceil() as i64, (2.0 * fy).ceil() as i64);
    for y in 0..p.height { for x in 0..p.width {
        let (dx, dy) = (x as f64 + p.x + 0.5, y as f64 + p.y + 0.5); let (u, v) = (p.a * dx + p.b * dy + p.tx, p.c * dx + p.d * dy + p.ty); let (ix, iy) = (u.floor() as i64, v.floor() as i64);
        let (mut r, mut g, mut b, mut a, mut total) = (0f64, 0f64, 0f64, 0f64, 0f64);
        for yy in iy - ry + 1..=iy + ry { let wy = cubic((v - yy as f64) / fy); for xx in ix - rx + 1..=ix + rx { let weight = wy * cubic((u - xx as f64) / fx); total += weight;
            if xx < 0 || xx >= sw || yy < 0 || yy >= sh { continue; } let i = ((yy * sw + xx) * 4) as usize; let alpha = src[i + 3] as f64 / 255.0;
            a += alpha * weight; r += src[i] as f64 / 255.0 * alpha * weight; g += src[i + 1] as f64 / 255.0 * alpha * weight; b += src[i + 2] as f64 / 255.0 * alpha * weight; } }
        if total != 0.0 { a /= total; r /= total; g /= total; b /= total; }
        let o = (y * p.width + x) * 4; let alpha = a.min(1.0).max(0.0);
        if alpha > 1e-6 { out[o] = u8c(r.min(alpha).max(0.0) / alpha * 255.0); out[o + 1] = u8c(g.min(alpha).max(0.0) / alpha * 255.0); out[o + 2] = u8c(b.min(alpha).max(0.0) / alpha * 255.0); }
        out[o + 3] = u8c(alpha * 255.0);
    } }
    out
}
#[test]
fn optimised_bicubic_is_identical() {
    let (w, h) = (300usize, 200usize); let mut d = vec![0u8; w * h * 4]; let mut seed = 7u32;
    for y in 0..h { for x in 0..w { let inside = (x as i64 - 120).pow(2) + (y as i64 - 90).pow(2) < 60 * 60 || (x > 220 && y > 150);
        if inside { seed = seed.wrapping_mul(1103515245).wrapping_add(12345); let i = (y * w + x) * 4; d[i] = (seed >> 8) as u8; d[i + 1] = (seed >> 16) as u8; d[i + 2] = x as u8; d[i + 3] = 40 + (seed >> 24) as u8 % 200; } } }
    let img = Img { w, h, d };
    for (ang, sx, fx) in [(0.25f64, 0.8f64, 1.0f64), (0.0, 1.0, 1.0), (1.1, 1.6, 1.0), (0.4, 0.3, 1.7)] {
        let (c, s) = (ang.cos(), ang.sin()); let (a, b, cc, dd) = (c / sx, s / sx, -s / sx, c / sx);
        let p = Plan { a, b, c: cc, d: dd, tx: 10.0, ty: -20.0, fx, fy: fx, x: -40.0, y: -30.0, width: 420, height: 380 };
        assert_eq!(bicubic(&img, &p), reference(&img, &p), "angle {ang} scale {sx}");
    }
}
#[test]
fn bicubic_speed_report() {
    let (w, h) = (2000usize, 1500usize); let mut d = vec![0u8; w * h * 4]; for (i, v) in d.iter_mut().enumerate() { *v = (i * 7 % 251) as u8 | 1; }
    let img = Img { w, h, d }; let (c, s) = (0.25f64.cos(), 0.25f64.sin());
    let p = Plan { a: c / 0.8, b: s / 0.8, c: -s / 0.8, d: c / 0.8, tx: 0.0, ty: 0.0, fx: 1.0, fy: 1.0, x: 0.0, y: 0.0, width: 2000, height: 1500 };
    let t = std::time::Instant::now(); let _ = bicubic(&img, &p); eprintln!("BICUBIC 3 MP: {:?}", t.elapsed());
}
