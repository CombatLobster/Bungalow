//! Raster parity with Chromium (fixtures from `tests/native-raster-fixtures-266.cjs`) and dense/sparse parity.
use bungalow_core::raster::{Op, Rect, Surface, TileStore};
use serde_json::Value;
fn load() -> Value { serde_json::from_str(&std::fs::read_to_string(format!("{}/tests/fixtures/raster.json", env!("CARGO_MANIFEST_DIR"))).unwrap()).unwrap() }
fn bytes(v: &Value) -> Vec<u8> { v.as_array().unwrap().iter().map(|x| x.as_u64().unwrap() as u8).collect() }
fn rect(v: &Value) -> Rect { Rect { x: v["x"].as_i64().unwrap(), y: v["y"].as_i64().unwrap(), w: v["w"].as_i64().unwrap(), h: v["h"].as_i64().unwrap() } }
fn rgb(s: &str) -> [u8; 3] { let n: Vec<u8> = s.trim_start_matches("rgb(").trim_end_matches(')').split(',').map(|x| x.trim().parse().unwrap()).collect(); [n[0], n[1], n[2]] }

#[test]
fn operations_match_chromium_within_rounding() {
    let f = load(); let mut worst = 0i32; let mut total = 0usize;
    for (n, c) in f["cases"].as_array().unwrap().iter().enumerate() {
        let (w, h) = (c["width"].as_u64().unwrap() as usize, c["height"].as_u64().unwrap() as usize);
        let mut s = Surface::from_straight(w, h, &bytes(&c["dst"]));
        let src = if c["src"].is_array() { Some(Surface::from_straight(c["sw"].as_u64().unwrap() as usize, c["sh"].as_u64().unwrap() as usize, &bytes(&c["src"]))) } else { None };
        let op = Op::parse(c["op"].as_str().unwrap()).unwrap(); let alpha = c["alpha"].as_f64().unwrap() as f32;
        match c["kind"].as_str().unwrap() {
            "compose" => s.compose_region(rect(&c["rect"]), src.as_ref().unwrap(), c["ox"].as_i64().unwrap(), c["oy"].as_i64().unwrap(), op, alpha),
            "fill" => s.fill_region(rect(&c["rect"]), rgb(c["colour"].as_str().unwrap()), op, alpha),
            "clear" => s.clear_region(rect(&c["rect"])),
            "write" => s.write_region(src.as_ref().unwrap(), c["ox"].as_i64().unwrap(), c["oy"].as_i64().unwrap()),
            k => panic!("{k}"),
        }
        // Compare premultiplied values (straight colour of nearly transparent pixels is not meaningful).
        let exp = Surface::from_straight(w, h, &bytes(&c["result"]));
        for (i, (a, b)) in s.data.iter().zip(&exp.data).enumerate() {
            let d = (*a as i32 - *b as i32).abs(); worst = worst.max(d); total += 1;
            assert!(d <= 3, "case {n} ({} {}) byte {i} (pixel {},{} ch {}): rust {a} vs chromium {b}", c["kind"], c["op"], (i / 4) % w, (i / 4) / w, i % 4);
        }
    }
    eprintln!("raster parity: {total} channel values, worst premultiplied difference {worst}");
}

#[test]
fn sparse_tiles_match_dense_and_swap_restores() {
    let (w, h) = (300usize, 200usize);
    let mut src = Surface::new(90, 70); for (i, b) in src.data.iter_mut().enumerate() { *b = ((i * 37) % 251) as u8; }
    for px in src.data.chunks_exact_mut(4) { let a = px[3]; for c in 0..3 { px[c] = px[c].min(a); } }
    let mut dense = Surface::new(w, h); let mut tiles = TileStore::new(w, h, 64);
    let r = Rect { x: 40, y: 30, w: 200, h: 150 };
    dense.compose_region(r, &src, 50, 40, Op::SourceOver, 0.8); tiles.compose_region(r, &src, 50, 40, Op::SourceOver, 0.8);
    assert_eq!(tiles.to_surface(), dense, "sparse and dense compositing identical");
    let before = tiles.to_surface(); let mut saved = tiles.snapshot(r);
    tiles.compose_region(r, &src, 100, 60, Op::DestinationOut, 1.0); let after = tiles.to_surface(); assert_ne!(after, before);
    tiles.swap(&mut saved); assert_eq!(tiles.to_surface(), before, "undo swap"); tiles.swap(&mut saved); assert_eq!(tiles.to_surface(), after, "redo swap");
}
