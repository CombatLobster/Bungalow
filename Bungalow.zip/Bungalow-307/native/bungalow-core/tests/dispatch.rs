//! Command API: the same fixture calls through `Core::handle` (JSON in, JSON out).
use bungalow_core::dispatch::Core;
use serde_json::{json, Value};
#[test]
fn dispatch_replays_store_fixtures_with_expectations() {
    let f: Value = serde_json::from_str(&std::fs::read_to_string(format!("{}/tests/fixtures/store-ops.json", env!("CARGO_MANIFEST_DIR"))).unwrap()).unwrap();
    for sc in f["scenarios"].as_array().unwrap() {
        let mut core = Core::new();
        for step in sc["steps"].as_array().unwrap() {
            let c = step["call"].as_array().unwrap();
            let resp = core.handle(&json!({"method": c[0], "args": c[1..], "expect": {"ok": step["ok"], "error": step["error"]}}));
            assert_eq!(resp["matchesExpectation"], json!(true), "{} {:?} -> {resp}", sc["name"], c);
            assert_eq!(resp["revision"].as_u64(), step["revision"].as_u64());
        }
        let snap = core.handle(&json!({"method": "snapshot"}));
        assert_eq!(snap["result"]["revision"].as_u64(), sc["steps"].as_array().unwrap().last().unwrap()["revision"].as_u64());
    }
}
#[test]
fn batch_unknown_and_aliases() {
    let mut core = Core::new();
    let n = |i: u32| format!("node_{:032x}", i);
    let r = core.handle(&json!({"batch": [
        {"method": "commitTree", "args": [{"layers": [n(1)], "groups": [], "parents": {}}]},
        {"method": "commitProps", "args": [{"set": {n(1): {"vis": true, "op": 1}}}]},
        {"method": "setProp", "args": [n(1), "op", 0.5]},
        {"method": "setProp", "args": [n(1), "op", {"$undefined": true}]},
        {"method": "nope"}
    ]}));
    let b = r["batch"].as_array().unwrap();
    assert!(b[..4].iter().all(|x| x["ok"] == json!(true)));
    assert_eq!(b[4]["error"], json!("Unknown method nope"));
    let snap = core.handle(&json!({"method": "snapshot"}));
    assert!(snap["result"]["state"]["props"][n(1)].get("op").is_none(), "undefined deletes the key");
}

/// v268: raster surface commands (base64 straight RGBA payloads), compare and resync.
#[test]
fn raster_surface_commands() {
    use bungalow_core::dispatch::Core;
    use serde_json::json;
    fn b64(b: &[u8]) -> String { const T: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; let mut o = String::new(); for c in b.chunks(3) { let n = (c[0] as u32) << 16 | (*c.get(1).unwrap_or(&0) as u32) << 8 | *c.get(2).unwrap_or(&0) as u32; for i in 0..4 { if i <= c.len() { o.push(T[(n >> (18 - 6 * i) & 63) as usize] as char) } else { o.push('=') } } } o }
    let img = |w: usize, h: usize, px: [u8; 4]| json!({"width": w, "height": h, "data": b64(&px.repeat(w * h))});
    let mut core = Core::new(); let id = "res_0123456789abcdef0123456789abcdef";
    let ok = |r: serde_json::Value| { assert_eq!(r["ok"], true, "{r}"); r };
    ok(core.handle(&json!({"method": "raster.set", "args": [id, img(8, 8, [0, 0, 0, 0])]})));
    ok(core.handle(&json!({"method": "raster.fillRegion", "args": [id, {"x": 0, "y": 0, "w": 4, "h": 8}, [255, 0, 0], "source-over", 1]})));
    ok(core.handle(&json!({"method": "raster.composeRegion", "args": [id, {"x": 2, "y": 0, "w": 4, "h": 4}, img(4, 4, [0, 0, 255, 255]), 2, 0, "source-over", 0.5]})));
    ok(core.handle(&json!({"method": "raster.clearRegion", "args": [id, {"x": 0, "y": 6, "w": 8, "h": 2}]})));
    // expected straight pixels
    let mut exp = vec![0u8; 8 * 8 * 4];
    for y in 0..8 { for x in 0..8 { let i = (y * 8 + x) * 4; let mut p = [0u8; 4]; if x < 4 { p = [255, 0, 0, 255]; } if (2..6).contains(&x) && y < 4 { p = if x < 4 { [128, 0, 128, 255] } else { [0, 0, 255, 128] }; } if y >= 6 { p = [0; 4]; } exp[i..i + 4].copy_from_slice(&p); } }
    let r = ok(core.handle(&json!({"method": "raster.compare", "args": [id, {"width": 8, "height": 8, "data": b64(&exp)}, {"tolerance": 1}]})));
    assert_eq!(r["result"]["over"], 0, "{r}");
    let r = ok(core.handle(&json!({"method": "raster.compare", "args": [id, img(8, 8, [9, 9, 9, 255]), {"resync": true}]})));
    assert!(r["result"]["over"].as_u64().unwrap() > 0);
    let r = ok(core.handle(&json!({"method": "raster.compare", "args": [id, img(8, 8, [9, 9, 9, 255])]}))); assert_eq!(r["result"]["maxDiff"], 0, "resync replaced surface");
    assert_eq!(core.handle(&json!({"method": "raster.fillRegion", "args": [id, {"x": 0, "y": 0, "w": 1, "h": 1}, [0, 0, 0], "multiply", 1]}))["error"], "Unsupported operator multiply");
    ok(core.handle(&json!({"method": "raster.release", "args": [id]})));
    assert_eq!(core.handle(&json!({"method": "raster.clearRegion", "args": [id, {"x": 0, "y": 0, "w": 1, "h": 1}]}))["error"], "Unknown raster surface");
}

/// v269: native tile snapshots and swaps (undo = redo = swap), surface snapshots, release cascade.
#[test]
fn raster_snapshot_commands() {
    use bungalow_core::dispatch::Core;
    use serde_json::{json, Value};
    fn b64(b: &[u8]) -> String { const T: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; let mut o = String::new(); for c in b.chunks(3) { let n = (c[0] as u32) << 16 | (*c.get(1).unwrap_or(&0) as u32) << 8 | *c.get(2).unwrap_or(&0) as u32; for i in 0..4 { if i <= c.len() { o.push(T[(n >> (18 - 6 * i) & 63) as usize] as char) } else { o.push('=') } } } o }
    let img = |w: usize, h: usize, px: [u8; 4]| json!({"width": w, "height": h, "data": b64(&px.repeat(w * h))});
    let mut c = Core::new(); let id = "res_00000000000000000000000000000001"; let (s1, s2) = ("snap_00000000000000000000000000000001", "snap_00000000000000000000000000000002");
    let mut call = |m: &str, a: Value| { let r = c.handle(&json!({"method": m, "args": a})); assert_eq!(r["ok"], true, "{m}: {r}"); r["result"].clone() };
    let same = |r: Value| assert_eq!(r["maxDiff"], 0, "{r}");
    call("raster.set", json!([id, img(20, 12, [0, 0, 0, 0])]));
    call("raster.fillRegion", json!([id, {"x": 0, "y": 0, "w": 8, "h": 8}, [255, 0, 0], "source-over", 1]));
    let before = call("raster.read", json!([id]));
    call("raster.captureTiles", json!([id, s1, ["0:0", "8:0", "16:0", "0:8", "8:8", "16:8"], 8]));
    call("raster.fillRegion", json!([id, {"x": 4, "y": 0, "w": 16, "h": 12}, [0, 0, 255], "source-over", 1]));
    let after = call("raster.read", json!([id]));
    call("raster.swapTiles", json!([id, s1])); same(call("raster.compare", json!([id, before.clone()])));
    call("raster.swapTiles", json!([id, s1])); same(call("raster.compare", json!([id, after.clone()])));
    call("raster.adoptSurface", json!([id, s2, img(20, 12, [0, 255, 0, 255])]));
    call("raster.restoreSurface", json!([id, s2])); same(call("raster.compare", json!([id, img(20, 12, [0, 255, 0, 255])])));
    call("raster.adoptTiles", json!([id, "snap_00000000000000000000000000000003", {"0:0": img(8, 8, [9, 9, 9, 255]), "8:0": null}, 8]));
    call("raster.swapTiles", json!([id, "snap_00000000000000000000000000000003"]));
    let r = call("raster.list", json!([])); assert_eq!(r["snapshots"], 3);
    call("raster.release", json!([id])); let r = call("raster.list", json!([])); assert_eq!(r["snapshots"], 0, "release drops snapshots");
}

/// v270: compositor from store + surfaces: source-over, multiply, hidden layer, composited group, unsupported mask.
#[test]
fn composite_from_store() {
    use bungalow_core::dispatch::Core;
    use serde_json::{json, Value};
    fn b64(b: &[u8]) -> String { const T: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; let mut o = String::new(); for c in b.chunks(3) { let n = (c[0] as u32) << 16 | (*c.get(1).unwrap_or(&0) as u32) << 8 | *c.get(2).unwrap_or(&0) as u32; for i in 0..4 { if i <= c.len() { o.push(T[(n >> (18 - 6 * i) & 63) as usize] as char) } else { o.push('=') } } } o }
    let img = |px: [u8; 4]| json!({"width": 4, "height": 2, "data": b64(&px.repeat(8))});
    let (a, b, g) = ("node_000000000000000000000000000000a1", "node_000000000000000000000000000000b2", "node_000000000000000000000000000000c3");
    let (ra, rb) = ("res_000000000000000000000000000000a1", "res_000000000000000000000000000000b2");
    let mut c = Core::new();
    let mut call = |m: &str, args: Value| { let r = c.handle(&json!({"method": m, "args": args})); assert_eq!(r["ok"], true, "{m}: {r}"); r["result"].clone() };
    let doc = |pb: Value, pg: Value| json!({"tree": {"layers": [a, b], "groups": [g], "parents": {a: null, b: g, g: null}}, "document": {"width": 4, "height": 2, "dpi": 72},
        "props": {a: {"vis": true, "op": 1, "blend": "normal", "rasterId": ra}, b: pb, g: pg}});
    call("raster.set", json!([ra, img([255, 0, 0, 255])])); call("raster.set", json!([rb, img([0, 0, 255, 128])]));
    let check = |call: &mut dyn FnMut(&str, Value) -> Value, expect: [u8; 4], what: &str| { let r = call("raster.composite", json!([{"compare": img(expect), "tolerance": 1}])); assert_eq!(r["supported"], true, "{what}: {r}"); assert_eq!(r["over"], 0, "{what}: {r}"); };
    call("restoreDocument", json!([doc(json!({"vis": true, "op": 1, "blend": "normal", "rasterId": rb}), json!({"vis": true}))]));
    check(&mut call, [127, 0, 128, 255], "source-over through pass-through group");
    call("restoreDocument", json!([doc(json!({"vis": true, "op": 1, "blend": "multiply", "rasterId": rb}), json!({"vis": true}))]));
    check(&mut call, [127, 0, 0, 255], "multiply");
    call("restoreDocument", json!([doc(json!({"vis": false, "op": 1, "blend": "normal", "rasterId": rb}), json!({"vis": true}))]));
    check(&mut call, [255, 0, 0, 255], "hidden layer");
    call("restoreDocument", json!([doc(json!({"vis": true, "op": 1, "blend": "normal", "rasterId": rb}), json!({"vis": true, "op": 0.5}))]));
    check(&mut call, [191, 0, 64, 255], "group opacity");
    // v271: a paint mask targeted at layer `a` (white-transparent = visible; opaque black hides). `b` is the mask here.
    let mask = |kind: &str, target: Value| doc(json!({"vis": true, "op": 1, "mask": true, "maskKind": kind, "maskTarget": target, "rasterId": rb}), json!({"vis": true}));
    call("raster.set", json!([rb, img([0, 0, 0, 255])]));
    call("restoreDocument", json!([mask("paint", json!(a))]));
    check(&mut call, [0, 0, 0, 0], "opaque black mask hides its target");
    call("raster.set", json!([rb, img([0, 0, 0, 0])]));
    check(&mut call, [255, 0, 0, 255], "transparent mask reveals its target");
    call("restoreDocument", json!([mask("paint", json!("orphan"))]));
    check(&mut call, [255, 0, 0, 255], "orphan mask has no effect");
    // v273: modifier layers. `b` (in group g) is a modifier targeting `a` (red, opaque).
    let modifier = |extra: Value| { let mut pb = json!({"vis": true, "op": 1, "mask": true, "maskTarget": a, "rasterId": rb}); for (k, v) in extra.as_object().unwrap() { pb[k] = v.clone(); } doc(pb, json!({"vis": true})) };
    call("restoreDocument", json!([modifier(json!({"maskKind": "transform"}))]));
    check(&mut call, [255, 0, 0, 255], "identity transform");
    call("restoreDocument", json!([modifier(json!({"maskKind": "transform", "maskTransform": {"xf": [1, 0, 0, 1, 4, 0]}}))]));
    check(&mut call, [0, 0, 0, 0], "translated out of the document");
    call("restoreDocument", json!([modifier(json!({"maskKind": "colour", "maskColour": {"colour": "#0000ff", "amount": 1}}))]));
    check(&mut call, [0, 0, 255, 255], "colour overlay");
    call("restoreDocument", json!([modifier(json!({"maskKind": "colour", "op": 0.5, "maskColour": {"colour": "#0000ff", "amount": 1}}))]));
    check(&mut call, [128, 0, 128, 255], "colour overlay at half opacity (straight mix)");
    call("restoreDocument", json!([modifier(json!({"maskKind": "filter", "maskFilter": {"type": "adjust", "params": {"type": "hsv", "hue": 120, "sat": 0, "val": 0}}}))]));
    check(&mut call, [0, 255, 0, 255], "hue shift");
    call("restoreDocument", json!([modifier(json!({"maskKind": "filter", "maskFilter": {"type": "adjust", "params": {"type": "brightness", "brightness": 0, "contrast": 0}}}))]));
    check(&mut call, [255, 0, 0, 255], "identity adjustment is skipped");
    call("restoreDocument", json!([modifier(json!({"maskKind": "mirror"}))]));
    check(&mut call, [255, 0, 0, 255], "v274: default vertical mirror of a uniform layer");
    // v274: blur of a uniform opaque layer keeps the interior colour; fractional shadow offsets fall back
    call("restoreDocument", json!([modifier(json!({"maskKind": "filter", "maskFilter": {"type": "adjust", "params": {"type": "blur", "blur": 0.4}}}))]));
    let r = call("raster.composite", json!([{}])); assert_eq!(r["supported"], true, "{r}");
    call("restoreDocument", json!([modifier(json!({"maskKind": "shadow", "maskShadow": {"colour": "#000000", "opacity": 0.5, "radius": 2, "offsetX": 1.5, "offsetY": 0}}))]));
    let r = call("raster.composite", json!([{}])); assert_eq!(r["supported"], true, "{r}");
    call("restoreDocument", json!([modifier(json!({"maskKind": "filter", "maskFilter": {"type": "invert", "value": 100}}))]));
    check(&mut call, [0, 255, 255, 255], "legacy invert filter");
}



/// v277: project container round trip: write a document from native surfaces (identical tiles stored once, empty tiles
/// skipped), read it back to the same premultiplied pixels; damaged headers are rejected.
#[test]
fn project_round_trip() {
    use bungalow_core::project; use bungalow_core::raster::Surface; use serde_json::json;
    let mut a = Surface::new(600, 300); for (i, p) in a.data.chunks_exact_mut(4).enumerate() { let x = i % 600; if x < 512 { p.copy_from_slice(&[100, 50, 25, 200]); } }
    let empty = Surface::new(600, 300);
    let meta = json!({"format": "LowLatPaint", "version": 5, "width": 600, "height": 300, "layers": [{"name": "A"}, {"name": "Empty"}]});
    let bytes = project::write(meta, &[vec![Some(&a), Some(&empty)]]).unwrap();
    let c = project::parse(bytes.clone()).unwrap(); let docs = project::documents(&c.meta); let doc = docs[0].1;
    let tiles = doc["layers"][0]["tiles"].as_array().unwrap(); assert_eq!(tiles.len(), 4, "two 256×256 tiles per row with paint, the 88-px column is empty");
    assert_eq!(tiles[0][2], tiles[1][2], "identical tiles share one PNG");
    assert_eq!(doc["layers"][1]["tiles"].as_array().unwrap().len(), 0, "empty layer stores nothing");
    assert_eq!(project::layer_surface(&c, doc, &doc["layers"][0]).unwrap(), a, "pixels round trip");
    let mut bad = bytes.clone(); bad[13] = 0xff; assert!(project::parse(bad).is_err()); assert!(project::parse(b"not a project".to_vec()).is_err());
}

/// v278: core mode primitives: setTiles builds a surface from painted tiles only. (v299: the brush.commit half moved to
/// the core brushes archive.)
#[test]
fn core_mode_commands() {
    use bungalow_core::dispatch::Core;
    use serde_json::{json, Value};
    let mut c = Core::new(); let id = "res_000000000000000000000000000000c1";
    let mut call = |m: &str, a: Value| { let r = c.handle(&json!({"method": m, "args": a})); assert_eq!(r["ok"], true, "{m}: {r}"); r["result"].clone() };
    let px = bungalow_core::surfaces::b64_encode(&[0, 0, 255, 255].repeat(4));
    call("raster.setTiles", json!([id, 300, 200, {"256:0": {"width": 2, "height": 2, "data": px}}]));
    let r = call("raster.read", json!([id])); let d = bungalow_core::surfaces::b64_decode(r["data"].as_str().unwrap()).unwrap();
    assert_eq!(&d[(256 * 4)..(256 * 4 + 4)], &[0, 0, 255, 255], "tile placed"); assert_eq!(&d[0..4], &[0, 0, 0, 0], "rest transparent");
}

/// v280: binary results: composite / read as [u32 w][u32 h] + straight RGBA, PNG tiles of a surface; the JSON
/// `binary` wrapper returns the same bytes in base64.
#[test]
fn binary_results() {
    use bungalow_core::dispatch::Core;
    use serde_json::json;
    let mut c = Core::new(); let id = "res_000000000000000000000000000000d1";
    let px = bungalow_core::surfaces::b64_encode(&[10, 20, 30, 255].repeat(300 * 2));
    c.handle(&json!({"method": "raster.set", "args": [id, {"width": 300, "height": 2, "data": px}]}));
    let b = c.handle_binary(&json!({"method": "raster.read", "args": [id]})).unwrap();
    assert_eq!(&b[..8], &[44, 1, 0, 0, 2, 0, 0, 0]); assert_eq!(&b[8..12], &[10, 20, 30, 255]); assert_eq!(b.len(), 8 + 300 * 2 * 4);
    let t = c.handle_binary(&json!({"method": "project.encodeTiles", "args": [id]})).unwrap();
    assert_eq!(u32::from_le_bytes([t[0], t[1], t[2], t[3]]), 2, "two tiles (256 + 44 px wide)");
    let r = c.handle(&json!({"method": "binary", "args": [{"method": "raster.read", "args": [id]}]}));
    assert_eq!(bungalow_core::surfaces::b64_decode(r["result"]["data"].as_str().unwrap()).unwrap(), b);
    assert!(c.handle_binary(&json!({"method": "store.nothing"})).is_err());
}

