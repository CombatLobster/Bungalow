// v293: timing of project tile encoding (cargo run --release --example encode_bench)
use serde_json::json;
fn main() {
    let mut core = bungalow_core::dispatch::Core::new();
    let (w, h) = (5000usize, 2813usize); let id = "res_0123456789abcdef0123456789abcdef";
    let mut px = vec![0u8; w * h * 4]; let mut seed = 1u32;
    for y in 0..h { for x in 0..w { let i = (y * w + x) * 4; let v = ((x / 7) ^ (y / 5)) as u8; seed = seed.wrapping_mul(1664525).wrapping_add(1013904223); px[i] = v; px[i + 1] = v.wrapping_mul(3); px[i + 2] = (seed >> 24) as u8 & 0x1f; px[i + 3] = if (x / 300 + y / 300) % 3 == 0 { 0 } else { 255 }; } }
    let b64 = bungalow_core::surfaces::b64_encode(&px);
    let r = core.handle(&json!({"method": "raster.set", "args": [id, {"width": w, "height": h, "data": b64}]})); assert!(r["ok"].as_bool().unwrap_or(false), "{r}");
    let t = std::time::Instant::now(); let a = core.handle_binary(&json!({"method": "project.encodeTiles", "args": [id]})).unwrap(); println!("cold encode: {:.0} ms, {} bytes", t.elapsed().as_secs_f64() * 1000.0, a.len());
    let t = std::time::Instant::now(); let b = core.handle_binary(&json!({"method": "project.encodeTiles", "args": [id]})).unwrap(); println!("cached encode: {:.0} ms, {} bytes", t.elapsed().as_secs_f64() * 1000.0, b.len());
    println!("threads: {}", rayon::current_num_threads());
}
