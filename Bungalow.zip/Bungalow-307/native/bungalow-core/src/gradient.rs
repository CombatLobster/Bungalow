//! v274: gradient modifier, a CPU port of BungalowGradient (src/part-04.js): stop model, 1024-entry LUT built exactly
//! like `Gradient.lut()`, and the fragment shader (types, repeat, aspect, blend/Replace, alpha lock, opacity).
//! The shader's ±1/255 dither noise is GPU-specific and is not reproduced (within the compare tolerance).
use crate::raster::Surface;
use serde_json::Value;

const GPU_BLEND: [&str; 22] = ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "linear-dodge", "linear-burn", "vivid-light", "subtract", "divide", "hue", "saturation", "color", "luminosity", "glow"];
#[derive(Clone, Debug)]
struct Stop { t: f64, v: [f64; 4], mid: f64, interp: String }
#[derive(Clone, Debug)]
pub struct GradientCfg { space: String, stops: Vec<Stop>, ty: u8, repeat: u8, aspect: f64, a: [f64; 2], b: [f64; 2], opacity: f64, blend: i32, lock: bool }

fn clamp(v: f64, a: f64, b: f64) -> f64 { if v < a { a } else if v > b { b } else { v } }
fn numv(v: Option<&Value>, d: f64) -> f64 { match v { Some(Value::Number(n)) => n.as_f64().unwrap_or(d), Some(Value::String(s)) => s.trim().parse().unwrap_or(d), _ => d } }
/// BungalowGradient.normalise (defaults for a 1000×1000 document, as `defaults()` with no arguments).
pub fn parse(c: &Value) -> GradientCfg {
    let def_stops = vec![Stop { t: 0.0, v: [0x14 as f64 / 255.0, 0x21 as f64 / 255.0, 0x3d as f64 / 255.0, 1.0], mid: 0.5, interp: "linear".into() }, Stop { t: 1.0, v: [0xfc as f64 / 255.0, 0xa3 as f64 / 255.0, 0x11 as f64 / 255.0, 1.0], mid: 0.5, interp: "linear".into() }];
    let interps = ["linear", "smooth", "easeIn", "easeOut", "step"];
    let mut stops: Vec<Stop> = c.get("stops").and_then(Value::as_array).map(|a| a.iter().filter(|s| s.get("v").and_then(Value::as_array).map_or(false, |v| v.len() == 4 && v.iter().all(|x| x.as_f64().map_or(false, f64::is_finite)))).take(64).map(|s| {
        let v = s["v"].as_array().unwrap(); Stop { t: clamp(numv(s.get("t"), 0.0), 0.0, 1.0), v: [0, 1, 2, 3].map(|i| clamp(v[i].as_f64().unwrap(), 0.0, 1.0)), mid: clamp(numv(s.get("mid"), 0.5), 0.02, 0.98), interp: s.get("interp").and_then(Value::as_str).filter(|i| interps.contains(i)).unwrap_or("linear").to_string() } }).collect()).unwrap_or_default();
    if stops.len() < 2 { stops = def_stops; } else { stops.sort_by(|a, b| a.t.partial_cmp(&b.t).unwrap()); }
    let pt = |k: &str, d: [f64; 2]| c.get(k).and_then(|p| { let (x, y) = (numv(p.get("x"), f64::NAN), numv(p.get("y"), f64::NAN)); if x.is_finite() && y.is_finite() { Some([x, y]) } else { None } }).unwrap_or(d);
    let pick = |k: &str, ok: &[&str]| c.get(k).and_then(Value::as_str).and_then(|s| ok.iter().position(|o| *o == s)).unwrap_or(0) as u8;
    let mode = c.get("mode").and_then(Value::as_str).unwrap_or("normal");
    let blend = if mode == "replace" { -1 } else { GPU_BLEND.iter().position(|m| *m == mode).unwrap_or(0) as i32 };
    let lock = if mode == "lock" { true } else { match c.get("alphaLock") { None => false, Some(v) => !matches!(v, Value::Null | Value::Bool(false)) && v.as_f64() != Some(0.0) && v.as_str() != Some("") } };
    GradientCfg { space: c.get("space").and_then(Value::as_str).filter(|s| ["oklab", "linear", "srgb"].contains(s)).unwrap_or("oklab").to_string(), stops,
        ty: pick("type", &["linear", "radial", "angle", "reflected", "diamond"]), repeat: pick("repeat", &["clamp", "repeat", "mirror"]), aspect: clamp(numv(c.get("aspect"), 1.0), 0.1, 4.0),
        a: pt("a", [200.0, 500.0]), b: pt("b", [800.0, 500.0]), opacity: clamp(numv(c.get("opacity"), 1.0), 0.0, 1.0), blend, lock }
}
fn s2l(c: f64) -> f64 { if c <= 0.04045 { c / 12.92 } else { ((c + 0.055) / 1.055).powf(2.4) } }
fn l2s(c: f64) -> f64 { if c <= 0.0031308 { c * 12.92 } else { 1.055 * c.powf(1.0 / 2.4) - 0.055 } }
fn enc(c: [f64; 4], space: &str) -> [f64; 4] {
    let [r, g, b, a] = c; if space == "srgb" { return c; } let (lr, lg, lb) = (s2l(r), s2l(g), s2l(b)); if space == "linear" { return [lr, lg, lb, a]; }
    let l = (0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb).cbrt(); let m = (0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb).cbrt(); let s = (0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb).cbrt();
    [0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s, 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s, 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s, a]
}
fn shape_u(mut u: f64, st: &Stop) -> f64 {
    if (st.mid - 0.5).abs() > 1e-4 { u = u.powf(0.5f64.ln() / st.mid.ln()); }
    match st.interp.as_str() { "smooth" => u * u * (3.0 - 2.0 * u), "easeIn" => u * u, "easeOut" => 1.0 - (1.0 - u).powi(2), "step" => if u < 0.5 { 0.0 } else { 1.0 }, _ => u }
}
fn js_round(v: f64) -> f64 { (v + 0.5).floor() }
/// Gradient.lut(1024) with the Float32 L2S table (l2sFast).
fn lut(c: &GradientCfg) -> Vec<u8> {
    let table: Vec<f32> = (0..4098).map(|i| l2s((i as f64 / 4096.0).min(1.0)) as f32).collect();
    let fast = |x: f64| { let x = if x <= 0.0 { 0.0 } else if x >= 1.0 { 1.0 } else { x }; let f = x * 4096.0; let i = f as usize; table[i] as f64 + (table[i + 1] as f64 - table[i] as f64) * (f - i as f64) };
    let n = 1024; let mut out = vec![0u8; n * 4]; let st = &c.stops; let m = st.len(); let space = c.space.as_str(); let e: Vec<[f64; 4]> = st.iter().map(|s| enc(s.v, space)).collect(); let mut seg = 0;
    let mut put = |i: usize, v: [f64; 4]| { for k in 0..4 { out[i * 4 + k] = js_round(v[k] * 255.0).clamp(0.0, 255.0) as u8; } };
    for i in 0..n { let t = i as f64 / (n - 1) as f64;
        if t <= st[0].t { put(i, st[0].v); continue; } if t >= st[m - 1].t { put(i, st[m - 1].v); continue; }
        while seg < m - 2 && t > st[seg + 1].t { seg += 1; }
        let (a, b) = (&st[seg], &st[seg + 1]); let sp = b.t - a.t; let u = if sp > 1e-9 { shape_u((t - a.t) / sp, a) } else { 1.0 };
        if u <= 0.0 { put(i, a.v); continue; } if u >= 1.0 { put(i, b.v); continue; }
        let (aa, bb) = (e[seg], e[seg + 1]); let (x, y, z, al) = (aa[0] + (bb[0] - aa[0]) * u, aa[1] + (bb[1] - aa[1]) * u, aa[2] + (bb[2] - aa[2]) * u, aa[3] + (bb[3] - aa[3]) * u);
        let col = match space { "srgb" => [x, y, z, al], "linear" => [fast(x), fast(y), fast(z), al], _ => {
            let l = (x + 0.3963377774 * y + 0.2158037573 * z).powi(3); let mm = (x - 0.1055613458 * y - 0.0638541728 * z).powi(3); let s2 = (x - 0.0894841775 * y - 1.2914855480 * z).powi(3);
            [fast(4.0767416621 * l - 3.3077115913 * mm + 0.2309699292 * s2), fast(-1.2684380046 * l + 2.6097574011 * mm - 0.3413193965 * s2), fast(-0.0041960863 * l - 0.7034186147 * mm + 1.7076147010 * s2), al] } };
        put(i, col); }
    out
}
// ---- BLEND_GLSL ----
fn dodge(b: f64, s: f64) -> f64 { if b == 0.0 { 0.0 } else if s >= 1.0 { 1.0 } else { (b / (1.0 - s)).min(1.0) } }
fn burn(b: f64, s: f64) -> f64 { if b >= 1.0 { 1.0 } else if s <= 0.0 { 0.0 } else { 1.0 - ((1.0 - b) / s).min(1.0) } }
fn chan(m: i32, b: f64, s: f64) -> f64 { match m {
    1 => b * s, 2 => b + s - b * s, 3 => if b <= 0.5 { 2.0 * b * s } else { 1.0 - 2.0 * (1.0 - b) * (1.0 - s) }, 4 => b.min(s), 5 => b.max(s), 6 => dodge(b, s), 7 => burn(b, s),
    8 => if s <= 0.5 { 2.0 * b * s } else { 1.0 - 2.0 * (1.0 - b) * (1.0 - s) },
    9 => { let d = if b <= 0.25 { ((16.0 * b - 12.0) * b + 4.0) * b } else { b.sqrt() }; if s <= 0.5 { b - (1.0 - 2.0 * s) * b * (1.0 - b) } else { b + (2.0 * s - 1.0) * (d - b) } }
    10 => (b - s).abs(), 11 => b + s - 2.0 * b * s, 12 => (b + s).min(1.0), 13 => (b + s - 1.0).max(0.0), 14 => if s <= 0.5 { burn(b, 2.0 * s) } else { dodge(b, 2.0 * s - 1.0) },
    15 => (b - s).max(0.0), 16 => if s <= 0.0 { 1.0 } else { (b / s).min(1.0) }, 21 => if b >= 1.0 { 1.0 } else { (s * s / (1.0 - b)).min(1.0) }, _ => s } }
fn lum(c: [f64; 3]) -> f64 { 0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2] }
fn clipc(c: [f64; 3]) -> [f64; 3] { let l = lum(c); let n = c[0].min(c[1]).min(c[2]); let x = c[0].max(c[1]).max(c[2]); let mut o = c; if n < 0.0 { o = o.map(|v| l + (v - l) * l / (l - n)); } if x > 1.0 { o = o.map(|v| l + (v - l) * (1.0 - l) / (x - l)); } o }
fn set_lum(c: [f64; 3], l: f64) -> [f64; 3] { let d = l - lum(c); clipc(c.map(|v| v + d)) }
fn satc(c: [f64; 3]) -> f64 { c[0].max(c[1]).max(c[2]) - c[0].min(c[1]).min(c[2]) }
fn set_sat(c: [f64; 3], s: f64) -> [f64; 3] { let mx = c[0].max(c[1]).max(c[2]); let mn = c[0].min(c[1]).min(c[2]); if mx > mn { c.map(|v| (v - mn) * s / (mx - mn)) } else { [0.0; 3] } }
fn gblend(m: i32, b: [f64; 3], s: [f64; 3]) -> [f64; 3] { match m { 17 => set_lum(set_sat(s, satc(b)), lum(b)), 18 => set_lum(set_sat(b, satc(s)), lum(b)), 19 => set_lum(s, lum(b)), 20 => set_lum(b, lum(s)), _ => [chan(m, b[0], s[0]), chan(m, b[1], s[1]), chan(m, b[2], s[2])] } }

pub fn draw(src: &Surface, c: &GradientCfg) -> Surface {
    let (w, h) = (src.width, src.height); let lt = lut(c); let mut out = Surface::new(w, h);
    let d = [c.b[0] - c.a[0], c.b[1] - c.a[1]]; let len = (d[0] * d[0] + d[1] * d[1]).sqrt().max(0.0001); let ax = [d[0] / len, d[1] / len]; let ay = [-ax[1], ax[0]];
    for y in 0..h { for x in 0..w {
        let p = [x as f64 + 0.5, y as f64 + 0.5]; let i = (y * w + x) * 4; let l = [0, 1, 2, 3].map(|k| src.data[i + k] as f64 / 255.0);
        let q = [p[0] - c.a[0], p[1] - c.a[1]]; let u = q[0] * ax[0] + q[1] * ax[1]; let v = (q[0] * ay[0] + q[1] * ay[1]) / c.aspect;
        let mut t = match c.ty { 0 => u / len, 1 => (u * u + v * v).sqrt() / len, 2 => { let a = v.atan2(u) / 6.2831853; a - a.floor() }, 3 => u.abs() / len, _ => (u.abs() + v.abs()) / len };
        if c.ty != 2 { t = match c.repeat { 0 => clamp(t, 0.0, 1.0), 1 => t - t.floor(), _ => 1.0 - (1.0 - (t - 2.0 * (t / 2.0).floor())).abs() }; }
        // LUT texture, LINEAR filter, clamp to edge: texel coordinate t*1023
        let f = clamp(t * 1023.0, 0.0, 1023.0); let i0 = f.floor() as usize; let i1 = (i0 + 1).min(1023); let fr = f - i0 as f64;
        let g = [0, 1, 2, 3].map(|k| (lt[i0 * 4 + k] as f64 + (lt[i1 * 4 + k] as f64 - lt[i0 * 4 + k] as f64) * fr) / 255.0);
        let op = c.opacity; let as_ = g[3] * op;
        let res: [f64; 4] = if c.blend < 0 && !c.lock { [0, 1, 2, 3].map(|k| { let gv = if k < 3 { g[k] * g[3] } else { g[3] }; l[k] + (gv - l[k]) * op }) } else {
            let cb = if l[3] > 0.0001 { [l[0] / l[3], l[1] / l[3], l[2] / l[3]] } else { [0.0; 3] }; let gs = [g[0], g[1], g[2]]; let bb = if c.blend > 0 { gblend(c.blend, cb, gs) } else { gs };
            if c.lock { [cb[0] + (bb[0] - cb[0]) * as_, cb[1] + (bb[1] - cb[1]) * as_, cb[2] + (bb[2] - cb[2]) * as_].map(|v| v * l[3]).into_iter().chain([l[3]]).collect::<Vec<_>>().try_into().unwrap() }
            else { let o = [0, 1, 2].map(|k| (1.0 - as_) * l[k] + (1.0 - l[3]) * as_ * gs[k] + as_ * l[3] * bb[k]); [o[0], o[1], o[2], as_ + l[3] * (1.0 - as_)] } };
        for k in 0..4 { out.data[i + k] = (res[k].clamp(0.0, 1.0) * 255.0).round() as u8; }
    } }
    out
}
