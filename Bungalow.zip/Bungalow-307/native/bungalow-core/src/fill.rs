//! v284 (stage 7): the app's bucket fill (floodRegion + the fill blend in bucketFill, src/app.js) run on the core's
//! pixels, so core mode sends the fill parameters instead of the filled pixels. Works on straight values exactly as
//! read by getImageData (the core unpremultiplies like Skia) with the same double arithmetic, so the region matches the
//! app's; the caller passes the app's region bounds and count and nothing is written unless they agree.
use crate::raster::Surface;

pub struct Fill { pub x: usize, pub y: usize, pub tolerance: f64, pub contiguous: bool, pub rgb: [f64; 3], pub alpha: f64, pub erase: bool, pub alpha_lock: bool }

/// floodRegion: mask of matching pixels, bounds (x, y, w, h) and count.
pub fn region(d: &[u8], w: usize, h: usize, f: &Fill) -> Option<(Vec<u8>, usize, usize, usize, usize, usize)> {
    if f.x >= w || f.y >= h { return None; }
    let seed = (f.y * w + f.x) * 4; let a = d[seed + 3] as f64; let (sr, sg, sb) = (d[seed] as f64 * a / 255.0, d[seed + 1] as f64 * a / 255.0, d[seed + 2] as f64 * a / 255.0);
    let mut visited = vec![0u8; w * h]; let tol = f.tolerance;
    let matches = |v: &Vec<u8>, i: usize| -> bool { if v[i] != 0 { return false; } let p = i * 4; let al = d[p + 3] as f64;
        (al - a).abs() <= tol && (d[p] as f64 * al / 255.0 - sr).abs() <= tol && (d[p + 1] as f64 * al / 255.0 - sg).abs() <= tol && (d[p + 2] as f64 * al / 255.0 - sb).abs() <= tol };
    let (mut x0, mut y0, mut x1, mut y1, mut count) = (w, h, 0usize, 0usize, 0usize);
    let mut stack = vec![f.y * w + f.x];
    if !f.contiguous { for i in 0..w * h { if matches(&visited, i) { visited[i] = 1; count += 1; let (xx, yy) = (i % w, i / w); x0 = x0.min(xx); x1 = x1.max(xx); y0 = y0.min(yy); y1 = y1.max(yy); } } stack.clear(); }
    while let Some(index) = stack.pop() {
        if !matches(&visited, index) { continue; } let row = index / w; let base = row * w; let mut left = index - base;
        while left > 0 && matches(&visited, base + left - 1) { left -= 1; }
        let (mut above, mut below) = (false, false); let mut xx = left;
        while xx < w && matches(&visited, base + xx) { let i = base + xx; visited[i] = 1; count += 1; x0 = x0.min(xx); x1 = x1.max(xx); y0 = y0.min(row); y1 = y1.max(row);
            if row > 0 { let ok = matches(&visited, i - w); if ok && !above { stack.push(i - w); } above = ok; }
            if row < h - 1 { let ok = matches(&visited, i + w); if ok && !below { stack.push(i + w); } below = ok; }
            xx += 1; }
    }
    if count == 0 { return Some((visited, 0, 0, 0, 0, 0)); }
    Some((visited, x0, y0, x1 - x0 + 1, y1 - y0 + 1, count))
}
fn round(v: f64) -> f64 { (v + 0.5).floor() } // Math.round for the non-negative values used here

/// Fill `s` like bucketFill when the region matches `expect` (x, y, w, h, count). Returns the region bounds and count.
pub fn apply(s: &mut Surface, f: &Fill, expect: (usize, usize, usize, usize, usize)) -> Result<(), (usize, usize, usize, usize, usize)> {
    let (w, h) = (s.width, s.height); let mut d = s.to_straight();
    let Some((mask, rx, ry, rw, rh, count)) = region(&d, w, h, f) else { return Err((0, 0, 0, 0, 0)) };
    if (rx, ry, rw, rh, count) != expect || count == 0 { return Err((rx, ry, rw, rh, count)); }
    let alpha = f.alpha;
    for yy in ry..ry + rh { for xx in rx..rx + rw { let i = yy * w + xx; if mask[i] == 0 { continue; } let p = i * 4; let old = d[p + 3] as f64 / 255.0;
        if f.alpha_lock && old == 0.0 { continue; }
        let out = if f.erase { old * (1.0 - alpha) } else if f.alpha_lock { old } else { alpha + old * (1.0 - alpha) };
        for k in 0..3 { let c = d[p + k] as f64;
            let v = if f.erase { if out > 0.0 { c } else { 0.0 } } else if f.alpha_lock { round(f.rgb[k] * alpha + c * (1.0 - alpha)) } else { round((f.rgb[k] * alpha + c * old * (1.0 - alpha)) / out) };
            d[p + k] = v.clamp(0.0, 255.0) as u8; }
        d[p + 3] = round(out * 255.0).clamp(0.0, 255.0) as u8; } }
    // The app writes the region rectangle back from straight values (putImageData / writeRegion of that rectangle).
    let mut patch = vec![0u8; rw * rh * 4]; for row in 0..rh { let si = ((ry + row) * w + rx) * 4; patch[row * rw * 4..(row + 1) * rw * 4].copy_from_slice(&d[si..si + rw * 4]); }
    s.write_region(&Surface::from_straight(rw, rh, &patch), rx as i64, ry as i64);
    Ok(())
}

/// v297: the whole bucket fill in the core (no region from the app): flood, blend, write back, and return the changed
/// 256px tiles for the app: [u32 x0][u32 y0][u32 w][u32 h][u32 count] (the region) then per tile [u32 x][u32 y]
/// [u32 kind: 0 empty, 1 pixels, 2 solid][u32 w][u32 h] + w*h*4 straight RGBA (kind 1) or 4 bytes (kind 2).
pub fn apply_tiles(s: &mut Surface, f: &Fill) -> Vec<u8> {
    let (w, h) = (s.width, s.height); let orig = s.to_straight(); let mut d = orig.clone();
    let mut out = Vec::new(); let put = |o: &mut Vec<u8>, v: usize| o.extend_from_slice(&(v as u32).to_le_bytes());
    let Some((mask, rx, ry, rw, rh, count)) = region(&d, w, h, f) else { for _ in 0..5 { put(&mut out, 0); } return out };
    for v in [rx, ry, rw, rh, count] { put(&mut out, v); } if count == 0 { return out; }
    let alpha = f.alpha;
    for yy in ry..ry + rh { for xx in rx..rx + rw { let i = yy * w + xx; if mask[i] == 0 { continue; } let p = i * 4; let old = d[p + 3] as f64 / 255.0;
        if f.alpha_lock && old == 0.0 { continue; }
        let o = if f.erase { old * (1.0 - alpha) } else if f.alpha_lock { old } else { alpha + old * (1.0 - alpha) };
        for k in 0..3 { let c = d[p + k] as f64; let v = if f.erase { if o > 0.0 { c } else { 0.0 } } else if f.alpha_lock { round(f.rgb[k] * alpha + c * (1.0 - alpha)) } else { round((f.rgb[k] * alpha + c * old * (1.0 - alpha)) / o) }; d[p + k] = v.clamp(0.0, 255.0) as u8; }
        d[p + 3] = round(o * 255.0).clamp(0.0, 255.0) as u8; } }
    // only changed tiles are written, here and in the app (both from the same straight values), so the two stay identical
    let t = 256; let mut ty = ry / t * t;
    while ty < ry + rh { let mut tx = rx / t * t; while tx < rx + rw { let (tw, th) = (t.min(w - tx), t.min(h - ty));
        let changed = (0..th).any(|r| { let i = ((ty + r) * w + tx) * 4; d[i..i + tw * 4] != orig[i..i + tw * 4] });
        if changed { let mut tile = vec![0u8; tw * th * 4]; for r in 0..th { let i = ((ty + r) * w + tx) * 4; tile[r * tw * 4..(r + 1) * tw * 4].copy_from_slice(&d[i..i + tw * 4]); }
            s.write_region(&Surface::from_straight(tw, th, &tile), tx as i64, ty as i64);
            put(&mut out, tx); put(&mut out, ty);
            let first = &d[(ty * w + tx) * 4..(ty * w + tx) * 4 + 4]; let uniform = (0..th).all(|r| { let i = ((ty + r) * w + tx) * 4; d[i..i + tw * 4].chunks_exact(4).all(|p| p == first) });
            let empty = uniform && first[3] == 0;
            if empty { put(&mut out, 0); put(&mut out, tw); put(&mut out, th); }
            else if uniform { put(&mut out, 2); put(&mut out, tw); put(&mut out, th); out.extend_from_slice(first); }
            else { put(&mut out, 1); put(&mut out, tw); put(&mut out, th); for r in 0..th { let i = ((ty + r) * w + tx) * 4; out.extend_from_slice(&d[i..i + tw * 4]); } } }
        tx += t; } ty += t; }
    out
}
