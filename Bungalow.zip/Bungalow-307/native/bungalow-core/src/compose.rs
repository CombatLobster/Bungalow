//! v270: native document compositor (stage 6, first slice). Builds the layer scene from the document store
//! (tree + props) exactly like `buildCompositeScene` in app.js and composites the native raster surfaces.
//!
//! Supported: raster layers (instance layers use their render cache surface), visibility through ancestors,
//! opacity, all 22 blend modes (16 CSS + linear-dodge, linear-burn, vivid-light, subtract, divide, glow),
//! inherit alpha (clipping) on layers and groups, pass-through vs. composited groups (opacity, blend, inherit
//! alpha, isolate), and (v271) paint masks: targeted at a layer or group, or legacy (untargeted: every layer
//! below the mask within its group). A mask multiplies the item's coverage by `maskAlphaByte(r,g,b,a,opacity)`
//! of its pixels (destination-in). v273 (stage 7): modifier layers (see modifiers.rs): targeted, stack-scoped
//! (untargeted: every visible layer below within its group, honouring isolated groups and maskDirect) and filter
//! layers (untargeted, non-direct adjustment: wraps everything below it in its bucket). Leaf/group order mirrors
//! paintLeafRaw/paintGroup: paint masks first, then the modifier chain, then opacity/blend. Unsupported modifier
//! kinds are reported so the caller falls back.
use crate::modifiers::{self, OpSpec};
use crate::raster::{Op, Rect, Surface};
use serde_json::Value;
use std::collections::{HashMap, HashSet};

const CSS: [&str; 16] = ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
const CUSTOM: [&str; 6] = ["linear-dodge", "linear-burn", "vivid-light", "subtract", "divide", "glow"];

/// Separable blend B(cb, cs) on straight [0, 1] channels (W3C compositing; app formulas for the custom modes).
fn sep(mode: &str, cb: f64, cs: f64) -> f64 {
    match mode {
        "multiply" => cb * cs,
        "screen" => cb + cs - cb * cs,
        "overlay" => sep("hard-light", cs, cb),
        "darken" => cb.min(cs),
        "lighten" => cb.max(cs),
        "color-dodge" => if cb <= 0.0 { 0.0 } else if cs >= 1.0 { 1.0 } else { (cb / (1.0 - cs)).min(1.0) },
        "color-burn" => if cb >= 1.0 { 1.0 } else if cs <= 0.0 { 0.0 } else { 1.0 - ((1.0 - cb) / cs).min(1.0) },
        "hard-light" => if cs <= 0.5 { cb * 2.0 * cs } else { let s = 2.0 * cs - 1.0; cb + s - cb * s },
        "soft-light" => if cs <= 0.5 { cb - (1.0 - 2.0 * cs) * cb * (1.0 - cb) } else { let d = if cb <= 0.25 { ((16.0 * cb - 12.0) * cb + 4.0) * cb } else { cb.sqrt() }; cb + (2.0 * cs - 1.0) * (d - cb) },
        "difference" => (cb - cs).abs(),
        "exclusion" => cb + cs - 2.0 * cb * cs,
        // custom (pixelBlendInto in app.js), clamped by the caller
        "linear-dodge" => cb + cs,
        "linear-burn" => cb + cs - 1.0,
        "vivid-light" => if cs <= 0.5 { if cs <= 0.0 { 0.0 } else { 1.0 - (1.0 - cb) / (2.0 * cs) } } else if cs >= 1.0 { 1.0 } else { cb / (2.0 * (1.0 - cs)) },
        "subtract" => cb - cs,
        "divide" => if cs <= 0.0 { 1.0 } else { cb / cs },
        "glow" => if cb >= 1.0 { 1.0 } else { cs * cs / (1.0 - cb) },
        _ => cs,
    }
}
fn lum(c: [f64; 3]) -> f64 { 0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2] }
fn clip_color(c: [f64; 3]) -> [f64; 3] {
    let l = lum(c); let n = c[0].min(c[1]).min(c[2]); let x = c[0].max(c[1]).max(c[2]); let mut o = c;
    if n < 0.0 { for v in o.iter_mut() { *v = l + (*v - l) * l / (l - n); } }
    if x > 1.0 { for v in o.iter_mut() { *v = l + (*v - l) * (1.0 - l) / (x - l); } }
    o
}
fn set_lum(c: [f64; 3], l: f64) -> [f64; 3] { let d = l - lum(c); clip_color([c[0] + d, c[1] + d, c[2] + d]) }
fn sat(c: [f64; 3]) -> f64 { c[0].max(c[1]).max(c[2]) - c[0].min(c[1]).min(c[2]) }
fn set_sat(c: [f64; 3], s: f64) -> [f64; 3] {
    let mut idx = [0usize, 1, 2]; idx.sort_by(|a, b| c[*a].partial_cmp(&c[*b]).unwrap());
    let (mn, md, mx) = (idx[0], idx[1], idx[2]); let mut o = [0.0; 3];
    if c[mx] > c[mn] { o[md] = (c[md] - c[mn]) * s / (c[mx] - c[mn]); o[mx] = s; }
    o
}
fn blend(mode: &str, b: [f64; 3], s: [f64; 3]) -> [f64; 3] {
    match mode {
        "hue" => set_lum(set_sat(s, sat(b)), lum(b)),
        "saturation" => set_lum(set_sat(b, sat(s)), lum(b)),
        "color" => set_lum(s, lum(b)),
        "luminosity" => set_lum(b, lum(s)),
        m => { let mut o = [sep(m, b[0], s[0]), sep(m, b[1], s[1]), sep(m, b[2], s[2])]; if CUSTOM.contains(&m) { for v in o.iter_mut() { *v = v.clamp(0.0, 1.0); } } o }
    }
}
fn straight(p: &[u8]) -> ([f64; 3], f64) { let a = p[3] as f64 / 255.0; if a <= 0.0 { ([0.0; 3], 0.0) } else { ([p[0] as f64 / 255.0 / a, p[1] as f64 / 255.0 / a, p[2] as f64 / 255.0 / a], a) } }
/// Blend `src` (opacity `alpha`) over `dst` with a non-normal mode: co = (1-as)·ab·Cb + (1-ab)·as·Cs + as·ab·B(Cb, Cs).
/// Skia's unpremultiply (SkUnPreMultiply scale table), which getImageData uses.
fn unpremul(p: u8, a: u8) -> f64 { if a == 0 { 0.0 } else { let scale = ((255u64 << 24) + (a as u64 >> 1)) / a as u64; (((p as u64 * scale) + (1 << 23)) >> 24).min(255) as f64 } }
fn premul(c: u8, a: u8) -> u8 { ((c as u32 * a as u32 + 127) / 255) as u8 }
/// The app's custom modes run on getImageData/putImageData (8-bit straight in and out); mirror that rounding.
fn blend_over_custom(dst: &mut Surface, src: &Surface, alpha: f64, mode: &str) {
    for i in (0..dst.data.len()).step_by(4) {
        let s = &src.data[i..i + 4]; let sa = s[3] as f64 / 255.0 * alpha; if sa <= 0.0 { continue; }
        let d = [dst.data[i], dst.data[i + 1], dst.data[i + 2], dst.data[i + 3]]; let da = d[3] as f64 / 255.0; let oa = sa + da * (1.0 - sa);
        if oa <= 0.0 { dst.data[i..i + 4].fill(0); continue; }
        let a8 = (255.0 * oa).round() as u8; let mut out = [0u8; 3];
        for k in 0..3 { let cs = unpremul(s[k], s[3]) / 255.0; let cb = unpremul(d[k], d[3]) / 255.0; let b = sep(mode, cb, cs).clamp(0.0, 1.0); out[k] = (255.0 * ((1.0 - sa) * da * cb + (1.0 - da) * sa * cs + sa * da * b) / oa).round().clamp(0.0, 255.0) as u8; }
        for k in 0..3 { dst.data[i + k] = premul(out[k], a8); } dst.data[i + 3] = a8;
    }
}
fn blend_over(dst: &mut Surface, src: &Surface, alpha: f64, mode: &str) {
    if CUSTOM.contains(&mode) { blend_over_custom(dst, src, alpha, mode); return; }
    for i in (0..dst.data.len()).step_by(4) {
        let (cs, sa0) = straight(&src.data[i..i + 4]); let sa = sa0 * alpha; if sa <= 0.0 { continue; }
        let (cb, da) = straight(&dst.data[i..i + 4]); let oa = sa + da * (1.0 - sa);
        let bx = blend(mode, cb, cs);
        for k in 0..3 { let co = (1.0 - sa) * da * cb[k] + (1.0 - da) * sa * cs[k] + sa * da * bx[k]; dst.data[i + k] = (co * 255.0).round().clamp(0.0, 255.0) as u8; }
        dst.data[i + 3] = (oa * 255.0).round().clamp(0.0, 255.0) as u8;
    }
}
/// Inherit alpha: colour comes from compositing `src` onto the backdrop, coverage stays the backdrop's.
fn draw_inherited(dst: &mut Surface, src: &Surface, alpha: f64, mode: &str) {
    let full = Rect { x: 0, y: 0, w: dst.width as i64, h: dst.height as i64 };
    if mode == "normal" { dst.compose_region(full, src, 0, 0, Op::SourceAtop, alpha as f32); return; }
    // backdrop over black (opaque), blend the source onto it, then source-atop onto the destination
    let mut buf = Surface::new(dst.width, dst.height);
    for i in (0..dst.data.len()).step_by(4) { buf.data[i..i + 3].copy_from_slice(&dst.data[i..i + 3]); buf.data[i + 3] = 255; }
    blend_over(&mut buf, src, alpha, mode);
    for i in (0..dst.data.len()).step_by(4) { let da = dst.data[i + 3] as f64 / 255.0; for k in 0..3 { dst.data[i + k] = (buf.data[i + k] as f64 * da).round() as u8; } }
}
fn draw(dst: &mut Surface, src: &Surface, alpha: f64, mode: &str, inherit: bool) {
    if inherit { draw_inherited(dst, src, alpha, mode); return; }
    if mode == "normal" { dst.compose_region(Rect { x: 0, y: 0, w: dst.width as i64, h: dst.height as i64 }, src, 0, 0, Op::SourceOver, alpha as f32); } else { blend_over(dst, src, alpha, mode); }
}

/// A paint mask applied to an item: its surface and layer opacity.
#[derive(Clone)]
struct Mask { surface: String, op: f64 }
enum Item { Leaf { surface: String, op: f64, blend: String, inherit: bool, masks: Vec<Mask>, ops: Vec<OpSpec> }, Group { op: f64, blend: String, inherit: bool, masks: Vec<Mask>, ops: Vec<OpSpec>, children: Vec<Item>, filter: bool } }

/// `maskAlphaByte` in app.js: coverage of one mask pixel (straight RGBA as getImageData reports it).
fn mask_alpha(r: f64, g: f64, b: f64, a: f64, opacity: f64) -> f64 { (255.0 - a * opacity * (1.0 - r.max(g).max(b) / 255.0)).round() }
/// destination-in with the mask: scale every channel of `dst` by the mask coverage.
fn stamp_mask(dst: &mut Surface, m: &Surface, opacity: f64) {
    for i in (0..dst.data.len()).step_by(4) {
        let a = m.data[i + 3];
        let (r, g, b) = (unpremul(m.data[i], a), unpremul(m.data[i + 1], a), unpremul(m.data[i + 2], a));
        let c = mask_alpha(r, g, b, a as f64, opacity).clamp(0.0, 255.0) as u32;
        for k in 0..4 { dst.data[i + k] = ((dst.data[i + k] as u32 * c + 127) / 255) as u8; }
    }
}

/// Composite the active document. `Err` lists why the document is outside the supported set (or broken).
/// `Ok((image, approximate))`: `approximate` lists modelled (not bit-level) ops in the scene, e.g. rotated transforms.
pub fn composite(doc: &Value, surfaces: &HashMap<&str, &Surface>) -> Result<(Surface, Vec<String>), Vec<String>> {
    let w = doc["document"]["width"].as_f64().unwrap_or(0.0) as usize; let h = doc["document"]["height"].as_f64().unwrap_or(0.0) as usize;
    let strs = |v: &Value| v.as_array().map(|a| a.iter().filter_map(|x| x.as_str().map(String::from)).collect::<Vec<_>>()).unwrap_or_default();
    let stack = strs(&doc["tree"]["layers"]);
    let empty = serde_json::Map::new(); let props = doc["props"].as_object().unwrap_or(&empty);
    let parent = |n: &str| doc["tree"]["parents"].get(n).and_then(Value::as_str).map(String::from);
    let p = |n: &str, k: &str| props.get(n).and_then(|r| r.get(k));
    let flag = |n: &str, k: &str| p(n, k).and_then(Value::as_bool).unwrap_or(false);
    let vis = |n: &str| p(n, "vis").and_then(Value::as_bool).unwrap_or(true);
    let op = |n: &str| p(n, "op").and_then(Value::as_f64).unwrap_or(1.0);
    let blend_of = |n: &str| p(n, "blend").and_then(Value::as_str).unwrap_or("normal").to_string();
    let ancestors = |n: &str| { let mut out = Vec::new(); let mut g = parent(n); while let Some(x) = g { if out.contains(&x) { break; } g = parent(&x); out.push(x); } out };
    let visible = |n: &str| vis(n) && ancestors(n).iter().all(|g| vis(g));
    let mut reasons = Vec::new();
    if w == 0 || h == 0 { reasons.push("no document size".to_string()); }
    let shown: Vec<&String> = stack.iter().filter(|l| visible(l)).collect();
    let target_of = |n: &str| p(n, "maskTarget").and_then(Value::as_str).map(String::from);
    let is_paint = |n: &str| p(n, "maskKind").and_then(Value::as_str).unwrap_or("paint") == "paint";
    // v273: an untargeted, non-direct filter modifier is a filter layer (wraps the items below it)
    let filter_layer = |n: &str| p(n, "maskKind").and_then(Value::as_str) == Some("filter") && target_of(n).is_none() && !flag(n, "maskDirect");
    for l in &shown {
        if flag(l, "mask") {
            let kind = p(l, "maskKind").and_then(Value::as_str).unwrap_or("paint");
            // v273: modifiers are supported per kind; anything else falls back with the reason
            if kind != "paint" && op(l) > 0.0 { if let Err(why) = modifiers::parse(&doc["props"][l.as_str()], !filter_layer(l)) { reasons.push(format!("{why}: {l}")); } }
            continue;
        }
        let b = blend_of(l); if !CSS.contains(&b.as_str()) && !CUSTOM.contains(&b.as_str()) { reasons.push(format!("blend {b}")); }
    }
    for g in strs(&doc["tree"]["groups"]) { let b = blend_of(&g); if !CSS.contains(&b.as_str()) && !CUSTOM.contains(&b.as_str()) { reasons.push(format!("blend {b}")); } }
    for m in shown.iter().filter(|l| flag(l, "mask") && is_paint(l)) {
        let Some(sid) = p(m, "rasterId").and_then(Value::as_str) else { reasons.push(format!("mask without surface: {m}")); continue };
        match surfaces.get(sid) { None => reasons.push(format!("missing mask surface {sid}")), Some(s) if s.width != w || s.height != h => reasons.push(format!("mask surface {sid} is {}x{}, document {w}x{h}", s.width, s.height)), _ => {} }
    }
    if !reasons.is_empty() { return Err(reasons); }
    // groups that must be composited (mirrors `composite(G)` in buildCompositeScene)
    let mut inherit_groups = HashSet::new();
    for l in shown.iter().filter(|l| !flag(l, "mask")) { let mut inh = flag(l, "inheritAlpha"); for g in ancestors(l) { inh = inh || flag(&g, "inheritAlpha"); if inh { inherit_groups.insert(g); } } }
    let iso_matters = |g: &str| shown.iter().any(|l| { let anc = ancestors(l); let pos = anc.iter().position(|x| x == g);
        // isolationWhy: a mask inside the group, or an untargeted mask anywhere (it can reach inside), matters
        if flag(l, "mask") { return pos.is_some() || target_of(l).is_none(); }
        let Some(pos) = pos else { return false }; flag(l, "inheritAlpha") || blend_of(l) != "normal" || anc[..pos].iter().any(|q| flag(q, "inheritAlpha") || blend_of(q) != "normal") });
    // v273: masks and modifiers reaching a node (maskReaches / stackModifierReaches), in stack order
    let isolated_away = |l: &str, m: &str| { let am = ancestors(m); ancestors(l).iter().any(|g| flag(g, "isolate") && !am.contains(g)) };
    let index_of = |n: &str| stack.iter().position(|x| x == n).unwrap_or(0);
    let direct_target = |m: &str| -> Option<String> { let mi = index_of(m); let mg = parent(m);
        (0..mi).rev().map(|j| &stack[j]).find(|c| !flag(c, "mask") && mg.as_ref().map_or(true, |g| ancestors(c).contains(g)) && !isolated_away(c, m) && visible(c)).cloned() };
    let reaches = |m: &str, l: &str| -> bool {
        if let Some(t) = target_of(m) { return t == l; }
        let (mi, li) = (index_of(m), index_of(l)); if li >= mi || !parent(m).map_or(true, |g| ancestors(l).contains(&g)) { return false; }
        if is_paint(m) { return true; }
        if isolated_away(l, m) { return false; }
        !flag(m, "maskDirect") || direct_target(m).as_deref() == Some(l)
    };
    // v274: untargeted random colour overlays pick a colour per reached layer (randomIndex: order among every non-mask layer it reaches)
    let random_index = |m: &str, l: &str| stack.iter().filter(|x| !flag(x, "mask") && reaches(m, x)).position(|x| x == l).unwrap_or(0) as u32;
    let fx_of = |list: Vec<&String>, target: Option<&str>| -> (Vec<Mask>, Vec<OpSpec>) { let (mut masks, mut ops) = (Vec::new(), Vec::new());
        for m in list { if is_paint(m) { if let Some(s) = p(m, "rasterId").and_then(Value::as_str) { masks.push(Mask { surface: s.into(), op: op(m) }); } }
            else if !filter_layer(m) { if let Ok(Some(mut spec)) = modifiers::parse(&doc["props"][m.as_str()], true) {
                if let (Some(l), None) = (target, target_of(m)) { modifiers::with_random_index(&mut spec, &doc["props"][m.as_str()], random_index(m, l)); } ops.push(spec); } } }
        (masks, ops) };
    let group_fx = |g: &str| fx_of(shown.iter().filter(|m| flag(m, "mask") && target_of(m).as_deref() == Some(g)).copied().collect(), None);
    let group_masked = |g: &str| shown.iter().any(|m| flag(m, "mask") && target_of(m).as_deref() == Some(g));
    let layer_fx = |l: &str| fx_of(shown.iter().filter(|m| flag(m, "mask") && reaches(m, l)).copied().collect(), Some(l));
    let needs = |g: &str| (flag(g, "isolate") && iso_matters(g)) || group_masked(g) || flag(g, "inheritAlpha") || inherit_groups.contains(g) || op(g) != 1.0 || blend_of(g) != "normal";
    let parent_for = |n: &str| ancestors(n).into_iter().find(|g| needs(g));
    // Build the scene: root items plus composited groups, created in first-use order like `bucket()`.
    let mut root: Vec<Item> = Vec::new(); let mut groups: HashMap<String, Vec<Item>> = HashMap::new(); let mut order: Vec<(String, Option<String>)> = Vec::new();
    let ensure = |g: &str, groups: &mut HashMap<String, Vec<Item>>, order: &mut Vec<(String, Option<String>)>| { let mut chain = Vec::new(); let mut cur = Some(g.to_string()); while let Some(x) = cur { if groups.contains_key(&x) { break; } groups.insert(x.clone(), Vec::new()); let pf = parent_for(&x); chain.push((x.clone(), pf.clone())); cur = pf; } chain.reverse(); order.extend(chain); };
    // placement records: (bucket, index) for leaves; groups are placed via `order`
    enum Slot { Leaf(Item), Group(String), Filter { op: f64, spec: OpSpec, children: Vec<Slot> } }
    let mut slots: HashMap<Option<String>, Vec<Slot>> = HashMap::new();
    for l in shown.iter() {
        let o = op(l); if o <= 0.0 { continue; }
        if flag(l, "mask") {
            // v273: filter layer = composited wrapper around everything already in its bucket
            if !filter_layer(l) { continue; }
            let Ok(Some(spec)) = modifiers::parse(&doc["props"][l.as_str()], false) else { continue };
            let pf = parent_for(l);
            if let Some(g) = &pf { let before = order.len(); ensure(g, &mut groups, &mut order); for (gid, gp) in order[before..].to_vec() { slots.entry(gp).or_default().push(Slot::Group(gid)); } }
            let list = slots.entry(pf).or_default(); let children: Vec<Slot> = list.drain(..).collect();
            if !children.is_empty() { list.push(Slot::Filter { op: o, spec, children }); }
            continue;
        }
        let Some(sid) = p(l, "rasterId").and_then(Value::as_str) else { continue };
        match surfaces.get(sid) { None => return Err(vec![format!("missing surface {sid}")]), Some(s) if s.width != w || s.height != h => return Err(vec![format!("surface {sid} is {}x{}, document {w}x{h}", s.width, s.height)]), _ => {} }
        let pf = parent_for(l);
        if let Some(g) = &pf { let before = order.len(); ensure(g, &mut groups, &mut order); for (gid, gp) in order[before..].to_vec() { slots.entry(gp).or_default().push(Slot::Group(gid)); } }
        let (masks, ops) = layer_fx(l);
        slots.entry(pf).or_default().push(Slot::Leaf(Item::Leaf { surface: sid.into(), op: o, blend: blend_of(l), inherit: flag(l, "inheritAlpha"), masks, ops }));
    }
    fn build(list: Vec<Slot>, slots: &mut HashMap<Option<String>, Vec<Slot>>, mk: &dyn Fn(&str, Vec<Item>) -> Item) -> Vec<Item> {
        list.into_iter().map(|s| match s {
            Slot::Leaf(i) => i,
            Slot::Group(g) => { let l = slots.remove(&Some(g.clone())).unwrap_or_default(); let ch = build(l, slots, mk); mk(&g, ch) }
            Slot::Filter { op, spec, children } => Item::Group { op, blend: "normal".into(), inherit: false, masks: vec![], ops: vec![spec], children: build(children, slots, mk), filter: true },
        }).collect()
    }
    let mk = |g: &str, children: Vec<Item>| { let (masks, ops) = group_fx(g); Item::Group { op: op(g), blend: blend_of(g), inherit: flag(g, "inheritAlpha"), masks, ops, children, filter: false } };
    let top = slots.remove(&None).unwrap_or_default();
    root.extend(build(top, &mut slots, &mk));
    let _ = groups;
    fn paint(dst: &mut Surface, items: &[Item], surfaces: &HashMap<&str, &Surface>) {
        let bo = |d: &mut Surface, s: &Surface, a: f64, m: &str| blend_over(d, s, a, m);
        for it in items { match it {
            Item::Leaf { surface, op, blend, inherit, masks, ops } => {
                if masks.is_empty() && ops.is_empty() { draw(dst, surfaces[surface.as_str()], *op, blend, *inherit); } else {
                    let mut tmp = surfaces[surface.as_str()].clone(); for m in masks { stamp_mask(&mut tmp, surfaces[m.surface.as_str()], m.op); }
                    if !ops.is_empty() { tmp = modifiers::apply(&tmp, ops, &bo); }
                    draw(dst, &tmp, *op, blend, *inherit);
                }
            }
            Item::Group { op, blend, inherit, masks, ops, children, filter } => {
                let mut buf = Surface::new(dst.width, dst.height); paint(&mut buf, children, surfaces); for m in masks { stamp_mask(&mut buf, surfaces[m.surface.as_str()], m.op); }
                // drawGroupResult: a filter layer below full opacity shows the unfiltered content underneath
                if *filter && *op < 1.0 { draw(dst, &buf, 1.0, "normal", false); }
                if !ops.is_empty() { buf = modifiers::apply(&buf, ops, &bo); } draw(dst, &buf, *op, blend, *inherit);
            }
        } }
    }
    fn approx(items: &[Item], out: &mut Vec<String>) { for it in items { let (ops, ch): (&Vec<OpSpec>, Option<&Vec<Item>>) = match it { Item::Leaf { ops, .. } => (ops, None), Item::Group { ops, children, .. } => (ops, Some(children)) };
        for o in ops { if let Some(r) = modifiers::approximate(o) { if !out.contains(&r) { out.push(r); } } } if let Some(c) = ch { approx(c, out); } } }
    let mut approximate = Vec::new(); approx(&root, &mut approximate);
    let mut out = Surface::new(w, h); paint(&mut out, &root, surfaces); Ok((out, approximate))
}

