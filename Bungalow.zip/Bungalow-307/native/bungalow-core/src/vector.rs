//! v285: retained vector layers rendered in the core with tiny-skia from the display list the app records
//! (src/native-vector-285.js). v299: the v282 Bristle stroke canvas was removed (archived with the core brushes).
use serde_json::Value;
use tiny_skia::{BlendMode, Color, FillRule, GradientStop, LinearGradient, LineCap, LineJoin, Mask, Paint, PathBuilder, Pixmap, Point, RadialGradient, Shader, SpreadMode, Stroke, StrokeDash, Transform};

/// Append an elliptical arc (canvas `ellipse`) as cubic Béziers; joins the current point with a line like canvas.
fn ellipse(pb: &mut PathBuilder, cx: f32, cy: f32, rx: f32, ry: f32, rot: f32, a0: f32, a1: f32, has_point: bool) {
    let mut sweep = a1 - a0; if sweep > std::f32::consts::TAU { sweep = std::f32::consts::TAU; } if sweep < -std::f32::consts::TAU { sweep = -std::f32::consts::TAU; }
    let n = ((sweep.abs() / std::f32::consts::FRAC_PI_2).ceil() as usize).max(1); let step = sweep / n as f32;
    let (cr, sr) = (rot.cos(), rot.sin()); let pt = |a: f32| { let (x, y) = (rx * a.cos(), ry * a.sin()); (cx + x * cr - y * sr, cy + x * sr + y * cr) };
    let d = |a: f32| { let (x, y) = (-rx * a.sin(), ry * a.cos()); (x * cr - y * sr, x * sr + y * cr) };
    let p0 = pt(a0); if has_point { pb.line_to(p0.0, p0.1); } else { pb.move_to(p0.0, p0.1); }
    let k = 4.0 / 3.0 * (step / 4.0).tan();
    for i in 0..n { let (s, e) = (a0 + step * i as f32, a0 + step * (i + 1) as f32); let (ps, pe, ds, de) = (pt(s), pt(e), d(s), d(e));
        pb.cubic_to(ps.0 + ds.0 * k, ps.1 + ds.1 * k, pe.0 - de.0 * k, pe.1 - de.1 * k, pe.0, pe.1); }
}
fn f(v: &Value, i: usize) -> f32 { v.get(i).and_then(Value::as_f64).unwrap_or(0.0) as f32 }
/// Path from a flat op list: 0 x y = moveTo, 1 x y = lineTo, 2 = closePath, 3 cx cy rx ry rot a0 a1 = ellipse,
/// (v285) 4 c1x c1y c2x c2y x y = cubic, 5 cx cy x y = quadratic.
fn path(ops: &[Value]) -> Option<tiny_skia::Path> {
    let mut pb = PathBuilder::new(); let mut i = 0; let mut has = false; let n = |k: usize| ops.get(k).and_then(Value::as_f64).unwrap_or(0.0) as f32;
    while i < ops.len() {
        match ops[i].as_u64().unwrap_or(99) {
            0 => { pb.move_to(n(i + 1), n(i + 2)); has = true; i += 3; }
            1 => { if has { pb.line_to(n(i + 1), n(i + 2)); } else { pb.move_to(n(i + 1), n(i + 2)); has = true; } i += 3; }
            2 => { if has { pb.close(); } i += 1; }
            3 => { ellipse(&mut pb, n(i + 1), n(i + 2), n(i + 3).abs(), n(i + 4).abs(), n(i + 5), n(i + 6), n(i + 7), has); has = true; i += 8; }
            4 => { if !has { pb.move_to(n(i + 1), n(i + 2)); has = true; } pb.cubic_to(n(i + 1), n(i + 2), n(i + 3), n(i + 4), n(i + 5), n(i + 6)); i += 7; }
            5 => { if !has { pb.move_to(n(i + 1), n(i + 2)); has = true; } pb.quad_to(n(i + 1), n(i + 2), n(i + 3), n(i + 4)); i += 5; }
            _ => return None,
        }
    }
    pb.finish()
}
// ---- v285: retained vector layers rendered in the core ----------------------------------------------------------------
// A layer's vector objects are recorded from the app's canvas calls (src/native-vector-285.js) as a display list in user
// space with the transform of each draw: {draws: [...], clips: [[{p, m, rule}...]...]}. A draw is
// {k: 'f'|'s', p: path ops, m: [a,b,c,d,e,f], rule?: 'evenodd', c?: [r,g,b,a] | g?: {t: 'l'|'r', v: [...], s: [[t,r,g,b,a]...]},
//  a: globalAlpha, o?: 'd' (destination-out), w, cap, join, ml, dash?, dof, clip?: index into clips, gm?: shader transform}.
fn tf(m: &Value) -> Transform { Transform::from_row(f(m, 0), f(m, 1), f(m, 2), f(m, 3), f(m, 4), f(m, 5)) }
fn rule(d: &Value) -> FillRule { if d.get("rule").and_then(Value::as_str) == Some("evenodd") { FillRule::EvenOdd } else { FillRule::Winding } }
fn shader(d: &Value, m: Transform, alpha: f32) -> Option<Shader<'static>> {
    if let Some(c) = d.get("c") { let mut col = Color::from_rgba8(f(c, 0).clamp(0.0, 255.0) as u8, f(c, 1).clamp(0.0, 255.0) as u8, f(c, 2).clamp(0.0, 255.0) as u8, (f(c, 3).clamp(0.0, 1.0) * 255.0).round() as u8); col.apply_opacity(alpha); return Some(Shader::SolidColor(col)); }
    let g = d.get("g")?; let v = g.get("v")?; let stops: Vec<GradientStop> = g.get("s")?.as_array()?.iter().map(|st| GradientStop::new(f(st, 0), Color::from_rgba8(f(st, 1) as u8, f(st, 2) as u8, f(st, 3) as u8, (f(st, 4).clamp(0.0, 1.0) * 255.0).round() as u8))).collect();
    let mut sh = match g.get("t").and_then(Value::as_str)? {
        "l" => LinearGradient::new(Point::from_xy(f(v, 0), f(v, 1)), Point::from_xy(f(v, 2), f(v, 3)), stops, SpreadMode::Pad, m)?,
        "r" => RadialGradient::new(Point::from_xy(f(v, 0), f(v, 1)), Point::from_xy(f(v, 0), f(v, 1)), f(v, 2), stops, SpreadMode::Pad, m)?,
        _ => return None };
    sh.apply_opacity(alpha); Some(sh)
}
/// Render a recorded vector layer into a transparent w×h surface (premultiplied).
pub fn render_list(w: usize, h: usize, list: &Value) -> Result<crate::raster::Surface, String> {
    let mut pix = Pixmap::new(w as u32, h as u32).ok_or("Invalid vector layer size")?;
    let mut masks: Vec<Option<Mask>> = Vec::new();
    for stack in list.get("clips").and_then(Value::as_array).map(|a| a.as_slice()).unwrap_or(&[]) {
        let mut mask: Option<Mask> = None;
        for c in stack.as_array().map(|a| a.as_slice()).unwrap_or(&[]) { let Some(p) = c.get("p").and_then(Value::as_array).and_then(|o| path(o)) else { mask = Mask::new(w as u32, h as u32); continue };
            match mask.as_mut() { Some(m) => m.intersect_path(&p, rule(c), true, tf(c.get("m").unwrap_or(&Value::Null))), None => { let mut m = Mask::new(w as u32, h as u32).ok_or("mask")?; m.fill_path(&p, rule(c), true, tf(c.get("m").unwrap_or(&Value::Null))); mask = Some(m); } } }
        masks.push(mask);
    }
    for d in list.get("draws").and_then(Value::as_array).map(|a| a.as_slice()).unwrap_or(&[]) {
        let Some(p) = d.get("p").and_then(Value::as_array).and_then(|o| path(o)) else { continue };
        let m = tf(d.get("m").unwrap_or(&Value::Null)); let alpha = d.get("a").and_then(Value::as_f64).unwrap_or(1.0).clamp(0.0, 1.0) as f32; if alpha <= 0.0 { continue; }
        let gm = d.get("gm").map(tf).unwrap_or(m); let Some(sh) = shader(d, gm, alpha) else { continue };
        let mut paint = Paint::default(); paint.anti_alias = true; paint.shader = sh; if d.get("o").and_then(Value::as_str) == Some("d") { paint.blend_mode = BlendMode::DestinationOut; }
        let mask = d.get("clip").and_then(Value::as_u64).and_then(|i| masks.get(i as usize)).and_then(|m| m.as_ref());
        match d.get("k").and_then(Value::as_str) {
            Some("f") => pix.fill_path(&p, &paint, rule(d), m, mask),
            Some("s") => { let width = d.get("w").and_then(Value::as_f64).unwrap_or(1.0) as f32; if width <= 0.0 { continue; }
                let cap = match d.get("cap").and_then(Value::as_str) { Some("round") => LineCap::Round, Some("square") => LineCap::Square, _ => LineCap::Butt };
                let join = match d.get("join").and_then(Value::as_str) { Some("round") => LineJoin::Round, Some("bevel") => LineJoin::Bevel, _ => LineJoin::Miter };
                let dash = d.get("dash").and_then(Value::as_array).filter(|a| !a.is_empty()).and_then(|a| { let mut v: Vec<f32> = a.iter().map(|x| x.as_f64().unwrap_or(0.0) as f32).collect(); if v.len() % 2 == 1 { v.extend(v.clone()); } StrokeDash::new(v, d.get("dof").and_then(Value::as_f64).unwrap_or(0.0) as f32) });
                let st = Stroke { width, line_cap: cap, line_join: join, miter_limit: d.get("ml").and_then(Value::as_f64).unwrap_or(10.0) as f32, dash };
                pix.stroke_path(&p, &paint, &st, m, mask) }
            _ => {}
        }
    }
    let mut s = crate::raster::Surface::new(w, h); s.data.copy_from_slice(pix.data()); Ok(s)
}
