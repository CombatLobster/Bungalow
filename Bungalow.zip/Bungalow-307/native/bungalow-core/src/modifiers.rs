//! v273: native modifier layers (stage 7, first slice). Mirrors `rawMaskOp` / `maskOp` / `applyOpOnto` in app.js.
//!
//! Supported op kinds: colour overlay (fixed colour, not random), transform (affine, Chromium drawImage sampling:
//! exact for integer translations, bilinear otherwise, anti-aliased edges when rotated/skewed), and the point
//! adjustments brightness/contrast, curves, HSV, alpha-from-colour and saturation curves. Every op also takes the
//! modifier layer's opacity (straight-alpha mix with the input, as applyOpOnto does) and blend (`opBlendInto`).
//! Identity adjustments are skipped like `adjustIsIdentity`. Everything else (mirror, stroke, gradient, shadow,
//! blur, sharpen, bloom, legacy CSS filters, random colour) is reported as unsupported so the caller falls back.
//!
//! The adjustments run on 8-bit straight colour exactly like getImageData/putImageData: Skia's unpremultiply on read,
//! Uint8ClampedArray rounding (half to even) on write, and premultiply on put.
use crate::raster::{Op, Rect, Surface};
use serde_json::Value;

const CSS_BLENDS: [&str; 15] = ["multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];

/// Point adjustment, pre-baked into tables where the app bakes them.
#[derive(Clone, Debug)]
pub enum Adjust { Tables([[u8; 256]; 3]), Hsv { hue: f64, sat: f64, val: f64 }, Alpha { target: [f64; 3], threshold: f64, value: f64 }, Saturation { lut: Vec<f32>, channels: [Vec<f32>; 3] } }
#[derive(Clone, Debug)]
pub enum Kind { Colour { rgb: [u8; 3], amount: f64 }, Transform([f64; 6]), Adjust(Adjust), Spatial(Spatial), Mirror(MirrorCfg), Stroke(crate::stroke::StrokeCfg), Gradient(crate::gradient::GradientCfg), Matrix([f64; 12]) }
/// v274: MirrorKit.normalise; the pivot needs the document size, so axes are built at apply time.
#[derive(Clone, Debug)]
pub struct MirrorCfg { cx: f64, cy: f64, angle: f64, v: bool, h: bool, side_v: String, side_h: String, clip: bool }
/// v274: spatial filters built on the canvas Gaussian blur (`filter = 'blur(σpx)'`; σ is the CSS value).
#[derive(Clone, Debug)]
pub enum Spatial {
    /// Gaussian blur of every channel (adjust blur, legacy blur filter layer).
    Blur { sigma: f64 },
    /// Adjust blur with "preserve edges": colour from the blur, alpha kept (adjustSteps).
    BlurPreserve { sigma: f64 },
    /// Unsharp mask (sharpenPixelsFast).
    Sharpen { amount: f64, sigma: f64, threshold: f64 },
    /// Bloom (adjustBloomInto): bright pass, blurred, screened on `intensity` times.
    Bloom { threshold: f64, sigma: f64, intensity: f64 },
    /// Drop shadow (filterCSS drop-shadow: σ = radius; fractional offsets sample the blurred shadow bilinearly), colour premultiplied by opacity.
    Shadow { rgb: [u8; 3], opacity: f64, sigma: f64, dx: f64, dy: f64 },
}
/// One step of a modifier chain (`maskOp`): `None` opacity/blend for filter layers (`rawMaskOp`).
#[derive(Clone, Debug)]
pub struct OpSpec { pub kind: Kind, pub opacity: Option<f64>, pub blend: Option<String> }

// ---------- JS numeric helpers ----------
/// Uint8ClampedArray store: clamp, round half to even, NaN -> 0.
pub fn u8c(v: f64) -> u8 { if !(v > 0.0) { return 0; } if v >= 255.0 { return 255; } let f = v.floor(); let d = v - f; let r = if d > 0.5 { f + 1.0 } else if d < 0.5 { f } else if (f as u32) % 2 == 0 { f } else { f + 1.0 }; r as u8 }
/// Math.round (half up).
fn js_round(v: f64) -> f64 { (v + 0.5).floor() }
fn clamp01(v: f64) -> f64 { v.max(0.0).min(1.0) }
/// Skia's unpremultiply (getImageData).
pub fn unpremul(p: u8, a: u8) -> u8 { if a == 0 { 0 } else { let scale = ((255u64 << 24) + (a as u64 >> 1)) / a as u64; (((p as u64 * scale) + (1 << 23)) >> 24).min(255) as u8 } }
fn premul(c: u8, a: u8) -> u8 { ((c as u32 * a as u32 + 127) / 255) as u8 }
/// getImageData: straight RGBA.
fn read(s: &Surface) -> Vec<u8> { let mut o = s.data.clone(); for px in o.chunks_exact_mut(4) { let a = px[3]; for k in 0..3 { px[k] = unpremul(px[k], a); } } o }
/// putImageData: premultiply into a surface.
fn put(w: usize, h: usize, d: &[u8]) -> Surface { let mut s = Surface::new(w, h); for (i, px) in d.chunks_exact(4).enumerate() { let a = px[3]; s.data[i * 4..i * 4 + 4].copy_from_slice(&[premul(px[0], a), premul(px[1], a), premul(px[2], a), a]); } s }

// ---------- curves (pointCurveLUT, cleanCurvePoints, cleanSaturationPoints) ----------
fn clean_points(v: Option<&Value>, neutral: [[f64; 2]; 2]) -> Vec<[f64; 2]> {
    let fallback = || neutral.to_vec();
    let Some(arr) = v.and_then(Value::as_array) else { return fallback() };
    if arr.len() < 2 || arr.len() > 64 { return fallback(); }
    let mut pts = Vec::new();
    for p in arr { let Some(q) = p.as_array() else { return fallback() }; if q.len() != 2 { return fallback(); } let (Some(x), Some(y)) = (q[0].as_f64(), q[1].as_f64()) else { return fallback() }; pts.push([clamp01(x), clamp01(y)]); }
    pts.sort_by(|a, b| a[0].partial_cmp(&b[0]).unwrap()); // stable, like Array.prototype.sort
    let kept: Vec<[f64; 2]> = pts.iter().enumerate().filter(|(i, p)| *i == 0 || p[0] - pts[i - 1][0] > 0.001).map(|(_, p)| *p).collect();
    if kept.len() < 2 { fallback() } else { kept }
}
fn point_curve_lut(points: &[[f64; 2]]) -> Vec<f32> {
    let n = points.len(); let mut lut = vec![0f32; 256];
    let slopes: Vec<f64> = (0..n - 1).map(|i| (points[i + 1][1] - points[i][1]) / (points[i + 1][0] - points[i][0])).collect();
    let m: Vec<f64> = (0..n).map(|i| if i == 0 { slopes[0] } else if i == n - 1 { slopes[n - 2] } else if slopes[i - 1] * slopes[i] <= 0.0 { 0.0 } else { 2.0 * slopes[i - 1] * slopes[i] / (slopes[i - 1] + slopes[i]) }).collect();
    let mut j = 0;
    for i in 0..256 {
        let x = i as f64 / 255.0;
        if x <= points[0][0] { lut[i] = points[0][1] as f32; continue; }
        if x >= points[n - 1][0] { lut[i] = points[n - 1][1] as f32; continue; }
        while j < n - 2 && x > points[j + 1][0] { j += 1; }
        let h = points[j + 1][0] - points[j][0]; let t = (x - points[j][0]) / h; let t2 = t * t; let t3 = t2 * t;
        lut[i] = clamp01((2.0 * t3 - 3.0 * t2 + 1.0) * points[j][1] + (t3 - 2.0 * t2 + t) * h * m[j] + (-2.0 * t3 + 3.0 * t2) * points[j + 1][1] + (t3 - t2) * h * m[j + 1]) as f32;
    }
    lut
}
const IDENTITY: [[f64; 2]; 2] = [[0.0, 0.0], [1.0, 1.0]];
const NEUTRAL: [[f64; 2]; 2] = [[0.0, 0.5], [1.0, 0.5]];
/// `tonalTables`: master curve then per-channel curve, as Float32 values in [0, 1].
fn tonal_tables(params: &Value) -> [Vec<f32>; 3] {
    let cp = params.get("curvePoints"); let master = point_curve_lut(&clean_points(cp.and_then(|c| c.get("rgb")), IDENTITY));
    ["r", "g", "b"].map(|k| { let ch = point_curve_lut(&clean_points(cp.and_then(|c| c.get(k)), IDENTITY)); master.iter().map(|v| ch[js_round(*v as f64 * 255.0) as usize]).collect() })
}
/// Byte table like the unmasked path of adjustSteps: t[v] = v; t[v] += l[v] - v.
fn byte_lut(l: &[f64]) -> [u8; 256] { let mut t = [0u8; 256]; for v in 0..256 { let f = v as f64; t[v] = u8c(f + (l[v] - f)); } t }

// ---------- parsing (rawMaskOp + sanitizeAdjustParams defaults) ----------
fn num(p: &Value, k: &str, d: f64, lo: f64, hi: f64) -> f64 { p.get(k).and_then(Value::as_f64).map(|v| v.max(lo).min(hi)).unwrap_or(d) }
fn hex_rgb(s: &str) -> Option<[u8; 3]> { if s.len() != 7 || !s.starts_with('#') { return None; } let b = |i: usize| u8::from_str_radix(&s[i..i + 2], 16).ok(); Some([b(1)?, b(3)?, b(5)?]) }
/// `None` = identity (skipped by applyOpOnto); `Err` = not supported natively.
fn parse_adjust(p: &Value) -> Result<Option<Kind>, String> { Ok(match parse_point(p)? { Point::Some(a) => Some(Kind::Adjust(a)), Point::Spatial(k) => Some(Kind::Spatial(k)), Point::Identity => None }) }
enum Point { Some(Adjust), Spatial(Spatial), Identity }
fn parse_point(p: &Value) -> Result<Point, String> {
    let ty = p.get("type").and_then(Value::as_str).unwrap_or("blur");
    match ty {
        "brightness" => {
            let (b, c) = (num(p, "brightness", 0.0, -100.0, 100.0), num(p, "contrast", 0.0, -100.0, 100.0));
            if b == 0.0 && c == 0.0 { return Ok(Point::Identity); }
            let gain = if c >= 0.0 { 1.0 + c / 25.0 } else { 1.0 + c / 100.0 };
            let l: Vec<f64> = (0..256).map(|v| ((v as f64 - 128.0) * gain + 128.0 + b * 2.55).max(0.0).min(255.0)).collect();
            let t = byte_lut(&l); Ok(Point::Some(Adjust::Tables([t, t, t])))
        }
        "curves" => {
            if p.get("curvePoints").is_none() && p.get("cc").is_some() { return Err("legacy bezier curves adjustment".into()); }
            let t = tonal_tables(p);
            if (0..3).all(|k| (0..256).all(|v| js_round(t[k][v] as f64 * 255.0) as usize == v)) { return Ok(Point::Identity); }
            Ok(Point::Some(Adjust::Tables([0, 1, 2].map(|k| byte_lut(&t[k].iter().map(|v| *v as f64 * 255.0).collect::<Vec<_>>())))))
        }
        "hsv" => { let (hue, sat, val) = (num(p, "hue", 0.0, -180.0, 180.0), num(p, "sat", 0.0, -100.0, 100.0), num(p, "val", 0.0, -100.0, 100.0)); if hue == 0.0 && sat == 0.0 && val == 0.0 { Ok(Point::Identity) } else { Ok(Point::Some(Adjust::Hsv { hue, sat, val })) } }
        "alpha" => {
            let rgb = p.get("alphaColour").and_then(Value::as_str).and_then(hex_rgb).unwrap_or([255, 255, 255]);
            Ok(Point::Some(Adjust::Alpha { target: rgb.map(f64::from), threshold: num(p, "alphaThreshold", 6.0, 0.0, 100.0) * 255.0 / 100.0, value: num(p, "alphaValue", 0.0, 0.0, 100.0) * 255.0 / 100.0 }))
        }
        "saturationCurves" => {
            let main = clean_points(p.get("saturationPoints"), NEUTRAL); let sc = p.get("saturationChannels");
            let chans = ["r", "g", "b"].map(|k| clean_points(sc.and_then(|c| c.get(k)), NEUTRAL));
            if std::iter::once(&main).chain(chans.iter()).all(|pts| pts.iter().all(|q| (q[1] - 0.5).abs() < 1e-8)) { return Ok(Point::Identity); }
            Ok(Point::Some(Adjust::Saturation { lut: point_curve_lut(&main), channels: chans.map(|c| point_curve_lut(&c)) }))
        }
        "blur" => { let sigma = num(p, "blur", 0.0, 0.0, 100.0); if !(sigma > 0.0) { Ok(Point::Identity) } else if p.get("blurPreserveEdges").and_then(Value::as_bool).unwrap_or(false) { Ok(Point::Spatial(Spatial::BlurPreserve { sigma })) } else { Ok(Point::Spatial(Spatial::Blur { sigma })) } }
        "sharpen" => { let amount = num(p, "sharpenAmount", 80.0, 0.0, 300.0); if amount == 0.0 { Ok(Point::Identity) } else { Ok(Point::Spatial(Spatial::Sharpen { amount, sigma: num(p, "sharpenRadius", 1.0, 0.5, 10.0), threshold: num(p, "sharpenThreshold", 2.0, 0.0, 100.0) })) } }
        "bloom" => { let intensity = num(p, "bloomIntensity", 60.0, 0.0, 200.0); if intensity == 0.0 { Ok(Point::Identity) } else { Ok(Point::Spatial(Spatial::Bloom { threshold: num(p, "bloomThreshold", 60.0, 0.0, 100.0) / 100.0 * 255.0, sigma: num(p, "bloomRadius", 20.0, 0.0, 200.0), intensity: intensity / 100.0 })) } }
        t => Err(format!("{t} adjustment")),
    }
}
fn mirror_cfg(c: &Value) -> MirrorCfg {
    let side = |k: &str, ok: [&str; 3]| c.get(k).and_then(Value::as_str).filter(|s| ok.contains(s)).unwrap_or("both").to_string();
    let (side_v, side_h) = (side("sideV", ["both", "left", "right"]), side("sideH", ["both", "top", "bottom"]));
    let valid_side = |k: &str, ok: [&str; 3]| c.get(k).and_then(Value::as_str).map_or(false, |s| ok.contains(&s) && s != "both");
    let clip = match c.get("clip") { None | Some(Value::Null) => valid_side("sideV", ["both", "left", "right"]) || valid_side("sideH", ["both", "top", "bottom"]), Some(v) => js_truthy(v) };
    MirrorCfg { cx: num(c, "cx", 0.5, -4.0, 5.0), cy: num(c, "cy", 0.5, -4.0, 5.0), angle: ((num(c, "angle", 0.0, -1e6, 1e6) % 360.0) + 540.0) % 360.0 - 180.0,
        v: match c.get("v") { None | Some(Value::Null) => true, Some(v) => js_truthy(v) }, h: c.get("h").map_or(false, js_truthy), side_v, side_h, clip }
}
fn js_truthy(v: &Value) -> bool { match v { Value::Null => false, Value::Bool(b) => *b, Value::Number(n) => n.as_f64().map_or(false, |f| f != 0.0 && !f.is_nan()), Value::String(s) => !s.is_empty(), _ => true } }
/// ShadowMod.normalise: defaults #000000, opacity .5, radius 8, offset 8,8.
fn shadow_kind(c: &Value) -> Result<Kind, String> {
    let rgb = c.get("colour").and_then(Value::as_str).and_then(hex_rgb).unwrap_or([0, 0, 0]);
    let (dx, dy) = (num(c, "offsetX", 8.0, -4096.0, 4096.0), num(c, "offsetY", 8.0, -4096.0, 4096.0));
    Ok(Kind::Spatial(Spatial::Shadow { rgb, opacity: num(c, "opacity", 0.5, 0.0, 1.0), sigma: num(c, "radius", 8.0, 0.0, 200.0), dx, dy }))
}
/// Parse a modifier layer's props into its op (`rawMaskOp`); `with_layer` adds opacity/blend (`maskOp`).
pub fn parse(props: &Value, with_layer: bool) -> Result<Option<OpSpec>, String> {
    let kind = props.get("maskKind").and_then(Value::as_str).unwrap_or("paint");
    let k = match kind {
        "colour" => {
            let c = props.get("maskColour").cloned().unwrap_or(Value::Null);
            // v274: seeded random colour (BungalowRandomColour); the compositor re-picks per target layer for untargeted overlays
            if let Some(rgb) = c.get("random").and_then(|r| random_colour(r, None)) { return Ok(Some(OpSpec { kind: Kind::Colour { rgb, amount: c.get("amount").and_then(Value::as_f64).map(clamp01).unwrap_or(1.0) }, opacity: if with_layer { Some(props.get("op").and_then(Value::as_f64).unwrap_or(1.0)) } else { None }, blend: if with_layer { Some(props.get("blend").and_then(Value::as_str).unwrap_or("normal").to_string()) } else { None } })); }
            let rgb = c.get("colour").and_then(Value::as_str).map(|s| s.to_lowercase()).and_then(|s| hex_rgb(&s)).unwrap_or([0x3b, 0x82, 0xf6]);
            Some(Kind::Colour { rgb, amount: c.get("amount").and_then(Value::as_f64).map(clamp01).unwrap_or(1.0) })
        }
        "transform" => {
            let xf = props.get("maskTransform").and_then(|t| t.get("xf")).and_then(Value::as_array).map(|a| a.iter().filter_map(Value::as_f64).collect::<Vec<_>>()).filter(|a| a.len() == 6).unwrap_or(vec![1.0, 0.0, 0.0, 1.0, 0.0, 0.0]);
            Some(Kind::Transform([xf[0], xf[1], xf[2], xf[3], xf[4], xf[5]]))
        }
        "filter" => {
            let f = props.get("maskFilter").cloned().unwrap_or(Value::Null);
            match f.get("type").and_then(Value::as_str) {
                Some("adjust") => parse_adjust(f.get("params").unwrap_or(&Value::Null))?,
                // legacy filter layer: normaliseFilter (missing/unknown type = blur, default radius 16)
                None | Some("blur") => { let r = num(&f, "radius", 16.0, 0.0, 200.0); Some(Kind::Spatial(Spatial::Blur { sigma: r })) }
                Some("shadow") => Some(shadow_kind(&f)?),
                Some(t) if !["brightness", "contrast", "saturate", "hue-rotate", "grayscale", "invert"].contains(&t) => Some(Kind::Spatial(Spatial::Blur { sigma: num(&f, "radius", 16.0, 0.0, 200.0) })),
                // v274: legacy CSS colour filters (Filter Effects colour matrices on straight colour)
                Some(t) => { let (d, lo, hi) = match t { "hue-rotate" => (0.0, -180.0, 180.0), "grayscale" | "invert" => (100.0, 0.0, 100.0), _ => (100.0, 0.0, 200.0) }; Some(Kind::Matrix(css_matrix(t, num(&f, "value", d, lo, hi)))) }
            }
        }
        "shadow" => Some(shadow_kind(props.get("maskShadow").unwrap_or(&Value::Null))?),
        "gradient" => Some(Kind::Gradient(crate::gradient::parse(props.get("maskGradient").unwrap_or(&Value::Null)))),
        "stroke" => Some(Kind::Stroke(crate::stroke::parse(props.get("maskStroke").unwrap_or(&Value::Null)))),
        "mirror" => Some(Kind::Mirror(mirror_cfg(props.get("maskMirror").unwrap_or(&Value::Null)))),
        other => return Err(format!("{other} modifier")),
    };
    Ok(k.map(|kind| OpSpec { kind, opacity: if with_layer { Some(props.get("op").and_then(Value::as_f64).unwrap_or(1.0)) } else { None }, blend: if with_layer { Some(props.get("blend").and_then(Value::as_str).unwrap_or("normal").to_string()) } else { None } }))
}

// ---------- ops ----------
fn colour(src: &Surface, rgb: [u8; 3], amount: f64) -> Surface {
    let mut out = src.clone(); let mut solid = Surface::new(src.width, src.height);
    for px in solid.data.chunks_exact_mut(4) { px.copy_from_slice(&[rgb[0], rgb[1], rgb[2], 255]); }
    out.compose_region(Rect { x: 0, y: 0, w: src.width as i64, h: src.height as i64 }, &solid, 0, 0, Op::SourceAtop, amount as f32);
    out
}
fn adjust(src: &Surface, a: &Adjust) -> Surface {
    let mut d = read(src);
    for px in d.chunks_exact_mut(4) {
        match a {
            Adjust::Tables(t) => { if px[3] == 0 { continue; } for k in 0..3 { px[k] = t[k][px[k] as usize]; } }
            Adjust::Hsv { hue, sat, val } => {
                if px[3] == 0 { continue; }
                let shift = ((hue / 60.0) % 6.0 + 6.0) % 6.0; let sm = 1.0 + sat / 100.0; let vd = val * 2.55;
                let (r, g, b) = (px[0] as f64, px[1] as f64, px[2] as f64); let hi = r.max(g).max(b); let lo = r.min(g).min(b); let delta = hi - lo;
                let mut h = if delta != 0.0 { if hi == r { (g - b) / delta } else if hi == g { (b - r) / delta + 2.0 } else { (r - g) / delta + 4.0 } } else { 0.0 };
                h += shift; if h < 0.0 { h += 6.0 } else if h >= 6.0 { h -= 6.0 }
                let v = (hi + vd).max(0.0).min(255.0); let s = (if hi != 0.0 { delta / hi } else { 0.0 } * sm).max(0.0).min(1.0);
                let c = v * s; let m = v - c; let f = h % 2.0; let x = c * if f < 1.0 { f } else { 2.0 - f };
                let (rr, gg, bb) = match h as i64 { 0 => (c, x, 0.0), 1 => (x, c, 0.0), 2 => (0.0, c, x), 3 => (0.0, x, c), 4 => (x, 0.0, c), _ => (c, 0.0, x) };
                px[0] = u8c(r + (rr + m - r)); px[1] = u8c(g + (gg + m - g)); px[2] = u8c(b + (bb + m - b));
            }
            Adjust::Alpha { target, threshold, value } => {
                if (0..3).all(|k| (px[k] as f64 - target[k]).abs() <= *threshold) { let a = px[3] as f64; px[3] = u8c(a + (value - a)); }
            }
            Adjust::Saturation { lut, channels } => {
                if px[3] == 0 { continue; }
                let (r, g, b) = (px[0] as f64, px[1] as f64, px[2] as f64); let hi = r.max(g).max(b); let lo = r.min(g).min(b);
                let light = (hi + lo) / 2.0; let chroma = (hi - lo) / 2.0; if chroma == 0.0 { continue; }
                let index = js_round(light) as usize; let factor = (2.0 * lut[index] as f64).min(light.min(255.0 - light) / chroma);
                for k in 0..3 { let old = px[k] as f64; let f = factor * 2.0 * channels[k][index] as f64; let value = (light + (old - light) * f).max(0.0).min(255.0); px[k] = u8c(old + (value - old)); }
            }
        }
    }
    put(src.width, src.height, &d)
}
/// `drawImage` under a transform, modelled on Chromium's output (measured against Chromium's canvas):
/// integer translations copy exactly; otherwise bilinear sampling (clamp to edge) at the pixel centre, multiplied by
/// an edge coverage = min over the four image edges of clamp(0.5 + distance), where distance is the signed distance
/// from the pixel centre to the edge. Axis-aligned transforms quantise the coverage to 1/16 (matches exactly);
/// rotated/skewed ones divide the distance by |nx| + |ny| of the edge normal (matches within a few levels on
/// edge pixels only, so they are reported as approximate, see `approximate`).
pub fn transform(src: &Surface, m: [f64; 6]) -> Surface {
    let (w, h) = (src.width, src.height); let mut out = Surface::new(w, h);
    let [a, b, c, d, e, f] = m;
    if a == 1.0 && b == 0.0 && c == 0.0 && d == 1.0 && e.fract() == 0.0 && f.fract() == 0.0 {
        out.compose_region(Rect { x: 0, y: 0, w: w as i64, h: h as i64 }, src, e as i64, f as i64, Op::Copy, 1.0); return out;
    }
    let det = a * d - b * c; if det.abs() < 1e-12 { return out; }
    let (ia, ib, ic, id) = (d / det, -b / det, -c / det, a / det); let (ie, if_) = (-(ia * e + ic * f), -(ib * e + id * f));
    let (sw, sh) = (w as f64, h as f64);
    let corner = |x: f64, y: f64| [a * x + c * y + e, b * x + d * y + f];
    let quad = [corner(0.0, 0.0), corner(sw, 0.0), corner(sw, sh), corner(0.0, sh)];
    let axis = (b == 0.0 && c == 0.0) || (a == 0.0 && d == 0.0);
    let mut area2 = 0.0; for i in 0..4 { let (p, n) = (quad[i], quad[(i + 1) % 4]); area2 += p[0] * n[1] - n[0] * p[1]; }
    let sg = if area2 >= 0.0 { 1.0 } else { -1.0 };
    // edge lines: (point, unit direction, distance divisor)
    let edges: Vec<([f64; 2], [f64; 2], f64)> = (0..4).map(|i| { let (p, n) = (quad[i], quad[(i + 1) % 4]); let l = ((n[0] - p[0]).powi(2) + (n[1] - p[1]).powi(2)).sqrt(); let (dx, dy) = ((n[0] - p[0]) / l, (n[1] - p[1]) / l); (p, [dx, dy], if axis { 1.0 } else { dx.abs() + dy.abs() }) }).collect();
    let (minx, maxx) = quad.iter().fold((f64::MAX, f64::MIN), |(lo, hi), p| (lo.min(p[0]), hi.max(p[0])));
    let (miny, maxy) = quad.iter().fold((f64::MAX, f64::MIN), |(lo, hi), p| (lo.min(p[1]), hi.max(p[1])));
    let span = |lo: f64, hi: f64, n: f64| ((lo - 1.0).floor().max(0.0).min(n) as usize, (hi + 1.0).ceil().max(0.0).min(n) as usize);
    let ((x0, x1), (y0, y1)) = (span(minx, maxx, sw), span(miny, maxy, sh));
    let px = |x: i64, y: i64| { let (x, y) = (x.clamp(0, w as i64 - 1) as usize, y.clamp(0, h as i64 - 1) as usize); let i = (y * w + x) * 4; [src.data[i] as f64, src.data[i + 1] as f64, src.data[i + 2] as f64, src.data[i + 3] as f64] };
    for y in y0..y1 { for x in x0..x1 {
        let (cx, cy) = (x as f64 + 0.5, y as f64 + 0.5);
        let mut cov: f64 = 1.0;
        for (p, dir, div) in &edges { let dist = sg * (dir[0] * (cy - p[1]) - dir[1] * (cx - p[0])) / div; cov = cov.min((dist + 0.5).max(0.0).min(1.0)); }
        if axis { cov = js_round(cov * 16.0) / 16.0; }
        if cov <= 0.0 { continue; }
        let (u, v) = (ia * cx + ic * cy + ie, ib * cx + id * cy + if_);
        let (su, sv) = (u - 0.5, v - 0.5); let (fx0, fy0) = (su.floor(), sv.floor()); let (tx, ty) = (su - fx0, sv - fy0); let (ix, iy) = (fx0 as i64, fy0 as i64);
        let (p00, p10, p01, p11) = (px(ix, iy), px(ix + 1, iy), px(ix, iy + 1), px(ix + 1, iy + 1));
        let i = (y * w + x) * 4;
        for k in 0..4 { let top = p00[k] + (p10[k] - p00[k]) * tx; let bot = p01[k] + (p11[k] - p01[k]) * tx; let s = top + (bot - top) * ty;
            out.data[i + k] = if axis { (s.round() * js_round(cov * 255.0) / 255.0).round() } else { (s * cov).round() }.clamp(0.0, 255.0) as u8; }
    } }
    out
}
/// Ops whose native result is a close model rather than a bit-level match (callers may allow edge near misses).
pub fn approximate(op: &OpSpec) -> Option<String> {
    if let Kind::Transform([a, b, c, d, _, _]) = op.kind { if !((b == 0.0 && c == 0.0) || (a == 0.0 && d == 0.0)) { return Some("rotated/skewed transform edges".into()); } }
    if let Kind::Mirror(c) = &op.kind { if c.angle % 90.0 != 0.0 { return Some("angled mirror axis".into()); } }
    None
}
// ---------- v274: Gaussian blur and the filters built on it ----------
/// One separable pass over premultiplied RGBA8 (`w`×`h`), transparent outside, rounded to 8 bits like the GPU pass.
fn gauss_pass(src: &[u8], w: usize, h: usize, k: &[f64], horizontal: bool) -> Vec<u8> {
    let r = (k.len() / 2) as i64; let mut out = vec![0u8; src.len()];
    for y in 0..h { for x in 0..w {
        let mut acc = [0f64; 4];
        for (t, wt) in k.iter().enumerate() { let o = t as i64 - r; let (sx, sy) = if horizontal { (x as i64 + o, y as i64) } else { (x as i64, y as i64 + o) };
            if sx < 0 || sy < 0 || sx >= w as i64 || sy >= h as i64 { continue; } let j = (sy as usize * w + sx as usize) * 4; for c in 0..4 { acc[c] += wt * src[j + c] as f64; } }
        let i = (y * w + x) * 4; for c in 0..4 { out[i + c] = acc[c].round().clamp(0.0, 255.0) as u8; }
    } }
    out
}
/// Canvas `blur(σpx)`: separable Gaussian, radius ceil(3σ), measured against Chromium within 2/255.
fn gaussian_raw(data: &[u8], w: usize, h: usize, sigma: f64) -> Vec<u8> {
    if !(sigma > 0.0) { return data.to_vec(); }
    let r = (3.0 * sigma).ceil() as i64; let mut k: Vec<f64> = (-r..=r).map(|i| (-(i * i) as f64 / (2.0 * sigma * sigma)).exp()).collect(); let sum: f64 = k.iter().sum(); for v in k.iter_mut() { *v /= sum; }
    let hp = gauss_pass(data, w, h, &k, true); gauss_pass(&hp, w, h, &k, false)
}
fn gaussian(s: &Surface, sigma: f64) -> Surface { Surface { width: s.width, height: s.height, data: gaussian_raw(&s.data, s.width, s.height, sigma) } }
fn spatial(cur: &Surface, sp: &Spatial, blend_over: &dyn Fn(&mut Surface, &Surface, f64, &str)) -> Surface {
    let (w, h) = (cur.width, cur.height);
    match *sp {
        Spatial::Blur { sigma } => gaussian(cur, sigma),
        Spatial::BlurPreserve { sigma } => {
            let (mut d, b) = (read(cur), read(&gaussian(cur, sigma)));
            for (px, bp) in d.chunks_exact_mut(4).zip(b.chunks_exact(4)) { if px[3] == 0 || bp[3] == 0 { continue; } for k in 0..3 { px[k] = bp[k]; } }
            put(w, h, &d)
        }
        Spatial::Sharpen { amount, sigma, threshold } => {
            let mut d = read(cur); let soft = read(&gaussian(&put(w, h, &d), sigma));
            for (px, sp) in d.chunks_exact_mut(4).zip(soft.chunks_exact(4)) {
                if px[3] == 0 || sp[3] == 0 { continue; }
                let (r, g, b) = (px[0] as f64, px[1] as f64, px[2] as f64); let delta = 0.2126 * (r - sp[0] as f64) + 0.7152 * (g - sp[1] as f64) + 0.0722 * (b - sp[2] as f64);
                if delta.abs() < threshold { continue; }
                for k in 0..3 { let v = px[k] as f64; px[k] = u8c(v + (v - sp[k] as f64) * amount / 100.0); }
            }
            put(w, h, &d)
        }
        Spatial::Bloom { threshold, sigma, intensity } => {
            let mut b = read(cur);
            for px in b.chunks_exact_mut(4) { let l = 0.2126 * px[0] as f64 + 0.7152 * px[1] as f64 + 0.0722 * px[2] as f64; if l <= threshold { px[3] = 0; continue; } let x = ((l - threshold) / (255.0 - threshold).max(1.0)).max(0.0).min(1.0); let k = x * x * (3.0 - 2.0 * x); px[3] = u8c(px[3] as f64 * k); }
            let bl = gaussian(&put(w, h, &b), sigma); let mut out = cur.clone(); let mut rem = intensity;
            while rem > 0.001 { blend_over(&mut out, &bl, rem.min(1.0), "screen"); rem -= 1.0; }
            out
        }
        Spatial::Shadow { rgb, opacity, sigma, dx, dy } => {
            // colour the alpha (premultiplied by opacity), blur on a canvas padded so blur spilling past the document edge can be offset back in
            let pad = (3.0 * sigma).ceil() as i64 + (dx.abs().max(dy.abs()).min(w.max(h) as f64)).ceil() as i64 + 1; let (pw, ph) = (w + 2 * pad as usize, h + 2 * pad as usize);
            let mut sh = vec![0u8; pw * ph * 4];
            for y in 0..h { for x in 0..w { let a = cur.data[(y * w + x) * 4 + 3] as f64 * opacity; let j = ((y + pad as usize) * pw + x + pad as usize) * 4; for k in 0..3 { sh[j + k] = (rgb[k] as f64 * a / 255.0).round() as u8; } sh[j + 3] = a.round() as u8; } }
            let bl = gaussian_raw(&sh, pw, ph, sigma); let mut out = Surface::new(w, h);
            let at = |x: i64, y: i64, k: usize| if x < 0 || y < 0 || x >= pw as i64 || y >= ph as i64 { 0.0 } else { bl[(y as usize * pw + x as usize) * 4 + k] as f64 };
            for y in 0..h { for x in 0..w {
                let i = (y * w + x) * 4; let (u, v) = (x as f64 - dx + pad as f64, y as f64 - dy + pad as f64); let (x0, y0) = (u.floor(), v.floor()); let (tx, ty) = (u - x0, v - y0); let (x0, y0) = (x0 as i64, y0 as i64);
                let a = cur.data[i + 3] as f64 / 255.0;
                for k in 0..4 { let t = at(x0, y0, k) + (at(x0 + 1, y0, k) - at(x0, y0, k)) * tx; let b = at(x0, y0 + 1, k) + (at(x0 + 1, y0 + 1, k) - at(x0, y0 + 1, k)) * tx; let s = (t + (b - t) * ty).round();
                    out.data[i + k] = (cur.data[i + k] as f64 + s * (1.0 - a)).round().clamp(0.0, 255.0) as u8; }
            } }
            out
        }
    }
}
/// BungalowRandomColour.colour (`index` overrides the stored one); `None` when the config is invalid (normalise → null).
pub fn random_colour(r: &Value, index: Option<u32>) -> Option<[u8; 3]> {
    let base = r.get("base").and_then(Value::as_str).filter(|s| s.len() == 7 && s.starts_with('#') && s[1..].chars().all(|c| c.is_ascii_hexdigit()))?.to_lowercase();
    let flag = |k: &str| r.get(k).and_then(Value::as_bool); let (hue, sat, light) = (flag("hue")?, flag("saturation")?, flag("lightness")?);
    let strength = r.get("strength").and_then(Value::as_f64).filter(|v| (0.0..=1.0).contains(v))?;
    let seed = r.get("seed").and_then(Value::as_f64).filter(|v| v.fract() == 0.0 && *v >= 0.0 && *v <= 4294967295.0)? as u32;
    let stored = r.get("index").and_then(Value::as_f64).filter(|v| v.fract() == 0.0 && *v >= 0.0 && *v < 1024.0)? as u32;
    let index = index.unwrap_or(stored);
    let rgb8 = hex_rgb(&base)?; if strength == 0.0 || (!hue && !sat && !light) { return Some(rgb8); }
    let rgb = rgb8.map(|v| v as f64 / 255.0); let (max, min) = (rgb[0].max(rgb[1]).max(rgb[2]), rgb[0].min(rgb[1]).min(rgb[2])); let d = max - min; let l = (max + min) / 2.0;
    let s = if d != 0.0 { d / (1.0 - (2.0 * l - 1.0).abs()) } else { 0.0 };
    let mut h = 0.0; if d != 0.0 { h = 60.0 * if max == rgb[0] { ((rgb[1] - rgb[2]) / d) % 6.0 } else if max == rgb[1] { (rgb[2] - rgb[0]) / d + 2.0 } else { (rgb[0] - rgb[1]) / d + 4.0 }; } h = (h + 360.0) % 360.0;
    let mut state = seed ^ (index.wrapping_add(1)).wrapping_mul(0x9e3779b9);
    let mut random = || { state = state.wrapping_add(0x6d2b79f5); let mut t = state; t = (t ^ (t >> 15)).wrapping_mul(t | 1); t ^= t.wrapping_add((t ^ (t >> 7)).wrapping_mul(t | 61)); (t ^ (t >> 14)) as f64 / 4294967296.0 };
    let target = [random() * 360.0, random(), random()];
    let hh = if hue { (h + (((target[0] - h + 540.0) % 360.0) - 180.0) * strength + 360.0) % 360.0 } else { h };
    let ss = if sat { s + (target[1] - s) * strength } else { s }; let ll = if light { l + (target[2] - l) * strength } else { l };
    let c = (1.0 - (2.0 * ll - 1.0).abs()) * ss; let x = c * (1.0 - ((hh / 60.0) % 2.0 - 1.0).abs()); let m = ll - c / 2.0;
    let parts = if hh < 60.0 { [c, x, 0.0] } else if hh < 120.0 { [x, c, 0.0] } else if hh < 180.0 { [0.0, c, x] } else if hh < 240.0 { [0.0, x, c] } else if hh < 300.0 { [x, 0.0, c] } else { [c, 0.0, x] };
    Some(parts.map(|v| js_round((v + m).max(0.0).min(1.0) * 255.0) as u8))
}
/// Re-pick an untargeted random colour overlay for its `index`-th reached layer (copyOp/randomIndex).
pub fn with_random_index(spec: &mut OpSpec, props: &Value, index: u32) {
    if let Kind::Colour { rgb, .. } = &mut spec.kind { if let Some(c) = props.get("maskColour").and_then(|c| c.get("random")).and_then(|r| random_colour(r, Some(index))) { *rgb = c; } }
}
/// CSS filter function as a 3×4 matrix (rows r, g, b: three weights + offset), per the Filter Effects spec.
fn css_matrix(t: &str, v: f64) -> [f64; 12] {
    let sat = |s: f64| [0.213 + 0.787 * s, 0.715 - 0.715 * s, 0.072 - 0.072 * s, 0.0, 0.213 - 0.213 * s, 0.715 + 0.285 * s, 0.072 - 0.072 * s, 0.0, 0.213 - 0.213 * s, 0.715 - 0.715 * s, 0.072 + 0.928 * s, 0.0];
    match t {
        "brightness" => { let a = v / 100.0; [a, 0.0, 0.0, 0.0, 0.0, a, 0.0, 0.0, 0.0, 0.0, a, 0.0] }
        "contrast" => { let a = v / 100.0; let o = 0.5 - 0.5 * a; [a, 0.0, 0.0, o, 0.0, a, 0.0, o, 0.0, 0.0, a, o] }
        "saturate" => sat(v / 100.0),
        "grayscale" => sat(1.0 - (v / 100.0).min(1.0)),
        "invert" => { let a = (v / 100.0).min(1.0); let s = 1.0 - 2.0 * a; [s, 0.0, 0.0, a, 0.0, s, 0.0, a, 0.0, 0.0, s, a] }
        _ => { let r = v.to_radians(); let (c, sn) = (r.cos(), r.sin());
            [0.213 + c * 0.787 - sn * 0.213, 0.715 - c * 0.715 - sn * 0.715, 0.072 - c * 0.072 + sn * 0.928, 0.0,
             0.213 - c * 0.213 + sn * 0.143, 0.715 + c * 0.285 + sn * 0.140, 0.072 - c * 0.072 - sn * 0.283, 0.0,
             0.213 - c * 0.213 - sn * 0.787, 0.715 - c * 0.715 + sn * 0.715, 0.072 + c * 0.928 + sn * 0.072, 0.0] }
    }
}
fn matrix(src: &Surface, m: &[f64; 12]) -> Surface {
    let mut out = src.clone();
    for px in out.data.chunks_exact_mut(4) { let a = px[3]; if a == 0 { continue; } let af = a as f64 / 255.0; let c = [0, 1, 2].map(|k| px[k] as f64 / 255.0 / af);
        for r in 0..3 { let v = (m[r * 4] * c[0] + m[r * 4 + 1] * c[1] + m[r * 4 + 2] * c[2] + m[r * 4 + 3]).max(0.0).min(1.0); px[r] = (v * af * 255.0).round() as u8; } }
    out
}
// ---------- v274: mirror (MirrorKit.compose) ----------
struct Axis { dir: f64, keep: i32, px: f64, py: f64, m: [f64; 6] }
fn tidy(v: f64) -> f64 { if v.abs() < 1e-9 { 0.0 } else if (v - 1.0).abs() < 1e-9 { 1.0 } else if (v + 1.0).abs() < 1e-9 { -1.0 } else { v } }
fn mirror_axes(c: &MirrorCfg, w: usize, h: usize) -> Vec<Axis> {
    let (px, py) = (js_round(c.cx * w as f64), js_round(c.cy * h as f64)); let th = c.angle * std::f64::consts::PI / 180.0; let mut out = Vec::new();
    if c.v { out.push((th + std::f64::consts::FRAC_PI_2, if c.clip { if c.side_v == "right" { -1 } else { 1 } } else { 0 })); }
    if c.h { out.push((th, if c.clip { if c.side_h == "bottom" { 1 } else { -1 } } else { 0 })); }
    out.into_iter().map(|(dir, keep)| { let (cs, sn) = (tidy((2.0 * dir).cos()), tidy((2.0 * dir).sin())); Axis { dir, keep, px, py, m: [cs, sn, sn, -cs, px - cs * px - sn * py, py - sn * px + cs * py] } }).collect()
}
/// Multiply `s` by the coverage of the half-plane on side `sign` of the axis line (MirrorKit half(): a clip rect in the axis frame).
fn clip_half(s: &mut Surface, a: &Axis, sign: i32) {
    let (c, sn) = (tidy(a.dir.cos()), tidy(a.dir.sin())); let div = c.abs() + sn.abs(); let aligned = c == 0.0 || sn == 0.0;
    for y in 0..s.height { for x in 0..s.width {
        let ly = -(x as f64 + 0.5 - a.px) * sn + (y as f64 + 0.5 - a.py) * c; let d = if sign > 0 { ly } else { -ly };
        let cov = if aligned { if d >= 0.0 { 1.0 } else { 0.0 } } else { (0.5 + d / div).max(0.0).min(1.0) };
        if cov < 1.0 { let i = (y * s.width + x) * 4; for k in 0..4 { s.data[i + k] = (s.data[i + k] as f64 * cov).round() as u8; } }
    } }
}
fn mirror(src: &Surface, c: &MirrorCfg) -> Surface {
    let (w, h) = (src.width, src.height); let full = Rect { x: 0, y: 0, w: w as i64, h: h as i64 };
    let mut cur = src.clone();
    for a in mirror_axes(c, w, h) {
        let mut refl = transform(&cur, a.m); let mut own = cur.clone();
        if a.keep != 0 { clip_half(&mut refl, &a, -a.keep); clip_half(&mut own, &a, a.keep); }
        refl.compose_region(full, &own, 0, 0, Op::SourceOver, 1.0); cur = refl;
    }
    cur
}
fn blend_kind(k: &Kind) -> bool { !matches!(k, Kind::Transform(_) | Kind::Mirror(_)) }

/// `applyOpOnto`: run the chain over `src`. `blend_over` is the compositor's separable/non-separable blend.
pub fn apply(src: &Surface, ops: &[OpSpec], blend_over: &dyn Fn(&mut Surface, &Surface, f64, &str)) -> Surface {
    let mut cur = src.clone();
    for op in ops {
        if op.opacity == Some(0.0) { continue; }
        let mut res = match &op.kind { Kind::Colour { rgb, amount } => colour(&cur, *rgb, *amount), Kind::Transform(m) => transform(&cur, *m), Kind::Adjust(a) => adjust(&cur, a), Kind::Spatial(sp) => spatial(&cur, sp, blend_over), Kind::Mirror(c) => mirror(&cur, c), Kind::Stroke(c) => crate::stroke::draw(&cur, c), Kind::Gradient(c) => crate::gradient::draw(&cur, c), Kind::Matrix(m) => matrix(&cur, m) };
        if let Some(b) = op.blend.as_deref() { if b != "normal" && blend_kind(&op.kind) {
            // opBlendInto: base, then the result with globalCompositeOperation = blend (unknown names stay source-over)
            let mut base = cur.clone();
            if CSS_BLENDS.contains(&b) { blend_over(&mut base, &res, 1.0, b); } else { base.compose_region(Rect { x: 0, y: 0, w: base.width as i64, h: base.height as i64 }, &res, 0, 0, Op::SourceOver, 1.0); }
            res = base;
        } }
        if let Some(t) = op.opacity { if t < 1.0 {
            let (mut d, bsrc) = (read(&res), read(&cur));
            for (px, bp) in d.chunks_exact_mut(4).zip(bsrc.chunks_exact(4)) {
                let a = px[3] as f64 * t; let q = bp[3] as f64 * (1.0 - t); let alpha = a + q;
                for k in 0..3 { px[k] = if alpha != 0.0 { u8c((px[k] as f64 * a + bp[k] as f64 * q) / alpha) } else { 0 }; }
                px[3] = u8c(alpha);
            }
            res = put(cur.width, cur.height, &d);
        } }
        cur = res;
    }
    cur
}
