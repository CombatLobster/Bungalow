//! Validity of encoded layer content (mirror of `BungalowContentCodec.valid`).
use serde_json::Value;
/// Plain JSON with finite numbers, at most 64 levels; `{"$ref": string, "id": string}` objects are references.
pub fn valid(v: &Value) -> bool { valid_at(v, 0) }
fn valid_at(v: &Value, depth: usize) -> bool {
    if depth > 64 { return false; }
    match v {
        Value::Null | Value::Bool(_) | Value::String(_) => true,
        Value::Number(n) => n.as_f64().map_or(false, f64::is_finite),
        Value::Array(a) => a.iter().all(|x| valid_at(x, depth + 1)),
        Value::Object(o) => {
            if o.contains_key("$ref") { return o.len() == 2 && o.get("$ref").map_or(false, Value::is_string) && o.get("id").map_or(false, Value::is_string); }
            o.values().all(|x| valid_at(x, depth + 1))
        }
    }
}
