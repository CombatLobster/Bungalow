//! v297 (stage 7, step F): layer transform commit in the core. A bit-exact port of the app's portable sampler
//! (TransformSampling in src/app.js): area-averaged mip halving, then Catmull-Rom bicubic in premultiplied alpha, with the
//! same double arithmetic and Uint8ClampedArray rounding, run in parallel over output rows. The app sends the plan it
//! computed; the core samples its own copy of the layer, so the source never has to be read back in the browser.
use crate::modifiers::u8c;
use rayon::prelude::*;

/// Straight RGBA image (getImageData layout).
pub struct Img { pub w: usize, pub h: usize, pub d: Vec<u8> }

/// TransformSampling.half: halve along the chosen axes, alpha-weighted colour average.
pub fn half(img: &Img, xa: bool, ya: bool) -> Img {
    let (w, h) = (if xa { img.w.div_ceil(2) } else { img.w }, if ya { img.h.div_ceil(2) } else { img.h });
    let (sx, sy) = (if xa { 2 } else { 1 }, if ya { 2 } else { 1 });
    let mut d = vec![0u8; w * h * 4];
    d.par_chunks_mut(w * 4).enumerate().for_each(|(y, row)| { for x in 0..w {
        let (mut r, mut g, mut b, mut a, mut count) = (0f64, 0f64, 0f64, 0f64, 0f64);
        for yy in y * sy..((y + 1) * sy).min(img.h) { for xx in x * sx..((x + 1) * sx).min(img.w) { let i = (yy * img.w + xx) * 4; let al = img.d[i + 3] as f64; a += al; r += img.d[i] as f64 * al; g += img.d[i + 1] as f64 * al; b += img.d[i + 2] as f64 * al; count += 1.0; } }
        let o = x * 4; if a != 0.0 { row[o] = u8c(r / a); row[o + 1] = u8c(g / a); row[o + 2] = u8c(b / a); } row[o + 3] = u8c(a / count);
    } });
    Img { w, h, d }
}
fn cubic(v: f64) -> f64 { let x = v.abs(); if x < 1.0 { (1.5 * x - 2.5) * x * x + 1.0 } else if x < 2.0 { ((-0.5 * x + 2.5) * x - 4.0) * x + 2.0 } else { 0.0 } }
/// The plan from TransformSampling.plan (output rectangle x, y, width, height in document pixels).
pub struct Plan { pub a: f64, pub b: f64, pub c: f64, pub d: f64, pub tx: f64, pub ty: f64, pub fx: f64, pub fy: f64, pub x: f64, pub y: f64, pub width: usize, pub height: usize }
/// TransformSampling.cpu.
pub fn bicubic(img: &Img, p: &Plan) -> Vec<u8> {
    let (sw, sh) = (img.w as i64, img.h as i64); let src = &img.d; let mut out = vec![0u8; p.width * p.height * 4];
    let (fx, fy) = (if p.fx != 0.0 { p.fx } else { 1.0 }, if p.fy != 0.0 { p.fy } else { 1.0 }); let (rx, ry) = ((2.0 * fx).ceil() as i64, (2.0 * fy).ceil() as i64);
    // v301: occupancy of 16x16 source blocks. An output pixel whose taps all fall in empty blocks is transparent (all
    // weights multiply alpha 0), so it is skipped: identical result, far less work on mostly empty layers.
    const B: i64 = 16; let (bw, bh) = ((sw + B - 1) / B, (sh + B - 1) / B); let mut occ = vec![false; (bw * bh).max(1) as usize];
    for y in 0..sh { for x in 0..sw { if src[((y * sw + x) * 4 + 3) as usize] != 0 { occ[((y / B) * bw + x / B) as usize] = true; } } }
    // summed-area table over blocks: any occupied block in a rectangle in O(1)
    let mut sat = vec![0u32; ((bw + 1) * (bh + 1)) as usize]; for by in 0..bh { for bx in 0..bw { let v = occ[(by * bw + bx) as usize] as u32; let i = ((by + 1) * (bw + 1) + bx + 1) as usize; sat[i] = v + sat[i - 1] + sat[i - (bw + 1) as usize] - sat[i - (bw + 2) as usize]; } }
    let any = |x0: i64, y0: i64, x1: i64, y1: i64| -> bool { let (x0, y0, x1, y1) = (x0.max(0) / B, y0.max(0) / B, (x1.min(sw - 1)) / B, (y1.min(sh - 1)) / B); if x1 < x0 || y1 < y0 { return false; }
        let at = |x: i64, y: i64| sat[(y * (bw + 1) + x) as usize] as i64; at(x1 + 1, y1 + 1) - at(x0, y1 + 1) - at(x1 + 1, y0) + at(x0, y0) > 0 };
    // v301: c / 255.0 for every byte value, computed once (the same divisions, so the same doubles)
    let mut lut = [0f64; 256]; for (i, v) in lut.iter_mut().enumerate() { *v = i as f64 / 255.0; }
    out.par_chunks_mut(p.width * 4).enumerate().for_each(|(y, row)| { let mut wx = vec![0f64; (2 * rx) as usize]; for x in 0..p.width {
        let (dx, dy) = (x as f64 + p.x + 0.5, y as f64 + p.y + 0.5); let (u, v) = (p.a * dx + p.b * dy + p.tx, p.c * dx + p.d * dy + p.ty); let (ix, iy) = (u.floor() as i64, v.floor() as i64);
        if !any(ix - rx + 1, iy - ry + 1, ix + rx, iy + ry) { continue; }
        // v301: horizontal weights once per pixel instead of once per tap row (same values, same accumulation order)
        for (k, xx) in (ix - rx + 1..=ix + rx).enumerate() { wx[k] = cubic((u - xx as f64) / fx); }
        let (mut r, mut g, mut b, mut a, mut total) = (0f64, 0f64, 0f64, 0f64, 0f64);
        for yy in iy - ry + 1..=iy + ry { let wy = cubic((v - yy as f64) / fy); for (k, xx) in (ix - rx + 1..=ix + rx).enumerate() { let weight = wy * wx[k]; total += weight;
            if xx < 0 || xx >= sw || yy < 0 || yy >= sh { continue; } let i = ((yy * sw + xx) * 4) as usize; let alpha = lut[src[i + 3] as usize];
            if alpha == 0.0 { continue; } // adds exactly +0.0 to every sum (weights are finite)
            a += alpha * weight; r += lut[src[i] as usize] * alpha * weight; g += lut[src[i + 1] as usize] * alpha * weight; b += lut[src[i + 2] as usize] * alpha * weight; } }
        if total != 0.0 { a /= total; r /= total; g /= total; b /= total; }
        let o = x * 4; let alpha = a.min(1.0).max(0.0);
        if alpha > 1e-6 { row[o] = u8c(r.min(alpha).max(0.0) / alpha * 255.0); row[o + 1] = u8c(g.min(alpha).max(0.0) / alpha * 255.0); row[o + 2] = u8c(b.min(alpha).max(0.0) / alpha * 255.0); }
        row[o + 3] = u8c(alpha * 255.0);
    } });
    out
}
/// v301: place a transform result (straight RGBA, `p.width` x `p.height` at p.x, p.y) as the whole content of a
/// premultiplied document-sized surface, and list the painted 256px document tiles as
/// [u32 n] then per tile [u32 x][u32 y][u32 w][u32 h] + straight RGBA (w*h*4). Empty tiles are left out.
pub fn commit(dst: &mut crate::raster::Surface, res: &[u8], p: &Plan) -> Vec<u8> {
    let (dw, dh) = (dst.width as i64, dst.height as i64); let (px, py) = (p.x as i64, p.y as i64); let (pw, ph) = (p.width as i64, p.height as i64);
    dst.data.iter_mut().for_each(|v| *v = 0);
    let x0 = px.max(0); let x1 = (px + pw).min(dw); let y0 = py.max(0); let y1 = (py + ph).min(dh);
    let premul = |c: u8, a: u8| ((c as u32 * a as u32 + 127) / 255) as u8;
    if x1 > x0 { let w = dst.width; dst.data.par_chunks_mut(w * 4).enumerate().for_each(|(y, row)| { let y = y as i64; if y < y0 || y >= y1 { return; }
        for x in x0..x1 { let si = (((y - py) * pw + (x - px)) * 4) as usize; let a = res[si + 3]; if a == 0 { continue; } let o = (x * 4) as usize; row[o] = premul(res[si], a); row[o + 1] = premul(res[si + 1], a); row[o + 2] = premul(res[si + 2], a); row[o + 3] = a; } }); }
    // painted tiles of the result, straight RGBA straight from `res` (what the app would read back)
    const T: i64 = 256; let mut keys = Vec::new(); let mut ty = (y0 / T) * T; while ty < y1 { let mut tx = (x0 / T) * T; while tx < x1 { keys.push((tx, ty)); tx += T; } ty += T; }
    let tiles: Vec<Option<Vec<u8>>> = keys.par_iter().map(|&(tx, ty)| { let (tw, th) = (T.min(dw - tx), T.min(dh - ty)); let mut o = vec![0u8; (16 + tw * th * 4) as usize]; let mut any = false;
        for y in ty.max(y0)..(ty + th).min(y1) { for x in tx.max(x0)..(tx + tw).min(x1) { let si = (((y - py) * pw + (x - px)) * 4) as usize; if res[si + 3] == 0 { continue; } any = true; let di = (16 + ((y - ty) * tw + (x - tx)) * 4) as usize; o[di..di + 4].copy_from_slice(&res[si..si + 4]); } }
        if !any { return None; } for (k, v) in [tx, ty, tw, th].iter().enumerate() { o[k * 4..k * 4 + 4].copy_from_slice(&(*v as u32).to_le_bytes()); } Some(o) }).collect();
    let painted: Vec<Vec<u8>> = tiles.into_iter().flatten().collect(); let mut out = Vec::with_capacity(4 + painted.iter().map(Vec::len).sum::<usize>()); out.extend_from_slice(&(painted.len() as u32).to_le_bytes()); for t in painted { out.extend_from_slice(&t); } out
}
/// v302: the tile positions of a `commit` listing: [u32 n] + n x [u32 x][u32 y].
pub fn tile_keys(list: &[u8]) -> Vec<u8> {
    let rd = |o: usize| u32::from_le_bytes([list[o], list[o + 1], list[o + 2], list[o + 3]]) as usize; let n = rd(0); let mut out = Vec::with_capacity(4 + n * 8); out.extend_from_slice(&(n as u32).to_le_bytes()); let mut o = 4;
    for _ in 0..n { let (w, h) = (rd(o + 8), rd(o + 12)); out.extend_from_slice(&list[o..o + 8]); o += 16 + w * h * 4; } out
}
