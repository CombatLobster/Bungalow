//! Pixel operations on RGBA8 surfaces (stage 6 prototype of the resource interface operations).
//!
//! Surfaces store premultiplied 8-bit RGBA, like the browser's canvas backend, so results can be
//! compared with Chromium. Operations mirror `RasterResources` in app.js: `compose_region`,
//! `fill_region`, `clear_region`, `write_region`. Coordinates are document pixels; rectangles are
//! clipped to the surface.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Op { SourceOver, DestinationOut, SourceAtop, Copy }
impl Op {
    pub fn parse(s: &str) -> Option<Op> { match s { "source-over" => Some(Op::SourceOver), "destination-out" => Some(Op::DestinationOut), "source-atop" => Some(Op::SourceAtop), "copy" => Some(Op::Copy), _ => None } }
}
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Rect { pub x: i64, pub y: i64, pub w: i64, pub h: i64 }

/// Premultiplied RGBA8 surface.
#[derive(Clone, Debug, PartialEq)]
pub struct Surface { pub width: usize, pub height: usize, pub data: Vec<u8> }
fn premul(c: u8, a: u8) -> u8 { ((c as u32 * a as u32 + 127) / 255) as u8 }
/// v277: Skia's unpremultiply (what getImageData reports), so straight reads match the browser exactly.
fn unpremul(p: u8, a: u8) -> u8 { if a == 0 { 0 } else { let scale = ((255u64 << 24) + (a as u64 >> 1)) / a as u64; (((p as u64 * scale) + (1 << 23)) >> 24).min(255) as u8 } }
impl Surface {
    pub fn new(width: usize, height: usize) -> Self { Surface { width, height, data: vec![0; width * height * 4] } }
    /// From straight (non-premultiplied) RGBA, e.g. ImageData.
    pub fn from_straight(width: usize, height: usize, rgba: &[u8]) -> Self {
        let mut s = Surface::new(width, height);
        for (i, px) in rgba.chunks_exact(4).enumerate() { let a = px[3]; s.data[i * 4..i * 4 + 4].copy_from_slice(&[premul(px[0], a), premul(px[1], a), premul(px[2], a), a]); }
        s
    }
    /// v284: invert colour in straight space (the app's layer invert: c -> 255 - c on getImageData values), alpha kept.
    pub fn invert(&mut self) {
        for px in self.data.chunks_exact_mut(4) { let a = px[3]; if a == 0 { continue; } for c in 0..3 { px[c] = premul(255 - unpremul(px[c], a), a); } }
    }
    /// To straight RGBA (getImageData semantics).
    pub fn to_straight(&self) -> Vec<u8> {
        let mut out = vec![0; self.data.len()];
        for (i, px) in self.data.chunks_exact(4).enumerate() { let a = px[3]; if a == 0 { continue; } if a == 255 { out[i * 4..i * 4 + 4].copy_from_slice(px); continue; } out[i * 4..i * 4 + 4].copy_from_slice(&[unpremul(px[0], a), unpremul(px[1], a), unpremul(px[2], a), a]); }
        out
    }
    fn clip(&self, r: Rect) -> Option<(usize, usize, usize, usize)> {
        let x0 = r.x.max(0); let y0 = r.y.max(0); let x1 = (r.x + r.w).min(self.width as i64); let y1 = (r.y + r.h).min(self.height as i64);
        if x1 <= x0 || y1 <= y0 { None } else { Some((x0 as usize, y0 as usize, x1 as usize, y1 as usize)) }
    }
    /// `s` is the premultiplied source pixel before opacity. `Copy` replaces with the source scaled by opacity
    /// (the app only uses copy at opacity 1 over the source area); other operators scale the source first.
    fn blend(&mut self, i: usize, s0: [f32; 4], alpha: f32, op: Op) {
        let s = [s0[0] * alpha, s0[1] * alpha, s0[2] * alpha, s0[3] * alpha];
        let d = [self.data[i] as f32, self.data[i + 1] as f32, self.data[i + 2] as f32, self.data[i + 3] as f32];
        let sa = s[3] / 255.0; let da = d[3] / 255.0;
        let out: [f32; 4] = match op {
            Op::SourceOver => [s[0] + d[0] * (1.0 - sa), s[1] + d[1] * (1.0 - sa), s[2] + d[2] * (1.0 - sa), s[3] + d[3] * (1.0 - sa)],
            Op::DestinationOut => [d[0] * (1.0 - sa), d[1] * (1.0 - sa), d[2] * (1.0 - sa), d[3] * (1.0 - sa)],
            Op::SourceAtop => [s[0] * da + d[0] * (1.0 - sa), s[1] * da + d[1] * (1.0 - sa), s[2] * da + d[2] * (1.0 - sa), d[3]],
            Op::Copy => s,
        };
        for k in 0..4 { self.data[i + k] = out[k].round().clamp(0.0, 255.0) as u8; }
    }
    /// Composite `src` (its origin at ox, oy) into `rect` with operator `op` and opacity `alpha`.
    /// Only pixels covered by the source are affected (Chromium behaviour, also for `Copy`).
    pub fn compose_region(&mut self, rect: Rect, src: &Surface, ox: i64, oy: i64, op: Op, alpha: f32) {
        let Some((x0, y0, x1, y1)) = self.clip(rect) else { return };
        // v289: clip to the source once per row and take exact fast paths (results identical to blend()):
        // Copy at full opacity copies rows; source-over skips transparent source pixels (premultiplied zero leaves the
        // destination unchanged) and copies opaque ones at full opacity.
        let (sx0, sx1) = ((x0 as i64).max(ox), (x1 as i64).min(ox + src.width as i64)); if sx1 <= sx0 { return; }
        let (cx0, cx1) = (sx0 as usize, sx1 as usize);
        for y in y0..y1 { let sy = y as i64 - oy; if sy < 0 || sy as usize >= src.height { continue; }
            let srow = sy as usize * src.width; let drow = y * self.width;
            if op == Op::Copy && alpha == 1.0 { let (a, b) = ((srow + (cx0 as i64 - ox) as usize) * 4, (srow + (cx1 as i64 - ox) as usize) * 4); self.data[(drow + cx0) * 4..(drow + cx1) * 4].copy_from_slice(&src.data[a..b]); continue; }
            for x in cx0..cx1 {
                let j = (srow + (x as i64 - ox) as usize) * 4; let sa = src.data[j + 3];
                if op == Op::SourceOver || op == Op::SourceAtop { if sa == 0 && src.data[j] == 0 && src.data[j + 1] == 0 && src.data[j + 2] == 0 { continue; } }
                if op == Op::DestinationOut && sa == 0 { continue; }
                let i = (drow + x) * 4;
                if op == Op::SourceOver && sa == 255 && alpha == 1.0 { self.data[i..i + 4].copy_from_slice(&src.data[j..j + 4]); continue; }
                let s = [src.data[j] as f32, src.data[j + 1] as f32, src.data[j + 2] as f32, sa as f32];
                self.blend(i, s, alpha, op);
            } }
    }
    /// Solid fill of `rect` with straight `rgb` colour at opacity `alpha`.
    pub fn fill_region(&mut self, rect: Rect, rgb: [u8; 3], op: Op, alpha: f32) {
        let Some((x0, y0, x1, y1)) = self.clip(rect) else { return };
        let s = [rgb[0] as f32, rgb[1] as f32, rgb[2] as f32, 255.0];
        for y in y0..y1 { for x in x0..x1 { self.blend((y * self.width + x) * 4, s, alpha, op); } }
    }
    pub fn clear_region(&mut self, rect: Rect) { if let Some((x0, y0, x1, y1)) = self.clip(rect) { for y in y0..y1 { for x in x0..x1 { let i = (y * self.width + x) * 4; self.data[i..i + 4].fill(0); } } } }
    /// Replace pixels under the patch rectangle at (x, y) with `patch`.
    pub fn write_region(&mut self, patch: &Surface, x: i64, y: i64) {
        self.compose_region(Rect { x, y, w: patch.width as i64, h: patch.height as i64 }, patch, x, y, Op::Copy, 1.0);
    }
}

/// Sparse tile storage with tile-swap history (mirror of the JS sparse store + RasterSnapshot swap).
#[derive(Clone, Debug, Default)]
pub struct TileStore { pub width: usize, pub height: usize, pub tile_size: usize, pub tiles: std::collections::BTreeMap<(usize, usize), Surface> }
impl TileStore {
    pub fn new(width: usize, height: usize, tile_size: usize) -> Self { TileStore { width, height, tile_size, tiles: Default::default() } }
    fn keys(&self, r: Rect) -> Vec<(usize, usize)> {
        crate::resources::tiles([r.x as f64, r.y as f64, r.w as f64, r.h as f64], self.width as f64, self.height as f64, self.tile_size as f64).unwrap_or_default().into_iter().map(|t| (t.x as usize, t.y as usize)).collect()
    }
    /// Copy the tiles under `r` (None for missing tiles): a tiles snapshot.
    pub fn snapshot(&self, r: Rect) -> Vec<((usize, usize), Option<Surface>)> { self.keys(r).into_iter().map(|k| (k, self.tiles.get(&k).cloned())).collect() }
    /// Exchange snapshot tiles with live tiles; undo and redo are the same swap.
    pub fn swap(&mut self, saved: &mut [((usize, usize), Option<Surface>)]) {
        for (k, t) in saved.iter_mut() { let cur = self.tiles.remove(k); if let Some(s) = t.take() { self.tiles.insert(*k, s); } *t = cur; }
    }
    /// Composite into tiles (creating tiles unless the operator only affects existing pixels).
    pub fn compose_region(&mut self, r: Rect, src: &Surface, ox: i64, oy: i64, op: Op, alpha: f32) {
        let existing_only = matches!(op, Op::DestinationOut | Op::SourceAtop);
        for (tx, ty) in self.keys(r) {
            let (w, h) = (self.tile_size.min(self.width - tx), self.tile_size.min(self.height - ty));
            if existing_only && !self.tiles.contains_key(&(tx, ty)) { continue; }
            let tile = self.tiles.entry((tx, ty)).or_insert_with(|| Surface::new(w, h));
            tile.compose_region(Rect { x: r.x - tx as i64, y: r.y - ty as i64, w: r.w, h: r.h }, src, ox - tx as i64, oy - ty as i64, op, alpha);
        }
    }
    /// Flatten to a dense surface.
    pub fn to_surface(&self) -> Surface {
        let mut s = Surface::new(self.width, self.height);
        for (&(tx, ty), t) in &self.tiles { s.write_region(t, tx as i64, ty as i64); }
        s
    }
}
