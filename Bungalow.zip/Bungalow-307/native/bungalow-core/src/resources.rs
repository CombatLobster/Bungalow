//! Pixel resource ledger and tile planner (mirror of `src/engine-resources-262.js`).
use crate::{err, ids, Result};
use serde_json::{json, Map, Value};

fn num(v: Option<&Value>) -> Option<f64> { v.and_then(Value::as_f64) }
fn pos_int(v: Option<&Value>) -> bool { num(v).map_or(false, |x| x.is_finite() && x.fract() == 0.0 && x > 0.0 && x <= 1e6) }
fn non_neg(v: Option<&Value>) -> bool { num(v).map_or(false, |x| x.is_finite() && x >= 0.0) }
fn int(v: Option<&Value>) -> bool { num(v).map_or(false, |x| x.is_finite() && x.fract() == 0.0) }

/// One planned tile: key `"x:y"` and its clipped size.
#[derive(Debug, Clone, PartialEq)]
pub struct Tile { pub k: String, pub x: i64, pub y: i64, pub w: i64, pub h: i64 }
/// Tiles covering `rect` (x, y, w, h) inside a `width` x `height` surface with square tiles.
pub fn tiles(rect: [f64; 4], width: f64, height: f64, tile_size: f64) -> Result<Vec<Tile>> {
    if !rect.iter().all(|v| v.is_finite()) { return err("Invalid tile rect"); }
    let pi = |v: f64| v.is_finite() && v.fract() == 0.0 && v > 0.0 && v <= 1e6;
    if !pi(width) || !pi(height) || !pi(tile_size) { return err("Invalid tile surface"); }
    let s = tile_size;
    let x0 = ((rect[0] / s).floor() * s).max(0.0); let y0 = ((rect[1] / s).floor() * s).max(0.0);
    let x1 = width.min(rect[0] + rect[2]); let y1 = height.min(rect[1] + rect[3]);
    let mut out = Vec::new();
    let mut y = y0;
    while y < y1 { let mut x = x0; while x < x1 { out.push(Tile { k: format!("{}:{}", x as i64, y as i64), x: x as i64, y: y as i64, w: s.min(width - x) as i64, h: s.min(height - y) as i64 }); x += s; } y += s; }
    Ok(out)
}

fn normalise_resource(r: &Value) -> Result<Value> {
    if !r.is_object() { return err("Invalid resource record"); }
    let kind = r.get("kind").and_then(Value::as_str);
    if !matches!(kind, Some("raster") | Some("mask") | Some("image")) { return err("Unknown resource kind"); }
    if !pos_int(r.get("width")) || !pos_int(r.get("height")) { return err("Invalid resource size"); }
    if !matches!(r.get("storage").and_then(Value::as_str), Some("dense") | Some("sparse")) { return err("Invalid resource storage"); }
    let ts = r.get("tileSize").cloned().unwrap_or(Value::Null);
    if !ts.is_null() && !pos_int(Some(&ts)) { return err("Invalid tile size"); }
    if !non_neg(r.get("bytes")) { return err("Invalid resource bytes"); }
    Ok(json!({"kind": r["kind"], "width": r["width"], "height": r["height"], "storage": r["storage"], "tileSize": ts, "bytes": r["bytes"]}))
}
fn normalise_snapshot(s: &Value) -> Result<Value> {
    if !s.is_object() { return err("Invalid snapshot record"); }
    if !s.get("resource").and_then(Value::as_str).map_or(false, ids::valid_resource) { return err("Invalid snapshot resource"); }
    let kind = s.get("kind").filter(|v| !v.is_null()).and_then(Value::as_str).unwrap_or("tiles").to_string();
    let has_kind = s.get("kind").map_or(false, |v| !v.is_null());
    if has_kind && !s["kind"].is_string() { return err("Unknown snapshot kind"); }
    if !non_neg(s.get("bytes")) { return err("Invalid snapshot bytes"); }
    match kind.as_str() {
        "tiles" => {
            let keys = match s.get("keys").and_then(Value::as_array) { Some(k) => k, None => return err("Invalid snapshot keys") };
            let valid = |k: &Value| k.as_str().map_or(false, |t| { let mut p = t.splitn(2, ':'); let a = p.next().unwrap_or(""); let b = p.next().unwrap_or(""); !a.is_empty() && !b.is_empty() && a.bytes().all(|c| c.is_ascii_digit()) && b.bytes().all(|c| c.is_ascii_digit()) });
            let mut seen: Vec<&Value> = Vec::new();
            for k in keys { if !valid(k) || seen.contains(&k) { return err("Invalid snapshot keys"); } seen.push(k); }
            Ok(json!({"resource": s["resource"], "kind": "tiles", "keys": keys, "bytes": s["bytes"]}))
        }
        "region" => {
            let r = match s.get("rect") { Some(r) if r.is_object() => r, _ => return err("Invalid snapshot rect") };
            if !int(r.get("x")) || !int(r.get("y")) || !pos_int(r.get("w")) || !pos_int(r.get("h")) { return err("Invalid snapshot rect"); }
            Ok(json!({"resource": s["resource"], "kind": "region", "rect": {"x": r["x"], "y": r["y"], "w": r["w"], "h": r["h"]}, "bytes": s["bytes"]}))
        }
        "surface" => {
            if !matches!(s.get("storage").and_then(Value::as_str), Some("dense") | Some("sparse")) { return err("Invalid snapshot storage"); }
            if !pos_int(s.get("width")) || !pos_int(s.get("height")) { return err("Invalid snapshot size"); }
            Ok(json!({"resource": s["resource"], "kind": "surface", "storage": s["storage"], "width": s["width"], "height": s["height"], "bytes": s["bytes"]}))
        }
        _ => err("Unknown snapshot kind"),
    }
}
fn merge(a: &Value, b: &Value) -> Value { let mut m = a.as_object().cloned().unwrap_or_default(); if let Some(o) = b.as_object() { for (k, v) in o { m.insert(k.clone(), v.clone()); } } Value::Object(m) }

/// Resource and snapshot records as plain JSON (insertion-ordered like the JS Maps).
#[derive(Debug, Clone, Default)]
pub struct Ledger { resources: Map<String, Value>, snapshots: Map<String, Value> }
impl Ledger {
    pub fn new() -> Self { Self::default() }
    pub fn register(&mut self, id: &str, record: &Value) -> Result<()> {
        if !ids::valid_resource(id) { return err("Invalid resource ID"); }
        if self.resources.contains_key(id) { return err("Resource already registered"); }
        let r = normalise_resource(record)?; self.resources.insert(id.into(), r); Ok(())
    }
    pub fn update(&mut self, id: &str, patch: &Value) -> Result<()> {
        let cur = match self.resources.get(id) { Some(c) => c, None => return err("Unknown resource") };
        let next = normalise_resource(&merge(cur, patch))?; self.resources.insert(id.into(), next); Ok(())
    }
    /// Releasing a resource drops its snapshots unless `keep_snapshots`.
    pub fn release(&mut self, id: &str, keep_snapshots: bool) {
        self.resources.shift_remove(id);
        if !keep_snapshots { self.snapshots.retain(|_, s| s["resource"].as_str() != Some(id)); }
    }
    pub fn add_snapshot(&mut self, id: &str, record: &Value) -> Result<()> {
        if !ids::valid_snapshot(id) { return err("Invalid snapshot ID"); }
        if self.snapshots.contains_key(id) { return err("Snapshot already registered"); }
        let s = normalise_snapshot(record)?; self.snapshots.insert(id.into(), s); Ok(())
    }
    pub fn update_snapshot(&mut self, id: &str, patch: &Value) -> Result<()> {
        let cur = match self.snapshots.get(id) { Some(c) => c, None => return err("Unknown snapshot") };
        let next = normalise_snapshot(&merge(cur, patch))?; self.snapshots.insert(id.into(), next); Ok(())
    }
    pub fn drop_snapshot(&mut self, id: &str) { self.snapshots.shift_remove(id); }
    pub fn totals(&self) -> Value {
        let rb: f64 = self.resources.values().map(|r| r["bytes"].as_f64().unwrap_or(0.0)).sum();
        let sb: f64 = self.snapshots.values().map(|s| s["bytes"].as_f64().unwrap_or(0.0)).sum();
        json!({"resources": self.resources.len(), "resourceBytes": rb, "snapshots": self.snapshots.len(), "snapshotBytes": sb})
    }
    pub fn verify(&self) -> Value {
        Value::Array(self.snapshots.iter().filter(|(_, s)| !self.resources.contains_key(s["resource"].as_str().unwrap_or(""))).map(|(id, _)| json!({"snapshot": id, "issue": "snapshot-of-released-resource"})).collect())
    }
    pub fn to_json(&self) -> Value { json!({"resources": self.resources, "snapshots": self.snapshots}) }
}
