//! v268: native raster surfaces addressed by resource ID (`res_…`), driven through the command API.
//! Shadow mode mirrors `RasterResources` writes here (`raster.*` methods) and compares pixels at history steps.
//! Pixel payloads travel as base64 straight RGBA (ImageData layout); surfaces store premultiplied RGBA8.
//! v269: history snapshots (`snap_…`): tile snapshots captured natively or adopted with pixels, swapped natively
//! (undo and redo are the same swap, as in the JS tile-swap history); surface snapshots restored natively.
use crate::raster::{Op, Rect, Surface};
use serde_json::{json, Map, Value};

/// Decode standard base64 (padding optional).
pub fn b64_decode(s: &str) -> Result<Vec<u8>, String> {
    let val = |c: u8| -> Option<u32> { Some(match c { b'A'..=b'Z' => c - b'A', b'a'..=b'z' => c - b'a' + 26, b'0'..=b'9' => c - b'0' + 52, b'+' => 62, b'/' => 63, _ => return None } as u32) };
    let bytes: Vec<u8> = s.bytes().filter(|c| *c != b'=' && !c.is_ascii_whitespace()).collect();
    let mut out = Vec::with_capacity(bytes.len() * 3 / 4);
    for chunk in bytes.chunks(4) {
        let mut n = 0u32; for (i, &c) in chunk.iter().enumerate() { n |= val(c).ok_or("Invalid base64")? << (18 - 6 * i); }
        out.push((n >> 16) as u8); if chunk.len() > 2 { out.push((n >> 8) as u8); } if chunk.len() > 3 { out.push(n as u8); }
    }
    Ok(out)
}
/// Encode standard base64 with padding.
pub fn b64_encode(b: &[u8]) -> String {
    const T: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; let mut o = String::with_capacity(b.len() * 4 / 3 + 4);
    for c in b.chunks(3) { let n = (c[0] as u32) << 16 | (*c.get(1).unwrap_or(&0) as u32) << 8 | *c.get(2).unwrap_or(&0) as u32; for i in 0..4 { o.push(if i <= c.len() { T[(n >> (18 - 6 * i) & 63) as usize] as char } else { '=' }); } }
    o
}
// v291: raw request attachments (bungalow_core_raw). A request's binary payloads follow its JSON; values reference them as
// {"$bin": [offset, length]}. Set for the duration of one request by Core::handle_raw.
thread_local! { pub static ATTACH: std::cell::RefCell<Vec<u8>> = const { std::cell::RefCell::new(Vec::new()) }; }
/// Bytes of a value: an attachment reference or base64 text.
pub fn bytes_of(v: &Value) -> Result<Vec<u8>, String> {
    if let Some(r) = v.get("$bin").and_then(Value::as_array) {
        let (o, n) = (r.first().and_then(Value::as_u64).unwrap_or(0) as usize, r.get(1).and_then(Value::as_u64).unwrap_or(0) as usize);
        return ATTACH.with(|a| a.borrow().get(o..o + n).map(|b| b.to_vec()).ok_or_else(|| "Invalid attachment".to_string()));
    }
    b64_decode(v.as_str().ok_or("Invalid data")?)
}
/// `{width, height, data}` (data: base64 straight RGBA, or an attachment) → premultiplied surface.
pub fn image(v: &Value) -> Result<Surface, String> {
    let w = v.get("width").and_then(Value::as_u64).filter(|w| *w > 0).ok_or("Invalid image width")? as usize;
    let h = v.get("height").and_then(Value::as_u64).filter(|h| *h > 0).ok_or("Invalid image height")? as usize;
    let data = bytes_of(v.get("data").ok_or("Invalid image data")?)?;
    if data.len() != w * h * 4 { return Err("Image data size mismatch".into()); }
    Ok(Surface::from_straight(w, h, &data))
}
/// Premultiplied per-channel comparison of two surfaces.
pub fn diff(s: &Surface, img: &Surface, tol: i32) -> Value {
    if s.width != img.width || s.height != img.height { return json!({"sizeMatch": false, "native": [s.width, s.height], "js": [img.width, img.height]}); }
    let (mut worst, mut over, mut first) = (0i32, 0usize, Value::Null);
    for (i, (x, y)) in s.data.iter().zip(&img.data).enumerate() { let d = (*x as i32 - *y as i32).abs(); worst = worst.max(d); if d > tol { if over == 0 { first = json!({"x": (i / 4) % s.width, "y": (i / 4) / s.width, "channel": i % 4, "native": x, "js": y}); } over += 1; } }
    json!({"sizeMatch": true, "maxDiff": worst, "over": over, "first": first})
}
fn rect(v: Option<&Value>) -> Result<Rect, String> {
    let v = v.ok_or("Invalid rect")?; let n = |k: &str| v.get(k).and_then(Value::as_f64).filter(|x| x.is_finite()).ok_or("Invalid rect");
    Ok(Rect { x: n("x")?.floor() as i64, y: n("y")?.floor() as i64, w: n("w")?.ceil() as i64, h: n("h")?.ceil() as i64 })
}
fn op(v: Option<&Value>) -> Result<Op, String> { let s = v.and_then(Value::as_str).unwrap_or("source-over"); Op::parse(s).ok_or_else(|| format!("Unsupported operator {s}")) }
fn alpha(v: Option<&Value>) -> f32 { v.and_then(Value::as_f64).unwrap_or(1.0) as f32 }
fn int(v: Option<&Value>) -> i64 { v.and_then(Value::as_f64).unwrap_or(0.0).round() as i64 }

/// Surfaces by resource ID (insertion-ordered for stable listings).
#[derive(Default)]
pub struct Surfaces { map: indexmap::IndexMap<String, Surface>, snaps: indexmap::IndexMap<String, Snap>, recent: std::collections::HashMap<(String, (usize, usize)), Surface>, hashes: std::collections::HashMap<(String, (usize, usize)), String>, /** v295: undo-history tiles kept by the core (snapshot id → [(key, PNG | None)]) */ pub stash: std::collections::HashMap<String, Vec<(String, Option<Vec<u8>>)>>, /** v293: PNG bytes of unchanged 256px tiles (from the last save or the opened file), dropped when a tile changes */ pub pngs: std::collections::HashMap<(String, (usize, usize)), Vec<u8>> }
/// v283: tile grid of the checkpoint cache and its bound (tiles, i.e. up to 256 MB of 256×256 RGBA).
const RECENT_TILE: usize = 256;
const RECENT_LIMIT: usize = 1024;
/// v269: a history snapshot owned by one resource.
enum Snap {
    /// Tiles by grid origin; `None` = no tile (transparent). Swapping exchanges these with the live pixels.
    Tiles { resource: String, tile: usize, tiles: Vec<((usize, usize), Option<Surface>)> },
    /// A whole surface (installed by `restoreSurface`).
    Surface { resource: String, surface: Surface },
}
fn tile_key(k: &str) -> Option<(usize, usize)> { let (a, b) = k.split_once(':')?; Some((a.parse().ok()?, b.parse().ok()?)) }
/// Copy of the pixels under one tile; `None` when the area is fully transparent (an absent sparse tile).
fn read_tile(s: &Surface, x: usize, y: usize, t: usize) -> Option<Surface> {
    let (w, h) = (t.min(s.width.saturating_sub(x)), t.min(s.height.saturating_sub(y))); if w == 0 || h == 0 { return None; }
    let mut out = Surface::new(w, h); let mut any = false;
    for row in 0..h { let si = ((y + row) * s.width + x) * 4; let di = row * w * 4; out.data[di..di + w * 4].copy_from_slice(&s.data[si..si + w * 4]); any |= out.data[di..di + w * 4].iter().any(|b| *b != 0); }
    if any { Some(out) } else { None }
}
/// v283: content hash of premultiplied pixels (two 32-bit lanes over little-endian words, plus the size). The mirror
/// computes the same hash in JS (native-shadow, from the canvas readback premultiplied the core's way) to reference
/// tiles the core already holds instead of uploading them.
fn tile_hash_of(s: &Surface) -> String { tile_hash(s.width, s.height, &s.data) }
pub fn tile_hash(w: usize, h: usize, data: &[u8]) -> String {
    let (mut a, mut b) = (0x811c9dc5u32 ^ (w as u32), 0x9747b28cu32 ^ (h as u32));
    for c in data.chunks_exact(4) { let v = u32::from_le_bytes([c[0], c[1], c[2], c[3]]);
        a = (a ^ v).wrapping_mul(0x01000193); b = (b ^ v.wrapping_mul(0xcc9e2d51)).rotate_left(13).wrapping_mul(5).wrapping_add(0xe6546b64); }
    format!("{a:08x}{b:08x}")
}
fn put_tile(s: &mut Surface, x: usize, y: usize, t: usize, tile: Option<&Surface>) {
    match tile { Some(p) => s.write_region(p, x as i64, y as i64), None => s.clear_region(Rect { x: x as i64, y: y as i64, w: t as i64, h: t as i64 }) }
}
impl Surfaces {
    /// v270: all surfaces by ID (for the compositor).
    pub fn all(&self) -> std::collections::HashMap<&str, &Surface> { self.map.iter().map(|(k, v)| (k.as_str(), v)).collect() }
    /// v277: read a surface / store one (project load).
    pub fn surface(&self, id: &str) -> Option<&Surface> { self.map.get(id) }
    pub fn surface_mut(&mut self, id: &str) -> Option<&mut Surface> { self.forget(id, None); self.map.get_mut(id) }
    /// v299: a write the caller reports itself: call `changed` with the touched area afterwards, so cached PNGs and hashes of
    /// the rest of the layer survive (surface_mut drops the whole layer's cache, which made the next save re-encode it).
    pub fn surface_mut_untracked(&mut self, id: &str) -> Option<&mut Surface> { self.map.get_mut(id) }
    pub fn changed(&mut self, id: &str, r: Rect) { self.forget(id, Some(r)) }
    pub fn insert(&mut self, id: &str, s: Surface) -> Result<(), String> { if !crate::ids::valid_resource(id) { return Err("Invalid resource ID".into()); } self.forget(id, None); self.map.insert(id.into(), s); Ok(()) }
    /// v283: checkpoint cache. The first time a painted tile is replaced after a history checkpoint (raster.checkpoint),
    /// a copy is kept, so the cache holds the checkpoint state of every tile touched since. App edits record their
    /// history snapshot after writing; adoptTiles finds those "before" tiles here by content hash instead of the
    /// pixels travelling back over the transport.
    fn keep(&mut self, id: &str, key: (usize, usize), tile: Option<Surface>) {
        let Some(tile) = tile else { return }; if self.recent.len() >= RECENT_LIMIT { return; }
        self.recent.entry((id.to_string(), key)).or_insert(tile);
    }
    /// v284: drop cached tile hashes of `id` (all, or the tiles under `r`) before its pixels change.
    fn forget(&mut self, id: &str, r: Option<Rect>) {
        match r { None => self.pngs.retain(|k, _| k.0 != id),
            Some(r) => { let t = RECENT_TILE as i64; self.pngs.retain(|k, _| k.0 != id || { let (x, y) = (k.1 .0 as i64, k.1 .1 as i64); x + t <= r.x || y + t <= r.y || x >= r.x + r.w || y >= r.y + r.h }); } }
        match r { None => self.hashes.retain(|k, _| k.0 != id),
            Some(r) => { let t = RECENT_TILE as i64; self.hashes.retain(|k, _| k.0 != id || { let (x, y) = (k.1 .0 as i64, k.1 .1 as i64); x + t <= r.x || y + t <= r.y || x >= r.x + r.w || y >= r.y + r.h }); } }
    }
    /// v284: hash of the live tile under `key` (cached until the surface changes); None when the area is empty.
    fn live_hash(&mut self, id: &str, key: (usize, usize)) -> Option<String> {
        let ck = (id.to_string(), key); if let Some(h) = self.hashes.get(&ck) { return Some(h.clone()); }
        let tile = read_tile(self.map.get(id)?, key.0, key.1, RECENT_TILE)?; let h = tile_hash_of(&tile); self.hashes.insert(ck, h.clone()); Some(h)
    }
    /// v284: a tile with this hash under `key` in any surface (a duplicated layer's tiles are already in the core).
    fn find_any(&mut self, key: (usize, usize), hash: &str) -> Option<Surface> {
        let ids: Vec<String> = self.map.keys().cloned().collect();
        for id in ids { if self.live_hash(&id, key).as_deref() == Some(hash) { return read_tile(self.map.get(&id)?, key.0, key.1, RECENT_TILE); } }
        self.recent.iter().find(|((_, k), tile)| *k == key && tile_hash_of(tile) == hash).map(|(_, t)| t.clone())
    }
    /// Keep the tiles of `r` (whole surface: None) that are about to be overwritten, for {live} lookups; drops their cached hashes/PNGs.
    fn remember(&mut self, id: &str, r: Option<Rect>) {
        self.forget(id, r); let Some(s) = self.map.get(id) else { return }; let t = RECENT_TILE;
        let r = r.unwrap_or(Rect { x: 0, y: 0, w: s.width as i64, h: s.height as i64 });
        let (x0, y0) = (r.x.max(0) as usize / t * t, r.y.max(0) as usize / t * t); let (x1, y1) = (((r.x + r.w).max(0) as usize).min(s.width), ((r.y + r.h).max(0) as usize).min(s.height));
        let mut todo = Vec::new(); let mut y = y0; while y < y1 { let mut x = x0; while x < x1 { if !self.recent.contains_key(&(id.to_string(), (x, y))) { todo.push(((x, y), read_tile(s, x, y, t))); } x += t; } y += t; }
        for (k, tile) in todo { self.keep(id, k, tile); }
    }
    /// v283: a tile with this content hash, live under `key` or kept there at the last checkpoint.
    fn find_tile(&self, id: &str, key: (usize, usize), t: usize, hash: &str) -> Option<Surface> {
        let s = self.map.get(id)?; if let Some(cur) = read_tile(s, key.0, key.1, t) { if tile_hash_of(&cur) == hash { return Some(cur); } }
        if t != RECENT_TILE { return None; }
        self.recent.get(&(id.to_string(), key)).filter(|tile| tile_hash_of(tile) == hash).cloned()
    }
    /// v293: a surface's painted tiles as PNGs ([u32 count] then [u32 x][u32 y][u32 length][png] per tile, the layout of
    /// project::encode_tiles). Unchanged tiles reuse their cached bytes; the rest are encoded in parallel.
    pub fn encode_tiles(&mut self, id: &str) -> Result<Vec<u8>, String> {
        use rayon::prelude::*;
        let s = self.map.get(id).ok_or("Unknown raster surface")?; let (w, h, t) = (s.width, s.height, RECENT_TILE);
        let keys: Vec<(usize, usize)> = (0..h).step_by(t).flat_map(|y| (0..w).step_by(t).map(move |x| (x, y))).collect();
        let cached: Vec<Option<Vec<u8>>> = keys.iter().map(|k| self.pngs.get(&(id.to_string(), *k)).cloned()).collect();
        let fresh: Vec<Option<Result<Vec<u8>, String>>> = keys.par_iter().zip(cached.par_iter()).map(|(&(x, y), c)| {
            if c.is_some() { return None; }
            let (tw, th) = (t.min(w - x), t.min(h - y)); let mut px = vec![0u8; tw * th * 4]; let mut any = false;
            for row in 0..th { let si = ((y + row) * w + x) * 4; let d = &mut px[row * tw * 4..(row + 1) * tw * 4]; d.copy_from_slice(&s.data[si..si + tw * 4]);
                for p in d.chunks_exact_mut(4) { let a = p[3]; if a == 0 { p[0] = 0; p[1] = 0; p[2] = 0; continue; } any = true; if a < 255 { for k in 0..3 { p[k] = crate::modifiers::unpremul(p[k], a); } } } }
            if !any { return Some(Ok(Vec::new())); } Some(crate::project::encode_png(tw, th, &px)) }).collect();
        let mut out = vec![0u8; 4]; let mut n = 0u32;
        for ((k, c), f) in keys.iter().zip(cached).zip(fresh) {
            let png = match (c, f) { (Some(b), _) => b, (None, Some(r)) => { let b = r?; if b.is_empty() { continue; } self.pngs.insert((id.to_string(), *k), b.clone()); b } (None, None) => continue };
            for v in [k.0 as u32, k.1 as u32, png.len() as u32] { out.extend_from_slice(&v.to_le_bytes()); } out.extend_from_slice(&png); n += 1;
        }
        out[..4].copy_from_slice(&n.to_le_bytes()); Ok(out)
    }
    /// v295: hand back and forget an undo snapshot kept by the core: [u32 count] then per tile [u32 key length][key]
    /// [u32 width][u32 height][straight RGBA] (width = height = 0: no tile).
    pub fn unstash(&mut self, snap: &str) -> Result<Vec<u8>, String> {
        use rayon::prelude::*;
        let items = self.stash.remove(snap).ok_or("Unknown stashed snapshot")?;
        let dec: Vec<(String, Option<(usize, usize, Vec<u8>)>)> = items.into_par_iter().map(|(k, b)| Ok((k, match b { None => None, Some(b) => Some(crate::project::decode_png(&b)?) }))).collect::<Result<_, String>>()?;
        let mut out = Vec::new(); out.extend_from_slice(&(dec.len() as u32).to_le_bytes());
        for (k, t) in dec { out.extend_from_slice(&(k.len() as u32).to_le_bytes()); out.extend_from_slice(k.as_bytes()); match t { None => { out.extend_from_slice(&0u32.to_le_bytes()); out.extend_from_slice(&0u32.to_le_bytes()); } Some((w, h, px)) => { out.extend_from_slice(&(w as u32).to_le_bytes()); out.extend_from_slice(&(h as u32).to_le_bytes()); out.extend_from_slice(&px); } } }
        Ok(out)
    }
    /// v293: remember a tile's PNG bytes (from an opened file) for the next save.
    pub fn seed_png(&mut self, id: &str, key: (usize, usize), png: Vec<u8>) { self.pngs.insert((id.to_string(), key), png); }
    fn get(&mut self, id: &str) -> Result<&mut Surface, String> { self.map.get_mut(id).ok_or_else(|| "Unknown raster surface".into()) }
    /// `method` without the `raster.` prefix; `a` the request args.
    pub fn handle(&mut self, method: &str, a: &[Value]) -> Result<Value, String> {
        let id = a.first().and_then(Value::as_str).unwrap_or("");
        match method {
            // set(id, image): create or replace a whole surface.
            "set" => { if !crate::ids::valid_resource(id) { return Err("Invalid resource ID".into()); } self.remember(id, None); let s = image(a.get(1).unwrap_or(&Value::Null))?; self.map.insert(id.into(), s); Ok(Value::Null) }
            // v278: setTiles(id, width, height, {"x:y": image}): a transparent surface plus only its painted tiles
            "setTiles" => { if !crate::ids::valid_resource(id) { return Err("Invalid resource ID".into()); }
                let (w, h) = (a.get(1).and_then(Value::as_u64).unwrap_or(0) as usize, a.get(2).and_then(Value::as_u64).unwrap_or(0) as usize); if w == 0 || h == 0 || w > 32768 || h > 32768 { return Err("Invalid surface size".into()); }
                self.remember(id, None); let mut sfc = Surface::new(w, h); let mut missing = Vec::new();
                // v284: a tile may be {"live": hash}: found by content in any surface at the same position (duplicates,
                // resyncs of unchanged surfaces); misses are listed and sent by patchTiles.
                if let Some(t) = a.get(3).and_then(Value::as_object) { for (k, v) in t { let mut it = k.split(':').map(|n| n.parse::<i64>()); let (Some(Ok(x)), Some(Ok(y))) = (it.next(), it.next()) else { return Err("Invalid tile key".into()) };
                    if let Some(hash) = v.get("live").and_then(Value::as_str) { match (x >= 0 && y >= 0).then(|| self.find_any((x as usize, y as usize), hash)).flatten() { Some(tile) => sfc.write_region(&tile, x, y), None => missing.push(k.clone()) } }
                    else { sfc.write_region(&image(v)?, x, y); } } }
                self.forget(id, None); self.map.insert(id.into(), sfc); Ok(if missing.is_empty() { Value::Null } else { json!({"missing": missing}) }) }
            // v284 patchTiles(id, {"x:y": image}): write tiles a setTiles call could not find in the core.
            "patchTiles" => { let t = a.get(1).and_then(Value::as_object).ok_or("Invalid tiles")?; self.forget(id, None);
                for (k, v) in t { let key = tile_key(k).ok_or("Invalid tile key")?; let img = image(v)?; self.get(id)?.write_region(&img, key.0 as i64, key.1 as i64); } Ok(Value::Null) }
            // v283 checkpoint(): a history step completed; the checkpoint cache starts over.
            "checkpoint" => { self.recent.clear(); Ok(Value::Null) }
            "release" => { self.map.shift_remove(id); self.recent.retain(|k, _| k.0 != id); self.snaps.retain(|_, s| match s { Snap::Tiles { resource, .. } | Snap::Surface { resource, .. } => resource != id }); Ok(Value::Null) }
            // v269 captureTiles(id, snapId, keys, tileSize): snapshot the live tiles under `keys` natively.
            "captureTiles" => {
                let snap = a.get(1).and_then(Value::as_str).filter(|s| crate::ids::valid_snapshot(s)).ok_or("Invalid snapshot ID")?.to_string();
                let t = a.get(3).and_then(Value::as_u64).filter(|t| *t > 0).ok_or("Invalid tile size")? as usize;
                let keys: Vec<(usize, usize)> = a.get(2).and_then(Value::as_array).ok_or("Invalid tile keys")?.iter().map(|k| k.as_str().and_then(tile_key).ok_or("Invalid tile key")).collect::<Result<_, _>>()?;
                let s = self.get(id)?; let tiles = keys.into_iter().map(|(x, y)| ((x, y), read_tile(s, x, y, t))).collect();
                self.snaps.insert(snap, Snap::Tiles { resource: id.into(), tile: t, tiles }); Ok(Value::Null)
            }
            // v269 adoptTiles(id, snapId, {"x:y": image | null}, tileSize): snapshot with tile pixels supplied.
            "adoptTiles" => {
                let snap = a.get(1).and_then(Value::as_str).filter(|s| crate::ids::valid_snapshot(s)).ok_or("Invalid snapshot ID")?.to_string();
                let t = a.get(3).and_then(Value::as_u64).filter(|t| *t > 0).ok_or("Invalid tile size")? as usize;
                let mut tiles = Vec::new();
                // v283: a tile may be {"live": hash}: the core's own pixels under that tile, used when their hash matches
                // (the usual case: the snapshot is the surface just before an edit). Mismatches are listed in `missing`
                // and filled by patchSnapshot.
                self.get(id)?; let mut missing = Vec::new();
                for (k, v) in a.get(2).and_then(Value::as_object).ok_or("Invalid tiles")? { let key = tile_key(k).ok_or("Invalid tile key")?;
                    let tile = if v.is_null() { None } else if let Some(hash) = v.get("live").and_then(Value::as_str) {
                        match self.find_tile(id, key, t, hash) { Some(cur) => Some(cur), None => { missing.push(k.clone()); None } }
                    } else { Some(image(v)?) };
                    tiles.push((key, tile)); }
                self.snaps.insert(snap, Snap::Tiles { resource: id.into(), tile: t, tiles }); Ok(if missing.is_empty() { Value::Null } else { json!({"missing": missing}) })
            }
            // v283 patchSnapshot(id, snapId, {"x:y": image | null}): supply tiles an adoptTiles call could not take live.
            "patchSnapshot" => {
                let snap = a.get(1).and_then(Value::as_str).unwrap_or(""); let patch = a.get(2).and_then(Value::as_object).ok_or("Invalid tiles")?;
                match self.snaps.get_mut(snap) {
                    Some(Snap::Tiles { resource, tiles, .. }) if resource == id => { for (k, v) in patch { let key = tile_key(k).ok_or("Invalid tile key")?; let img = if v.is_null() { None } else { Some(image(v)?) };
                        if let Some(e) = tiles.iter_mut().find(|e| e.0 == key) { e.1 = img; } } Ok(Value::Null) }
                    _ => Err("Unknown tile snapshot".into()),
                }
            }
            // v269 swapTiles(id, snapId): exchange snapshot tiles with live pixels.
            "swapTiles" => {
                let snap = a.get(1).and_then(Value::as_str).unwrap_or(""); self.forget(id, None);
                let surface = self.map.get_mut(id).ok_or("Unknown raster surface")?;
                match self.snaps.get_mut(snap) {
                    Some(Snap::Tiles { resource, tile, tiles }) if resource == id => { let t = *tile; for ((x, y), saved) in tiles.iter_mut() { let cur = read_tile(surface, *x, *y, t); if t == RECENT_TILE && self.recent.len() < RECENT_LIMIT { if let Some(c) = &cur { self.recent.entry((id.to_string(), (*x, *y))).or_insert_with(|| c.clone()); } } put_tile(surface, *x, *y, t, saved.as_ref()); *saved = cur; } Ok(Value::Null) }
                    _ => Err("Unknown tile snapshot".into()),
                }
            }
            // v269 adoptSurface(id, snapId, image) / restoreSurface(id, snapId)
            "adoptSurface" => { let snap = a.get(1).and_then(Value::as_str).filter(|s| crate::ids::valid_snapshot(s)).ok_or("Invalid snapshot ID")?.to_string(); let surface = image(a.get(2).unwrap_or(&Value::Null))?; self.get(id)?; self.snaps.insert(snap, Snap::Surface { resource: id.into(), surface }); Ok(Value::Null) }
            "restoreSurface" => { let snap = a.get(1).and_then(Value::as_str).unwrap_or(""); self.remember(id, None); let s = match self.snaps.get(snap) { Some(Snap::Surface { resource, surface }) if resource == id => surface.clone(), _ => return Err("Unknown surface snapshot".into()) }; *self.get(id)? = s; Ok(Value::Null) }
            // v269 read(id): the surface as a straight-RGBA image (tests and diagnostics).
            "read" => { let s = self.get(id)?; Ok(json!({"width": s.width, "height": s.height, "data": b64_encode(&s.to_straight())})) }
            "dropSnapshot" => { self.snaps.shift_remove(a.get(1).and_then(Value::as_str).unwrap_or("")); Ok(Value::Null) }
            // writeRegion(id, image, x, y): replace pixels under the image.
            "writeRegion" => { let p = image(a.get(1).unwrap_or(&Value::Null))?; self.remember(id, Some(Rect { x: int(a.get(2)), y: int(a.get(3)), w: p.width as i64, h: p.height as i64 })); self.get(id)?.write_region(&p, int(a.get(2)), int(a.get(3))); Ok(Value::Null) }
            // composeRegion(id, rect, image, ox, oy, op, alpha)
            "composeRegion" => { let r = rect(a.get(1))?; self.remember(id, Some(r)); let src = image(a.get(2).unwrap_or(&Value::Null))?; let o = op(a.get(5))?; self.get(id)?.compose_region(r, &src, int(a.get(3)), int(a.get(4)), o, alpha(a.get(6))); Ok(Value::Null) }
            // fillRegion(id, rect, [r, g, b], op, alpha)
            "fillRegion" => { let r = rect(a.get(1))?; self.remember(id, Some(r)); let c = a.get(2).and_then(Value::as_array).ok_or("Invalid colour")?; let ch = |i: usize| c.get(i).and_then(Value::as_u64).unwrap_or(0).min(255) as u8; let o = op(a.get(3))?; self.get(id)?.fill_region(r, [ch(0), ch(1), ch(2)], o, alpha(a.get(4))); Ok(Value::Null) }
            // v284 invert(id): the app's whole-layer invert (RasterResources.invertPixels without a selection).
            "invert" => { self.remember(id, None); self.get(id)?.invert(); Ok(Value::Null) }
            // v284 writeChunks(id, [[x, y, w, h, hash | null, image | null]...]): a large write split on the tile grid. Chunks
            // given as a hash are unchanged if the core's pixels there hash the same; the indices of the rest are returned
            // (`missing`) and sent as writeRegion.
            "writeChunks" => { let list = a.get(1).and_then(Value::as_array).ok_or("Invalid chunks")?.clone(); let mut missing = Vec::new();
                for (i, c) in list.iter().enumerate() { let n = |k: usize| c.get(k).and_then(Value::as_i64).unwrap_or(0); let r = Rect { x: n(0), y: n(1), w: n(2), h: n(3) };
                    if let Some(img) = c.get(5).filter(|v| !v.is_null()) { let img = image(img)?; self.remember(id, Some(r)); self.get(id)?.write_region(&img, r.x, r.y); continue; }
                    let hash = c.get(4).and_then(Value::as_str).unwrap_or(""); let s = self.get(id)?; if r.w <= 0 || r.h <= 0 { continue; }
                    let mut cur = Surface::new(r.w as usize, r.h as usize); for row in 0..r.h { let y = r.y + row; if y < 0 || y as usize >= s.height { continue; } for col in 0..r.w { let x = r.x + col; if x < 0 || x as usize >= s.width { continue; } let si = (y as usize * s.width + x as usize) * 4; let di = (row as usize * r.w as usize + col as usize) * 4; cur.data[di..di + 4].copy_from_slice(&s.data[si..si + 4]); } }
                    if tile_hash_of(&cur) != hash { missing.push(i); } }
                Ok(if missing.is_empty() { Value::Null } else { json!({"missing": missing}) }) }
            // v284 floodFill(id, {x, y, tolerance, contiguous, rgb, alpha, erase, alphaLock}, [x, y, w, h, count]): the app's
            // bucket fill on the core's pixels; written only when the region equals the app's (else {"mismatch": region}).
            "floodFill" => { let o = a.get(1).ok_or("Invalid fill")?; let num = |k: &str| o.get(k).and_then(Value::as_f64).unwrap_or(0.0); let flag = |k: &str| o.get(k).and_then(Value::as_bool).unwrap_or(false);
                let rgb = o.get("rgb").and_then(Value::as_array).ok_or("Invalid colour")?; let ch = |i: usize| rgb.get(i).and_then(Value::as_f64).unwrap_or(0.0);
                let f = crate::fill::Fill { x: num("x") as usize, y: num("y") as usize, tolerance: num("tolerance"), contiguous: flag("contiguous"), rgb: [ch(0), ch(1), ch(2)], alpha: num("alpha"), erase: flag("erase"), alpha_lock: flag("alphaLock") };
                let e = a.get(2).and_then(Value::as_array).ok_or("Invalid region")?; let eu = |i: usize| e.get(i).and_then(Value::as_u64).unwrap_or(0) as usize; let expect = (eu(0), eu(1), eu(2), eu(3), eu(4));
                self.remember(id, Some(Rect { x: expect.0 as i64, y: expect.1 as i64, w: expect.2 as i64, h: expect.3 as i64 }));
                match crate::fill::apply(self.get(id)?, &f, expect) { Ok(()) => Ok(Value::Null), Err(r) => Ok(json!({"mismatch": [r.0, r.1, r.2, r.3, r.4]})) } }
            // v286 cloneFrom(id, srcId, [a,b,c,d,e,f]): a clone layer's surface drawn from its source surface under the instance
            // transform (drawImage modelled as for transform modifiers: exact for translations, flips and axis scales).
            "cloneFrom" => { let src = self.map.get(a.get(1).and_then(Value::as_str).unwrap_or("")).ok_or("Unknown clone source")?.clone();
                let m = a.get(2).and_then(Value::as_array).ok_or("Invalid matrix")?; let mut t = [0f64; 6]; for (i, v) in t.iter_mut().enumerate() { *v = m.get(i).and_then(Value::as_f64).ok_or("Invalid matrix")?; }
                let out = crate::modifiers::transform(&src, t); if !crate::ids::valid_resource(id) { return Err("Invalid resource ID".into()); } self.remember(id, None); self.forget(id, None); self.map.insert(id.into(), out); Ok(Value::Null) }
            // v291 writeTiles(id, width, height, {"x:y": image | null}, {replace?}): lazily synced tiles (null = the tile is now empty);
            // creates the surface when the core does not have it yet.
            "writeTiles" => { if !crate::ids::valid_resource(id) { return Err("Invalid resource ID".into()); }
                let (w, h) = (a.get(1).and_then(Value::as_u64).unwrap_or(0) as usize, a.get(2).and_then(Value::as_u64).unwrap_or(0) as usize); if w == 0 || h == 0 || w > 32768 || h > 32768 { return Err("Invalid surface size".into()); }
                // v292: {replace: true} (args[4]) starts from a transparent surface: the first batch of a whole-surface sync
                let replace = a.get(4).and_then(|o| o.get("replace")).and_then(Value::as_bool).unwrap_or(false);
                if replace || !matches!(self.map.get(id), Some(sf) if sf.width == w && sf.height == h) { self.remember(id, None); self.map.insert(id.into(), Surface::new(w, h)); }
                let mut missing: Vec<String> = Vec::new(); let tiles = a.get(3).and_then(Value::as_object).ok_or("Invalid tiles")?.clone();
                for (k, v) in tiles.iter() { let (x, y) = tile_key(k).ok_or("Invalid tile key")?; let r = Rect { x: x as i64, y: y as i64, w: RECENT_TILE as i64, h: RECENT_TILE as i64 };
                    // v293: {live: hash}: keep the core's tile when its content hash matches, else list it as missing
                    if let Some(hh) = v.get("live").and_then(Value::as_str) { if self.live_hash(id, (x, y)).as_deref() != Some(hh) { missing.push(k.clone()); } continue; }
                    // v293: a tile identical to what the core holds is skipped (keeps its cached PNG for the next save)
                    let img = if v.is_null() { None } else { Some(image(v)?) };
                    { let sf = self.get(id)?; let same = match &img { None => read_tile(sf, x, y, RECENT_TILE).is_none(), Some(im) => (0..im.height).all(|row| { let (yy, n) = (y + row, im.width.min(sf.width.saturating_sub(x))); yy >= sf.height || { let si = (yy * sf.width + x) * 4; sf.data[si..si + n * 4] == im.data[row * im.width * 4..row * im.width * 4 + n * 4] } }) };
                      if same { continue; } }
                    self.remember(id, Some(r)); let sf = self.get(id)?; sf.clear_region(r); if let Some(im) = img { sf.write_region(&im, x as i64, y as i64); } }
                Ok(if missing.is_empty() { Value::Null } else { json!({"missing": missing}) }) }
            // v295 stash(_, snapId, {"x:y": image | null}): keep an undo snapshot's tiles in the core (PNG, encoded in parallel)
            // so the app can free them; unstash (binary) hands them back. dropStash(_, [snapIds]) forgets them.
            "stash" => { use rayon::prelude::*; let snap = a.get(1).and_then(Value::as_str).ok_or("Invalid snapshot ID")?.to_string();
                // straight RGBA exactly as the app read it (no premultiplied round trip)
                let items: Vec<(String, Option<(usize, usize, Vec<u8>)>)> = a.get(2).and_then(Value::as_object).ok_or("Invalid tiles")?.iter().map(|(k, v)| Ok((k.clone(), if v.is_null() { None } else {
                    let (w, h) = (v.get("width").and_then(Value::as_u64).unwrap_or(0) as usize, v.get("height").and_then(Value::as_u64).unwrap_or(0) as usize); let d = bytes_of(v.get("data").ok_or("Invalid image data")?)?; if w == 0 || h == 0 || d.len() != w * h * 4 { return Err("Invalid stash tile".to_string()); } Some((w, h, d) ) }))).collect::<Result<_, String>>()?;
                let enc: Vec<(String, Option<Vec<u8>>)> = items.par_iter().map(|(k, t)| Ok((k.clone(), match t { None => None, Some((w, h, d)) => Some(crate::project::encode_png(*w, *h, d)?) }))).collect::<Result<_, String>>()?;
                let bytes: usize = enc.iter().map(|(_, b)| b.as_ref().map_or(0, |b| b.len())).sum(); self.stash.insert(snap, enc); Ok(json!({"bytes": bytes})) }
            "dropStash" => { for v in a.get(1).and_then(Value::as_array).map(|a| a.as_slice()).unwrap_or(&[]) { if let Some(id) = v.as_str() { self.stash.remove(id); } } Ok(json!({"stashes": self.stash.len()})) }
            "clearRegion" => { let r = rect(a.get(1))?; self.remember(id, Some(r)); self.get(id)?.clear_region(r); Ok(Value::Null) }
            // compare(id, image, {tolerance, resync}): premultiplied channel differences; resync replaces the surface with the image.
            "compare" => {
                let img = image(a.get(1).unwrap_or(&Value::Null))?; let o = a.get(2).cloned().unwrap_or(json!({}));
                let tol = o.get("tolerance").and_then(Value::as_u64).unwrap_or(3) as i32;
                let s = self.get(id)?;
                let res = diff(s, &img, tol);
                if o.get("resync").and_then(Value::as_bool).unwrap_or(false) { self.forget(id, None); self.map.insert(id.into(), img); }
                Ok(res)
            }
            "list" => { let mut m = Map::new(); for (k, s) in &self.map { m.insert(k.clone(), json!([s.width, s.height])); } Ok(json!({"surfaces": m, "snapshots": self.snaps.len()})) }
            m => Err(format!("Unknown method raster.{m}")),
        }
    }
}

/// v301: tiles of `sf` at (x, y) document positions covering 256*lv pixels each, box-shrunk by `lv`, as
/// [u32 n] then per painted tile [u32 x][u32 y][u32 w][u32 h] + straight RGBA (w = ceil(covered width / lv)).
pub fn tile_list(sf: &Surface, keys: &[(usize, usize)], lv: usize) -> Vec<u8> {
    use rayon::prelude::*;
    let parts: Vec<Vec<u8>> = keys.par_iter().filter_map(|&(x, y)| { if x >= sf.width || y >= sf.height { return None; }
        let (rw, rh) = ((256 * lv).min(sf.width - x), (256 * lv).min(sf.height - y)); let (w, h) = (rw.div_ceil(lv), rh.div_ceil(lv));
        let mut o = vec![0u8; 16 + w * h * 4]; let mut any = false;
        for oy in 0..h { for ox in 0..w { let mut acc = [0u32; 4]; let mut n = 0u32;
            for yy in y + oy * lv..(y + oy * lv + lv).min(y + rh) { let row = yy * sf.width; for xx in x + ox * lv..(x + ox * lv + lv).min(x + rw) { let i = (row + xx) * 4; for c in 0..4 { acc[c] += sf.data[i + c] as u32; } n += 1; } }
            if n == 0 || acc[3] == 0 { continue; } any = true; let a = ((acc[3] + n / 2) / n) as u8; let di = 16 + (oy * w + ox) * 4; o[di + 3] = a;
            if a > 0 { for c in 0..3 { let p = ((acc[c] + n / 2) / n) as u8; o[di + c] = crate::modifiers::unpremul(p, a); } } } }
        if !any { return None; } for (k, v) in [x, y, w, h].iter().enumerate() { o[k * 4..k * 4 + 4].copy_from_slice(&(*v as u32).to_le_bytes()); } Some(o) }).collect();
    let mut out = Vec::with_capacity(4 + parts.iter().map(Vec::len).sum::<usize>()); out.extend_from_slice(&(parts.len() as u32).to_le_bytes()); for p in parts { out.extend_from_slice(&p); } out
}
