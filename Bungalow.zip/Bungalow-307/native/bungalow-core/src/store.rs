//! Authoritative document store (mirror of `src/engine-document-store-265.js`).
//!
//! Every slice is plain JSON. Commits validate the whole patch first and either apply it or
//! leave the state untouched; no-op commits do not advance `revision`. Error messages, iteration
//! order and revision counting match the JS engine exactly (checked by the conformance tests).
//!
//! Patch arguments are JSON values. A JSON object `{"$undefined": true}` stands for JavaScript
//! `undefined` (used to delete a record key, or to leave a patch field unspecified).
use crate::{codec, err, ids, Result};
use serde_json::{json, Map, Value};

// ---------------------------------------------------------------- helpers
pub fn is_undefined(v: &Value) -> bool { matches!(v, Value::Object(o) if o.len() == 1 && o.get("$undefined") == Some(&Value::Bool(true))) }
/// `patch[key]`, or None when missing or `undefined`.
fn field<'a>(patch: &'a Value, key: &str) -> Option<&'a Value> { patch.as_object().and_then(|o| o.get(key)).filter(|v| !is_undefined(v)) }
/// JavaScript `!patch || typeof patch !== 'object'`.
fn is_objectish(v: &Value) -> bool { matches!(v, Value::Object(_) | Value::Array(_)) }
fn truthy(v: &Value) -> bool { match v { Value::Null => false, Value::Bool(b) => *b, Value::Number(n) => n.as_f64().map_or(false, |x| x != 0.0 && !x.is_nan()), Value::String(s) => !s.is_empty(), _ => !is_undefined(v) } }
fn num(v: &Value) -> Option<f64> { v.as_f64() }
fn finite(v: &Value) -> bool { num(v).map_or(false, f64::is_finite) }
fn str_le(v: &Value, max: usize) -> bool { v.as_str().map_or(false, |s| ids::js_len(s) <= max) }
fn js_integer(v: &Value) -> bool { num(v).map_or(false, |x| x.is_finite() && x.fract() == 0.0) }
fn obj(v: &Value) -> &Map<String, Value> { v.as_object().expect("slice is an object") }
/// Strict equality for primitives (numbers compared numerically).
fn prim_eq(a: &Value, b: &Value) -> bool {
    match (a, b) {
        (Value::Number(x), Value::Number(y)) => x.as_f64() == y.as_f64(),
        (Value::Null, Value::Null) => true,
        (Value::Bool(x), Value::Bool(y)) => x == y,
        (Value::String(x), Value::String(y)) => x == y,
        _ => false,
    }
}
fn list_eq(a: &Value, b: &Value) -> bool {
    match (a.as_array(), b.as_array()) { (Some(x), Some(y)) => x.len() == y.len() && x.iter().zip(y).all(|(p, q)| prim_eq(p, q)), _ => false }
}
/// JSON.stringify comparison (key order matters, as in JS).
fn json_eq(a: &Value, b: &Value) -> bool { serde_json::to_string(a).ok() == serde_json::to_string(b).ok() }

// ---------------------------------------------------------------- id rules
fn node_id(v: Option<&Value>, label: &str) -> Result<Value> {
    match v { Some(Value::Null) => Ok(Value::Null), Some(Value::String(s)) if ids::valid_node(s) => Ok(Value::String(s.clone())), _ => err(format!("Invalid {label} ID")) }
}
fn key_id(v: Option<&Value>, label: &str) -> Result<Value> {
    match v { Some(Value::Null) => Ok(Value::Null), Some(Value::String(s)) if !s.is_empty() && ids::js_len(s) <= 256 => Ok(Value::String(s.clone())), _ => err(format!("Invalid {label} ID")) }
}
fn key_list(list: &Value, label: &str, dedupe: bool) -> Result<Value> {
    let arr = match list.as_array() { Some(a) => a, None => return err(format!("Invalid {label} list")) };
    let mut out: Vec<Value> = Vec::new();
    for v in arr {
        if v.is_null() { return err(format!("Invalid {label} ID")); }
        let undef = is_undefined(v);
        key_id(if undef { None } else { Some(v) }, label)?;
        if out.iter().any(|x| x == v) { if dedupe { continue; } return err(format!("Duplicate {label} ID")); }
        out.push(v.clone());
    }
    Ok(Value::Array(out))
}

// ---------------------------------------------------------------- empty slices
fn empty_selection() -> Value { json!({"selected": [], "anchor": null, "active": null}) }
fn empty_tree() -> Value { json!({"layers": [], "groups": [], "parents": {}}) }
fn empty_references() -> Value { json!({"ids": [], "selected": null, "shown": true}) }
fn empty_boards() -> Value { json!({"ids": [], "active": null, "selected": [], "anchor": null}) }
fn empty_document() -> Value { json!({"width": 1920, "height": 1080, "dpi": 72}) }
fn empty_session() -> Value { json!({"dirty": false, "editSerial": 0, "filename": "painting.bung", "hasFile": false}) }
fn empty_map() -> Value { Value::Object(Map::new()) }

// ---------------------------------------------------------------- slice normalisers
pub fn normalise_selection(patch: &Value, base: &Value) -> Result<Value> {
    if !is_objectish(patch) { return err("Invalid selection patch"); }
    let selected = field(patch, "selected").cloned().unwrap_or_else(|| base["selected"].clone());
    let arr = match selected.as_array() { Some(a) => a.clone(), None => return err("Invalid selected list") };
    let mut list: Vec<Value> = Vec::new();
    for v in &arr {
        if v.is_null() { return err("Invalid selected ID"); }
        node_id(if is_undefined(v) { None } else { Some(v) }, "selected")?;
        if !list.contains(v) { list.push(v.clone()); }
    }
    let anchor = match field(patch, "anchor") { None => base["anchor"].clone(), Some(v) => node_id(Some(v), "anchor")? };
    let active = match field(patch, "active") { None => base["active"].clone(), Some(v) => node_id(Some(v), "active")? };
    Ok(json!({"selected": list, "anchor": anchor, "active": active}))
}
fn same_selection(a: &Value, b: &Value) -> bool { prim_eq(&a["anchor"], &b["anchor"]) && prim_eq(&a["active"], &b["active"]) && list_eq(&a["selected"], &b["selected"]) }

pub fn normalise_tree(patch: &Value, base: &Value) -> Result<Value> {
    if !is_objectish(patch) { return err("Invalid tree patch"); }
    let layers = field(patch, "layers").unwrap_or(&base["layers"]);
    let groups = field(patch, "groups").unwrap_or(&base["groups"]);
    let (la, ga) = match (layers.as_array(), groups.as_array()) { (Some(l), Some(g)) => (l, g), _ => return err("Invalid tree order") };
    let mut seen: Vec<String> = Vec::new();
    for v in la.iter().chain(ga.iter()) {
        if v.is_null() { return err("Invalid tree ID"); }
        let s = node_id(if is_undefined(v) { None } else { Some(v) }, "tree")?;
        let s = s.as_str().unwrap().to_string();
        if seen.contains(&s) { return err("Duplicate tree ID"); }
        seen.push(s);
    }
    let given_v = field(patch, "parents");
    let empty = Map::new();
    let given: &Map<String, Value> = match given_v { None => &empty, Some(Value::Object(o)) => o, Some(Value::Null) | Some(Value::Bool(false)) => &empty, Some(Value::Array(_)) => &empty, Some(Value::String(s)) if s.is_empty() => &empty, Some(Value::Number(n)) if n.as_f64() == Some(0.0) => &empty, Some(_) => return err("Invalid parents") };
    let base_parents = obj(&base["parents"]);
    let mut parents = Map::new();
    for v in &seen {
        let p: Option<&Value> = if given.contains_key(v) { given.get(v).filter(|x| !is_undefined(x)) } else if base_parents.contains_key(v) { base_parents.get(v) } else { Some(&Value::Null) };
        let p = node_id(p, "parent")?;
        if p.as_str() == Some(v.as_str()) { return err("Node cannot parent itself"); }
        parents.insert(v.clone(), p);
    }
    for g in ga {
        let g = g.as_str().unwrap();
        let mut path = vec![g.to_string()];
        let mut p = parents.get(g).cloned().unwrap_or(Value::Null);
        while let Value::String(ps) = &p {
            if !parents.contains_key(ps) { break; }
            if path.contains(ps) { return err("Group cycle"); }
            path.push(ps.clone());
            p = parents.get(ps).cloned().unwrap_or(Value::Null);
        }
    }
    Ok(json!({"layers": la, "groups": ga, "parents": parents}))
}
fn same_tree(a: &Value, b: &Value) -> bool {
    let (pa, pb) = (obj(&a["parents"]), obj(&b["parents"]));
    list_eq(&a["layers"], &b["layers"]) && list_eq(&a["groups"], &b["groups"]) && pa.len() == pb.len() && pa.iter().all(|(k, v)| pb.get(k).map_or(false, |w| prim_eq(v, w)))
}
pub fn verify_tree(tree: &Value) -> Value {
    let groups = tree["groups"].as_array().unwrap();
    let layers = tree["layers"].as_array().unwrap();
    let mut issues = Vec::new();
    for (k, p) in obj(&tree["parents"]) {
        if p.is_null() { continue; }
        if layers.contains(p) { issues.push(json!({"id": k, "issue": "layer-parent"})); } else if !groups.contains(p) { issues.push(json!({"id": k, "issue": "dangling-parent"})); }
    }
    Value::Array(issues)
}

pub fn normalise_references(patch: &Value, base: &Value) -> Result<Value> {
    if !is_objectish(patch) { return err("Invalid references patch"); }
    let shown = field(patch, "shown").cloned().unwrap_or_else(|| base["shown"].clone());
    if !shown.is_boolean() { return err("Invalid references shown flag"); }
    let ids_v = match field(patch, "ids") { None => base["ids"].clone(), Some(v) => key_list(v, "reference", false)? };
    let selected = match field(patch, "selected") { None => base["selected"].clone(), Some(v) => key_id(Some(v), "reference")? };
    Ok(json!({"ids": ids_v, "selected": selected, "shown": shown}))
}
fn same_references(a: &Value, b: &Value) -> bool { prim_eq(&a["selected"], &b["selected"]) && prim_eq(&a["shown"], &b["shown"]) && list_eq(&a["ids"], &b["ids"]) }

pub fn normalise_boards(patch: &Value, base: &Value) -> Result<Value> {
    if !is_objectish(patch) { return err("Invalid boards patch"); }
    let ids_v = match field(patch, "ids") { None => base["ids"].clone(), Some(v) => key_list(v, "artboard", false)? };
    let active = match field(patch, "active") { None => base["active"].clone(), Some(v) => key_id(Some(v), "artboard")? };
    let selected = match field(patch, "selected") { None => base["selected"].clone(), Some(v) => key_list(v, "artboard", true)? };
    let anchor = match field(patch, "anchor") { None => base["anchor"].clone(), Some(v) => key_id(Some(v), "artboard")? };
    Ok(json!({"ids": ids_v, "active": active, "selected": selected, "anchor": anchor}))
}
fn same_boards(a: &Value, b: &Value) -> bool { prim_eq(&a["active"], &b["active"]) && prim_eq(&a["anchor"], &b["anchor"]) && list_eq(&a["ids"], &b["ids"]) && list_eq(&a["selected"], &b["selected"]) }

pub fn normalise_document(patch: &Value, base: &Value) -> Result<Value> {
    if !is_objectish(patch) { return err("Invalid document patch"); }
    let mut out = Map::new();
    for k in ["width", "height", "dpi"] {
        let v = field(patch, k).cloned().unwrap_or_else(|| base[k].clone());
        let ok = num(&v).map_or(false, |x| x.is_finite() && x > 0.0 && x <= 1e6);
        if !ok { return err(format!("Invalid document {k}")); }
        out.insert(k.into(), v);
    }
    Ok(Value::Object(out))
}
fn same_document(a: &Value, b: &Value) -> bool { ["width", "height", "dpi"].iter().all(|k| prim_eq(&a[*k], &b[*k])) }

// ---------------------------------------------------------------- record slices
fn plain_json(v: &Value, d: usize) -> bool {
    if d > 32 { return false; }
    match v {
        Value::Null | Value::Bool(_) | Value::String(_) => true,
        Value::Number(_) => finite(v),
        Value::Array(a) => a.iter().all(|x| plain_json(x, d + 1)),
        Value::Object(o) => is_undefined(v) || o.values().all(|x| is_undefined(x) || plain_json(x, d + 1)),
    }
}
fn json_value(v: &Value) -> bool { v.is_null() || (matches!(v, Value::Object(_) | Value::Array(_)) && plain_json(v, 0)) }
fn content_value(v: &Value) -> bool { v.is_null() || (v.is_object() && codec::valid(v)) }
fn is_bool(v: &Value) -> bool { v.is_boolean() }

#[derive(Clone, Copy, PartialEq)]
pub enum Slice { Props, BoardProps, ReferenceProps }
impl Slice {
    pub fn parse(name: &str) -> Option<Slice> { match name { "props" => Some(Slice::Props), "boardProps" => Some(Slice::BoardProps), "referenceProps" => Some(Slice::ReferenceProps), _ => None } }
    fn name(self) -> &'static str { match self { Slice::Props => "props", Slice::BoardProps => "boardProps", Slice::ReferenceProps => "referenceProps" } }
    fn check_id(self, v: Option<&Value>) -> Result<Value> { match self { Slice::Props => node_id(v, "props"), Slice::BoardProps => key_id(v, "artboard"), Slice::ReferenceProps => key_id(v, "reference") } }
    /// Key validator; None for unknown keys.
    fn validator(self, k: &str) -> Option<fn(&Value) -> bool> {
        match self {
            Slice::Props => Some(match k {
                "vis" | "locked" | "alphaLock" | "inheritAlpha" | "reference" | "collapsed" | "isolate" | "mask" | "maskDirect" | "preventTrim" => is_bool,
                "op" => finite,
                "blend" => |v| str_le(v, 64),
                "name" => |v| str_le(v, 4096),
                "rasterId" => |v| v.as_str().map_or(false, ids::valid_resource),
                "maskKind" => |v| str_le(v, 32),
                "maskFilter" | "maskTransform" | "maskMirror" | "maskColour" | "maskGradient" | "maskStroke" | "maskShadow" => json_value,
                "instance" | "retained" => content_value,
                "maskTarget" => |v| v.is_null() || v.as_str().map_or(false, |s| s == "orphan" || ids::valid_node(s)),
                _ => return None,
            }),
            Slice::BoardProps => Some(match k {
                "name" => |v| str_le(v, 4096),
                "x" | "y" => finite,
                "visible" | "locked" => is_bool,
                "group" => |v| v.is_null() || v.as_str().map_or(false, |s| !s.is_empty() && ids::js_len(s) <= 256),
                _ => return None,
            }),
            Slice::ReferenceProps => Some(match k {
                "name" => |v| str_le(v, 4096),
                "x" | "y" | "w" | "h" | "angle" | "op" | "saturation" => finite,
                "vis" => is_bool,
                "matrix" => |v| v.as_array().map_or(false, |a| a.len() == 4 && a.iter().all(finite)),
                "src" => |v| v.as_str().map_or(false, |s| s.starts_with("data:image/")),
                "nw" | "nh" => |v| js_integer(v) && num(v).unwrap() > 0.0,
                _ => return None,
            }),
        }
    }
}
/// Deep copy dropping `undefined` object members (JS deepFreeze).
fn deep_copy(v: &Value) -> Value {
    match v {
        Value::Array(a) => Value::Array(a.iter().map(deep_copy).collect()),
        Value::Object(o) => Value::Object(o.iter().filter(|(_, x)| !is_undefined(x)).map(|(k, x)| (k.clone(), deep_copy(x))).collect()),
        _ => v.clone(),
    }
}
/// JS `sameValue`: primitives strictly, arrays element-wise (objects inside arrays never equal: fresh copies), objects by JSON text.
fn same_value(a: Option<&Value>, b: Option<&Value>) -> bool {
    match (a, b) {
        (None, None) => true,
        (Some(Value::Array(x)), Some(Value::Array(y))) => x.len() == y.len() && x.iter().zip(y).all(|(p, q)| prim_eq(p, q)),
        (Some(x @ Value::Object(_)), Some(y @ Value::Object(_))) => json_eq(x, y),
        (Some(x), Some(y)) => prim_eq(x, y),
        _ => false,
    }
}
/// Normalise one record; returns (record, keys written by the patch).
fn normalise_record(values: &Value, base: Option<&Value>, slice: Slice) -> Result<(Value, Vec<String>)> {
    if !is_objectish(values) { return err("Invalid property record"); }
    let mut out: Map<String, Value> = base.and_then(|b| b.as_object()).cloned().unwrap_or_default();
    let mut touched = Vec::new();
    if let Some(o) = values.as_object() {
        for (k, v) in o {
            let ok = match slice.validator(k) { Some(f) => f, None => return err(format!("Unknown property {k}")) };
            if is_undefined(v) { out.shift_remove(k); touched.push(k.clone()); continue; }
            if !ok(v) { return err(format!("Invalid property {k}")); }
            out.insert(k.clone(), deep_copy(v));
            touched.push(k.clone());
        }
    }
    Ok((Value::Object(out), touched))
}
/// Returns (next records, changed?).
fn normalise_props(patch: &Value, base: &Value, slice: Slice) -> Result<(Value, bool)> {
    if !is_objectish(patch) { return err("Invalid props patch"); }
    let mut next = obj(base).clone();
    let remove = match field(patch, "remove") { Some(v) if truthy(v) => v.clone(), _ => json!([]) };
    let set = match field(patch, "set") { Some(v) if truthy(v) => v.clone(), _ => json!({}) };
    if !remove.is_array() || !is_objectish(&set) { return err("Invalid props patch"); }
    let base_map = obj(base);
    let mut changed = false;
    for v in remove.as_array().unwrap() {
        let id = slice.check_id(if is_undefined(v) { None } else { Some(v) })?;
        let key = id.as_str().map(str::to_string).unwrap_or_else(|| "null".into());
        if next.shift_remove(&key).is_some() { changed = true; }
    }
    if let Some(o) = set.as_object() {
        for (k, values) in o {
            slice.check_id(Some(&Value::String(k.clone())))?;
            let prior = next.get(k).cloned();
            let (rec, touched) = normalise_record(values, prior.as_ref(), slice)?;
            let old = base_map.get(k);
            if !changed {
                changed = match old {
                    None => true,
                    Some(old) => {
                        let (ro, oo) = (obj(&rec), obj(old));
                        ro.len() != oo.len() || ro.keys().any(|kk| !oo.contains_key(kk)) || touched.iter().any(|t| !same_value(ro.get(t), oo.get(t)) || (ro.get(t).map_or(false, |x| x.is_array() && x.as_array().unwrap().iter().any(|e| e.is_object() || e.is_array()))))
                    }
                };
            }
            next.insert(k.clone(), rec);
        }
    }
    if !changed && next.len() != base_map.len() { changed = true; }
    Ok((Value::Object(next), changed))
}

// ---------------------------------------------------------------- coordinates
fn deep_json(v: &Value, depth: usize) -> Result<Value> {
    if depth > 32 { return err("Coordinates too deep"); }
    match v {
        Value::Null | Value::Bool(_) | Value::String(_) => Ok(v.clone()),
        Value::Number(_) => if finite(v) { Ok(v.clone()) } else { err("Invalid coordinate number") },
        Value::Array(a) => Ok(Value::Array(a.iter().map(|x| deep_json(x, depth + 1)).collect::<Result<_>>()?)),
        Value::Object(o) => { let mut m = Map::new(); for (k, x) in o { if is_undefined(x) { continue; } m.insert(k.clone(), deep_json(x, depth + 1)?); } Ok(Value::Object(m)) }
    }
}
pub fn normalise_coordinates(v: &Value) -> Result<Value> { if !v.is_object() || is_undefined(v) { return err("Invalid coordinates"); } deep_json(v, 0) }

// ---------------------------------------------------------------- parked documents
const PARKED_PARTS: [&str; 7] = ["tree", "selection", "references", "document", "props", "referenceProps", "coordinates"];
fn or_empty(v: &Value) -> Value { if truthy(v) { v.clone() } else { empty_map() } }
pub fn normalise_parked(doc: &Value, base: Option<&Value>) -> Result<Value> {
    if !is_objectish(doc) { return err("Invalid parked document"); }
    let part = |k: &str, f: &dyn Fn(Option<&Value>) -> Result<Value>| -> Result<Value> {
        match field(doc, k) { None => match base.and_then(|b| b.get(k)) { Some(v) => Ok(v.clone()), None => f(None) }, Some(v) => f(Some(v)) }
    };
    let none = Value::Null;
    let tree = part("tree", &|v| normalise_tree(&or_empty(v.unwrap_or(&none)), &empty_tree()))?;
    let selection = part("selection", &|v| normalise_selection(&or_empty(v.unwrap_or(&none)), &empty_selection()))?;
    let references = part("references", &|v| normalise_references(&or_empty(v.unwrap_or(&none)), &empty_references()))?;
    let document = part("document", &|v| normalise_document(&or_empty(v.unwrap_or(&none)), &empty_document()))?;
    let props = part("props", &|v| Ok(normalise_props(&json!({"set": or_empty(v.unwrap_or(&none))}), &empty_map(), Slice::Props)?.0))?;
    let reference_props = part("referenceProps", &|v| Ok(normalise_props(&json!({"set": or_empty(v.unwrap_or(&none))}), &empty_map(), Slice::ReferenceProps)?.0))?;
    let coordinates = part("coordinates", &|v| match v { Some(x) if truthy(x) => normalise_coordinates(x), _ => Ok(empty_map()) })?;
    if let Some(o) = doc.as_object() { for k in o.keys() { if !PARKED_PARTS.contains(&k.as_str()) { return err(format!("Unknown parked part {k}")); } } }
    Ok(json!({"tree": tree, "selection": selection, "references": references, "document": document, "props": props, "referenceProps": reference_props, "coordinates": coordinates}))
}
fn verify_parked_doc(board: &str, d: &Value) -> Vec<Value> {
    let mut issues = Vec::new();
    let mut live: Vec<&Value> = Vec::new();
    for v in d["tree"]["layers"].as_array().unwrap().iter().chain(d["tree"]["groups"].as_array().unwrap()) { if !live.contains(&v) { live.push(v); } }
    let props = obj(&d["props"]);
    for k in &live { if !props.contains_key(k.as_str().unwrap()) { issues.push(json!({"board": board, "id": k, "issue": "node-without-props"})); } }
    for k in props.keys() { if !live.iter().any(|v| v.as_str() == Some(k)) { issues.push(json!({"board": board, "id": k, "issue": "props-without-node"})); } }
    let rp = obj(&d["referenceProps"]);
    for k in d["references"]["ids"].as_array().unwrap() { if !rp.contains_key(k.as_str().unwrap()) { issues.push(json!({"board": board, "id": k, "issue": "reference-without-record"})); } }
    for x in verify_tree(&d["tree"]).as_array().unwrap() { let mut m = Map::new(); m.insert("board".into(), json!(board)); for (k, v) in obj(x) { m.insert(k.clone(), v.clone()); } issues.push(Value::Object(m)); }
    issues
}

// ---------------------------------------------------------------- session
pub fn normalise_session(patch: &Value, base: &Value) -> Result<Value> {
    if !is_objectish(patch) { return err("Invalid session patch"); }
    let mut o = obj(base).clone();
    if let Some(p) = patch.as_object() {
        for (k, v) in p {
            if is_undefined(v) { continue; }
            match k.as_str() {
                "dirty" | "hasFile" => if !v.is_boolean() { return err(format!("Invalid session {k}")); },
                "editSerial" => if !(js_integer(v) && num(v).unwrap().abs() <= 9007199254740991.0 && num(v).unwrap() >= 0.0) { return err("Invalid session editSerial"); },
                "filename" => if !(v.is_null() || str_le(v, 4096)) { return err("Invalid session filename"); },
                _ => return err(format!("Unknown session field {k}")),
            }
            o.insert(k.clone(), v.clone());
        }
    }
    Ok(Value::Object(o))
}

// ---------------------------------------------------------------- the store
/// One slice per field; `revision` counts every applied slice change (as the JS `set`).
#[derive(Clone, Debug)]
pub struct DocumentStore {
    pub revision: u64,
    selection: Value, tree: Value, references: Value, boards: Value, document: Value,
    props: Value, board_props: Value, reference_props: Value, coordinates: Value, parked: Value, session: Value,
}
impl Default for DocumentStore { fn default() -> Self { Self::new() } }
impl DocumentStore {
    pub fn new() -> Self {
        DocumentStore { revision: 0, selection: empty_selection(), tree: empty_tree(), references: empty_references(), boards: empty_boards(), document: empty_document(), props: empty_map(), board_props: empty_map(), reference_props: empty_map(), coordinates: empty_map(), parked: empty_map(), session: empty_session() }
    }
    fn set(&mut self, slice: &str, v: Value) {
        match slice {
            "selection" => self.selection = v, "tree" => self.tree = v, "references" => self.references = v, "boards" => self.boards = v,
            "document" => self.document = v, "props" => self.props = v, "boardProps" => self.board_props = v, "referenceProps" => self.reference_props = v,
            "coordinates" => self.coordinates = v, "parked" => self.parked = v, "session" => self.session = v, _ => unreachable!(),
        }
        self.revision += 1;
    }
    fn records(&self, s: Slice) -> &Value { match s { Slice::Props => &self.props, Slice::BoardProps => &self.board_props, Slice::ReferenceProps => &self.reference_props } }
    // -- selection
    pub fn commit(&mut self, patch: &Value) -> Result<()> { let next = normalise_selection(patch, &self.selection)?; if !same_selection(&next, &self.selection) { self.set("selection", next); } Ok(()) }
    pub fn prune(&mut self, live: &[String]) -> Result<()> {
        let s = self.selection.clone();
        let keep = |v: &Value| v.as_str().map_or(false, |x| live.iter().any(|l| l == x));
        let selected: Vec<Value> = s["selected"].as_array().unwrap().iter().filter(|v| keep(v)).cloned().collect();
        let anchor = if keep(&s["anchor"]) { s["anchor"].clone() } else { Value::Null };
        let active = if keep(&s["active"]) { s["active"].clone() } else { Value::Null };
        self.commit(&json!({"selected": selected, "anchor": anchor, "active": active}))
    }
    pub fn replace(&mut self, snapshot: &Value) -> Result<()> { let v = normalise_selection(snapshot, &empty_selection())?; self.set("selection", v); Ok(()) }
    pub fn reset(&mut self) {
        for (s, v) in [("selection", empty_selection()), ("tree", empty_tree()), ("references", empty_references()), ("boards", empty_boards()), ("document", empty_document()), ("props", empty_map()), ("boardProps", empty_map()), ("referenceProps", empty_map()), ("coordinates", empty_map()), ("parked", empty_map()), ("session", empty_session())] { self.set(s, v); }
    }
    // -- tree / collections / document
    pub fn commit_tree(&mut self, patch: &Value, replace: bool) -> Result<()> { let base = if replace { empty_tree() } else { self.tree.clone() }; let next = normalise_tree(patch, &base)?; if !same_tree(&next, &self.tree) { self.set("tree", next); } Ok(()) }
    pub fn commit_references(&mut self, patch: &Value) -> Result<()> { let next = normalise_references(patch, &self.references)?; if !same_references(&next, &self.references) { self.set("references", next); } Ok(()) }
    pub fn commit_boards(&mut self, patch: &Value) -> Result<()> { let next = normalise_boards(patch, &self.boards)?; if !same_boards(&next, &self.boards) { self.set("boards", next); } Ok(()) }
    pub fn commit_document(&mut self, patch: &Value) -> Result<()> { let next = normalise_document(patch, &self.document)?; if !same_document(&next, &self.document) { self.set("document", next); } Ok(()) }
    // -- records
    pub fn commit_records(&mut self, slice: &str, patch: &Value) -> Result<()> {
        let s = match Slice::parse(slice) { Some(s) => s, None => return err("Unknown record slice") };
        let (next, changed) = normalise_props(patch, self.records(s), s)?;
        if changed { self.set(s.name(), next); }
        Ok(())
    }
    /// `value` None deletes the key (JS `undefined`).
    pub fn set_record(&mut self, slice: &str, id: &str, key: &str, value: Option<&Value>) -> Result<()> {
        let s = match Slice::parse(slice) { Some(s) => s, None => return err("Property write to a record outside the document") };
        let cur = match self.records(s).get(id) { Some(c) => c.clone(), None => return err("Property write to a record outside the document") };
        let fresh_obj_array = value.map_or(false, |v| v.as_array().map_or(false, |a| a.iter().any(|e| e.is_object() || e.is_array())));
        if !fresh_obj_array && same_value(cur.get(key), value) && (value.is_some() || !obj(&cur).contains_key(key)) { return Ok(()); }
        let mut rec = Map::new(); rec.insert(key.into(), value.cloned().unwrap_or(json!({"$undefined": true})));
        let mut set = Map::new(); set.insert(id.into(), Value::Object(rec));
        self.commit_records(slice, &json!({"set": set}))
    }
    pub fn commit_coordinates(&mut self, v: &Value) -> Result<()> { let next = normalise_coordinates(v)?; if !json_eq(&next, &self.coordinates) { self.set("coordinates", next); } Ok(()) }
    pub fn commit_session(&mut self, patch: &Value) -> Result<()> { let next = normalise_session(patch, &self.session)?; if obj(&next).iter().any(|(k, v)| !self.session.get(k).map_or(false, |w| prim_eq(v, w))) { self.set("session", next); } Ok(()) }
    // -- parked
    pub fn park(&mut self, board: &Value, doc: &Value) -> Result<()> {
        let id = key_id(if is_undefined(board) { None } else { Some(board) }, "artboard")?;
        let next = normalise_parked(doc, None)?;
        let mut p = obj(&self.parked).clone(); p.insert(id.as_str().map(str::to_string).unwrap_or_else(|| "null".into()), next); self.set("parked", Value::Object(p)); Ok(())
    }
    pub fn commit_parked(&mut self, board: &str, parts: &Value) -> Result<()> {
        let cur = match self.parked.get(board) { Some(c) => c.clone(), None => return err("Board is not parked") };
        let next = normalise_parked(parts, Some(&cur))?;
        let mut p = obj(&self.parked).clone(); p.insert(board.into(), next); self.set("parked", Value::Object(p)); Ok(())
    }
    pub fn unpark(&mut self, board: &str) -> Option<Value> {
        let doc = self.parked.get(board)?.clone();
        let mut p = obj(&self.parked).clone(); p.shift_remove(board); self.set("parked", Value::Object(p)); Some(doc)
    }
    pub fn set_parked_record(&mut self, board: &str, slice: &str, id: &str, key: &str, value: Option<&Value>) -> Result<()> {
        let cur = match self.parked.get(board) { Some(c) => c.clone(), None => return err("Board is not parked") };
        let s = match slice { "props" => Slice::Props, "referenceProps" => Slice::ReferenceProps, _ => return err("Unknown parked record slice") };
        let rec = match cur[slice].get(id) { Some(r) => r.clone(), None => return err("Property write to a record outside the parked document") };
        let fresh_obj_array = value.map_or(false, |v| v.as_array().map_or(false, |a| a.iter().any(|e| e.is_object() || e.is_array())));
        if !fresh_obj_array && same_value(rec.get(key), value) && (value.is_some() || !obj(&rec).contains_key(key)) { return Ok(()); }
        let mut r = Map::new(); r.insert(key.into(), value.cloned().unwrap_or(json!({"$undefined": true})));
        let mut set = Map::new(); set.insert(id.into(), Value::Object(r));
        let (records, _) = normalise_props(&json!({"set": set}), &cur[slice], s)?;
        let mut next = obj(&cur).clone(); next.insert(slice.into(), records);
        let mut p = obj(&self.parked).clone(); p.insert(board.into(), Value::Object(next)); self.set("parked", Value::Object(p)); Ok(())
    }
    pub fn set_parked_parent(&mut self, board: &str, node: &str, parent: &Value) -> Result<()> {
        let cur = match self.parked.get(board) { Some(c) => c.clone(), None => return err("Board is not parked") };
        let parents = obj(&cur["tree"]["parents"]);
        if !parents.contains_key(node) { return err("Parent write to a node outside the parked document"); }
        if prim_eq(&parents[node], parent) { return Ok(()); }
        let mut np = parents.clone(); np.insert(node.into(), parent.clone());
        self.commit_parked(board, &json!({"tree": {"layers": cur["tree"]["layers"], "groups": cur["tree"]["groups"], "parents": np}}))
    }
    // -- whole document
    pub fn snapshot_document(&self) -> Value {
        json!({"selection": self.selection, "tree": self.tree, "references": self.references, "boards": self.boards, "document": self.document, "props": self.props, "boardProps": self.board_props, "referenceProps": self.reference_props, "coordinates": self.coordinates, "parked": self.parked, "session": self.session})
    }
    pub fn restore_document(&mut self, doc: &Value) -> Result<()> {
        let g = |k: &str| or_empty(field(doc, k).unwrap_or(&Value::Null));
        let tree = normalise_tree(&g("tree"), &empty_tree())?;
        let selection = normalise_selection(&g("selection"), &empty_selection())?;
        let references = normalise_references(&g("references"), &empty_references())?;
        let boards = normalise_boards(&g("boards"), &empty_boards())?;
        let document = normalise_document(&g("document"), &empty_document())?;
        self.set("document", document);
        let v = normalise_props(&json!({"set": g("props")}), &empty_map(), Slice::Props)?.0; self.set("props", v);
        let v = normalise_props(&json!({"set": g("boardProps")}), &empty_map(), Slice::BoardProps)?.0; self.set("boardProps", v);
        let v = normalise_props(&json!({"set": g("referenceProps")}), &empty_map(), Slice::ReferenceProps)?.0; self.set("referenceProps", v);
        let mut p = Map::new();
        if let Some(o) = g("parked").as_object() { for (k, d) in o { key_id(Some(&Value::String(k.clone())), "artboard")?; p.insert(k.clone(), normalise_parked(d, None)?); } }
        self.set("parked", Value::Object(p));
        let v = normalise_session(&g("session"), &empty_session())?; self.set("session", v);
        let v = match field(doc, "coordinates") { Some(c) if truthy(c) => normalise_coordinates(c)?, _ => empty_map() }; self.set("coordinates", v);
        self.set("tree", tree); self.set("selection", selection); self.set("references", references); self.set("boards", boards);
        Ok(())
    }
    // -- verification
    pub fn verify(&self) -> Value { verify_tree(&self.tree) }
    pub fn verify_collections(&self) -> Value {
        let refs = self.references["ids"].as_array().unwrap(); let boards = self.boards["ids"].as_array().unwrap();
        let mut issues = Vec::new();
        if !self.references["selected"].is_null() && !refs.contains(&self.references["selected"]) { issues.push(json!({"slice": "references", "issue": "selected-missing"})); }
        if !boards.is_empty() && !self.boards["active"].is_null() && !boards.contains(&self.boards["active"]) { issues.push(json!({"slice": "boards", "issue": "active-missing"})); }
        for id in self.boards["selected"].as_array().unwrap() { if !boards.contains(id) { issues.push(json!({"slice": "boards", "id": id, "issue": "selected-missing"})); } }
        Value::Array(issues)
    }
    pub fn verify_props(&self) -> Value {
        let mut live: Vec<&Value> = Vec::new();
        for v in self.tree["layers"].as_array().unwrap().iter().chain(self.tree["groups"].as_array().unwrap()) { if !live.contains(&v) { live.push(v); } }
        let props = obj(&self.props); let mut issues = Vec::new();
        for k in props.keys() { if !live.iter().any(|v| v.as_str() == Some(k)) { issues.push(json!({"id": k, "issue": "props-without-node"})); } }
        for k in &live { if !props.contains_key(k.as_str().unwrap()) { issues.push(json!({"id": k, "issue": "node-without-props"})); } }
        Value::Array(issues)
    }
    pub fn verify_records(&self) -> Value {
        let mut issues = Vec::new();
        for (slice, recs, ids_v) in [("boardProps", &self.board_props, &self.boards["ids"]), ("referenceProps", &self.reference_props, &self.references["ids"])] {
            let live = ids_v.as_array().unwrap();
            for k in obj(recs).keys() { if !live.iter().any(|v| v.as_str() == Some(k)) { issues.push(json!({"slice": slice, "id": k, "issue": "record-without-member"})); } }
            let mut seen: Vec<&Value> = Vec::new();
            for k in live { if seen.contains(&k) { continue; } seen.push(k); if !obj(recs).contains_key(k.as_str().unwrap()) { issues.push(json!({"slice": slice, "id": k, "issue": "member-without-record"})); } }
        }
        Value::Array(issues)
    }
    pub fn verify_parked(&self) -> Value {
        let boards = self.boards["ids"].as_array().unwrap(); let mut issues = Vec::new();
        for (k, d) in obj(&self.parked) {
            if !boards.iter().any(|b| b.as_str() == Some(k)) { issues.push(json!({"board": k, "issue": "parked-unknown-board"})); }
            if self.boards["active"].as_str() == Some(k) { issues.push(json!({"board": k, "issue": "active-board-parked"})); }
            issues.extend(verify_parked_doc(k, d));
        }
        Value::Array(issues)
    }
}
