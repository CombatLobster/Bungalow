//! Transport-agnostic command API (v267). One JSON request in, one JSON response out, so the same core can sit
//! behind a Tauri command, a stdio process (tests) or WebAssembly later.
//!
//! Request:  `{"method": "commitTree", "args": [patch, {"replace": true}], "expect": {"ok": true, "error": null}}`
//! Response: `{"ok": true, "error": null, "result": ..., "matchesExpectation": true}`
//! `{"batch": [request, ...]}` returns `{"batch": [response, ...]}`.
//! Method names and argument shapes are the JS store's (`documentStore.*`), including the aliases
//! `commitProps`/`setProp`. `{"$undefined": true}` stands for JavaScript `undefined`.
use crate::{resources::Ledger, store::{is_undefined, DocumentStore}};
use serde_json::{json, Value};

/// The native engine state owned by one document window.
#[derive(Default)]
pub struct Core { pub store: DocumentStore, pub ledger: Ledger, /** v268: raster surfaces (`raster.*` methods) */ pub surfaces: crate::surfaces::Surfaces }

fn s(v: Option<&Value>) -> &str { v.and_then(Value::as_str).unwrap_or("") }
fn opt(v: Option<&Value>) -> Option<&Value> { v.filter(|x| !is_undefined(x)) }
fn ids(v: Option<&Value>) -> Vec<String> { v.and_then(Value::as_array).map(|a| a.iter().filter_map(|x| x.as_str().map(String::from)).collect()).unwrap_or_default() }

impl Core {
    pub fn new() -> Self { Self::default() }
    /// Snapshot with revision and every consistency report.
    pub fn snapshot(&self) -> Value {
        json!({"revision": self.store.revision, "state": self.store.snapshot_document(), "verify": {"tree": self.store.verify(), "collections": self.store.verify_collections(), "props": self.store.verify_props(), "records": self.store.verify_records(), "parked": self.store.verify_parked()}, "ledger": self.ledger.to_json()})
    }
    /// v280: binary results for bulky methods (Tauri returns them as raw bytes, `tauri::ipc::Response`):
    /// - `raster.composite` → [u32 width][u32 height] + straight RGBA (getImageData order), or an error when unsupported;
    /// - `raster.read [id]` → [u32 width][u32 height] + straight RGBA;
    /// - `project.encodeTiles [id]` → see `project::encode_tiles`.
    /// The JSON transport reaches the same results through `{method: "binary", args: [request]}` (base64).
    pub fn handle_binary(&mut self, req: &Value) -> Result<Vec<u8>, String> {
        let method = s(req.get("method")); let empty = vec![]; let a: &Vec<Value> = req.get("args").and_then(Value::as_array).unwrap_or(&empty);
        let image = |w: usize, h: usize, rgba: Vec<u8>| { let mut o = Vec::with_capacity(8 + rgba.len()); o.extend_from_slice(&(w as u32).to_le_bytes()); o.extend_from_slice(&(h as u32).to_le_bytes()); o.extend_from_slice(&rgba); o };
        match method {
            "raster.composite" => { let doc = self.store.snapshot_document(); let (img, _) = crate::compose::composite(&doc, &self.surfaces.all()).map_err(|r| format!("unsupported: {}", r.join("; ")))?; Ok(image(img.width, img.height, crate::project::read_back(&img))) }
            // v301 (parked layers) raster.readTiles [id, ["x:y", ...]] and raster.lod [id, level, ["x:y", ...]]: tiles of a
            // surface as [u32 n] then per tile [u32 x][u32 y][u32 w][u32 h] + straight RGBA. readTiles: 256px document tiles
            // at full resolution (bringing a parked layer back). lod: the display tile at (x, y) covering 256*level
            // document pixels, box-shrunk by `level` (1-16), so a zoomed-out view moves screen-sized data. Empty tiles
            // are left out.
            "raster.readTiles" | "raster.lod" => { let sf = self.surfaces.surface(s(a.first())).ok_or("Unknown raster surface")?;
                let lod = method == "raster.lod"; let lv = if lod { a.get(1).and_then(Value::as_u64).unwrap_or(1).clamp(1, 16) as usize } else { 1 };
                let keys: Vec<(usize, usize)> = a.get(if lod { 2 } else { 1 }).and_then(Value::as_array).map(|v| v.iter().filter_map(|k| { let k = k.as_str()?; let (x, y) = k.split_once(':')?; Some((x.parse().ok()?, y.parse().ok()?)) }).collect()).unwrap_or_default();
                Ok(crate::surfaces::tile_list(sf, &keys, lv)) }
            "raster.read" => { let sfc = self.surfaces.surface(s(a.first())).ok_or("Unknown raster surface")?; Ok(image(sfc.width, sfc.height, crate::project::read_back(sfc))) }
            "project.encodeTiles" => self.surfaces.encode_tiles(s(a.first())), // v293: cached + parallel
            "raster.unstash" => self.surfaces.unstash(s(a.first())), // v295: undo tiles back to the app
            // v297 raster.fillTiles [id, {x, y, tolerance, contiguous, rgb, alpha, erase, alphaLock}]: the whole bucket fill in the
            // core; returns the changed tiles (fill::apply_tiles).
            "raster.fillTiles" => { let o = a.get(1).ok_or("Invalid fill")?; let num = |k: &str| o.get(k).and_then(Value::as_f64).unwrap_or(0.0); let flag = |k: &str| o.get(k).and_then(Value::as_bool).unwrap_or(false);
                let rgb = o.get("rgb").and_then(Value::as_array).ok_or("Invalid colour")?; let ch = |i: usize| rgb.get(i).and_then(Value::as_f64).unwrap_or(0.0);
                let f = crate::fill::Fill { x: num("x") as usize, y: num("y") as usize, tolerance: num("tolerance"), contiguous: flag("contiguous"), rgb: [ch(0), ch(1), ch(2)], alpha: num("alpha"), erase: flag("erase"), alpha_lock: flag("alphaLock") };
                let id = s(a.first()); let sf = self.surfaces.surface_mut_untracked(id).ok_or("Unknown raster surface")?; let out = crate::fill::apply_tiles(sf, &f);
                // v299: only the filled rectangle loses its cached tile PNGs ([rx, ry, rw, rh, count] head)
                let u = |i: usize| out.get(i * 4..i * 4 + 4).map_or(0, |b| u32::from_le_bytes([b[0], b[1], b[2], b[3]]) as i64);
                if u(4) > 0 { self.surfaces.changed(id, crate::raster::Rect { x: u(0), y: u(1), w: u(2), h: u(3) }); } Ok(out) }
            // v297 raster.transform [id, {x, y, w, h} source rectangle, [lx, ly] mip levels, plan]: the app's bicubic commit on
            // the core's copy of the layer → straight RGBA of plan.width x plan.height (see transform.rs).
            "raster.transform" => { let sf = self.surfaces.surface(s(a.first())).ok_or("Unknown raster surface")?; let r = a.get(1).ok_or("Invalid rect")?; let n = |v: &Value, k: &str| v.get(k).and_then(Value::as_f64).unwrap_or(0.0);
                let (rx, ry, rw, rh) = (n(r, "x") as i64, n(r, "y") as i64, n(r, "w").max(0.0) as usize, n(r, "h").max(0.0) as usize); if rw == 0 || rh == 0 { return Err("Empty source".into()); }
                let mut d = vec![0u8; rw * rh * 4]; for row in 0..rh { let sy = ry + row as i64; if sy < 0 || sy as usize >= sf.height { continue; } for col in 0..rw { let sx = rx + col as i64; if sx < 0 || sx as usize >= sf.width { continue; } let si = (sy as usize * sf.width + sx as usize) * 4; let a = sf.data[si + 3]; let o = (row * rw + col) * 4; if a == 0 { continue; } d[o + 3] = a; for k in 0..3 { d[o + k] = crate::modifiers::unpremul(sf.data[si + k], a); } } }
                let mut img = crate::transform::Img { w: rw, h: rh, d }; let lv = a.get(2).and_then(Value::as_array).cloned().unwrap_or_default(); let (lx, ly) = (lv.first().and_then(Value::as_u64).unwrap_or(0) as usize, lv.get(1).and_then(Value::as_u64).unwrap_or(0) as usize);
                for i in 0..lx.max(ly) { img = crate::transform::half(&img, i < lx, i < ly); }
                let p = a.get(3).ok_or("Invalid plan")?; let plan = crate::transform::Plan { a: n(p, "a"), b: n(p, "b"), c: n(p, "c"), d: n(p, "d"), tx: n(p, "tx"), ty: n(p, "ty"), fx: n(p, "fx"), fy: n(p, "fy"), x: n(p, "x"), y: n(p, "y"), width: n(p, "width") as usize, height: n(p, "height") as usize };
                if plan.width == 0 || plan.height == 0 || plan.width * plan.height > 100_000_000 { return Err("Invalid plan size".into()); }
                let res = crate::transform::bicubic(&img, &plan);
                // v301 commit flag (args[4] = true): the result becomes the layer's content in the core too (no flush back
                // from the app) and only painted tiles are returned (see transform::commit)
                if a.get(4).and_then(Value::as_bool).unwrap_or(false) { let id = s(a.first()).to_string(); let sf = self.surfaces.surface_mut(&id).ok_or("Unknown raster surface")?; let tiles = crate::transform::commit(sf, &res, &plan);
                    // v302 keys only (args[5] = true): the app parks the layer, so just the painted tile positions: [u32 n] + n x [u32 x][u32 y]
                    if a.get(5).and_then(Value::as_bool).unwrap_or(false) { return Ok(crate::transform::tile_keys(&tiles)); } return Ok(tiles); }
                Ok(res) }
            m => Err(format!("no binary form for {m}")),
        }
    }
    /// v291: raw framing (Tauri `bungalow_core_raw`). Request: [u32le json length][JSON request][attachments]; values in the
    /// request may reference attachments as {"$bin": [offset, length]} (offsets into the attachment area). A request with
    /// "binary": true answers with the binary result. Response: [u32le json length][JSON response][binary result or nothing].
    pub fn handle_raw(&mut self, body: &[u8]) -> Vec<u8> {
        let frame = |json: Value, bin: Vec<u8>| { let j = json.to_string().into_bytes(); let mut o = Vec::with_capacity(4 + j.len() + bin.len()); o.extend_from_slice(&(j.len() as u32).to_le_bytes()); o.extend_from_slice(&j); o.extend_from_slice(&bin); o };
        if body.len() < 4 { return frame(json!({"ok": false, "error": "Bad raw request"}), vec![]); }
        let n = u32::from_le_bytes([body[0], body[1], body[2], body[3]]) as usize;
        let Some(jb) = body.get(4..4 + n) else { return frame(json!({"ok": false, "error": "Bad raw request"}), vec![]) };
        let req: Value = match serde_json::from_slice(jb) { Ok(v) => v, Err(e) => return frame(json!({"ok": false, "error": format!("Bad request: {e}")}), vec![]) };
        crate::surfaces::ATTACH.with(|a| *a.borrow_mut() = body[4 + n..].to_vec());
        let out = if req.get("binary").and_then(Value::as_bool).unwrap_or(false) {
            match self.handle_binary(&req) { Ok(b) => frame(json!({"ok": true, "error": null, "result": null, "revision": self.store.revision}), b), Err(e) => frame(json!({"ok": false, "error": e, "result": null, "revision": self.store.revision}), vec![]) }
        } else { frame(self.handle(&req), vec![]) };
        crate::surfaces::ATTACH.with(|a| a.borrow_mut().clear());
        out
    }
    pub fn handle(&mut self, req: &Value) -> Value {
        if req.get("method").and_then(Value::as_str) == Some("binary") {
            let inner = req.get("args").and_then(|a| a.get(0)).cloned().unwrap_or(Value::Null);
            return match self.handle_binary(&inner) { Ok(b) => json!({"ok": true, "error": null, "result": {"data": crate::surfaces::b64_encode(&b)}, "revision": self.store.revision}), Err(e) => json!({"ok": false, "error": e, "result": null, "revision": self.store.revision}) };
        }
        if let Some(batch) = req.get("batch").and_then(Value::as_array) { return json!({"batch": batch.iter().map(|r| self.handle(r)).collect::<Vec<_>>()}); }
        let method = s(req.get("method"));
        let empty = vec![]; let a: &Vec<Value> = req.get("args").and_then(Value::as_array).unwrap_or(&empty);
        // v268: raster surface commands return their own result and do not touch the store revision.
        // v270: composite the document from the store + native surfaces. args[0]: {compare?: image, tolerance?}.
        // v285: vector.layer [rasterId, w, h, list]: render a retained vector layer's recorded objects into its surface.
        if method == "vector.layer" {
            let id = s(a.first()).to_string(); let (w, h) = (a.get(1).and_then(Value::as_u64).unwrap_or(0) as usize, a.get(2).and_then(Value::as_u64).unwrap_or(0) as usize);
            let (ok, error) = if w == 0 || h == 0 || w > 32768 || h > 32768 { (false, json!("vector.layer: invalid size")) } else { match crate::vector::render_list(w, h, a.get(3).unwrap_or(&Value::Null)).and_then(|sfc| self.surfaces.insert(&id, sfc)) { Ok(()) => (true, Value::Null), Err(e) => (false, json!(e)) } };
            return json!({"ok": ok, "error": error, "result": Value::Null, "revision": self.store.revision});
        }
        // v277: native project files. inspect [path] → per-layer hashes; load [path, [[doc, layer, rasterId], ...]] → surfaces;
        // write [path, meta, [[doc, layer, rasterId|null], ...]] → {bytes, tiles}. The core reads/writes the file itself.
        if let Some(m) = method.strip_prefix("project.") {
            let path = s(a.first()).to_string();
            let res: Result<Value, String> = (|| match m {
                // v287: loadData [base64 file, entries] = load from bytes the app already has (opening a file in core mode)
                "inspect" | "load" | "loadData" => {
                    let bytes = if m == "loadData" { crate::surfaces::bytes_of(a.first().unwrap_or(&Value::Null))? } else { std::fs::read(&path).map_err(|e| format!("Cannot read {path}: {e}"))? };
                    let c = crate::project::parse(bytes)?;
                    let docs = crate::project::documents(&c.meta);
                    if m == "inspect" {
                        let mut out = Vec::new();
                        for (name, doc) in &docs { let mut ls = Vec::new(); for l in doc["layers"].as_array().map(|a| a.as_slice()).unwrap_or(&[]) { let sfc = crate::project::layer_surface(&c, doc, l)?; let (h, n) = crate::project::hash(&crate::project::read_back(&sfc)); ls.push(json!({"name": l["name"], "hash": h, "painted": n, "tiles": l["tiles"].as_array().map_or(0, |t| t.len())})); }
                            out.push(json!({"name": name, "width": doc["width"], "height": doc["height"], "layers": ls})); }
                        return Ok(json!({"format": c.meta["format"], "documents": out}));
                    }
                    let mut n = 0;
                    for e in a.get(1).and_then(Value::as_array).map(|a| a.as_slice()).unwrap_or(&[]) {
                        let (d, i, id) = (e[0].as_u64().unwrap_or(0) as usize, e[1].as_u64().unwrap_or(0) as usize, e[2].as_str().unwrap_or(""));
                        let (_, doc) = docs.get(d).ok_or("No such document")?; let l = doc["layers"].get(i).ok_or("No such layer")?;
                        let sfc = crate::project::layer_surface(&c, doc, l)?; self.surfaces.insert(id, sfc)?; n += 1;
                        // v293: the file's tile PNGs are the cached encoding of these pixels until they change
                        for r in l.get("tiles").and_then(Value::as_array).map(|a| a.as_slice()).unwrap_or(&[]) { let v: Vec<u64> = r.as_array().map(|a| a.iter().filter_map(Value::as_u64).collect()).unwrap_or_default();
                            if v.len() == 4 { if let Some(b) = c.data.get(v[2] as usize..(v[2] + v[3]) as usize) { self.surfaces.seed_png(id, (v[0] as usize, v[1] as usize), b.to_vec()); } } }
                    }
                    Ok(json!({"loaded": n}))
                }
                "write" => {
                    let meta = a.get(1).cloned().ok_or("project.write: no metadata")?;
                    let docs_n = crate::project::documents(&meta).len(); let counts: Vec<usize> = crate::project::documents(&meta).iter().map(|(_, d)| d["layers"].as_array().map_or(0, |l| l.len())).collect();
                    let mut layers: Vec<Vec<Option<&crate::raster::Surface>>> = counts.iter().map(|&k| vec![None; k]).collect();
                    for e in a.get(2).and_then(Value::as_array).map(|a| a.as_slice()).unwrap_or(&[]) {
                        let (d, i) = (e[0].as_u64().unwrap_or(0) as usize, e[1].as_u64().unwrap_or(0) as usize);
                        if d >= docs_n || i >= layers[d].len() { return Err("project.write: layer out of range".into()); }
                        if let Some(id) = e[2].as_str() { layers[d][i] = Some(self.surfaces.surface(id).ok_or_else(|| format!("project.write: unknown surface {id}"))?); }
                    }
                    let bytes = crate::project::write(meta, &layers)?; let n = bytes.len();
                    std::fs::write(&path, &bytes).map_err(|e| format!("Cannot write {path}: {e}"))?; Ok(json!({"bytes": n}))
                }
                // export [path, {white?}]: composite the active document natively and write a PNG
                "export" => {
                    let o = a.get(1).cloned().unwrap_or(json!({})); let doc = self.store.snapshot_document();
                    let (img, _) = crate::compose::composite(&doc, &self.surfaces.all()).map_err(|r| format!("export: unsupported document: {}", r.join("; ")))?;
                    let png = crate::project::encode_png(img.width, img.height, &crate::project::export_rgba(&img, o.get("white").and_then(Value::as_bool).unwrap_or(false)))?;
                    std::fs::write(&path, &png).map_err(|e| format!("Cannot write {path}: {e}"))?; Ok(json!({"bytes": png.len(), "width": img.width, "height": img.height}))
                }
                _ => Err(format!("unknown method project.{m}")),
            })();
            let (ok, error, result) = match res { Ok(v) => (true, Value::Null, v), Err(e) => (false, json!(e), Value::Null) };
            return json!({"ok": ok, "error": error, "result": result, "revision": self.store.revision});
        }
        if method == "raster.composite" {
            let o = a.first().cloned().unwrap_or(json!({}));
            let doc = self.store.snapshot_document();
            let out = match crate::compose::composite(&doc, &self.surfaces.all()) {
                Err(reasons) => json!({"supported": false, "reasons": reasons}),
                // v273: `approximate` names modelled ops (rotated transforms) so callers can allow edge near misses
                Ok((s, approx)) => match o.get("compare") {
                    Some(img) => match crate::surfaces::image(img) { Ok(js) => { let mut d = crate::surfaces::diff(&s, &js, o.get("tolerance").and_then(Value::as_u64).unwrap_or(3) as i32); d["supported"] = json!(true); d["approximate"] = json!(approx); d } Err(e) => return json!({"ok": false, "error": e, "result": null, "revision": self.store.revision}) },
                    None => json!({"supported": true, "approximate": approx, "image": {"width": s.width, "height": s.height, "data": crate::surfaces::b64_encode(&s.to_straight())}}),
                },
            };
            return json!({"ok": true, "error": null, "result": out, "revision": self.store.revision});
        }
        if let Some(m) = method.strip_prefix("raster.") {
            let (ok, error, result) = match self.surfaces.handle(m, a) { Ok(v) => (true, Value::Null, v), Err(e) => (false, Value::String(e), Value::Null) };
            return json!({"ok": ok, "error": error, "result": result, "revision": self.store.revision});
        }
        let arg = |i: usize| a.get(i).cloned().unwrap_or(Value::Null);
        let st = &mut self.store;
        let mut result = Value::Null;
        let r: Result<(), String> = (|| -> crate::Result<()> {
            match method {
                "commit" => st.commit(&arg(0)),
                "prune" => st.prune(&ids(a.first())),
                "replace" => st.replace(&arg(0)),
                "reset" => { st.reset(); Ok(()) }
                "commitTree" => st.commit_tree(&arg(0), a.get(1).and_then(|o| o.get("replace")).and_then(Value::as_bool).unwrap_or(false)),
                "commitReferences" => st.commit_references(&arg(0)),
                "commitBoards" => st.commit_boards(&arg(0)),
                "commitDocument" => st.commit_document(&arg(0)),
                "commitRecords" => st.commit_records(s(a.first()), &arg(1)),
                "commitProps" => st.commit_records("props", &arg(0)),
                "setRecord" => st.set_record(s(a.first()), s(a.get(1)), s(a.get(2)), opt(a.get(3))),
                "setProp" => st.set_record("props", s(a.first()), s(a.get(1)), opt(a.get(2))),
                "commitCoordinates" => st.commit_coordinates(&arg(0)),
                "park" => st.park(&arg(0), &arg(1)),
                "commitParked" => st.commit_parked(s(a.first()), &arg(1)),
                "unpark" => { st.unpark(s(a.first())); Ok(()) }
                "setParkedRecord" => st.set_parked_record(s(a.first()), s(a.get(1)), s(a.get(2)), s(a.get(3)), opt(a.get(4))),
                "setParkedParent" => st.set_parked_parent(s(a.first()), s(a.get(1)), &arg(2)),
                "commitSession" => st.commit_session(&arg(0)),
                "restoreDocument" => st.restore_document(&arg(0)),
                "snapshot" => Ok(()),
                // resource ledger
                "ledger.register" => self.ledger.register(s(a.first()), &arg(1)),
                "ledger.update" => self.ledger.update(s(a.first()), &arg(1)),
                "ledger.release" => { self.ledger.release(s(a.first()), a.get(1).and_then(|o| o.get("keepSnapshots")).and_then(Value::as_bool).unwrap_or(false)); Ok(()) }
                "ledger.addSnapshot" => self.ledger.add_snapshot(s(a.first()), &arg(1)),
                "ledger.updateSnapshot" => self.ledger.update_snapshot(s(a.first()), &arg(1)),
                "ledger.dropSnapshot" => { self.ledger.drop_snapshot(s(a.first())); Ok(()) }
                m => crate::err(format!("Unknown method {m}")),
            }
        })().map_err(|e| e.0);
        if method == "snapshot" { result = self.snapshot(); }
        let (ok, error) = match &r { Ok(()) => (true, Value::Null), Err(e) => (false, Value::String(e.clone())) };
        let mut resp = json!({"ok": ok, "error": error, "result": result, "revision": self.store.revision});
        if let Some(exp) = req.get("expect") {
            let matches = exp.get("ok").and_then(Value::as_bool) == Some(ok) && (ok || exp.get("error") == Some(&resp["error"]));
            resp["matchesExpectation"] = Value::Bool(matches);
        }
        resp
    }
}
