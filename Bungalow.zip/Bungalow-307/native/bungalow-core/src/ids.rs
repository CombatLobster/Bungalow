//! Identity rules shared by every slice.
/// `node_<32 lowercase hex>`: layer and group IDs.
pub fn valid_node(id: &str) -> bool { hex_id(id, "node_") }
/// `res_<32 lowercase hex>`: pixel resource IDs.
pub fn valid_resource(id: &str) -> bool { hex_id(id, "res_") }
/// `snap_<32 lowercase hex>`: history snapshot IDs.
pub fn valid_snapshot(id: &str) -> bool { hex_id(id, "snap_") }
fn hex_id(id: &str, prefix: &str) -> bool {
    id.len() == prefix.len() + 32 && id.starts_with(prefix) && id[prefix.len()..].bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
}
/// Length in UTF-16 code units, matching JavaScript `String.prototype.length`.
pub fn js_len(s: &str) -> usize { s.encode_utf16().count() }
