//! v274: stroke modifier, a port of `StrokeMod.draw` in app.js (distance-field ring around the layer's alpha).
//! Float32 storage is kept wherever the app uses Float32Array so results match bit for bit.
use crate::raster::{Op, Rect, Surface};
use serde_json::Value;

const BIG: f64 = 1e10;
#[derive(Clone, Debug)]
pub struct StrokeCfg { rgb: [u8; 3], width: f64, position: String, opacity: f64, offset: f64, variation: f64, variation_scale: f64, round: bool, smoothing: f64, antialias: bool }

fn num(c: &Value, k: &str, d: f64, lo: f64, hi: f64) -> f64 { c.get(k).and_then(Value::as_f64).map(|v| v.max(lo).min(hi)).unwrap_or(d) }
/// StrokeMod.normalise
pub fn parse(c: &Value) -> StrokeCfg {
    let rgb = c.get("colour").and_then(Value::as_str).filter(|s| s.len() == 7 && s.starts_with('#') && s[1..].chars().all(|ch| ch.is_ascii_hexdigit()))
        .map(|s| [1, 3, 5].map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap())).unwrap_or([0, 0, 0]);
    let pick = |k: &str, ok: &[&str], d: &str| c.get(k).and_then(Value::as_str).filter(|s| ok.contains(s)).unwrap_or(d).to_string();
    StrokeCfg { rgb, width: (num(c, "width", 4.0, 1.0, 40.0) + 0.5).floor(), position: pick("position", &["outside", "inside", "centre"], "outside"), opacity: num(c, "opacity", 1.0, 0.0, 1.0),
        offset: num(c, "offset", 0.0, -40.0, 40.0), variation: num(c, "variation", 0.0, 0.0, 1.0), variation_scale: num(c, "variationScale", 160.0, 20.0, 600.0),
        round: pick("join", &["round", "square"], "square") == "round", smoothing: num(c, "smoothing", 0.0, 0.0, 6.0), antialias: c.get("antialias").map_or(true, |v| !matches!(v, Value::Bool(false) | Value::Null) && v.as_f64() != Some(0.0) && v.as_str() != Some("")) }
}
fn edt1(f: &[f64], n: usize, out: &mut [f64], v: &mut [i64], z: &mut [f64]) {
    let mut k: usize = 0; v[0] = 0; z[0] = -BIG; z[1] = BIG;
    for q in 1..n { let qf = q as f64;
        let s_of = |k: usize, v: &[i64]| { let vk = v[k] as f64; ((f[q] + qf * qf) - (f[v[k] as usize] + vk * vk)) / (2.0 * qf - 2.0 * vk) };
        let mut s = s_of(k, v); while s <= z[k] { k -= 1; s = s_of(k, v); }
        k += 1; v[k] = q as i64; z[k] = s; z[k + 1] = BIG; }
    k = 0; for q in 0..n { while z[k + 1] < q as f64 { k += 1; } let d = q as f64 - v[k] as f64; out[q] = d * d + f[v[k] as usize]; }
}
fn edt2(f: &[f32], w: usize, h: usize) -> Vec<f32> {
    let n = w.max(h); let (mut d, mut o, mut v, mut z) = (vec![0f64; n], vec![0f64; n], vec![0i64; n], vec![0f64; n + 1]); let mut g = vec![0f32; w * h];
    for x in 0..w { for y in 0..h { d[y] = f[y * w + x] as f64; } edt1(&d, h, &mut o, &mut v, &mut z); for y in 0..h { g[y * w + x] = o[y] as f32; } }
    for y in 0..h { for x in 0..w { d[x] = g[y * w + x] as f64; } edt1(&d, w, &mut o, &mut v, &mut z); for x in 0..w { g[y * w + x] = o[x] as f32; } }
    g
}
fn cheb(f: &[f32], w: usize, h: usize) -> Vec<f32> {
    let mut g = f.to_vec(); let m = |a: f32, b: f32| if b < a { b } else { a };
    for y in 0..h { for x in 0..w { let i = y * w + x; let mut v = g[i]; if x > 0 { v = m(v, g[i - 1] + 1.0); } if y > 0 { v = m(v, g[i - w] + 1.0); if x > 0 { v = m(v, g[i - w - 1] + 1.0); } if x < w - 1 { v = m(v, g[i - w + 1] + 1.0); } } g[i] = v; } }
    for y in (0..h).rev() { for x in (0..w).rev() { let i = y * w + x; let mut v = g[i]; if x < w - 1 { v = m(v, g[i + 1] + 1.0); } if y < h - 1 { v = m(v, g[i + w] + 1.0); if x < w - 1 { v = m(v, g[i + w + 1] + 1.0); } if x > 0 { v = m(v, g[i + w - 1] + 1.0); } } g[i] = v; } }
    g
}
fn dist(mask: &[u8], w: usize, h: usize, round: bool, seed: u8) -> Vec<f32> {
    let f: Vec<f32> = mask.iter().map(|&m| if m == seed { 0.0 } else { BIG as f32 }).collect();
    if round { edt2(&f, w, h).into_iter().map(|v| (v as f64).sqrt() as f32).collect() } else { cheb(&f, w, h) }
}
fn box_pass(a: &[f32], w: usize, h: usize, r: i64) -> Vec<f32> {
    let (mut tmp, mut out) = (vec![0f32; w * h], vec![0f32; w * h]); let inv = 1.0 / (2.0 * r as f64 + 1.0); let cl = |v: i64, hi: usize| v.max(0).min(hi as i64 - 1) as usize;
    for y in 0..h { let row = y * w; let mut s = 0f64; for k in -r..=r { s += a[row + cl(k, w)] as f64; } for x in 0..w { tmp[row + x] = (s * inv) as f32; s += a[row + cl(x as i64 + r + 1, w)] as f64 - a[row + cl(x as i64 - r, w)] as f64; } }
    for x in 0..w { let mut s = 0f64; for k in -r..=r { s += tmp[cl(k, h) * w + x] as f64; } for y in 0..h { out[y * w + x] = (s * inv) as f32; s += tmp[cl(y as i64 + r + 1, h) * w + x] as f64 - tmp[cl(y as i64 - r, h) * w + x] as f64; } }
    out
}
fn hash(a: f64, b: f64) -> f64 { let s = (a * 127.1 + b * 311.7).sin() * 43758.5453; (s - s.floor()) * 2.0 - 1.0 }
fn ramp(t: f64) -> f64 { if t < 0.0 { 0.0 } else if t > 1.0 { 1.0 } else { t } }
fn band(pos: &str, o: f64, w: f64) -> (f64, f64) { match pos { "outside" => (o, o + w), "inside" => (-(o + w), -o), _ => (o - w / 2.0, o + w / 2.0) } }

pub fn draw(src: &Surface, c: &StrokeCfg) -> Surface {
    let (w, h) = (src.width, src.height); let alpha = |i: usize| src.data[i * 4 + 3];
    let (mut x0, mut y0, mut x1, mut y1) = (w as i64, h as i64, -1i64, -1i64);
    for y in 0..h { for x in 0..w { if alpha(y * w + x) != 0 { x0 = x0.min(x as i64); x1 = x1.max(x as i64); y0 = y0.min(y as i64); y1 = y1.max(y as i64); } } }
    if x1 < 0 { return src.clone(); }
    let vr = c.variation; let wmax = c.width * (1.0 + vr); let o = c.offset; let span = (o.abs() + wmax).max(1.0);
    let (lo, hi) = band(&c.position, o, wmax); let (need_out, need_in) = (hi > 0.5, lo < -0.5);
    let sm = (c.smoothing + 0.5).floor() as i64; let margin = span.ceil() as i64 + 2 * sm + 3;
    let (bx0, by0, bx1, by1) = ((x0 - margin).max(0), (y0 - margin).max(0), (x1 + margin).min(w as i64 - 1), (y1 + margin).min(h as i64 - 1));
    let (cw, ch) = ((bx1 - bx0 + 1) as usize, (by1 - by0 + 1) as usize); let n = cw * ch; let (bx0, by0) = (bx0 as usize, by0 as usize);
    let (mut partial, mut inside) = (vec![0u8; n], vec![0u8; n]);
    for j in 0..ch { for i in 0..cw { let v = alpha((by0 + j) * w + bx0 + i); let k = j * cw + i; if v >= 128 { inside[k] = 1; } if v > 0 && v < 255 { partial[k] = 1; } } }
    let d_out = if need_out { Some(dist(&inside, cw, ch, c.round, 1)) } else { None }; let d_in = if need_in { Some(dist(&inside, cw, ch, c.round, 0)) } else { None };
    let sd: Vec<f32> = (0..n).map(|k| if inside[k] == 1 { match &d_in { Some(d) => -(d[k] as f64 - 0.5), None => -0.5 } } else { match &d_out { Some(d) => d[k] as f64 - 0.5, None => 0.5 } } as f32).collect();
    // noise lattice (noiseGrid)
    let lv = c.variation_scale;
    let ng = if vr != 0.0 { let (ix0, iy0) = ((bx0 as f64 / lv).floor() as i64 - 1, (by0 as f64 / lv).floor() as i64 - 1);
        let nx = (((bx0 + cw) as f64) / lv).floor() as i64 - ix0 + 3; let ny = (((by0 + ch) as f64) / lv).floor() as i64 - iy0 + 3;
        let mut g = vec![0f32; (nx * ny) as usize]; for j in 0..ny { for i in 0..nx { g[(j * nx + i) as usize] = hash((ix0 + i) as f64, (iy0 + j) as f64) as f32; } } Some((g, nx, ix0, iy0)) } else { None };
    let reach = o.abs() + wmax + 2.0; let mut cov = vec![0f32; n];
    for j in 0..ch {
        let yy = (by0 + j) as f64; let (mut iy, mut sy) = (0i64, 0f64);
        if let Some((_, _, _, iy0)) = &ng { let gy = yy / lv - *iy0 as f64; iy = gy.floor() as i64; sy = gy - iy as f64; sy = sy * sy * (3.0 - 2.0 * sy); }
        for i in 0..cw { let k = j * cw + i; let s = sd[k] as f64; if s > reach || s < -reach { continue; }
            let mut wk = c.width;
            if let Some((g, nx, ix0, _)) = &ng { let gx = (bx0 + i) as f64 / lv - *ix0 as f64; let ix = gx.floor() as i64; let fx = gx - ix as f64; let sx = fx * fx * (3.0 - 2.0 * fx); let p = (iy * nx + ix) as usize; let nxu = *nx as usize;
                let (n00, n10, n01, n11) = (g[p] as f64, g[p + 1] as f64, g[p + nxu] as f64, g[p + nxu + 1] as f64);
                let f = 1.0 + vr * (n00 + (n10 - n00) * sx + (n01 - n00) * sy + (n00 - n10 - n01 + n11) * sx * sy); wk *= f; }
            let (l, hh) = band(&c.position, o, wk);
            if s < l - 1.0 || s > hh + 1.0 { continue; }
            let v = if partial[k] == 1 && l <= 0.5 && hh >= -0.5 { 1.0 } else if c.antialias { ramp(s - l + 0.5) * ramp(hh - s + 0.5) } else if s >= l && s <= hh { 1.0 } else { 0.0 };
            cov[k] = v as f32; }
    }
    let mut fin = cov.clone();
    if sm > 0 { let cb = if sm < 1 { cov.clone() } else { box_pass(&cov, cw, ch, sm) }; for k in 0..n { let d = (sd[k] as f64).abs(); let wgt = ramp((d - 0.5) / 2.0); fin[k] = (cov[k] as f64 * (1.0 - wgt) + cb[k] as f64 * wgt) as f32; } }
    let keep = match c.position.as_str() { "outside" => Some(-0.5), "inside" => Some(0.5), _ => None };
    let mut ring = vec![0u8; n * 4];
    for k in 0..n { if let Some(kp) = keep { let s = sd[k] as f64; if (c.position == "outside" && s < kp) || (c.position != "outside" && s > kp) { fin[k] = 0.0; } }
        let v = fin[k] as f64; if v <= 0.0 { continue; } let a = (v * c.opacity * 255.0 + 0.5).floor().clamp(0.0, 255.0) as u8;
        ring[k * 4..k * 4 + 4].copy_from_slice(&[((c.rgb[0] as u32 * a as u32 + 127) / 255) as u8, ((c.rgb[1] as u32 * a as u32 + 127) / 255) as u8, ((c.rgb[2] as u32 * a as u32 + 127) / 255) as u8, a]); }
    let ring = Surface { width: cw, height: ch, data: ring }; let full = Rect { x: 0, y: 0, w: w as i64, h: h as i64 };
    let mut out = Surface::new(w, h);
    if c.position == "outside" { out.compose_region(full, &ring, bx0 as i64, by0 as i64, Op::SourceOver, 1.0); out.compose_region(full, src, 0, 0, Op::SourceOver, 1.0); }
    else { out.compose_region(full, src, 0, 0, Op::SourceOver, 1.0); out.compose_region(full, &ring, bx0 as i64, by0 as i64, Op::SourceOver, 1.0); }
    out
}
