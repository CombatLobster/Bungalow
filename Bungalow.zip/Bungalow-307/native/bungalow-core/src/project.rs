//! v277 (stage 7): native reader/writer for the Bungalow binary project container (v2, `.bung`), matching
//! `encodeProject` / `readProject` in app.js:
//!
//!   [12 bytes magic "BUNGALOW\0\2\r\n"][u32le metadata length][metadata JSON][data: concatenated tile PNGs]
//!
//! The metadata is a single document (format "LowLatPaint") or a workspace (format "BungalowWorkspace", boards[i].document).
//! Each layer lists its painted 256×256 tiles as [x, y, offset, length] into the data section; empty tiles are not stored.
//! Reading decodes tiles straight into native surfaces (premultiplied, like the canvas); writing encodes the native
//! surfaces into tiles (identical tiles are stored once) around metadata supplied by the app (layer records with
//! `tiles` filled in here). The core reads and writes the file itself (path), so pixels never cross the IPC channel.
use crate::raster::Surface;
use serde_json::{json, Value};
use std::collections::HashMap;

pub const MAGIC: [u8; 12] = [66, 85, 78, 71, 65, 76, 79, 87, 0, 2, 13, 10];
const TILE: usize = 256;
const FILE_LIMIT: usize = 256 * 1024 * 1024;

pub struct Container { pub meta: Value, pub data: Vec<u8> }
/// Split a file into metadata and data section, with the app's limits.
pub fn parse(bytes: Vec<u8>) -> Result<Container, String> {
    if bytes.len() > FILE_LIMIT { return Err("Project exceeds the 256 MB file limit".into()); }
    if bytes.len() < 16 || bytes[..12] != MAGIC { return Err("Not a Bungalow binary project".into()); }
    let len = u32::from_le_bytes([bytes[12], bytes[13], bytes[14], bytes[15]]) as usize;
    if len < 2 || len > 64 * 1024 * 1024 || 16 + len > bytes.len() { return Err("Damaged project header".into()); }
    let meta: Value = serde_json::from_slice(&bytes[16..16 + len]).map_err(|_| "Project metadata is not valid JSON".to_string())?;
    Ok(Container { meta, data: bytes[16 + len..].to_vec() })
}
/// The documents in a container: (board name, document metadata).
pub fn documents(meta: &Value) -> Vec<(String, &Value)> {
    match meta.get("boards").and_then(Value::as_array) {
        Some(b) => b.iter().map(|x| (x.get("name").and_then(Value::as_str).unwrap_or("").to_string(), &x["document"])).collect(),
        None => vec![(meta.get("artboardName").and_then(Value::as_str).unwrap_or("").to_string(), meta)],
    }
}
pub fn decode_png(bytes: &[u8]) -> Result<(usize, usize, Vec<u8>), String> {
    let mut dec = png::Decoder::new(std::io::Cursor::new(bytes)); dec.set_transformations(png::Transformations::EXPAND | png::Transformations::STRIP_16);
    let mut r = dec.read_info().map_err(|_| "A layer tile could not be decoded".to_string())?;
    let mut buf = vec![0; r.output_buffer_size()]; let info = r.next_frame(&mut buf).map_err(|_| "A layer tile could not be decoded".to_string())?;
    let (w, h) = (info.width as usize, info.height as usize); let px = &buf[..info.buffer_size()];
    let rgba: Vec<u8> = match info.color_type { png::ColorType::Rgba => px.to_vec(), png::ColorType::Rgb => px.chunks_exact(3).flat_map(|c| [c[0], c[1], c[2], 255]).collect(),
        png::ColorType::GrayscaleAlpha => px.chunks_exact(2).flat_map(|c| [c[0], c[0], c[0], c[1]]).collect(), png::ColorType::Grayscale => px.iter().flat_map(|&g| [g, g, g, 255]).collect(), _ => return Err("Unsupported tile colour type".into()) };
    Ok((w, h, rgba))
}
/// Decode one layer's tiles into a document-size surface (premultiplied).
pub fn layer_surface(c: &Container, doc: &Value, layer: &Value) -> Result<Surface, String> { let (w, h, st) = layer_straight(c, doc, layer)?; Ok(Surface::from_straight(w, h, &st)) }
/// Decode one layer's tiles as straight RGBA, exactly as stored (what getImageData reports for the saved layer).
pub fn layer_straight(c: &Container, doc: &Value, layer: &Value) -> Result<(usize, usize, Vec<u8>), String> {
    let (w, h) = (doc["width"].as_u64().unwrap_or(0) as usize, doc["height"].as_u64().unwrap_or(0) as usize);
    if w == 0 || h == 0 || w > 32768 || h > 32768 { return Err("Invalid document size".into()); }
    let mut out = vec![0u8; w * h * 4];
    for r in layer.get("tiles").and_then(Value::as_array).map(|a| a.as_slice()).unwrap_or(&[]) {
        let v: Vec<i64> = r.as_array().map(|a| a.iter().filter_map(Value::as_i64).collect()).unwrap_or_default();
        if v.len() != 4 { return Err("Invalid layer tile reference".into()); }
        let (x, y, o, n) = (v[0], v[1], v[2], v[3]);
        if x < 0 || y < 0 || x as usize >= w || y as usize >= h || x as usize % TILE != 0 || y as usize % TILE != 0 || o < 0 || n < 8 || (o + n) as usize > c.data.len() { return Err("Invalid layer tile reference".into()); }
        let (tw, th, rgba) = decode_png(&c.data[o as usize..(o + n) as usize])?;
        if tw != TILE.min(w - x as usize) || th != TILE.min(h - y as usize) { return Err("Invalid layer tile dimensions".into()); }
        for row in 0..th { let di = ((y as usize + row) * w + x as usize) * 4; out[di..di + tw * 4].copy_from_slice(&rgba[row * tw * 4..(row + 1) * tw * 4]); }
    }
    Ok((w, h, out))
}
/// The surface as getImageData would report it (Skia unpremultiply), for comparing with the app.
pub fn read_back(s: &Surface) -> Vec<u8> { let mut o = s.data.clone(); for p in o.chunks_exact_mut(4) { let a = p[3]; if a == 255 { continue; } if a == 0 { p[0] = 0; p[1] = 0; p[2] = 0; continue; } for k in 0..3 { p[k] = crate::modifiers::unpremul(p[k], a); } } o } // v289: opaque/transparent fast paths
/// FNV-1a over straight RGBA (getImageData semantics) for cross-checking with the app.
pub fn hash(st: &[u8]) -> (u32, usize) { let mut hsh: u32 = 2166136261; let mut painted = 0; for (i, b) in st.iter().enumerate() { hsh = (hsh ^ *b as u32).wrapping_mul(16777619); if i % 4 == 3 && *b != 0 { painted += 1; } } (hsh, painted) }

pub fn encode_png(w: usize, h: usize, rgba: &[u8]) -> Result<Vec<u8>, String> {
    let mut out = Vec::new(); { let mut e = png::Encoder::new(&mut out, w as u32, h as u32); e.set_color(png::ColorType::Rgba); e.set_depth(png::BitDepth::Eight); e.set_compression(png::Compression::Fast); /* v293: fdeflate: ~30x faster than Default for ~1.4x the bytes (still smaller than the browser encoder) */ e.set_adaptive_filter(png::AdaptiveFilterType::Adaptive);
        let mut wr = e.write_header().map_err(|e| e.to_string())?; wr.write_image_data(rgba).map_err(|e| e.to_string())?; } Ok(out)
}
/// Write a container: `meta` is the app's metadata (single document or workspace) with layer records in order;
/// `layers[doc][i]` the surface for layer i of document doc (None = empty). Fills each record's `tiles`.
pub fn write(mut meta: Value, layers: &[Vec<Option<&Surface>>]) -> Result<Vec<u8>, String> {
    let mut data: Vec<u8> = Vec::new(); let mut seen: HashMap<Vec<u8>, (usize, usize)> = HashMap::new();
    let docs: Vec<&mut Value> = match meta.get_mut("boards") { Some(Value::Array(b)) => b.iter_mut().map(|x| &mut x["document"]).collect(), _ => vec![&mut meta] };
    let mut docs = docs;
    if docs.len() != layers.len() { return Err("Layer surfaces do not match the documents".into()); }
    for (d, doc) in docs.iter_mut().enumerate() {
        let (w, h) = (doc["width"].as_u64().unwrap_or(0) as usize, doc["height"].as_u64().unwrap_or(0) as usize);
        let recs = doc.get_mut("layers").and_then(Value::as_array_mut).ok_or("Document without layers")?;
        if recs.len() != layers[d].len() { return Err("Layer surfaces do not match the layer records".into()); }
        for (i, rec) in recs.iter_mut().enumerate() {
            let mut refs = Vec::new();
            if let Some(s) = layers[d][i] {
                if s.width != w || s.height != h { return Err(format!("Layer {i} surface is {}x{}, document {w}x{h}", s.width, s.height)); }
                let st = s.to_straight();
                for ty in (0..h).step_by(TILE) { for tx in (0..w).step_by(TILE) {
                    let (tw, th) = (TILE.min(w - tx), TILE.min(h - ty)); let mut t = vec![0u8; tw * th * 4];
                    for row in 0..th { let si = ((ty + row) * w + tx) * 4; t[row * tw * 4..(row + 1) * tw * 4].copy_from_slice(&st[si..si + tw * 4]); }
                    if !t.chunks_exact(4).any(|p| p[3] != 0) { continue; }
                    let mut key = t.clone(); key.extend_from_slice(&[(tw >> 8) as u8, tw as u8, (th >> 8) as u8, th as u8]);
                    let (o, n) = match seen.get(&key) { Some(&v) => v, None => { let png = encode_png(tw, th, &t)?; let v = (data.len(), png.len()); data.extend_from_slice(&png); seen.insert(key, v); v } };
                    refs.push(json!([tx, ty, o, n]));
                } }
            }
            rec["tiles"] = Value::Array(refs); rec["png"] = Value::Null;
        }
        doc["tileSize"] = json!(TILE);
    }
    let js = serde_json::to_vec(&meta).map_err(|e| e.to_string())?; if js.len() > 64 * 1024 * 1024 { return Err("Source metadata exceeds the 64 MB limit".into()); }
    let mut out = Vec::with_capacity(16 + js.len() + data.len()); out.extend_from_slice(&MAGIC); out.extend_from_slice(&(js.len() as u32).to_le_bytes()); out.extend_from_slice(&js); out.extend_from_slice(&data);
    if out.len() > FILE_LIMIT { return Err("Project exceeds the 256 MB file limit".into()); }
    Ok(out)
}

/// v277: flatten for export: composite straight RGBA (getImageData semantics), optionally over white.
pub fn export_rgba(s: &Surface, white: bool) -> Vec<u8> {
    if !white { return read_back(s); }
    let mut o = vec![0u8; s.data.len()];
    for (d, p) in o.chunks_exact_mut(4).zip(s.data.chunks_exact(4)) { let ia = 255 - p[3] as u32; for k in 0..3 { d[k] = (p[k] as u32 + (255 * ia + 127) / 255).min(255) as u8; } d[3] = 255; }
    o
}

/// v280: one surface's painted 256×256 tiles as PNGs (for the app's own container writer):
/// [u32 count] then per tile [u32 x][u32 y][u32 length][PNG bytes], little-endian.
pub fn encode_tiles(s: &Surface) -> Result<Vec<u8>, String> {
    let (w, h) = (s.width, s.height); let st = read_back(s); let mut out = vec![0u8; 4]; let mut n = 0u32;
    for ty in (0..h).step_by(TILE) { for tx in (0..w).step_by(TILE) {
        let (tw, th) = (TILE.min(w - tx), TILE.min(h - ty)); let mut t = vec![0u8; tw * th * 4];
        for row in 0..th { let si = ((ty + row) * w + tx) * 4; t[row * tw * 4..(row + 1) * tw * 4].copy_from_slice(&st[si..si + tw * 4]); }
        if !t.chunks_exact(4).any(|p| p[3] != 0) { continue; }
        let png = encode_png(tw, th, &t)?; for v in [tx as u32, ty as u32, png.len() as u32] { out.extend_from_slice(&v.to_le_bytes()); } out.extend_from_slice(&png); n += 1;
    } }
    out[..4].copy_from_slice(&n.to_le_bytes()); Ok(out)
}
