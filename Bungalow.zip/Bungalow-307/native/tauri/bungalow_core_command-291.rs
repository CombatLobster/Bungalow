//! v291: Tauri glue for the native core (copy into src-tauri/src as bungalow_core_command.rs).
//! All commands are `async`: Tauri runs them on its worker threads, so core work (compositing, encoding, decoding) never
//! blocks the window. (Before v291 they were plain functions, which Tauri runs on the main thread.)
//! - `bungalow_core` (JSON): `invoke('bungalow_core', { request })`.
//! - `bungalow_core_bin` (raw response): `invoke('bungalow_core_bin', { request })` → ArrayBuffer.
//! - `bungalow_core_raw` (v291, raw request and response): `invoke('bungalow_core_raw', bytes)` with a Uint8Array body
//!   [u32 JSON length][JSON request][attachments] → ArrayBuffer [u32 JSON length][JSON response][binary result].
//!   Pixels and files travel as bytes both ways; see `Core::handle_raw`.
use bungalow_core::dispatch::Core;
use serde_json::Value;
use std::sync::Mutex;

/// One core per window/document. Held in Tauri managed state.
#[derive(Default)]
pub struct CoreState(pub Mutex<Core>);

#[tauri::command]
pub async fn bungalow_core(state: tauri::State<'_, CoreState>, request: Value) -> Result<Value, String> {
    let mut core = state.0.lock().map_err(|_| "Native core unavailable".to_string())?;
    Ok(core.handle(&request))
}

#[tauri::command]
pub async fn bungalow_core_bin(state: tauri::State<'_, CoreState>, request: Value) -> Result<tauri::ipc::Response, String> {
    let mut core = state.0.lock().map_err(|_| "Native core unavailable".to_string())?;
    core.handle_binary(&request).map(tauri::ipc::Response::new)
}

#[tauri::command]
pub async fn bungalow_core_raw(state: tauri::State<'_, CoreState>, request: tauri::ipc::Request<'_>) -> Result<tauri::ipc::Response, String> {
    let tauri::ipc::InvokeBody::Raw(body) = request.body() else { return Err("bungalow_core_raw expects a binary body".into()) };
    let mut core = state.0.lock().map_err(|_| "Native core unavailable".to_string())?;
    Ok(tauri::ipc::Response::new(core.handle_raw(body)))
}

// In lib.rs:
// tauri::Builder::default()
//     .manage(CoreState::default())
//     .invoke_handler(tauri::generate_handler![bungalow_core, bungalow_core_bin, bungalow_core_raw /*, your other commands */])
//     ...
