# Plan: inactive layers live only in the core (v300)

Status: stages 0–2 built in v301 (src/layer-parking-301.js). Decisions: parked tiles are fetched from the core as needed; parking starts above a limit (default 1 GiB) and proceeds one layer per idle tick. Stages 3–4 remain. Builds on v291–v300 (lazy core mode).

## Goal

Today every layer's pixels are held twice: as browser tiles and in the Rust core. At 5000×3000, that is about
60 MB per layer on each side, so a 12-layer document uses about 1.4 GB.

The target:

- **Active layer:** browser tiles (painting needs them now) and the core copy (via the lazy flush, as today).
- **Inactive layers:** core only. The browser keeps the GPU textures it is currently displaying, nothing else.
- **RAM:** roughly core copy + active layer + GPU caches. For the example above, about 0.8 GB instead of 1.4 GB, and the
  saving grows with every layer added.
- **No visible change:** painting latency, panning and zooming stay as they are. Selecting a layer and starting to paint
  should feel instant.

## How it works

A layer is **parked** once it has been inactive for a while and the core is known to hold all of it (nothing
pending, hashes verified). Parking replaces its browser tiles with stubs (`{remote, hash}`) and frees the memory. The
core is now the only full copy.

A parked layer is **fetched** back (its tiles return as raw RGBA over the raw transport) when:

- it becomes active: visible tiles first, the rest in the background; strokes wait at most for the tiles they touch;
- a command needs its pixels (see stage 3).

The GPU display does not need the CPU tiles while its source textures are cached. When it needs a parked tile it
does not have, it asks the core for that tile at the current level of detail (`raster.tilesAt`, box-shrunk in the
core, so zoomed-out views move small data). The renderer already handles pending tiles: it shows the previous level
or the overview, then refines.

History already works this way for old steps (v295 stash/unstash); this extends the same mechanism to layers.

## The hard part

About 470 places in the JS read layer pixels directly (`L._canvas`, `L.ctx`, sparse tiles, `getImageData`,
`peekLayerCanvas`). Webview-to-core calls are asynchronous, so these synchronous reads cannot simply "fetch on demand".

The approach is to **gate commands, not readers**. Every user command that touches non-active layers (merge, flatten,
export, filters, transform of several layers, selection from layer alpha, duplicate, eyedropper "all layers", etc.)
first awaits `ensureLocal(layers)`. Only then does the existing synchronous code run.

A **tripwire** catches what the gates miss. In tests and in a debug build, touching the tiles of a parked layer
throws with the call site. In a release build it logs and falls back to a blocking fetch path so nothing is lost.

## Stages

| Stage | Work | Test checkpoint |
|---|---|---|
| 0. Audit + tripwire | Stub type for parked tiles; tripwire on every tile accessor; list command entry points that read other layers; parking off by default | Full suite passes with "park everything immediately" forced on in tests: this produces the to-do list |
| 1. Park / fetch | Parking policy (inactive ≥ N s, nothing pending, hash verified); `ensureLocal(layer, rect?)`; fetch on select (visible first); fetch before history steps that touch a parked layer | **You test:** RAM usage on a big document, switching layers, undo across layers |
| 2. Display from the core | `raster.tilesAt(id, level, keys)` in Rust (rayon, box-shrunk); async source provider in the tiled compositor; GPU cache budget per layer | **You test:** pan/zoom on a big document with most layers parked; no flicker or holes |
| 3. Gate commands | `ensureLocal` before every command found in stage 0; move cheap ones into the core instead where it already has the code (merge, flatten, fill, transform, export composite) | Tripwire silent across the suite and a manual session |
| 4. Policy + polish | Memory budget instead of a fixed delay (park least-recently-used layers when over budget); stats in `captureRenderDebug`; Settings tooltip/option | **You test:** long session, autosave, artboards |

Rough size: 7–9 versions. Stage 1 alone already halves RAM for documents you don't zoom around in much. Stage 2 is
what makes it complete.

## Risks

- **Missed reader → wrong or blank pixels.** Mitigated by the tripwire, plus the release fallback (blocking fetch).
  Stage 0 forces parking on in tests to flush these out early.
- **Core becomes the only copy.** If the webview reloads or the core errors, parked pixels exist only in the core.
  Autosave already goes through the core; an error in the core channel must un-park everything it still can and
  stop parking (fail safe to today's behaviour).
- **Select-to-paint latency.** A full 5000×3000 layer is about 60 MB raw. Fetching visible tiles first keeps the first
  dab quick; target: under 150 ms to the first paintable tile.
- **Web (non-Tauri) build.** There is no core, so parking stays off and nothing changes.
- **Sync bugs, same class as v296/v299.** Fewer moving parts afterwards: inactive layers stop syncing at all.

## What it replaces / simplifies

- Lazy flush of inactive layers (they no longer change in the browser).
- The double PNG/hash caches for those layers.
- Later: the same command boundary is where a wgpu canvas would plug in. The core would then also feed the GPU for the
  active layer, and the browser copy goes completely.

## Decisions needed

1. **GPU textures for parked layers:** fetch from the core on demand at the current level (recommended: bounded
   memory) or keep them resident (simpler, but VRAM grows with the document; on integrated GPUs that is RAM anyway).
2. **When to park:** always after a short idle (simplest to reason about, most savings) or only over a memory budget
   (recommended: no behaviour change for small documents).
3. **Order:** stages 0–1 first, then test (recommended), or 0–2 together.
