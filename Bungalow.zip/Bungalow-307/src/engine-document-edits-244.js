/* DOM-free document geometry and selection decisions. */
const BungalowDocumentEdits=(()=>{
 function positions(records){if(!Array.isArray(records))throw Error('Invalid positions');const ids=new Set();return records.map(r=>{if(!r||typeof r.id!=='string'||!r.id||ids.has(r.id)||!Number.isFinite(r.x)||!Number.isFinite(r.y)||Math.abs(r.x)>=1e7||Math.abs(r.y)>=1e7)throw Error('Invalid position');ids.add(r.id);return {id:r.id,x:r.x,y:r.y}})}
 function move(before,after){const a=positions(before),b=positions(after);if(a.length!==b.length||a.some((r,i)=>r.id!==b[i].id))throw Error('Position membership mismatch');return {type:'positions',before:a,after:b,changed:a.some((r,i)=>r.x!==b[i].x||r.y!==b[i].y)}}
 function bounds(rects){if(!rects.length)return null;const x=Math.min(...rects.map(r=>r.x)),y=Math.min(...rects.map(r=>r.y));return {x,y,width:Math.max(...rects.map(r=>r.x+r.width))-x,height:Math.max(...rects.map(r=>r.y+r.height))-y}}
 function coordinate(rects,axis,value){if(!['x','y'].includes(axis)||!Number.isFinite(value)||Math.abs(value)>=1e7)throw Error('Invalid coordinate');const B=bounds(rects);if(!B)return move([],[]);const delta=Math.round(value)-B[axis];return move(rects,rects.map(r=>({...r,[axis]:r[axis]+delta})))}
 function select(state,request){if(!state||!Array.isArray(state.selected)||!Array.isArray(request.visible)||typeof request.id!=='string')throw Error('Invalid selection');const selected=new Set(state.selected);let anchor=state.anchor;
 if(request.range&&anchor){const a=request.visible.indexOf(anchor),b=request.visible.indexOf(request.id);if(a>=0&&b>=0){if(!request.toggle)selected.clear();for(const id of request.visible.slice(Math.min(a,b),Math.max(a,b)+1))selected.add(id)}else selected.add(request.id)}
 else if(request.toggle){selected.has(request.id)?selected.delete(request.id):selected.add(request.id);anchor=request.id}
 else{selected.clear();selected.add(request.id);anchor=request.id}return {selected:[...selected],anchor};
 }
 return Object.freeze({positions,move,bounds,coordinate,select});
})();if(typeof module!=='undefined')module.exports=BungalowDocumentEdits;
