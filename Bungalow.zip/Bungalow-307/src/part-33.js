
/* ====== Build 176: a tidier layer right-click menu: four short sections, rarely used ones collapsed ====== */
const LAYER_MENU_PLAN=[
 ['create','Create',['layerNewAbove','layerNewBelow','layerDuplicate','layerNewGroup','layerModifiers','layerRelinkAll'],true],
 ['edit','Edit',['layerCopy','layerCut','layerPaste','layerMergeDown','layerBatchRename'],true],
 ['convert','Convert & link',['layerClone','layerFile','layerConvertFile','layerPreventTrim','layerConvertReference','layerMask','layerReference','layerInheritAlpha'],false]
];
const layerMenuState={open:{},heads:new Map(),items:new Map()};
function layerMenuSetup(){
 const m=$('layerMenu');if(!m||m.dataset.sections)return;m.dataset.sections='1';
 try{Object.assign(layerMenuState.open,Object.fromEntries(LAYER_MENU_PLAN.map(p=>[p[0],p[3]])),JSON.parse(localStorage.getItem('llLayerMenuOpen')||'{}'))}catch(_){Object.assign(layerMenuState.open,Object.fromEntries(LAYER_MENU_PLAN.map(p=>[p[0],p[3]])))}
 const anchor=$('layerInstRule');
 // the old flat headings and separators go; the Linked layer and Remove parts keep theirs
 for(const el of [...m.children]){if(el.classList.contains('panel-menu-heading')&&['Create','Edit','Layer type','Filters & transforms'].includes(el.textContent.trim()))el.remove();else if(el.tagName==='HR'&&el.id!=='layerInstRule')el.remove()}
 for(const [key,title,ids] of LAYER_MENU_PLAN){
  const head=document.createElement('div');head.className='panel-menu-heading mm-head';head.setAttribute('role','button');head.tabIndex=0;head.dataset.sec=key;
  const label=document.createElement('span');label.textContent=title;const count=document.createElement('small');head.append(label,count);
  const toggle=()=>{layerMenuState.open[key]=!layerMenuState.open[key];try{localStorage.setItem('llLayerMenuOpen',JSON.stringify(layerMenuState.open))}catch(_){}layerMenuSync(layerMenuTarget,true)};
  head.addEventListener('click',toggle);head.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle()}});
  anchor.before(head);layerMenuState.heads.set(key,{head,count});
  const items=ids.map($).filter(Boolean);layerMenuState.items.set(key,items);for(const b of items){b.dataset.sec=key;anchor.before(b)}
 }
}
const menuItemShown=b=>!b.hidden&&b.style.display!=='none';
function layerMenuSync(L,keepPosition=false){
 layerMenuSetup();const open={...layerMenuState.open};if(L?.mask)open.mods=true;
 for(const [key,{head,count}] of layerMenuState.heads){
  const items=layerMenuState.items.get(key),shown=items.filter(menuItemShown);
  head.classList.toggle('mm-empty',!shown.length);head.setAttribute('aria-expanded',String(!!open[key]));
  count.textContent=!open[key]&&shown.length?' · '+shown.length:'';
  for(const b of items)b.classList.toggle('mm-hide',!open[key]);
 }
 const m=$('layerMenu');if(keepPosition&&m.style.display==='block'){const r=m.getBoundingClientRect();m.style.top=Math.min(parseFloat(m.style.top)||0,Math.max(8,(innerHeight-r.height-8)/uiScaleFactor))+'px'}
}
{const base=openLayerMenu;openLayerMenu=function(L,x,y){const r=base.apply(this,arguments);const m=$('layerMenu');if(m.style.display==='block'){layerMenuSync(L);m.style.left=clamp(x,8,innerWidth-m.getBoundingClientRect().width-8)/uiScaleFactor+'px';m.style.top=clamp(y,8,innerHeight-m.getBoundingClientRect().height-8)/uiScaleFactor+'px'}return r}}
layerMenuSetup();
// icons for the two items added in the last build, in the same style as their neighbours
for(const [id,key] of [['layerBatchRename','rename'],['layerConvertFile','external'],['groupConvertFile','external']]){const b=$(id),d=BungalowIcons.paths[key]||PIE_ICON_NEW[key];if(b&&d){BungalowIcons.paths[key]=d;b.classList.add('has-menu-icon');b.dataset.icon=key;b.style.setProperty('--menu-icon',BungalowIcons.url(key))}}
