
/* ====== Build 181: artboards never overlap · delete works on artboards · rename on the canvas · all units in resize · tool-appropriate cursors ====== */
// ---------- no overlap ----------
const rectsTouch=(a,b)=>a.x<b.x+b.width&&a.x+a.width>b.x&&a.y<b.y+b.height&&a.y+a.height>b.y;
function otherBoardRects(excludeIds){const ids=new Set(excludeIds);return artboards.filter(b=>b.visible!==false&&!ids.has(b.id)).map(artboardRect)}
function overlapsOthers(rects){
 const others=otherBoardRects(rects.map(r=>r.id));
 for(let i=0;i<rects.length;i++){for(const o of others)if(rectsTouch(rects[i],o))return true;for(let j=i+1;j<rects.length;j++)if(rectsTouch(rects[i],rects[j]))return true}
 return false;
}
// dragging boards: slide along the free axis, otherwise stay at the last free position
{const base=moveArtboardDrag;wrap.removeEventListener('pointermove',base,true);moveArtboardDrag=function(e){
  const d=artboardDrag;if(!d||e.pointerId!==d.pointer)return base.apply(this,arguments);
  const prev=d.preview.map(r=>({...r}));base.apply(this,arguments);if(!d.moved||!overlapsOthers(d.preview))return;
  const next=d.preview,a=next.map((r,i)=>d.corner<0?{...r,y:prev[i].y}:{...r,y:prev[i].y,height:prev[i].height}),b2=next.map((r,i)=>d.corner<0?{...r,x:prev[i].x}:{...r,x:prev[i].x,width:prev[i].width});
  const pick=[a,b2,prev].find(c=>!overlapsOthers(c))||prev;
  d.preview=pick;
  if(d.corner<0){for(const r of pick){const bd=artboards.find(b=>b.id===r.id);if(bd){bd.x=r.x;bd.y=r.y}}setArtboardWorldView(d.world)}else updateArtboardWorkspace();
  drawArtboardHandles();
 };wrap.addEventListener('pointermove',moveArtboardDrag,true)}   /* the listener held the original function, so it is replaced too */
{const base=setArtboardCoordinate;setArtboardCoordinate=function(axis,value){
  if(Number.isFinite(value)&&artboardReady()){const before=selectedBoardList().filter(b=>!b.locked).map(artboardRect),B=artboardSelectionBounds(before);
   if(B){const delta=Math.round(value)-B[axis],after=before.map(r=>({...r,[axis]:r[axis]+delta}));if(delta&&overlapsOthers(after)){toast('Artboards cannot overlap');syncArtboardToolCoordinates();return}}}
  return base.apply(this,arguments);
 }}
{const base=resizeArtboardRecords;resizeArtboardRecords=function(records,scale,anchor){if(overlapsOthers(records.filter(r=>!artboards.find(b=>b.id===r.id)?.locked))){toast('Resizing would make artboards overlap');return false}return base.apply(this,arguments)}}
{const base=moveBoards;moveBoards=function(records,label){if(overlapsOthers(records)){toast('That would make artboards overlap');return false}return base.apply(this,arguments)}}
// ---------- drawing: only in free space ----------
function clipDrawRect(a,p){
 const others=otherBoardRects([]);let x=p.x,y=p.y;
 for(let n=0;n<8;n++){
  const r={x:Math.min(a.x,x),y:Math.min(a.y,y),width:Math.abs(x-a.x),height:Math.abs(y-a.y)},hit=others.find(o=>rectsTouch(r,o));if(!hit)break;
  const nx=x>=a.x?Math.min(x,hit.x):Math.max(x,hit.x+hit.width),ny=y>=a.y?Math.min(y,hit.y):Math.max(y,hit.y+hit.height);
  const areaX=Math.abs(nx-a.x)*Math.abs(y-a.y),areaY=Math.abs(x-a.x)*Math.abs(ny-a.y);
  if(areaX>=areaY)x=nx;else y=ny;
 }
 return {x,y};
}
const insideAnyBoard=p=>otherBoardRects([]).some(o=>p.x>o.x&&p.x<o.x+o.width&&p.y>o.y&&p.y<o.y+o.height);
function boardLabelAt(e){return [...wrap.querySelectorAll('.artboard-label')].find(el=>{const r=el.getBoundingClientRect();return e.clientX>=r.left&&e.clientX<=r.right&&e.clientY>=r.top&&e.clientY<=r.bottom})}
function startArtboardDraw(e){
 e.preventDefault();e.stopImmediatePropagation();if(!artboardReady())return;
 const label=boardLabelAt(e);if(label){const board=artboards.find(b=>b.id===label.dataset.board);if(board)selectArtboard(board.id,e);return}
 if(artboards.length>=64){toast('A project supports up to 64 artboards');return}
 const sn=prepareArtboardSnap([]),tol=8/Math.max(z,.001),xs=[],ys=[];
 for(const r of sn.others){xs.push(r.x,r.x+r.width/2,r.x+r.width);ys.push(r.y,r.y+r.height/2,r.y+r.height)}
 const snap=(p,ev)=>{if(ev.altKey||!sn.enabled)return {x:Math.round(p.x),y:Math.round(p.y)};const near=(v,list)=>{let best=null,d=tol;for(const c of list){const k=Math.abs(c-v);if(k<d){d=k;best=c}}return best};
  let x=near(p.x,xs),y=near(p.y,ys);if(x==null&&sn.increment>0){const g=Math.round(p.x/sn.increment)*sn.increment;if(Math.abs(g-p.x)<tol)x=g}if(y==null&&sn.increment>0){const g=Math.round(p.y/sn.increment)*sn.increment;if(Math.abs(g-p.y)<tol)y=g}
  return {x:Math.round(x??p.x),y:Math.round(y??p.y)}};
 const a=snap(artboardWorldPoint(e),e);
 if(insideAnyBoard(a)){toast('Artboards cannot overlap: draw in empty space');return}
 let rect=null,moved=false;
 const shape=(p,ev)=>{let w=p.x-a.x,h=p.y-a.y;if(ev.shiftKey){const k=Math.max(Math.abs(w),Math.abs(h));w=Math.sign(w||1)*k;h=Math.sign(h||1)*k}w=Math.max(-8192,Math.min(8192,w));h=Math.max(-8192,Math.min(8192,h));const q=clipDrawRect(a,{x:a.x+w,y:a.y+h});return {x:Math.min(a.x,q.x),y:Math.min(a.y,q.y),width:Math.abs(q.x-a.x),height:Math.abs(q.y-a.y)}};
 abCursorLock='crosshair';
 trackPointer(e,ev=>{const p=snap(artboardWorldPoint(ev),ev);if(!moved&&Math.hypot(p.x-a.x,p.y-a.y)*z<3)return;moved=true;rect=shape(p,ev);showRubber(rect,rect.width+' × '+rect.height,true)},(ev,cancel)=>{
  abCursorLock=null;if(cancel||!rect)return;if(rect.width<16||rect.height<16){toast('Drag a larger area to draw an artboard');return}
  if(overlapsOthers([{id:'new',...rect}])){toast('Artboards cannot overlap');return}
  // placed and framed exactly where it was drawn: the view stays put (no fit, no jump)
  groupedHistory(()=>{createArtboard({width:rect.width,height:rect.height,white:true,x:rect.x,y:rect.y,fit:false})});
  commitBoards({selected:[...([activeArtboardId])]});renderArtboards();drawArtboardHandles();
 });
}
// ---------- deleting artboards (Delete / Delete layer while the artboard tool is active) ----------
async function boardIsEmpty(board){
 stashActiveArtboard();
 for(const L of board.state.layers){
  if(L.instance||L.mask)return false;
  if(L._sparse){for(const tile of L._sparse.tiles.values())if(!sparseTileEmpty(tile))return false;continue}
  const cv=L._canvas||L.cv;if(!cv)continue;const g=cv.getContext('2d'),w=cv.width,h=cv.height;let first=null;
  for(let y=0;y<h;y+=256){const rows=Math.min(256,h-y),d=new Uint32Array(g.getImageData(0,y,w,rows).data.buffer);if(first===null)first=d[0];for(let i=0;i<d.length;i++)if(d[i]!==first)return false}
  /* a layer of one flat colour (white background, transparent) holds no artwork */
 }
 return true;
}
async function deleteSelectedArtboards({prompt=true}={}){
 if(!artboardReady())return;stashActiveArtboard();
 let boards=selectedBoardList();if(!boards.length)boards=artboards.filter(b=>b.id===activeArtboardId);
 const locked=boards.filter(b=>b.locked);boards=boards.filter(b=>!b.locked);
 if(!boards.length){toast('Unlock the artboard first');return}
 if(boards.length>=artboards.length){toast('A document needs at least one artboard');return}
 const filled=[];for(const b of boards)if(!await boardIsEmpty(b))filled.push(b);
 if(prompt&&filled.length){
  const names=filled.slice(0,3).map(b=>'“'+b.name+'”').join(', ')+(filled.length>3?' and '+(filled.length-3)+' more':'');
  if(!await showConfirm('Delete '+(boards.length===1?'artboard '+names:boards.length+' artboards')+'?'+(boards.length===1?'':'\n\n'+names+(filled.length===1?' contains':' contain')+' artwork.')+'\n\nUndo brings them back.'))return;
 }
 if(!artboardReady())return;
 deleteBoardResources(boards);
 uiNotice((boards.length===1?'Deleted “'+boards[0].name+'”':'Deleted '+boards.length+' artboards')+(locked.length?' · '+locked.length+' locked kept':''));
}
deleteArtboard=function(){deleteSelectedArtboards()};
$('artboardDelete').onclick=()=>deleteSelectedArtboards();$('artboardDelete').title='Delete the selected artboards; undo restores them';
// ---------- double-click a board name on the canvas to rename it ----------
function renameBoardLabel(board,label){
 if(board.locked){toast('Unlock the artboard first');return}
 if($('artboardLabelInput'))return;
 const r=label.getBoundingClientRect(),w=wrap.getBoundingClientRect(),input=document.createElement('input');
 input.id='artboardLabelInput';input.type='text';input.value=board.name;input.maxLength=120;input.setAttribute('aria-label','Artboard name');
 Object.assign(input.style,{position:'absolute',left:(r.left-w.left)+'px',top:(r.top-w.top)+'px',minWidth:Math.max(120,r.width)+'px',height:r.height+'px',zIndex:30});
 wrap.append(input);input.focus();input.select();let done=false;
 const finish=commit=>{if(done)return;done=true;const v=input.value;input.remove();if(commit)renameArtboard(v,board.id)};
 input.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Enter'){e.preventDefault();finish(true)}else if(e.key==='Escape'){e.preventDefault();finish(false)}});
 input.addEventListener('blur',()=>finish(true));input.addEventListener('pointerdown',e=>e.stopPropagation());
}
wrap.addEventListener('dblclick',e=>{const label=boardLabelAt(e);if(!label)return;const board=artboards.find(b=>b.id===label.dataset.board);if(!board)return;e.preventDefault();e.stopPropagation();renameBoardLabel(board,label)},true);
// ---------- resize dialog: every unit ----------
{const sel=$('artboardResizeUnit');sel.replaceChildren(...[['pixels','Pixels'],['points','Points'],['picas','Picas'],['millimetres','Millimetres'],['centimetres','Centimetres'],['inches','Inches'],['percent','Percentage']].map(([v,t])=>new Option(t,v)))}
const AB_UNITS={pixels:[dpi=>1,0],points:[dpi=>dpi/72,2],picas:[dpi=>dpi/6,2],millimetres:[dpi=>dpi/25.4,2],centimetres:[dpi=>dpi/2.54,3],inches:[dpi=>dpi,3]};
let abResizeFieldUnit='pixels';
function artboardResizeDpi(){const ids=JSON.parse($('artboardResizeDialog').dataset.ids||'[]'),b=artboards.find(b=>ids.includes(b.id))||artboards.find(b=>b.id===activeArtboardId);return b?.state?.dpi||documentDPI}
function resizeFieldPx(id){const u=abResizeFieldUnit,v=+$(id).value;return Math.round(v*(AB_UNITS[u]||AB_UNITS.pixels)[0](artboardResizeDpi()))}
syncArtboardResizeFields=function(){
 const u=$('artboardResizeUnit').value,percent=u==='percent',dpi=artboardResizeDpi();
 if(!percent&&AB_UNITS[u]&&u!==abResizeFieldUnit){for(const id of ['artboardResizeWidth','artboardResizeHeight']){const el=$(id),px=(+el.value)*AB_UNITS[abResizeFieldUnit][0](dpi);el.value=+(px/AB_UNITS[u][0](dpi)).toFixed(AB_UNITS[u][1])}abResizeFieldUnit=u}
 for(const id of ['artboardResizeWidth','artboardResizeHeight']){const el=$(id),step=AB_UNITS[abResizeFieldUnit][1]?1/10**AB_UNITS[abResizeFieldUnit][1]:1;el.step=String(step);el.min=String(step);el.removeAttribute('max')}
 $('artboardResizePixels').hidden=percent;$('artboardResizePercentRow').hidden=!percent;$('artboardResizeAnchor').disabled=$('artboardResizeMode').value==='scale';
};
{const open=openArtboardResize;openArtboardResize=function(){abResizeFieldUnit='pixels';return open.apply(this,arguments)}}
$('artboardResizeUnit').onchange=syncArtboardResizeFields;
// ---------- cursors that match what a click will do ----------
let abCursorLock=null;
const resizeCursor=i=>i%2===0?'nwse-resize':'nesw-resize';
function artboardCursorAt(e){
 if(abCursorLock)return abCursorLock;
 if(artboardDrag)return artboardDrag.corner<0?'move':resizeCursor(artboardDrag.corner);
 if(boardLabelAt(e))return 'pointer';
 const board=artboardAtPointer(e);
 if(artboardMode==='draw')return board?'not-allowed':'crosshair';
 const point={x:e.clientX-wr.left,y:e.clientY-wr.top},free=selectedBoardList().filter(b=>b.visible!==false&&!b.locked).map(artboardRect);
 if(free.length){const corners=artboardScreenCorners(artboardSelectionBounds(free)),hit=corners.findIndex(p=>Math.hypot(p.x-point.x,p.y-point.y)<=12);if(hit>=0)return resizeCursor(hit)}
 if(board)return board.locked?'not-allowed':'move';
 return 'default';
}
function updateArtboardCursor(e){const on=artboardToolActive();document.body.classList.toggle('artboard-tool',on);if(!on){wrap.style.removeProperty('--ab-cursor');return}wrap.style.setProperty('--ab-cursor',artboardCursorAt(e))}
wrap.addEventListener('pointermove',updateArtboardCursor,true);wrap.addEventListener('pointerdown',e=>setTimeout(()=>updateArtboardCursor(e),0),true);
{const sync=syncArtboardUi;syncArtboardUi=function(){const r=sync.apply(this,arguments);document.body.classList.toggle('artboard-tool',artboardToolActive());if(!artboardToolActive())wrap.style.removeProperty('--ab-cursor');return r}}

