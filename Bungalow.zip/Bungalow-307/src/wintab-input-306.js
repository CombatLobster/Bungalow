
/* ====== WinTab pen input (Windows, inside Tauri) ====== */
// With Windows Ink turned off in the tablet driver, a pen reaches the page as a mouse: no pressure, tilt or rotation. The native side
// reads the WinTab driver and sends batches of samples ("bungalow://wintab"); this fills in the pen data for pointer events.
// v306 fixes:
//  - per-event samples: every sample of a batch is kept (spread over the time since the previous batch), and each pointer
//    event, including coalesced ones, takes the sample at its own timeStamp. Before, all events used the last sample of the
//    latest batch: stepped pressure in fast strokes.
//  - holding the pen still in contact no longer goes stale after 90 ms. WinTab sends no packets while nothing changes, so the
//    lift then fell back to mouse pressure and left a blob at the stroke end.
//  - a contact event whose sample still reads zero pressure (its batch not here yet) takes the last pressure seen while in contact,
//    instead of drawing an invisible first dab.
//  - the eraser end is reported (eraser()), so flipping the pen erases as with Windows Ink.
//  - start/stop races: turning WinTab off while it was starting left a second event listener behind.
const WinTabInput=(()=>{
 const T=window.__TAURI__,I=window.__TAURI_INTERNALS__,available=!!(T||I);   // shown in any Tauri window; start() explains what is missing
 const cfg={on:false,invertTiltX:false,invertTiltY:false};try{Object.assign(cfg,JSON.parse(localStorage.getItem('llwintab')||'{}'))}catch(_){}
 const save=()=>{try{localStorage.setItem('llwintab',JSON.stringify(cfg))}catch(_){}};
 let latest=null,unlisten=null,busy=false,status='',lastBatchAt=0,lastContact=null,generation=0;
 const ring=[];const RING=256;
 const call=(c,a)=>T?.core?.invoke?T.core.invoke(c,a):I.invoke(c,a);
 // in proximity and recent; while the pen is in contact, packets may pause for as long as it is held still
 const fresh=()=>{if(!cfg.on||!latest||!latest.prox)return false;const age=performance.now()-latest.at;return age<90||(latest.pressure>0&&age<5000)};
 const D=Math.PI/180;
 function convert(s,at){const mag=Math.max(0,Math.min(89.5,90-Math.max(0,Math.min(90,+s.alt||0)))),az=(+s.az||0)*D;
  let tx=Math.atan(Math.tan(mag*D)*Math.sin(az))/D,ty=Math.atan(Math.tan(mag*D)*Math.cos(az))/D;if(cfg.invertTiltX)tx=-tx;if(cfg.invertTiltY)ty=-ty;
  return {at,prox:s.prox!==false,pressure:Math.max(0,Math.min(1,+s.p||0)),tiltX:Math.round(tx),tiltY:Math.round(ty),twist:((+s.twist||0)%360+360)%360,eraser:!!s.erase,buttons:s.b|0}}
 function ingest(list){
  if(!cfg.on||!Array.isArray(list)||!list.length)return;const now=performance.now(),span=Math.max(0,Math.min(30,now-(lastBatchAt||now-8*list.length))),n=list.length;lastBatchAt=now;
  for(let i=0;i<n;i++){const s=list[i];if(!s)continue;const x=convert(s,now-span*(n-1-i)/n);ring.push(x);if(x.pressure>0&&x.prox)lastContact=x;latest=x}
  if(ring.length>RING)ring.splice(0,ring.length-RING);
 }
 // the sample for a pointer event (its timeStamp; interpolated between samples), or null when WinTab is not in use
 function sample(e){if(!fresh()||e?.pointerType==='touch')return null;const t=e?.timeStamp;let s=latest;
  if(Number.isFinite(t)&&ring.length>1&&t<latest.at){let i=ring.length-1;while(i>0&&ring[i-1].at>t)i--;const b=ring[i],a=ring[i-1];
   if(a&&b.at>a.at&&t>=a.at){const k=(t-a.at)/(b.at-a.at);s={...b,pressure:a.pressure+(b.pressure-a.pressure)*k}}else s=b}
  // in contact (button down) but the sample still says zero: the pressure batch has not arrived yet
  if(s.pressure===0&&(e?.buttons&1)&&lastContact&&performance.now()-lastContact.at<150)s={...s,pressure:lastContact.pressure};
  return s}
 const eraser=e=>!!sample(e)?.eraser;
 async function start(){
  if(!available||busy)return;busy=true;const gen=++generation;
  try{
   if(!T?.event?.listen)throw Error('window.__TAURI__.event is missing. Set app.withGlobalTauri to true in tauri.conf.json and restart');
   if(!(T?.core?.invoke||I?.invoke))throw Error('the Tauri invoke API is missing');
   const un=await T.event.listen('bungalow://wintab',e=>ingest(e.payload));
   if(gen!==generation||!cfg.on){un();return} // turned off meanwhile
   if(unlisten)try{unlisten()}catch(_){}unlisten=un;
   const info=await call('wintab_start');status='WinTab · '+(info?.device||'connected');
  }catch(error){cfg.on=false;save();status='WinTab unavailable · '+(error?.message||error);try{if(unlisten)unlisten()}catch(_){}unlisten=null}
  finally{busy=false;ui()}
 }
 async function stop(){generation++;try{await call('wintab_stop')}catch(_){}try{if(unlisten)unlisten()}catch(_){}unlisten=null;latest=null;lastContact=null;ring.length=0;lastBatchAt=0;status='';ui()}
 async function set(on){cfg.on=!!on;save();if(cfg.on)await start();else await stop();ui()}
 let box=null;
 function ui(){
  if(!box)return;const c=box.querySelector('#tabletWintab');if(c)c.checked=cfg.on;
  box.querySelector('#tabletWintabStatus').textContent=status;box.querySelector('#tabletWintabOptions').hidden=!cfg.on;
 }
 function build(){
  const anchor=document.getElementById('tabletDetect');if(!anchor||box||!available)return;
  box=document.createElement('div');box.id='tabletWintabBox';
  box.innerHTML='<label class="t"><input id="tabletWintab" type="checkbox" title="Read pressure, tilt and rotation from the WinTab driver. Use this when Windows Ink is off in the tablet settings">Use WinTab</label><p id="tabletWintabStatus" class="tablet-note"></p><div id="tabletWintabOptions" hidden><label class="t"><input id="tabletWintabInvX" type="checkbox" title="Mirror left/right pen tilt, if brushes lean the wrong way horizontally">Invert tilt X</label><label class="t"><input id="tabletWintabInvY" type="checkbox" title="Mirror up/down pen tilt, if brushes lean the wrong way vertically">Invert tilt Y</label></div>';
  anchor.before(box);
  box.querySelector('#tabletWintab').onchange=e=>set(e.target.checked);
  for(const [id,key] of [['tabletWintabInvX','invertTiltX'],['tabletWintabInvY','invertTiltY']]){const el=box.querySelector('#'+id);el.checked=cfg[key];el.onchange=()=>{cfg[key]=el.checked;save()}}
  ui();if(cfg.on)start();
 }
 return {available,cfg,fresh,sample,eraser,get latest(){return latest},ingest,build,set};
})();
WinTabInput.build();
