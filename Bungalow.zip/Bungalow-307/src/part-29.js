
/* ====== Build 173: relink a source (file, artboard or layer) for one layer or every layer sharing it; resources grouped by source ====== */
const sourceKeyIds=new WeakMap();let sourceKeySerial=0;
// One key per unique source: the same embedded image object, the same linked artboard, or the same (possibly missing) file path.
function sourceKey(L){
 const I=L?.instance;if(I?.type!=='file')return null;
 if(I.frame?.artboard)return 'board:'+I.frame.artboard;
 if(I.img){let n=sourceKeyIds.get(I.img);if(!n){n=++sourceKeySerial;sourceKeyIds.set(I.img,n)}return (I.embedded?'emb:':'ext:')+n}
 return 'path:'+String(I.sourcePath||I.name||'').toLowerCase();
}
function sharedSourceLayers(L){const k=sourceKey(L);return k?layers.filter(x=>sourceKey(x)===k):[L]}
const relinkState={seed:null,group:[],kind:'file',file:null,busy:false};
const relinkSizeOk=img=>{const w=img.naturalWidth||img.width,h=img.naturalHeight||img.height;return w>0&&h>0&&w<=16384&&h<=16384&&w*h<=33554432&&!memoryBudgetExceeded(memoryUsage().total+w*h*8)};
function relinkLayerChoices(group){
 const bad=new Set(group),dependsOnGroup=L=>{const seen=new Set();for(let c=L;c&&!seen.has(c);c=c.instance?.type==='clone'?c.instance.src:null){if(bad.has(c))return true;seen.add(c)}return false};
 return layers.filter(L=>!L.mask&&!bad.has(L)&&!dependsOnGroup(L));
}
function relinkBoardChoices(){return (typeof artboards!=='undefined'?artboards:[]).filter(b=>b.id!==activeArtboardId&&(!window.ArtboardLinks||ArtboardLinks.canLink(activeArtboardId,b.id)))}
function relinkNames(list,max=3){const n=list.map(L=>'“'+L.name+'”');return n.length>max?n.slice(0,max).join(', ')+' +'+(n.length-max)+' more':n.join(', ')}
function relinkValid(){
 const k=relinkState.kind;
 if(k==='file')return !!relinkState.file;
 if(k==='artboard')return !!$('relinkBoard').value;
 return !!$('relinkLayer').value;
}
function relinkRefresh(){
 const S=relinkState,k=S.kind,group=S.group,seed=S.seed;
 for(const r of document.querySelectorAll('input[name=relinkKind]'))r.checked=r.value===k;
 $('relinkFileRow').hidden=k!=='file';$('relinkBoardRow').hidden=k!=='artboard';$('relinkLayerRow').hidden=k!=='layer';
 $('relinkFileName').textContent=S.file?S.file.name+' · '+(S.file.img.naturalWidth||S.file.img.width)+' × '+(S.file.img.naturalHeight||S.file.img.height)+' px':'No file chosen';
 $('relinkEmbedRow').hidden=k!=='file';
 const all=$('relinkScope').querySelector('input[value=all]'),one=$('relinkScope').querySelector('input[value=this]');
 $('relinkScopeOne').textContent='This layer only: “'+seed.name+'”';
 $('relinkScopeAll').textContent=group.length>1?'All '+group.length+' layers that share this source: '+relinkNames(group):'Only one layer uses this source';
 all.disabled=group.length<2;if(group.length<2)one.checked=true;
 $('relinkApply').disabled=S.busy||!relinkValid();
}
async function relinkPick(){
 const S=relinkState;if(S.busy)return;S.busy=true;relinkRefresh();
 try{
  const picked=await pickFileLayerSource();if(!picked.file)return;
  const img=await decodeFileLayerSource(picked.file);
  if(!relinkSizeOk(img))throw Error('That image is too large for the memory budget (16384 px per side, 32 million pixels)');
  S.file={img,name:picked.file.name,handle:picked.handle,mtime:picked.file.lastModified,size:picked.file.size};
 }catch(e){if(e.name!=='AbortError')toast('Could not open file: '+e.message)}
 finally{S.busy=false;relinkRefresh()}
}
function openRelinkDialog(seedOrList,{scope='this'}={}){
 if(editBlocked())return false;
 const seed=Array.isArray(seedOrList)?(seedOrList.includes(AL)?AL:seedOrList[0]):seedOrList;
 if(!seed||seed.instance?.type!=='file'){toast('Select a file layer first');return false}
 const group=sharedSourceLayers(seed);
 Object.assign(relinkState,{seed,group,kind:'file',file:null,busy:false});
 const boards=relinkBoardChoices(),choices=relinkLayerChoices(group);
 $('relinkBoard').replaceChildren(...boards.map(b=>new Option(b.name,b.id)));
 $('relinkLayer').replaceChildren(...choices.map(L=>new Option((L.group?'· ':'')+L.name,String(layers.indexOf(L)))));
 $('relinkKindArtboard').disabled=!boards.length;$('relinkKindLayer').disabled=!choices.length;
 $('relinkKindArtboardText').textContent=boards.length?'Artboard':'Artboard (no other artboards to link)';
 $('relinkKindLayerText').textContent=choices.length?'Layer in this artboard':'Layer (none available)';
 $('relinkInfo').textContent='“'+(seed.instance.name||seed.name)+'” '+(seed.instance.frame?.artboard?'is linked from an artboard':seed.instance.embedded?'is embedded':'is a linked file')+' and used by '+group.length+' layer'+(group.length===1?'':'s')+': '+relinkNames(group,4)+'.';
 const radios=$('relinkScope').querySelectorAll('input');radios.forEach(r=>r.checked=r.value===(scope==='all'&&group.length>1?'all':'this'));
 $('relinkEmbed').checked=false;relinkRefresh();
 const dlg=$('relinkDialog');if(!dlg.open)dlg.showModal();return true;
}
// ---- applying the choice ----
function relinkBounds(L){try{return layerContentBounds(L)}catch(_){return null}}
function relinkFrameFor(L,img,board){
 const w=img.naturalWidth||img.width,h=img.naturalHeight||img.height,ratio=Math.max(.01,Math.min(100,w/h)),old=L.instance.frame;
 if(old)return {...structuredClone(old),artboard:board.id,ratio};
 const b=relinkBounds(L)||{x:DW*.25,y:DH*.25,width:DW*.5,height:DH*.5};
 return {quad:[{x:b.x,y:b.y},{x:b.x+b.width,y:b.y},{x:b.x+b.width,y:b.y+b.height},{x:b.x,y:b.y+b.height}],fit:'fit',ratio,artboard:board.id};
}
function relinkNext(L,choice){
 const I=L.instance;
 if(choice.kind==='file'){
  const f=choice.file,next={...I,name:f.name,img:f.img,mtime:f.mtime,size:f.size,pending:null,denied:false,stale:false,missing:false,sourcePath:null,sourcePick:choice.pick?{file:f.name,board:choice.pick.board||null,layer:choice.pick.layer||null}:null};
  if(next.frame)next.frame={...next.frame,artboard:null};
  if(choice.embed){next.embedded=true;next.handle=null;next.embeddedSource=SourceLayers.record(f.img);next._embeddedImage=f.img}
  else{next.embedded=false;next.handle=f.handle;delete next.embeddedSource;delete next._embeddedImage}
  return next;
 }
 if(choice.kind==='artboard'){
  const img=choice.image,frame=relinkFrameFor(L,img,choice.board);if(choice.layer)frame.layer=choice.layer;
  return {...I,type:'file',sourcePick:null,embedded:true,img,name:choice.board.name+' artboard',handle:null,mtime:0,size:0,frame,placement:null,kraPlacement:null,sourceClip:null,xf:null,dx:0,dy:0,flipH:false,flipV:false,deformations:null,embeddedSource:SourceLayers.record(img),_embeddedImage:img,stale:false,missing:false,denied:false,pending:null};
 }
 const src=choice.src,a=relinkBounds(L),b=relinkBounds(src);
 const tx=a&&b?Math.round((a.x+a.width/2)-(b.x+b.width/2)):0,ty=a&&b?Math.round((a.y+a.height/2)-(b.y+b.height/2)):0;
 return {type:'clone',src,flipH:false,flipV:false,dx:0,dy:0,xf:tx||ty?[1,0,0,1,tx,ty]:null};
}
function relinkSources(targets,choice){
 const list=targets.filter(L=>layers.includes(L)&&!layerLocked(L)&&!groupLocked(L.group)),skipped=targets.length-list.length;
 if(!list.length){toast('Unlock the layers first');return false}
 const changes=list.map(L=>({L,before:L.instance,after:null}));
 try{for(const c of changes)c.after=relinkNext(c.L,choice);if(choice.kind==='artboard')for(const c of changes){window.Frame3D?.validate(c.after.frame);window.Frame3D?.source({...c.after,xf:[1,0,0,1,0,0]})}}
 catch(e){toast('Could not relink: '+e.message);return false}
 const put=side=>{for(const c of changes)c.L.instance=c[side];for(const c of changes){try{instanceRedraw(c.L)}catch(_){}}relayer();renderLayers();if(typeof renderFileTab==='function')renderFileTab(true);if(typeof scheduleLayerMasks==='function')scheduleLayerMasks()};
 try{put('after')}catch(e){put('before');toast('Could not relink: '+e.message);return false}
 if(choice.kind==='file'&&!choice.embed&&choice.file.handle)for(const c of changes)instPutHandle(c.after.id,choice.file.handle);
 const px=choice.kind==='file'?(choice.file.img.naturalWidth||choice.file.img.width)*(choice.file.img.naturalHeight||choice.file.img.height)*4:choice.kind==='artboard'?(choice.image.width*choice.image.height*4):0;
 doH({bytes:px,undo:()=>put('before'),redo:()=>put('after')});
 const what=choice.kind==='file'?choice.file.name+(choice.embed?' · embedded':' · linked'):choice.kind==='artboard'?choice.board.name+' · linked artboard':'layer “'+choice.src.name+'”';
 uiNotice('Relinked '+changes.length+' layer'+(changes.length===1?'':'s')+' to '+what+(skipped?' · '+skipped+' locked skipped':''));return true;
}
function relinkSubmit(){
 const S=relinkState,scope=$('relinkScope').querySelector('input:checked')?.value||'this',targets=scope==='all'?S.group:[S.seed];
 let choice;
 try{
  if(S.kind==='file')choice={kind:'file',file:S.file,embed:$('relinkEmbed').checked};
  else if(S.kind==='artboard'){
   const board=artboards.find(b=>b.id===$('relinkBoard').value);if(!board)throw Error('Choose an artboard');
   if(window.ArtboardLinks&&!ArtboardLinks.canLink(activeArtboardId,board.id))throw Error('This would create a circular artboard link');
   const image=Frame3D.boardImage(board,ArtboardLinks.exclusions(board));if(!relinkSizeOk(image))throw Error('That artboard is too large for the memory budget');
   choice={kind:'artboard',board,image};
  }else{const src=layers[+$('relinkLayer').value];if(!src)throw Error('Choose a layer');choice={kind:'layer',src}}
 }catch(e){toast(e.message);return false}
 return relinkSources(targets,choice);
}
for(const r of document.querySelectorAll('input[name=relinkKind]'))r.addEventListener('change',()=>{relinkState.kind=r.value;relinkRefresh()});
for(const id of ['relinkBoard','relinkLayer'])$(id).addEventListener('change',relinkRefresh);
$('relinkPick').onclick=relinkPick;
$('relinkCancel').onclick=()=>$('relinkDialog').close();
$('relinkForm').addEventListener('submit',e=>{e.preventDefault();if(!relinkValid())return;if(relinkSubmit())$('relinkDialog').close()});

