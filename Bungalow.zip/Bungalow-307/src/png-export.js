// Export-only colour precision and PNG encoding. Brush/document pixels are never changed.
const PNGExport=(()=>{
 const table=Uint32Array.from({length:256},(_,i)=>{for(let k=0;k<8;k++)i=i&1?0xedb88320^(i>>>1):i>>>1;return i>>>0});
 function chunk(type,data=new Uint8Array()){
  const header=new Uint8Array(8),tail=new Uint8Array(4);new DataView(header.buffer).setUint32(0,data.length);header.set([...type].map(c=>c.charCodeAt(0)),4);let crc=0xffffffff;
  for(const x of header.subarray(4))crc=table[(crc^x)&255]^(crc>>>8);for(const x of data)crc=table[(crc^x)&255]^(crc>>>8);new DataView(tail.buffer).setUint32(0,(crc^0xffffffff)>>>0);return new Blob([header,data,tail]);
 }
 const native=cv=>new Promise((resolve,reject)=>cv.toBlob(b=>b?resolve(b):reject(Error('Could not encode PNG')),'image/png'));
 const pause=()=>new Promise(r=>setTimeout(r,0));
 function paeth(a,b,c){const p=a+b-c,A=Math.abs(p-a),B=Math.abs(p-b),C=Math.abs(p-c);return A<=B&&A<=C?a:B<=C?b:c}
 async function encode(cv,{quality='full',compression='native'}={}){
  if(!['full','6','5'].includes(String(quality))||!['native','compact','none'].includes(compression))throw Error('Invalid PNG encoding options');
  if(quality==='full'&&compression==='native')return native(cv);if(compression==='compact'&&typeof CompressionStream==='undefined')throw Error('Compact compression is unavailable; choose Standard or None');
  const {width:w,height:h}=cv;if(!w||!h||w*h>33554432)throw Error('PNG exceeds export size limit');const image=cv.getContext('2d').getImageData(0,0,w,h),pixels=image.data;
  if(quality!=='full'){const levels=(1<<Number(quality))-1;let at=performance.now();for(let start=0;start<pixels.length;start+=65536){for(let i=start;i<Math.min(start+65536,pixels.length);i+=4)for(let c=0;c<3;c++)pixels[i+c]=Math.round(Math.round(pixels[i+c]*levels/255)*255/levels);if(performance.now()-at>8){await pause();at=performance.now()}}}
  if(compression==='native'){const copy=document.createElement('canvas');copy.width=w;copy.height=h;copy.getContext('2d').putImageData(image,0,0);try{return await native(copy)}finally{copy.width=copy.height=1}}
  const stride=w*4,rows=Math.max(1,Math.floor(65500/(stride+1)));let y=0,lastYield=performance.now();
  const raw=new ReadableStream({async pull(controller){
   if(y>=h){controller.close();return}const count=Math.min(rows,h-y),out=new Uint8Array(count*(stride+1));
   for(let r=0;r<count;r++,y++){
    const offset=y*stride,base=r*(stride+1);let best=Infinity,chosen=0;const candidates=compression==='compact'?5:1;
    for(let filter=0;filter<candidates;filter++){let score=0;for(let x=0;x<stride;x++){const a=x>=4?pixels[offset+x-4]:0,b=y?pixels[offset+x-stride]:0,c=y&&x>=4?pixels[offset+x-stride-4]:0,p=filter===1?a:filter===2?b:filter===3?(a+b)>>>1:filter===4?paeth(a,b,c):0,d=(pixels[offset+x]-p)&255;score+=Math.min(d,256-d)}if(score<best){best=score;chosen=filter}}
    out[base]=chosen;for(let x=0;x<stride;x++){const a=x>=4?pixels[offset+x-4]:0,b=y?pixels[offset+x-stride]:0,c=y&&x>=4?pixels[offset+x-stride-4]:0,p=chosen===1?a:chosen===2?b:chosen===3?(a+b)>>>1:chosen===4?paeth(a,b,c):0;out[base+1+x]=(pixels[offset+x]-p)&255}
   }
   controller.enqueue(out);if(performance.now()-lastYield>8){await pause();lastYield=performance.now()}
  }});
  let stream=raw;
  if(compression==='compact'){if(typeof CompressionStream==='undefined')throw Error('Compact compression is unavailable; choose Standard or None');stream=raw.pipeThrough(new CompressionStream('deflate'))}
  const ihdr=new Uint8Array(13),dv=new DataView(ihdr.buffer);dv.setUint32(0,w);dv.setUint32(4,h);ihdr[8]=8;ihdr[9]=6;
  const parts=[new Uint8Array([137,80,78,71,13,10,26,10]),chunk('IHDR',ihdr),chunk('sRGB',new Uint8Array([0]))],reader=stream.getReader();let sum1=1,sum2=0;
  if(compression==='none')parts.push(chunk('IDAT',new Uint8Array([0x78,0x01])));
  for(;;){const {value,done}=await reader.read();if(done)break;if(compression==='compact'){parts.push(chunk('IDAT',value));continue}
   for(let start=0;start<value.length;start+=65535){const data=value.subarray(start,start+65535),block=new Uint8Array(data.length+5),n=data.length;block[0]=0;block[1]=n&255;block[2]=n>>>8;block[3]=(~n)&255;block[4]=((~n)>>>8)&255;block.set(data,5);for(const x of data){sum1=(sum1+x)%65521;sum2=(sum2+sum1)%65521}parts.push(chunk('IDAT',block))}
  }
  if(compression==='none'){const end=new Uint8Array(9);end.set([1,0,0,255,255]);new DataView(end.buffer).setUint32(5,((sum2<<16)|sum1)>>>0);parts.push(chunk('IDAT',end))}
  parts.push(chunk('IEND'));return new Blob(parts,{type:'image/png'});
 }
 return Object.freeze({encode});
})();
