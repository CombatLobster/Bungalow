
/* ====== Build 160: external SVG shapes (paste / place), movable Options panel ====== */
// ---- SVG parsing. Nothing from the file is ever inserted into the page: only attributes are read. ----
const SVG_SKIP=new Set(['defs','clippath','mask','symbol','pattern','marker','metadata','title','desc','style','script','foreignobject','lineargradient','radialgradient','filter','switch','text','tspan','image']);
const SVG_PROPS=['fill','stroke','stroke-width','fill-opacity','stroke-opacity','opacity','fill-rule','stroke-linejoin','stroke-linecap','color','display','visibility'];
const SVG_MAX_ELEMENTS=600,SVG_XLINK='http://www.w3.org/1999/xlink';
const svgNum=(v,d=0)=>{const n=parseFloat(v);return Number.isFinite(n)?n:d};
const svgUnit=(v,d=0)=>{const s=String(v??'').trim();const n=parseFloat(s);return Number.isFinite(n)?(s.endsWith('%')?n/100:n):d};
const svgClamp01=v=>v<0?0:v>1?1:v;
function svgTransform(str){
 let m=[1,0,0,1,0,0];if(!str)return m;const re=/(matrix|translate|scale|rotate|skewX|skewY)\s*\(([^)]*)\)/g;let t;
 while((t=re.exec(str))){const a=t[2].trim().split(/[\s,]+/).filter(Boolean).map(Number);if(a.some(v=>!Number.isFinite(v)))continue;let n=null;
  switch(t[1]){case 'matrix':if(a.length===6)n=a;break;case 'translate':n=[1,0,0,1,a[0]||0,a[1]||0];break;case 'scale':n=[a[0]??1,0,0,a[1]??a[0]??1,0,0];break;
   case 'rotate':{const r=(a[0]||0)*Math.PI/180,c=Math.cos(r),s=Math.sin(r),cx=a[1]||0,cy=a[2]||0;n=[c,s,-s,c,cx-c*cx+s*cy,cy-s*cx-c*cy];break}
   case 'skewX':n=[1,0,Math.tan((a[0]||0)*Math.PI/180),1,0,0];break;case 'skewY':n=[1,Math.tan((a[0]||0)*Math.PI/180),0,1,0,0];break}
  if(n)m=instMul(m,n)}
 return m;
}
let svgColourCtx=null;
// -> {hex,a} or null for none / transparent / unparseable
function svgColour(str){
 str=String(str||'').trim();if(!str||str==='none'||str==='transparent')return null;
 // hex and rgb()/rgba() are read directly; names and hsl() are normalised by the canvas
 let h=/^#([0-9a-f]{3,8})$/i.exec(str);
 if(h&&[3,4,6,8].includes(h[1].length)){let x=h[1];if(x.length<=4)x=[...x].map(ch=>ch+ch).join('');return {hex:'#'+x.slice(0,6).toLowerCase(),a:x.length===8?parseInt(x.slice(6,8),16)/255:1}}
 const rg=/^rgba?\(\s*([\d.]+%?)[\s,]+([\d.]+%?)[\s,]+([\d.]+%?)(?:[\s,/]+([\d.]+%?))?\s*\)$/i.exec(str);
 if(rg){const ch=v=>Math.max(0,Math.min(255,Math.round(v.endsWith('%')?parseFloat(v)*2.55:parseFloat(v)))),hx=v=>ch(v).toString(16).padStart(2,'0'),al=rg[4]===undefined?1:Math.max(0,Math.min(1,rg[4].endsWith('%')?parseFloat(rg[4])/100:parseFloat(rg[4])));return {hex:'#'+hx(rg[1])+hx(rg[2])+hx(rg[3]),a:al}}
 const c=svgColourCtx||(svgColourCtx=document.createElement('canvas').getContext('2d'));
 c.fillStyle='#000';c.fillStyle=str;const a=c.fillStyle;c.fillStyle='#fff';c.fillStyle=str;const b=c.fillStyle;if(a!==b)return null; // an invalid colour leaves the previous value in place
 let m=/^#([0-9a-f]{6})$/i.exec(a);if(m)return {hex:'#'+m[1].toLowerCase(),a:1};
 m=/^rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)(?:[\s,/]+([\d.]+))?\s*\)$/i.exec(a);
 if(m){const h=v=>(+v).toString(16).padStart(2,'0');return {hex:'#'+h(m[1])+h(m[2])+h(m[3]),a:m[4]===undefined?1:+m[4]}}
 return null;
}
function svgDecl(text){const out={};for(const part of String(text||'').split(';')){const i=part.indexOf(':');if(i>0)out[part.slice(0,i).trim().toLowerCase()]=part.slice(i+1).trim().replace(/\s*!important$/i,'')}return out}
function svgCssRules(doc){
 const rules=[];
 for(const st of doc.getElementsByTagName('style')){const css=(st.textContent||'').replace(/\/\*[\s\S]*?\*\//g,'');const re=/([^{}]+)\{([^{}]*)\}/g;let m;
  while((m=re.exec(css)))for(const sel of m[1].split(',')){const s=sel.trim();if(/^(\*|[a-z][\w-]*)?(\.[\w-]+|#[\w-]+)*$/i.test(s))rules.push({s,decl:svgDecl(m[2]),spec:(s.match(/#/g)||[]).length*100+(s.match(/\./g)||[]).length*10+(/^[a-z]/i.test(s)?1:0)})}}
 return rules.sort((a,b)=>a.spec-b.spec);
}
function svgMatches(el,sel){
 const m=/^(\*|[a-z][\w-]*)?((?:\.[\w-]+|#[\w-]+)*)$/i.exec(sel);if(!m)return false;
 if(m[1]&&m[1]!=='*'&&el.localName.toLowerCase()!==m[1].toLowerCase())return false;
 for(const part of (m[2].match(/[.#][\w-]+/g)||[])){if(part[0]==='.'){if(!(el.getAttribute('class')||'').split(/\s+/).includes(part.slice(1)))return false}else if(el.getAttribute('id')!==part.slice(1))return false}
 return true;
}
const SVG_ROOT_STYLE={fill:'black',stroke:'none','stroke-width':'1','fill-opacity':'1','stroke-opacity':'1','fill-rule':'nonzero','stroke-linejoin':'miter','stroke-linecap':'butt',color:'black',visibility:'visible',opacity:1,display:'inline'};
function svgStyleOf(el,parent,rules){
 const decl={};for(const p of SVG_PROPS){const v=el.getAttribute(p);if(v!=null)decl[p]=v}
 for(const r of rules)if(svgMatches(el,r.s))Object.assign(decl,r.decl);Object.assign(decl,svgDecl(el.getAttribute('style')));
 const st={...parent};
 for(const p of ['fill','stroke','stroke-width','fill-opacity','stroke-opacity','fill-rule','stroke-linejoin','stroke-linecap','color','visibility'])if(decl[p]!==undefined&&decl[p]!=='inherit')st[p]=decl[p];
 if(decl.opacity!==undefined)st.opacity=parent.opacity*svgClamp01(svgNum(decl.opacity,1));
 st.display=decl.display==='none'?'none':'inline';return st;
}
// ---- path flattening, for bounds only (drawing uses Path2D on the original data) ----
// Flattened subpaths [{pts:[[x,y]...],closed}] of SVG path data, with the matrix M applied (used for bounds and for deforming shapes).
function svgPathSubpaths(d,M=[1,0,0,1,0,0]){
 const tokens=String(d).match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g)||[],subs=[];
 let i=0,cmd='',x=0,y=0,sx=0,sy=0,lcx=0,lcy=0,prev='',cur=null,total=0;
 let bad=false;/* v283: a missing number marks the path malformed (no NaN coordinates, no endless loop) */const num=()=>{const t=tokens[i];if(t===undefined||/[a-zA-Z]/.test(t)){bad=true;return NaN}i++;return parseFloat(t)},P=(X,Y)=>[M[0]*X+M[2]*Y+M[4],M[1]*X+M[3]*Y+M[5]];
 const begin=(X,Y)=>{cur={pts:[P(X,Y)],closed:false};subs.push(cur)},ensure=()=>{if(!cur)begin(x,y)},add=(X,Y)=>{cur.pts.push(P(X,Y));total++};
 const cubic=(x0,y0,x1,y1,x2,y2,x3,y3)=>{for(let k=1;k<=20;k++){const t=k/20,u=1-t;add(u*u*u*x0+3*u*u*t*x1+3*u*t*t*x2+t*t*t*x3,u*u*u*y0+3*u*u*t*y1+3*u*t*t*y2+t*t*t*y3)}};
 const quad=(x0,y0,x1,y1,x2,y2)=>{for(let k=1;k<=16;k++){const t=k/16,u=1-t;add(u*u*x0+2*u*t*x1+t*t*x2,u*u*y0+2*u*t*y1+t*t*y2)}};
 const arc=(x0,y0,rx,ry,deg,fa,fs,x1,y1)=>{
  rx=Math.abs(rx);ry=Math.abs(ry);if(!rx||!ry||(x0===x1&&y0===y1)){add(x1,y1);return}
  const phi=deg*Math.PI/180,cp=Math.cos(phi),sp=Math.sin(phi),dx=(x0-x1)/2,dy=(y0-y1)/2,xp=cp*dx+sp*dy,yp=-sp*dx+cp*dy,lam=xp*xp/(rx*rx)+yp*yp/(ry*ry);
  if(lam>1){const k=Math.sqrt(lam);rx*=k;ry*=k}
  const sign=fa===fs?-1:1,num2=rx*rx*ry*ry-rx*rx*yp*yp-ry*ry*xp*xp,den=rx*rx*yp*yp+ry*ry*xp*xp,coef=sign*Math.sqrt(Math.max(0,num2/den)),cxp=coef*rx*yp/ry,cyp=-coef*ry*xp/rx;
  const cx=cp*cxp-sp*cyp+(x0+x1)/2,cy=sp*cxp+cp*cyp+(y0+y1)/2,ang=(ux,uy,vx,vy)=>Math.atan2(ux*vy-uy*vx,ux*vx+uy*vy);
  const ux=(xp-cxp)/rx,uy=(yp-cyp)/ry,vx=(-xp-cxp)/rx,vy=(-yp-cyp)/ry,t1=Math.atan2(uy,ux);let dt=ang(ux,uy,vx,vy);
  if(!fs&&dt>0)dt-=2*Math.PI;if(fs&&dt<0)dt+=2*Math.PI;
  for(let k=1;k<=32;k++){const t=t1+dt*k/32;add(cx+rx*Math.cos(t)*cp-ry*Math.sin(t)*sp,cy+rx*Math.cos(t)*sp+ry*Math.sin(t)*cp)}
 };
 while(i<tokens.length){
  if(/[a-zA-Z]/.test(tokens[i])){cmd=tokens[i++];if(cmd==='z'||cmd==='Z'){if(cur)cur.closed=true;x=sx;y=sy;prev='z';cur=null;continue}}
  const rel=cmd===cmd.toLowerCase(),C=cmd.toUpperCase();if(!C||!'MLHVCSQTA'.includes(C)){i++;continue}
  const ox=rel?x:0,oy=rel?y:0;
  if(C==='M'){x=ox+num();y=oy+num();sx=x;sy=y;begin(x,y);cmd=rel?'l':'L';prev='M'}
  else if(C==='L'){ensure();x=ox+num();y=oy+num();add(x,y);prev='L'}
  else if(C==='H'){ensure();x=(rel?x:0)+num();add(x,y);prev='L'}
  else if(C==='V'){ensure();y=(rel?y:0)+num();add(x,y);prev='L'}
  else if(C==='C'){ensure();const x1=ox+num(),y1=oy+num(),x2=ox+num(),y2=oy+num(),x3=ox+num(),y3=oy+num();cubic(x,y,x1,y1,x2,y2,x3,y3);lcx=x2;lcy=y2;x=x3;y=y3;prev='C'}
  else if(C==='S'){ensure();const x1=prev==='C'?2*x-lcx:x,y1=prev==='C'?2*y-lcy:y,x2=ox+num(),y2=oy+num(),x3=ox+num(),y3=oy+num();cubic(x,y,x1,y1,x2,y2,x3,y3);lcx=x2;lcy=y2;x=x3;y=y3;prev='C'}
  else if(C==='Q'){ensure();const x1=ox+num(),y1=oy+num(),x2=ox+num(),y2=oy+num();quad(x,y,x1,y1,x2,y2);lcx=x1;lcy=y1;x=x2;y=y2;prev='Q'}
  else if(C==='T'){ensure();const x1=prev==='Q'?2*x-lcx:x,y1=prev==='Q'?2*y-lcy:y,x2=ox+num(),y2=oy+num();quad(x,y,x1,y1,x2,y2);lcx=x1;lcy=y1;x=x2;y=y2;prev='Q'}
  else if(C==='A'){ensure();const rx=num(),ry=num(),rot=num(),fa=num(),fs=num(),x1=ox+num(),y1=oy+num();arc(x,y,rx,ry,rot,fa,fs,x1,y1);x=x1;y=y1;prev='A'}
  if(bad||total>200000)break;
 }
 // SVG renders up to the first error; a lone moveto draws nothing
 return subs.map(sp=>({closed:sp.closed,pts:sp.pts.filter(p=>Number.isFinite(p[0])&&Number.isFinite(p[1]))})).filter(sp=>sp.pts.length>1);
}
function svgPathPoints(d,M=[1,0,0,1,0,0]){return svgPathSubpaths(d,M).flatMap(sp=>sp.pts)}
function svgPathBounds(d,M){const pts=svgPathPoints(d,M);if(!pts.length)return null;let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;for(const [x,y] of pts){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}return {x:x0,y:y0,w:x1-x0,h:y1-y0}}
function svgGeometry(el,tag){
 const n=k=>svgNum(el.getAttribute(k));
 if(tag==='path')return el.getAttribute('d')||null;
 if(tag==='rect'){const x=n('x'),y=n('y'),w=n('width'),h=n('height');if(!(w>0&&h>0))return null;let rx=svgNum(el.getAttribute('rx'),NaN),ry=svgNum(el.getAttribute('ry'),NaN);if(!Number.isFinite(rx))rx=Number.isFinite(ry)?ry:0;if(!Number.isFinite(ry))ry=rx;rx=Math.min(rx,w/2);ry=Math.min(ry,h/2);
  return rx>0&&ry>0?`M${x+rx} ${y}H${x+w-rx}A${rx} ${ry} 0 0 1 ${x+w} ${y+ry}V${y+h-ry}A${rx} ${ry} 0 0 1 ${x+w-rx} ${y+h}H${x+rx}A${rx} ${ry} 0 0 1 ${x} ${y+h-ry}V${y+ry}A${rx} ${ry} 0 0 1 ${x+rx} ${y}Z`:`M${x} ${y}H${x+w}V${y+h}H${x}Z`}
 if(tag==='circle'||tag==='ellipse'){const cx=n('cx'),cy=n('cy'),rx=tag==='circle'?n('r'):n('rx'),ry=tag==='circle'?n('r'):n('ry');if(!(rx>0&&ry>0))return null;return `M${cx-rx} ${cy}A${rx} ${ry} 0 1 0 ${cx+rx} ${cy}A${rx} ${ry} 0 1 0 ${cx-rx} ${cy}Z`}
 if(tag==='line')return `M${n('x1')} ${n('y1')}L${n('x2')} ${n('y2')}`;
 if(tag==='polyline'||tag==='polygon'){const v=(el.getAttribute('points')||'').trim().split(/[\s,]+/).map(Number).filter(Number.isFinite);if(v.length<4)return null;let d='M'+v[0]+' '+v[1];for(let i=2;i+1<v.length;i+=2)d+='L'+v[i]+' '+v[i+1];return tag==='polygon'?d+'Z':d}
 return null;
}
// linear / radial gradients become the shape's own gradient fill (approximate: gradientTransform is ignored)
function svgGradient(el,ids,depth=0){
 if(!el||depth>6)return null;const tag=el.localName.toLowerCase();if(tag!=='lineargradient'&&tag!=='radialgradient')return null;
 const href=(el.getAttribute('href')||el.getAttributeNS(SVG_XLINK,'href')||'').replace(/^#/,''),parent=href?ids.get(href):null;
 const attr=k=>el.getAttribute(k)??(parent?.getAttribute?.(k)??null);
 let stopsEl=[...el.children].filter(c=>c.localName.toLowerCase()==='stop');if(!stopsEl.length&&parent){const p=svgGradient(parent,ids,depth+1);if(!p)return null;stopsEl=null;var inherited=p.stops}
 let stops=inherited;
 if(stopsEl){stops=[];let last=0;for(const s of stopsEl){const d={...svgDecl(s.getAttribute('style'))};const sc=d['stop-color']??s.getAttribute('stop-color')??'black',so=svgClamp01(svgNum(d['stop-opacity']??s.getAttribute('stop-opacity'),1)),c=svgColour(sc);if(!c)continue;
  const t=Math.max(last,svgClamp01(svgUnit(s.getAttribute('offset'),0)));last=t;const a=Math.round(svgClamp01(so*c.a)*255);stops.push({t,v:c.hex+(a<255?a.toString(16).padStart(2,'0'):'')})}}
 if(!stops||stops.length<1)return null;if(stops.length===1)stops=[{...stops[0],t:0},{...stops[0],t:1}];stops=stops.slice(0,32);
 const units=attr('gradientUnits')==='userSpaceOnUse'?'userSpaceOnUse':'objectBoundingBox';
 if(tag==='lineargradient')return {type:'linear',units,a:{x:svgUnit(attr('x1'),0),y:svgUnit(attr('y1'),0)},b:{x:svgUnit(attr('x2'),units==='objectBoundingBox'?1:100),y:svgUnit(attr('y2'),0)},stops};
 const cx=svgUnit(attr('cx'),.5),cy=svgUnit(attr('cy'),.5),r=svgUnit(attr('r'),.5);return {type:'radial',units,a:{x:cx,y:cy},b:{x:cx+r,y:cy},stops};
}
function svgPaint(value,st,ids){
 value=String(value??'').trim();if(value==='currentColor')value=st.color;
 const u=/^url\(\s*['"]?#([^'")\s]+)['"]?\s*\)\s*(.*)$/.exec(value);
 if(u){const g=svgGradient(ids.get(u[1]),ids);if(g)return {gradient:g};const fb=svgColour(u[2]);return fb?{hex:fb.hex,a:fb.a}:null}
 const c=svgColour(value);return c&&c.a>0?{hex:c.hex,a:c.a}:null;
}
function parseSvgDocument(text){
 let doc;try{doc=new DOMParser().parseFromString(String(text),'image/svg+xml')}catch(_){return null}
 const root=doc.documentElement;if(!root||doc.getElementsByTagName('parsererror').length||root.localName.toLowerCase()!=='svg')return null;
 const rules=svgCssRules(doc),ids=new Map();for(const el of doc.querySelectorAll('[id]'))ids.set(el.getAttribute('id'),el);
 const items=[];let skipped=0;
 const visit=(el,parentStyle,M,depth)=>{
  if(items.length>=SVG_MAX_ELEMENTS||depth>24)return;
  const tag=el.localName.toLowerCase();
  if(SVG_SKIP.has(tag)){if(tag==='text'||tag==='tspan'||tag==='image')skipped++;return}
  const st=svgStyleOf(el,parentStyle,rules);if(st.display==='none')return;
  const T=instMul(M,svgTransform(el.getAttribute('transform')));
  if(tag==='g'||tag==='svg'||tag==='a'){for(const c of el.children)visit(c,st,T,depth+1);return}
  if(tag==='use'){const ref=ids.get((el.getAttribute('href')||el.getAttributeNS(SVG_XLINK,'href')||'').replace(/^#/,''));if(!ref){skipped++;return}visit(ref,st,instMul(T,[1,0,0,1,svgNum(el.getAttribute('x')),svgNum(el.getAttribute('y'))]),depth+1);return}
  const d=svgGeometry(el,tag);if(!d)return;if(st.visibility==='hidden'||st.visibility==='collapse')return;
  const fill=tag==='line'?null:svgPaint(st.fill,st,ids),stroke=svgPaint(st.stroke,st,ids),fo=svgClamp01(svgNum(st['fill-opacity'],1)),so=svgClamp01(svgNum(st['stroke-opacity'],1)),sw=Math.max(0,svgNum(st['stroke-width'],1));
  const hasFill=!!fill&&fo>0,hasStroke=!!stroke&&so>0&&sw>0&&!stroke.gradient;
  if(!hasFill&&!hasStroke)return;
  items.push({id:el.getAttribute('id'),tag,d,M:T,fill:hasFill?fill:null,stroke:hasStroke?stroke:null,fillOpacity:hasFill?fo*(fill.a??1):1,strokeOpacity:hasStroke?so*(stroke.a??1):1,sw,rule:st['fill-rule'],join:st['stroke-linejoin'],cap:st['stroke-linecap'],opacity:st.opacity});
 };
 visit(root,SVG_ROOT_STYLE,[1,0,0,1,0,0],0);
 const vb=(root.getAttribute('viewBox')||'').trim().split(/[\s,]+/).map(Number),w=parseFloat(root.getAttribute('width')),h=parseFloat(root.getAttribute('height'));
 const natural=vb.length===4&&vb[2]>0&&Number.isFinite(w)&&w>0&&!String(root.getAttribute('width')).includes('%')?w/vb[2]:1;
 return {items,skipped,natural};
}
// Fit the imported elements into a placement rectangle and build shape records (kind 'path').
function buildSvgShapes(parsed,center,docW,docH,baseName='SVG'){
 const boxes=parsed.items.map(it=>svgPathBounds(it.d,it.M)),idx=parsed.items.map((_,i)=>i).filter(i=>boxes[i]);
 if(!idx.length)return [];
 let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;for(const i of idx){const b=boxes[i];x0=Math.min(x0,b.x);y0=Math.min(y0,b.y);x1=Math.max(x1,b.x+b.w);y1=Math.max(y1,b.y+b.h)}
 const uw=x1-x0,uh=y1-y0,big=Math.max(uw,uh);let s=parsed.natural||1;const dim=big*s,minSide=Math.min(docW,docH);
 if(big>0&&(dim>minSide*.85||dim<64))s=(dim>minSide*.85?minSide*.5:Math.min(240,minSide*.25))/big;
 const ucx=x0+uw/2,ucy=y0+uh/2,shapes=[];
 for(const i of idx){
  const it=parsed.items[i],b=boxes[i],det=Math.abs(it.M[0]*it.M[3]-it.M[1]*it.M[2]),swd=Math.min(1000,it.sw*s*Math.sqrt(det)),sw0=it.stroke?swd:0;
  const sh={kind:'path',d:it.d,m:it.M.map(v=>+v),bx:b.x,by:b.y,bw:b.w,bh:b.h,x:center.x+(b.x-ucx)*s,y:center.y+(b.y-ucy)*s,w:b.w*s,h:b.h*s,
   paint:it.fill&&it.stroke?'both':it.fill?'fill':'stroke',colour:it.fill?.hex||it.fill?.gradient?.stops[0].v.slice(0,7)||'#000000',strokeColour:it.stroke?.hex||'#000000',strokeWidth:+sw0.toFixed(3),strokeAlign:'center',fillMode:'solid',
   radius:24,sides:5,inner:.5,flip:false};
  if(it.fillOpacity<.999)sh.fillOpacity=+it.fillOpacity.toFixed(3);if(it.strokeOpacity<.999)sh.strokeOpacity=+it.strokeOpacity.toFixed(3);if(it.rule==='evenodd')sh.evenodd=true;if(['round','miter','bevel'].includes(it.join))sh.join=it.join;if(['butt','round','square'].includes(it.cap))sh.cap=it.cap;
  if(it.fill?.gradient){const g=it.fill.gradient;let a={...g.a},bb={...g.b};
   if(g.units==='userSpaceOnUse'){const lb=svgPathBounds(it.d,[1,0,0,1,0,0]);if(lb&&lb.w>1e-9&&lb.h>1e-9){const f=p=>({x:(p.x-lb.x)/lb.w,y:(p.y-lb.y)/lb.h});a=f(a);bb=f(bb)}else{a={x:.5,y:0};bb={x:.5,y:1}}}
   sh.fillMode='gradient';sh.gradient={type:g.type,a,b:bb,space:'srgb',stops:g.stops.map(st=>({t:st.t,v:st.v,mid:.5,interp:'linear'}))}}
  if(!sh.strokeWidth)sh.strokeWidth=it.stroke?.5:0;
  shapes.push({name:it.id||(it.tag+' '+(shapes.length+1)),shape:sh,op:svgClamp01(it.opacity)});
 }
 return shapes.map((r,k)=>({...r,name:shapes.length>1?baseName+' · '+r.name:baseName}));
}
// ---- creating the layers ----
function placeVectorShapes(items,label='SVG'){
 if(!items.length)return false;
 if(canvasBusy())return false;
 if(layerLocked(AL)||groupLocked(AL?.group)){toast('Unlock the destination first');return false}
 const sparseShape=sparseVectorsOn()&&nativeSparseActive();
 if(residentArtboardLayers().length+items.length>=4096||memoryBudgetExceeded(memoryUsage().total+items.length*(sparseShape?SPARSE_LAYER_TILE*SPARSE_LAYER_TILE*16:DW*DH*4))){toast('Shapes exceed the configured memory budget');return false}
 if(!vectoring)vectorTool();
 closeTextEditor();
 const previous=AL,selection=new Set(selectedStack),index=layers.indexOf(AL)+1,created=[];
 items.forEach((it,k)=>{
  const L=newLayer(it.name,null,sparseShape);L.group=previous?.group||null;L.instance={type:'shape',shape:it.shape,flipH:false,flipV:false,dx:0,dy:0,xf:null};L._vecRect=null;if(it.op!=null&&it.op<1)L.op=it.op;
  created.push(L);insertLayer(L,index+k);drawVectorLayer(L);
 });
 const show=()=>{setStackSelection(created,{active:created[created.length-1],anchor:created[created.length-1]});relayer();renderLayers();BungalowVectors.sync()};
 show();
 doH({bytes:created.reduce((n,L)=>n+layerRasterBytes(L),0),
  undo(){for(const L of created)removeLayer(L);setStackSelection([...selection].filter(n=>layers.includes(n)||layerGroups.includes(n)),{active:layers.includes(previous)?previous:AL});relayer();renderLayers();BungalowVectors.sync()},
  redo(){created.forEach((L,k)=>insertLayer(L,index+k));show()}});
 uiNotice(label);return true;
}
function visibleCentre(){try{const p=gradToDoc({x:wrap.clientWidth/2,y:wrap.clientHeight/2});return {x:clamp(p.x,0,DW),y:clamp(p.y,0,DH)}}catch(_){return {x:DW/2,y:DH/2}}}
function importSvgText(text,{name='SVG',point=null}={}){
 const parsed=parseSvgDocument(text);if(!parsed){toast('That is not a readable SVG');return false}
 const shapes=buildSvgShapes(parsed,point||visibleCentre(),DW,DH,name);
 if(!shapes.length){toast(parsed.skipped?'Nothing to import: this SVG only has text or images':'No shapes found in that SVG');return false}
 const note=parsed.skipped?' · '+parsed.skipped+' text/image element'+(parsed.skipped>1?'s':'')+' skipped':'';
 return placeVectorShapes(shapes,shapes.length+' shape'+(shapes.length>1?'s':'')+' placed'+note);
}
async function importSvgFiles(files,point=null){const epoch=typeof documentEpoch==='number'?documentEpoch:0;for(const f of files){let text='';try{text=await f.text()}catch(_){toast('Could not read '+f.name);continue}/* v283: a read that finishes after the document was replaced is dropped */if(typeof documentEpoch==='number'&&documentEpoch!==epoch)return;importSvgText(text,{name:String(f.name||'SVG').replace(/\.svg$/i,''),point})}}
function looksLikeSvg(t){return /^\s*(<\?xml[^>]*>\s*)?(<!--[\s\S]*?-->\s*)*(<!DOCTYPE[^>]*>\s*)?<svg[\s>]/i.test(String(t).slice(0,4000))}
function pickSvgFiles(){const input=document.createElement('input');input.type='file';input.accept='.svg,image/svg+xml';input.multiple=true;input.onchange=()=>{if(input.files.length)importSvgFiles([...input.files])};input.click()}
async function pasteSvgFromClipboard(){
 try{const text=await navigator.clipboard.readText();if(looksLikeSvg(text)){importSvgText(text,{name:'Pasted SVG'});return}const m=text.match(/<svg[\s\S]*<\/svg>/i);if(m){importSvgText(m[0],{name:'Pasted SVG'});return}toast('No SVG markup in the clipboard')}
 catch(_){toast('Clipboard access was blocked, use Ctrl+V instead')}
}
// Ctrl+V with SVG markup (or an SVG file) on the clipboard places editable shapes instead of a bitmap
document.addEventListener('paste',e=>{
 if(typeof clipboardTextTarget==='function'&&clipboardTextTarget(e))return;
 const cd=e.clipboardData;if(!cd)return;
 const files=[...(cd.items||[])].filter(i=>i.kind==='file').map(i=>i.getAsFile()).filter(f=>f&&(f.type==='image/svg+xml'||/\.svg$/i.test(f.name)));
 let text='';try{text=cd.getData('image/svg+xml')||cd.getData('text/plain')||''}catch(_){}
 if(!looksLikeSvg(text)){let html='';try{html=cd.getData('text/html')||''}catch(_){}const m=!files.length&&!text.startsWith(LAYER_CLIP_PREFIX)?html.match(/<svg[\s>][\s\S]*<\/svg>/i):null;text=m?m[0]:(looksLikeSvg(text)?text:'')}
 if(!files.length&&!text)return;
 e.preventDefault();e.stopImmediatePropagation();
 if(files.length)importSvgFiles(files);else importSvgText(text,{name:'Pasted SVG'});
},true);
// dropping SVG files while the Vector tool is active places them as shapes
window.addEventListener('drop',e=>{
 if(!vectoring||!e.dataTransfer?.files?.length)return;const files=[...e.dataTransfer.files];
 if(!files.every(f=>f.type==='image/svg+xml'||/\.svg$/i.test(f.name)))return;
 e.preventDefault();e.stopImmediatePropagation();try{$('fileDropHint').hidden=true;fileDragDepth=0}catch(_){}
 let p=null;try{p=screenToDoc(e)}catch(_){}importSvgFiles(files,p);
},true);

// ---- remember the "Keep stroke sizes" choice ----
(function(){const box=$('transformKeepStrokes');if(!box)return;try{box.checked=localStorage.getItem('llKeepStrokes')==='on'}catch(_){}box.addEventListener('change',()=>{try{localStorage.setItem('llKeepStrokes',box.checked?'on':'off')}catch(_){}})})();
// ---- the Options panel can be dragged by its header (double-click the header to reset) ----
(function movableOptionsPanel(){
 const panel=$('docpanel'),head=panel?.querySelector('.lh');if(!panel||!head)return;
 const KEY='llOptionsPanelPos';let saved=null;try{saved=JSON.parse(localStorage.getItem(KEY)||'null')}catch(_){}
 head.style.cursor='grab';head.style.touchAction='none';head.title='Drag to move · double-click to reset';
 const place=(x,y)=>{const sc=uiScaleFactor||1,r=panel.getBoundingClientRect();x=clamp(x,10,Math.max(10,innerWidth-Math.min(r.width,innerWidth-20)-10));y=clamp(y,10,Math.max(10,innerHeight-60));
  panel.style.position='fixed';panel.style.right='auto';panel.style.left=x/sc+'px';panel.style.top=y/sc+'px';panel.style.maxHeight=Math.max(120,(innerHeight-y-8)/sc)+'px';return {x,y}};
 const reset=()=>{saved=null;try{localStorage.removeItem(KEY)}catch(_){}for(const k of ['position','right','left','top','maxHeight'])panel.style[k]=''};
 head.addEventListener('pointerdown',e=>{
  if(e.button!==0||e.target.closest('button,input,select,a'))return;e.preventDefault();
  const r=panel.getBoundingClientRect(),dx=e.clientX-r.left,dy=e.clientY-r.top;let pos=null;head.setPointerCapture(e.pointerId);head.style.cursor='grabbing';
  const move=ev=>{if(ev.pointerId!==e.pointerId)return;pos=place(ev.clientX-dx,ev.clientY-dy)};
  const end=ev=>{if(ev.pointerId!==e.pointerId)return;head.removeEventListener('pointermove',move);head.removeEventListener('pointerup',end);head.removeEventListener('pointercancel',end);head.style.cursor='grab';if(pos){saved=pos;try{localStorage.setItem(KEY,JSON.stringify(pos))}catch(_){}}};
  head.addEventListener('pointermove',move);head.addEventListener('pointerup',end);head.addEventListener('pointercancel',end);
 });
 head.addEventListener('dblclick',e=>{if(!e.target.closest('button,input,select,a'))reset()});
 new MutationObserver(()=>{if(panel.classList.contains('open')&&saved)place(saved.x,saved.y)}).observe(panel,{attributes:true,attributeFilter:['class']});
 addEventListener('resize',()=>{if(saved&&panel.classList.contains('open'))place(saved.x,saved.y)});
})();


// ---- size fields always show true physical sizes: refresh them whenever the document DPI / size or the active layer's scale changes ----
function refreshDocumentUnits(){
 try{BungalowDesktopValues.sync()}catch(_){}
 try{BungalowVectors.sync()}catch(_){}
 for(const id of ['settingtextSize','settingtextTracking'])try{$(id)?._compactValue?.sync()}catch(_){}
 try{BungalowContext.sync()}catch(_){}
}
(function(){
 let last='';
 const signature=()=>{let u='';try{const I=AL?.instance;if(I&&(I.type==='text'||I.type==='shape')){const sc=instanceScale(I);u=[sc.u,sc.x,sc.y].map(v=>+v.toFixed(5)).join(',')}}catch(_){}return [documentDPI,DW,DH,u].join('|')};
 setInterval(()=>{if(document.hidden)return;const sig=signature();if(sig!==last){last=sig;refreshDocumentUnits()}},250);
})();
