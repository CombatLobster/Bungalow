/* layer-parking-307.js — v307: clone sources park too; a clone whose source is parked redraws once the source is back
 *       (part-05.js SourceLayers.draw).
 * v305: merges load only the layers they merge (not every parked layer); PNG/JPEG export and
 *       copy merged are composited by the core (app.js flatForExport) and load nothing.
 * v304: display tiles of parked layers are requested once each (no per-frame flood), one fetch
 *       at a time, with failure back-off and fallback to loading the layer; reads wait for files still being decoded.
 * v303: display tiles of parked layers no longer recomposite the whole layer when their pixels
 *       arrive; tiles still waiting are skipped (no GPU work) and retried.
 * v302: previews of parked layers (thumbnails, focus view, artboard previews) draw a coarse copy
 *       from the core (previewDraw), refined to the real pixels when the layer comes back; transforms park their
 *       non-active layers right after the commit (parkCommitted).
 * v301: inactive layers live only in the core (PLAN-CORE-OWNED-LAYERS-300.md, stages 0-2).
 *
 * Parking: once the browser holds more layer pixels than the limit (Preferences > Memory, "Park inactive layers above"),
 * the least recently used inactive layer is parked, one per idle tick, so memory comes down gradually instead of in one
 * stall. A parked layer's tiles are dropped in the browser; the Rust core (lazy core mode) holds the only full copy.
 *  - Display: the tiled GPU compositor asks for parked tiles at the current level of detail (raster.lod, box-shrunk in
 *    the core) and redraws when they arrive; textures it already has are reused.
 *  - Unparking: selecting a layer, a history step that touched it, or a gated command (merge, export, ...) brings its
 *    tiles back (raster.readTiles) before anything reads them.
 *  - Tripwire: the parked tile map reports any direct read (stats + console, and starts unparking); with
 *    window.__parkTripwireThrow (tests) it throws, so missed readers show up. Writes to a parked layer always throw
 *    (RasterResources guard) rather than lose pixels.
 * Only in lazy core mode (Tauri); the web build never parks. LayerParking.stats() for diagnostics.
 */
const LayerParking=(()=>{
 const S={parked:0,unparked:0,tripwires:0,trips:[],lodRequests:0,lodTiles:0,bytesFreed:0,errors:[]};
 const parkedIds=new Map(); // rasterId -> layer
 const lastTouch=new Map(); // rasterId -> time of the last write
 const fetching=new Map(); // rasterId -> unpark promise
 const lodCache=new Map(); // rasterId -> Map('level:x:y' -> canvas | false (empty))
 const lodWant=new Map(); // rasterId -> Set('level:x:y')
 let touchedSinceHistory=new Set(),tickTimer=0,lodTimer=0,lodBytes=0;
 const LOD_BUDGET=256*1048576,TICK_MS=2000,HYSTERESIS=.85;
 const NS=()=>typeof NativeShadow!=='undefined'&&NativeShadow.lazy?.()?NativeShadow:null;
 // ---- settings: limit in GiB (0 = never park) -------------------------------------------------------------------
 let limitGiB=1;try{const v=localStorage.getItem('bungalowLayerParkGiB');if(v!==null&&v!=='')limitGiB=Math.max(0,Number(v)||0)}catch(_){}
 const limitBytes=()=>limitGiB>0?limitGiB*1073741824:Infinity;
 function bindSetting(){const el=document.getElementById('layerParkGiB');if(!el)return;el.value=limitGiB;el.onchange=()=>{limitGiB=Math.max(0,Number(el.value)||0);el.value=limitGiB;try{localStorage.setItem('bungalowLayerParkGiB',String(limitGiB))}catch(_){}schedule(200)}}
 // ---- tripwire map ------------------------------------------------------------------------------------------------
 class ParkedTiles extends Map{}
 const trip=(map,what)=>{const L=map.__layer;S.tripwires++;let where='';try{where=(new Error().stack||'').split('\n').slice(3,6).join(' | ')}catch(_){}
  if(S.trips.length<40)S.trips.push({layer:L?.name,what,where});if(S.tripwires<=5)console.warn('[Bungalow parking] parked layer read directly:',L?.name,what,where);
  if(L)unpark(L);if(window.__parkTripwireThrow)throw Error('Layer "'+(L?.name||'?')+'" is parked in the core ('+what+')')};
 for(const m of ['get','has','keys','values','entries','forEach',Symbol.iterator])ParkedTiles.prototype[m]=function(...a){trip(this,String(m));return Map.prototype[m].apply(this,a)};
 Object.defineProperty(ParkedTiles.prototype,'size',{get(){trip(this,'size');return 0}});
 for(const m of ['set','delete','clear'])ParkedTiles.prototype[m]=function(){trip(this,m);throw Error('Layer is parked in the core; it is being loaded, try again')};
 // ---- eligibility and accounting ----------------------------------------------------------------------------------
 const stack=()=>typeof layers!=='undefined'?layers:[];
 const isParked=L=>!!L?._sparse?.parked;
 function storeBytes(st){if(!st||st.parked)return 0;let n=0;for(const t of Map.prototype.values.call(st.tiles))if(t)n+=t.width*t.height*4;return n}
 function residentBytes(){let n=0;for(const L of stack())if(L._sparse)n+=storeBytes(L._sparse);return n}
 function cloneSources(){const out=new Set();for(const L of stack())if(L.instance?.src)out.add(L.instance.src);return out}
 function eligible(L,sources){const st=L._sparse;if(!st||st.parked||!L.rasterId||L.instance||L.mask||L.retained||L===AL)return false;
  if(typeof selectedStack!=='undefined'&&selectedStack.has(L))return false;if(fetching.has(L.rasterId))return false;
  const p=NS()?.pendingFor?.(L.rasterId);return !p&&storeBytes(st)>0}
 const busy=()=>{try{return !!(drawing||transformSession||projectIOBusy||historyBusy||(typeof adjustmentSession!=='undefined'&&adjustmentSession)||(typeof panning!=='undefined'&&panning))}catch(_){return true}};
 // ---- park ---------------------------------------------------------------------------------------------------------
 function park(L){const st=L._sparse,id=L.rasterId,keys=new Set();for(const [k,t] of Map.prototype.entries.call(st.tiles))if(t)keys.add(k);
  const freed=storeBytes(st),map=new ParkedTiles();map.__layer=L;st.parked={id,keys,at:performance.now()};st.tiles=map;parkedIds.set(id,L);
  previews.delete(id);S.parked++;S.bytesFreed+=freed;window.dispatchEvent(new CustomEvent('bungalow-layer-parked',{detail:{layer:L,parked:true}}))}
 // v302: after a core transform commit (app.js prepareCoreTransforms): every transformed layer but the active one is
 // parked at once instead of its result travelling back. Its current tiles (the state before the transform) go to the
 // history entry; the step is recorded as writing this layer, so undo brings it back first.
 function canParkAfterCommit(L){const st=L?._sparse;return !!(NS()&&limitGiB>0&&tiledDisplay()&&st&&!st.parked&&L.rasterId&&!L.instance&&!L.mask&&!L.retained&&L!==AL)}
 function parkCommitted(L,keys){const st=L._sparse,id=L.rasterId,map=new ParkedTiles();map.__layer=L;st.parked={id,keys:new Set(keys),at:performance.now()};st.tiles=map;parkedIds.set(id,L);previews.delete(id);dropLod(id);
  touchedSinceHistory.add(id);lastTouch.set(id,performance.now());S.parked++;S.parkedOnCommit=(S.parkedOnCommit||0)+1}
 // ---- unpark: tiles come back from the core (visible area first) ---------------------------------------------------
 function viewOrder(keys){try{const r=typeof visibleDocumentRect==='function'?visibleDocumentRect():null;if(!r)return keys;const cx=r.x+r.w/2,cy=r.y+r.h/2;return keys.sort((a,b)=>{const [ax,ay]=a.split(':').map(Number),[bx,by]=b.split(':').map(Number);return Math.hypot(ax+128-cx,ay+128-cy)-Math.hypot(bx+128-cx,by+128-cy)})}catch(_){return keys}}
 function tilesFrom(u,into){const dv=new DataView(u.buffer,u.byteOffset,u.byteLength),n=dv.getUint32(0,true);let o=4;
  for(let i=0;i<n;i++){const x=dv.getUint32(o,true),y=dv.getUint32(o+4,true),w=dv.getUint32(o+8,true),h=dv.getUint32(o+12,true),len=w*h*4,c=document.createElement('canvas');c.width=w;c.height=h;
   c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(u.buffer,u.byteOffset+o+16,len),w,h),0,0);c.__occ=null;into(x,y,c);o+=16+len}}
 function unpark(L){const st=L?._sparse,id=L?.rasterId;if(!st?.parked)return Promise.resolve();if(fetching.has(id))return fetching.get(id);const ns=NS();
  const p=(async()=>{const keys=viewOrder([...st.parked.keys]),tiles=new Map();
   if(!ns)throw Error('native core unavailable');
   for(let i=0;i<keys.length;i+=32){const u=await ns.binaryNow({method:'raster.readTiles',args:[id,keys.slice(i,i+32)]});tilesFrom(u,(x,y,c)=>tiles.set(x+':'+y,c))}
   if(st.parked){st.tiles=tiles;st.parked=null;parkedIds.delete(id);dropLod(id);S.unparked++;lastTouch.set(id,performance.now()); /* just used: last in line to park again */previews.delete(id);refreshPreviews(L); /* v302: thumbnails now from the real pixels */window.dispatchEvent(new CustomEvent('bungalow-layer-parked',{detail:{layer:L,parked:false}}))}})()
   .catch(e=>{S.errors.push(String(e?.message||e));throw e}).finally(()=>fetching.delete(id));
  fetching.set(id,p);return p}
 const ensure=list=>Promise.all([...new Set(list)].filter(isParked).map(unpark));
 const ensureAll=()=>ensure([...parkedIds.values()]);
 const ensureIds=ids=>ensure([...ids].map(id=>parkedIds.get(id)).filter(Boolean));
 // ---- display: tiles at a level of detail, fetched on demand -------------------------------------------------------
 function dropLod(id){for(const q of lodInflight)if(q.startsWith(id+'|'))lodInflight.delete(q);const m=lodCache.get(id);if(m)for(const [k,c] of m)if(c){lodBytes-=c.width*c.height*4;lru.delete(id+'|'+k)}lodCache.delete(id);lodWant.delete(id)}
 // v303: least recently used first (was insertion order: tiles still on screen were evicted and fetched again in a loop
 // once the budget filled, which froze the app on zoom/flip)
 const lru=new Map(); // 'id|level:x:y' -> [id, key], oldest first
 const touchLod=(id,k)=>{const q=id+'|'+k;lru.delete(q);lru.set(q,[id,k,performance.now()])};
 function trimLod(){if(lodBytes<=LOD_BUDGET)return;const now=performance.now();for(const [q,[id,k,at]] of lru){if(now-at<1500)return; /* in use on screen: never evicted, even over budget */const m=lodCache.get(id),c=m?.get(k);if(c)lodBytes-=c.width*c.height*4;m?.delete(k);lru.delete(q);if(lodBytes<=LOD_BUDGET*.8)return}}
 // canvas | 'empty' | null (requested; the display redraws when it arrives)
 // v304: each tile is requested once until it arrives (the display asks for missing tiles every frame: on desktop the same
 // tiles were re-requested ~60 times a second, flooding the core channel until the app crashed); one fetch runs at a
 // time; failures back off, and a layer that keeps failing is brought back (loaded) instead of being retried for ever.
 const lodInflight=new Set(); // 'id|level:x:y'
 const lodFail=new Map(); // rasterId -> {n, until}
 let lodRunning=false;
 function lodTile(st,level,x,y){const id=st.parked?.id;if(!id)return null;const k=level+':'+x+':'+y,m=lodCache.get(id),hit=m?.get(k);
  if(hit){touchLod(id,k);return hit}if(hit===false)return 'empty';
  // no painted 256px tile under this display tile: nothing to fetch
  const span=256*level;let any=false;for(const key of st.parked.keys){const [tx,ty]=key.split(':').map(Number);if(tx>=x&&tx<x+span&&ty>=y&&ty<y+span){any=true;break}}if(!any)return 'empty';
  const q=id+'|'+k;if(lodInflight.has(q))return null;const f=lodFail.get(id);if(f&&performance.now()<f.until)return null;
  lodInflight.add(q);let w=lodWant.get(id);if(!w)lodWant.set(id,w=new Set());w.add(k);if(!lodTimer&&!lodRunning)lodTimer=setTimeout(fetchLod,0);return null}
 async function fetchLod(){lodTimer=0;const ns=NS();if(!ns||lodRunning)return;lodRunning=true;let arrived=false;
  try{while(lodWant.size){const want=[...lodWant];lodWant.clear();
   for(const [id,set] of want){const L=parkedIds.get(id);if(!L){for(const k of set)lodInflight.delete(id+'|'+k);continue}const byLevel=new Map();for(const k of set){const [lv,x,y]=k.split(':');let a=byLevel.get(lv);if(!a)byLevel.set(lv,a=[]);a.push(x+':'+y)}
    let m=lodCache.get(id);if(!m)lodCache.set(id,m=new Map());
    for(const [lv,keys] of byLevel){S.lodRequests++;S.lodKeys=(S.lodKeys||0)+keys.length;
     try{const u=await ns.binaryNow({method:'raster.lod',args:[id,+lv,keys]}),got=new Set();
      tilesFrom(u,(x,y,c)=>{const k=lv+':'+x+':'+y;m.set(k,c);touchLod(id,k);got.add(x+':'+y);lodBytes+=c.width*c.height*4;S.lodTiles++});for(const k of keys)if(!got.has(k)){m.set(lv+':'+k,false);S.lodEmpty=(S.lodEmpty||0)+1}lodFail.delete(id);arrived=true}
     catch(e){const msg=String(e?.message||e),f=lodFail.get(id)||{n:0,until:0};f.n++;f.until=performance.now()+Math.min(8000,250*2**f.n);lodFail.set(id,f);S.errors.length<20&&S.errors.push('lod '+L.name+': '+msg);
      if(f.n===1)try{logMessage('warn','Parked layer could not be drawn from the core · '+L.name+' · '+msg)}catch(_){}
      if(f.n>=4){lodFail.delete(id);unpark(L).catch(()=>{})} /* keeps failing: load it instead */}
     finally{for(const k of keys)lodInflight.delete(id+'|'+lv+':'+k)}}}
   trimLod();if(arrived){arrived=false;try{maskDisplay?.refine?.()}catch(_){}}}}
  finally{lodRunning=false;if(lodWant.size&&!lodTimer)lodTimer=setTimeout(fetchLod,0)}}
 // v303: every parked layer's pixels for display tile (x, y) at this level are at hand (requests what is missing)
 function tileReady(items,level,x,y){let ok=true;const walk=list=>{for(const it of list||[]){const st=it.source?.sparseStore;if(st?.parked&&lodTile(st,level,x,y)===null)ok=false;if(it.children)walk(it.children);if(it.masks)walk(it.masks)}};walk(items);return ok}
 // ---- v302: previews. One coarse copy per parked layer (long side <= 512 px, from raster.lod in one request). Previews
 // draw it at once if present; otherwise they draw nothing this time and are redrawn when it arrives.
 const previews=new Map(); // rasterId -> {canvas, level} | 'pending'
 function previewLevel(st){let lv=1;while(lv<16&&Math.max(st.width,st.height)/lv>512)lv*=2;return lv}
 function requestPreview(L,st){const id=st.parked.id;if(previews.has(id))return;previews.set(id,'pending');const ns=NS();if(!ns){previews.delete(id);return}S.previewRequests=(S.previewRequests||0)+1;
  const lv=previewLevel(st),span=256*lv,keys=[];for(let y=0;y<st.height;y+=span)for(let x=0;x<st.width;x+=span)keys.push(x+':'+y);
  ns.binaryNow({method:'raster.lod',args:[id,lv,keys]}).then(u=>{if(previews.get(id)!=='pending')return;const c=document.createElement('canvas');c.width=Math.max(1,Math.ceil(st.width/lv));c.height=Math.max(1,Math.ceil(st.height/lv));const g=c.getContext('2d');
   tilesFrom(u,(x,y,t)=>g.drawImage(t,x/lv,y/lv));previews.set(id,{canvas:c,level:lv});S.previews=(S.previews||0)+1;refreshPreviews(L)},e=>{previews.delete(id);S.errors.push('preview '+(e?.message||e))})}
 function refreshPreviews(L){try{if(L){L._thumbRev=-1;queueLayerThumb(L)}scheduleGroupThumbnails?.();if(typeof renderArtboards==='function'&&typeof artboards!=='undefined'&&artboards.length>1)renderArtboards()}catch(_){}}
 function previewDraw(g,st,dx,dy,dw,dh,rect){const p=previews.get(st.parked?.id);if(!p||p==='pending'){const L=parkedIds.get(st.parked?.id);if(L)requestPreview(L,st);return false}
  g.save();if(rect){const sx=dw/st.width,sy=dh/st.height;g.beginPath();g.rect(dx+rect.x*sx,dy+rect.y*sy,rect.w*sx,rect.h*sy);g.clip()}g.imageSmoothingEnabled=true;g.drawImage(p.canvas,0,0,p.canvas.width,p.canvas.height,dx,dy,dw*(p.canvas.width*p.level/st.width),dh*(p.canvas.height*p.level/st.height));g.restore();return true}
 // ---- policy: one layer per idle tick while over the limit ----------------------------------------------------------
 function schedule(ms=TICK_MS){clearTimeout(tickTimer);tickTimer=setTimeout(tick,ms)}
 const tiledDisplay=()=>{try{return maskDisplay?.kind==='tiled-gpu'&&!maskDisplay.lost&&!maskTiledFailed}catch(_){return false}};
 function tick(){schedule();if(!NS()||!(limitGiB>0)||!tiledDisplay())return;if(busy())return; // parked layers are drawn by the tiled GPU compositor only
  const used=residentBytes(),limit=limitBytes();if(used<=limit&&!parkedIds.size)return;
  if(used>limit||(S.parking&&used>limit*HYSTERESIS)){S.parking=used>limit*HYSTERESIS;const src=cloneSources(),cands=stack().filter(L=>eligible(L,src)).sort((a,b)=>(lastTouch.get(a.rasterId)||0)-(lastTouch.get(b.rasterId)||0));
   if(cands.length)park(cands[0]);else S.parking=false}else{S.parking=false;
   // v302: well under the limit again (e.g. layers parked by a transform commit): bring the most recently used parked
   // layer back, one per tick, so it is ready before it is needed
   if(parkedIds.size&&!fetching.size&&used<limit*.6){const L=[...parkedIds.values()].sort((a,b)=>(lastTouch.get(b.rasterId)||0)-(lastTouch.get(a.rasterId)||0))[0];const st=L._sparse;
    let est=0;if(st?.parked)est=st.parked.keys.size*262144;if(used+est<limit*.6)unpark(L).catch(()=>{})}}}
 // ---- hooks ---------------------------------------------------------------------------------------------------------
 // RasterResources pre-write guard: records writes (LRU, history) and refuses writes to a parked layer.
 const WRITE=new Set(['fillRegion','clearRegion','putPixels','invertPixels','floodFill','placeImage','fillGeometry','composeRegion','installTiles','swapTiles','detachTiles','fillTiles','writeRegion','replaceSurface','restoreSurface','adoptSurface']);
 function guard(name,id){if(typeof id!=='string')return;if(WRITE.has(name)){lastTouch.set(id,performance.now());touchedSinceHistory.add(id);const L=parkedIds.get(id);if(L){S.tripwires++;unpark(L);throw Error('Layer "'+L.name+'" is parked in the core; it is being loaded, try again')}}}
 // doH(entry): the layers this step wrote, so undo/redo can bring them back first
 function noteHistory(entry){if(entry&&touchedSinceHistory.size){try{Object.defineProperty(entry,'__parkIds',{value:[...touchedSinceHistory],configurable:true})}catch(_){}}touchedSinceHistory=new Set()}
 const ensureForHistory=entry=>entry?.__parkIds?ensureIds(entry.__parkIds):Promise.resolve();
 // the active layer is always local
 function selectionChanged(){try{if(AL)ensure([AL])}catch(_){}} // v302: only the active layer; other selected layers come back when a command needs them (editBlocked gate)
 // commands that read other layers wait until every parked layer is back (sync functions return a promise then)
 const GATED=['mergeSelectedArtboards','exportKrita','exportOpenRaster','exportPSD','exportSelectedNodes','exportTexturePNG','exportArtboardBatch','exportTextureAssets','copyArtboards'];
 // v305: mergeLayers (every merge goes through it) loads just the layers it merges: the items, masks targeting them and the
 // layers of groups being flattened. exportFlatImage / copyPNG use the core composite instead (app.js flatForExport).
 function mergeTargets(items,replaceGroup){const out=new Set(items||[]);try{for(const M of stack())if(M.mask&&M.maskTarget&&out.has(M.maskTarget))out.add(M);
  const gs=Array.isArray(replaceGroup)?replaceGroup:replaceGroup?[replaceGroup]:[];for(const G of gs)for(const L of stack()){let g=L.group;while(g&&g!==G)g=g.group;if(g===G)out.add(L)}}catch(_){}return [...out]}
 function gateMerge(){const f=window.mergeLayers;if(typeof f!=='function'||f.__parkGated)return;const g=function(items,name,group,replaceGroup){const want=mergeTargets(items,replaceGroup).filter(isParked);if(!want.length)return f.apply(this,arguments);const a=arguments;S.targetedLoads=(S.targetedLoads||0)+1;return ensure(want).then(()=>f.apply(this,a),e=>{toast?.('Could not load parked layers: '+(e?.message||e))})};g.__parkGated=true;window.mergeLayers=g}
 function gate(){for(const n of GATED){const f=window[n];if(typeof f!=='function'||f.__parkGated)continue;const g=function(...a){if(!parkedIds.size)return f.apply(this,a);return ensureAll().then(()=>f.apply(this,a),e=>{toast?.('Could not load parked layers: '+(e?.message||e))})};g.__parkGated=true;window[n]=g}}
 function start(){bindSetting();gate();gateMerge();schedule(3000);
  // editBlocked() opens most commands: while the active or a selected layer is still coming back, they wait (toast)
  {const f=window.editBlocked;if(typeof f==='function'&&!f.__parkHooked){const g=function(...a){if(parkedIds.size){const want=[];try{if(AL)want.push(AL);for(const n of selectedStack)if(n?._sparse)want.push(n)}catch(_){}
   if(want.some(isParked)){ensure(want);toast?.('Loading layer…');return true}}return f.apply(this,a)};g.__parkHooked=true;window.__editBlockedUnparked=f;window.editBlocked=g}}
  for(const n of ['select','setStackSelection']){const f=window[n];if(typeof f==='function'&&!f.__parkHooked){const g=function(...a){const r=f.apply(this,a);selectionChanged();return r};g.__parkHooked=true;window[n]=g}}}
 return Object.freeze({tileReady,canParkAfterCommit,parkCommitted,previewDraw,start,park,unpark,ensure,ensureAll,ensureForHistory,noteHistory,guard,lodTile,isParked,tick,residentBytes,
  enabled:()=>!!NS()&&limitGiB>0,setLimitGiB:v=>{limitGiB=Math.max(0,+v||0)},parkedCount:()=>parkedIds.size,
  stats:()=>({...S,trips:S.trips.slice(),errors:S.errors.slice(),parkedNow:parkedIds.size,residentMB:Math.round(residentBytes()/1048576),lodMB:Math.round(lodBytes/1048576),limitGiB})});
})();
LayerParking.start();
