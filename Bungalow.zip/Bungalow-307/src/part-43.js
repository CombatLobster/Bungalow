/* Brush settings discovery v174: prefer named sections/groups, then control labels,
 * and only fall back to tooltip text. Filtering never alters native hidden states. */
(function(G){
 const root=$('brushControls'),input=$('brushSettingsSearch'),status=document.createElement('p');status.id='brushSettingsSearchStatus';status.className='smoothing-note';status.setAttribute('role','status');status.hidden=true;input.after(status);let layout=null;
 const normal=text=>String(text||'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
 const matches=(text,terms)=>terms.every(term=>normal(text).includes(term));
 function nameOf(el){const clone=el.cloneNode(true);clone.querySelectorAll('select,option,output,svg,canvas,p,small,textarea').forEach(n=>n.remove());return clone.textContent}
 function refresh(){const terms=normal(input.value).split(/\s+/).filter(Boolean),allSections=[...root.querySelectorAll(':scope > details')];root.querySelectorAll('.brush-search-hidden').forEach(el=>el.classList.remove('brush-search-hidden'));
  const sections=allSections.filter(section=>!section.hidden&&getComputedStyle(section).display!=='none');
  if(!terms.length){if(layout)for(const [el,open] of layout)if(el.isConnected)el.open=open;layout=null;status.hidden=true;return}
  if(!layout)layout=new Map();for(const el of root.querySelectorAll('details'))if(!layout.has(el))layout.set(el,el.open);
  const groups=[];for(const section of sections){const summary=section.querySelector(':scope > summary');let group={section,heading:summary,items:[]};groups.push(group);for(const child of section.children){if(child===summary)continue;if(/^H[2-6]$/.test(child.tagName)){group={section,heading:child,items:[]};groups.push(group)}else group.items.push(child)}}
  const titleSections=new Set(sections.filter(s=>matches(s.querySelector(':scope > summary')?.textContent,terms))),headingGroups=new Set(groups.filter(g=>g.heading?.tagName!=='SUMMARY'&&matches(g.heading?.textContent,terms)));
  // A heading match is more useful than unrelated controls whose help mentions that heading.
  const named=new Set(),tooltips=new Set();if(!titleSections.size&&!headingGroups.size)for(const g of groups)for(const item of g.items){if(matches(nameOf(item),terms))named.add(item);if(matches([item.title,...[...item.querySelectorAll('[title]')].map(n=>n.title)].join(' '),terms))tooltips.add(item)}
  const rows=named.size?named:tooltips,visibleSections=new Set(),shown=new Set();for(const g of groups){const whole=titleSections.has(g.section)||headingGroups.has(g);const items=whole?g.items:g.items.filter(item=>rows.has(item));if(whole||items.length){visibleSections.add(g.section);if(g.heading)shown.add(g.heading);for(const item of items)shown.add(item)}}
  for(const section of sections){const visible=visibleSections.has(section);section.classList.toggle('brush-search-hidden',!visible);if(visible)section.open=true;for(const child of section.children){if(child.tagName==='SUMMARY')continue;child.classList.toggle('brush-search-hidden',!shown.has(child));if(shown.has(child)){if(child.tagName==='DETAILS')child.open=true;for(const nested of child.querySelectorAll('details'))nested.open=true}}}
  // Hide unrelated standalone previews while searching, without moving or recreating controls.
  for(const child of root.children)if(child!==input&&child!==status&&child.tagName!=='DETAILS')child.classList.add('brush-search-hidden');
  status.hidden=false;const text=visibleSections.size?`${visibleSections.size} matching section${visibleSections.size===1?'':'s'}`:'No matching brush controls';if(status.textContent!==text)status.textContent=text;
 }
 input.oninput=()=>{refresh();cloop();scheduleStrokePreview()};root.addEventListener('change',()=>{if(input.value.trim())queueMicrotask(refresh)});G.BrushSettingsSearch={refresh};refresh();
})(globalThis);
