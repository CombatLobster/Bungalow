// Linked-image decoding and bounded diagnostics; no source names or paths in telemetry.
const FileUpdateRuntime=(()=>{
 const checks=new WeakMap(),stats={},events=[],lastLog=new Map(),jobs=new Map();let worker=null,failed=false,serial=0;
 function record(kind,data={},ms=0){if(typeof debugMode==='undefined'||!debugMode)return;const s=stats[kind]||(stats[kind]={count:0,totalMs:0,maxMs:0});s.count++;s.totalMs+=ms;s.maxMs=Math.max(s.maxMs,ms);const e={kind,ms:+ms.toFixed(3),...data};events.push(e);if(events.length>60)events.shift();const now=performance.now();if(now-(lastLog.get(kind)??-Infinity)>2000){lastLog.set(kind,now);logMessage('debug','Linked files',e)}}
 function due(handle,force=false,now=performance.now()){return force||now>=(checks.get(handle)?.next??0)}
 function observed(handle,file,force=false,now=performance.now()){const signature=file.lastModified+':'+file.size,old=checks.get(handle),unchanged=!force&&old?.signature===signature?old.unchanged+1:0,period=Math.min(12000,1500*2**Math.floor(unchanged/4));checks.set(handle,{signature,unchanged,next:now+period});return period}
 function fail(){failed=true;worker?.terminate();worker=null;for(const j of jobs.values()){clearTimeout(j.timer);j.reject(Error('Image worker unavailable'))}jobs.clear()}
 function getWorker(){if(failed)throw Error('Image worker unavailable');if(worker)return worker;const code='onmessage=async({data:{id,blob}})=>{try{const image=await createImageBitmap(blob);postMessage({id,image},[image])}catch(e){postMessage({id,error:e.message})}}',url=URL.createObjectURL(new Blob([code],{type:'text/javascript'}));try{worker=new Worker(url)}catch(e){failed=true;throw e}finally{URL.revokeObjectURL(url)}worker.onmessageerror=fail;worker.onerror=e=>{e.preventDefault();fail()};worker.onmessage=({data})=>{const j=jobs.get(data.id);if(!j){data.image?.close();return}jobs.delete(data.id);clearTimeout(j.timer);if(data.error)j.reject(Error(data.error));else j.resolve(data.image)};return worker}
 async function decode(blob,fallback){
  // Preserve existing SVG/GIF and layered-format behaviour. Returned bitmaps retain full resolution.
  if(!/^(image\/(png|jpeg|webp|bmp))$/i.test(blob.type))return fallback(blob);
  const start=performance.now();try{const w=getWorker(),id=++serial;const image=await new Promise((resolve,reject)=>{jobs.set(id,{resolve,reject,timer:setTimeout(fail,30000)});try{w.postMessage({id,blob})}catch(e){fail()}});record('worker-decode',{bytes:blob.size,width:image.width,height:image.height},performance.now()-start);return image}catch(e){record('worker-fallback',{bytes:blob.size},performance.now()-start);return fallback(blob)}
 }
 return {due,observed,record,decode,snapshot:(includeEvents=true)=>({stats:structuredClone(stats),...(includeEvents?{events:structuredClone(events)}:{}),worker:{active:!!worker,failed,pending:jobs.size},timingNote:'Wall time; asynchronous stages may overlap other work'})};
})();
