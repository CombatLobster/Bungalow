
/* ====== Build 193: Tauri desktop shell support ====== */
// In a browser this is a thin pass-through. Inside Tauri, window.open is not available, so new windows are created through Tauri,
// and the windows talk to each other over a BroadcastChannel (same origin, so it carries files and blobs, unlike Tauri events).
const TauriBridge=(()=>{
 const T=window.__TAURI__,I=window.__TAURI_INTERNALS__,enabled=!!(T||I);
 if(!enabled)return {enabled:false,open:url=>window.open(url||'about:blank','_blank'),from:(e,win)=>!!e.source&&e.source===win,closeSelf:()=>window.close()};
 const q=new URLSearchParams(location.search),parentLabel=q.get('bungParent');
 const label=q.get('bungLabel')||(()=>{try{return I?.metadata?.currentWebview?.label||I?.metadata?.currentWindow?.label||'main'}catch(_){return 'main'}})();
 const channel=new BroadcastChannel('bungalow-windows');
 channel.onmessage=e=>{const m=e.data;if(!m||m.to!==label)return;const ev=new MessageEvent('message',{data:m.data});ev.bungFrom=m.from;window.dispatchEvent(ev)};
 const say=message=>{try{toast(message)}catch(_){console.warn(message)}};
 const invoke=(cmd,args)=>I?.invoke?I.invoke(cmd,args):Promise.reject(Error('Tauri IPC is not available'));
 const hint=' · allow core:webview:allow-create-webview-window in the Tauri capabilities';
 async function create(child,raw){
  const url=new URL(raw,location.href);url.searchParams.set('bungParent',label);url.searchParams.set('bungLabel',child.label);
  // a path relative to the app, so the new window gets the same origin (shared storage) and the same IPC access.
  // dragDropEnabled:false lets files dropped from the desktop reach the page as ordinary drop events (Tauri otherwise swallows them on Windows)
  const rel=(url.pathname.replace(/^\//,'')||'index.html')+url.search+url.hash,title=document.title||'Bungalow',width=Math.max(640,innerWidth),height=Math.max(480,innerHeight);
  try{
   if(T?.webviewWindow?.WebviewWindow){const w=new T.webviewWindow.WebviewWindow(child.label,{url:rel,title,width,height,focus:true,dragDropEnabled:false});w.once?.('tauri://error',e=>{child.closed=true;say('Could not open a window: '+(e?.payload||'unknown error')+hint)})}
   else await invoke('plugin:webview|create_webview_window',{options:{label:child.label,url:rel,title,width,height,focus:true,dragDropEnabled:false}});
  }catch(error){child.closed=true;say('Could not open a window: '+(error?.message||error)+hint)}
 }
 async function closeLabel(l){
  try{const w=await T?.webviewWindow?.WebviewWindow?.getByLabel?.(l);if(w){await w.close();return}}catch(_){}
  try{await invoke('plugin:window|close',{label:l})}catch(_){}
 }
 let serial=0;
 // a window-like object: assigning location.href creates the window, postMessage reaches it, close() closes it
 function open(url){
  const child={tauri:true,label:'bung-'+Date.now().toString(36)+'-'+(++serial),closed:false,_url:'',
   location:{get href(){return child._url},set href(u){child._url=String(u);create(child,u)}},
   postMessage(data){channel.postMessage({to:child.label,from:label,data})},
   close(){if(!child.closed){child.closed=true;closeLabel(child.label)}}};
  if(url&&url!=='about:blank'){child._url=url;create(child,url)}
  return child;
 }
 if(parentLabel&&!window.opener){
  const stub={tauri:true,label:parentLabel,closed:false,postMessage(data){channel.postMessage({to:parentLabel,from:label,data})}};
  try{Object.defineProperty(window,'opener',{value:stub,configurable:true,writable:true})}catch(_){try{window.opener=stub}catch(__){}}
 }
 const from=(e,win)=>e.source?e.source===win:!!win?.tauri&&e.bungFrom===win.label;
 const closeSelf=()=>{if(parentLabel)closeLabel(label);else window.close()};
 // Native save dialogs may return extensionless paths even when defaultPath has an extension.
 let saveBlob=null;
 if(T?.dialog?.save&&T?.fs?.writeFile){
  saveBlob=async(blob,name,options={})=>{
   const ext=/\.([a-z0-9]{1,12})$/i.exec(name)?.[1]||'',documentCreated=typeof documentMeta==='undefined'?null:documentMeta.created;
   const picked=await T.dialog.save({defaultPath:options.defaultPath||name,...(ext?{filters:[{name:ext.toUpperCase()+' file',extensions:[ext]}]}:{})});if(!picked)return null;
   const path=ext&&!picked.toLowerCase().endsWith('.'+ext.toLowerCase())?picked.replace(/[. ]+$/,'')+'.'+ext:picked;
   if(path!==picked&&T.fs.exists&&await T.fs.exists(path)){if(typeof showConfirm!=='function'||!await showConfirm('Replace the existing file “'+path.split(/[\\/]/).pop()+'”?'))return null}
   await T.fs.writeFile(path,new Uint8Array(await blob.arrayBuffer()));const actual=path.split(/[\\/]/).pop();window.dispatchEvent(new CustomEvent('bungalow-download',{detail:{path,name:actual,documentCreated}}));return {path,name:actual};
  };
  const click=HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click=function(){
   if(this.download&&/^blob:/.test(this.href)){const name=this.download;fetch(this.href).then(r=>r.blob()).then(blob=>saveBlob(blob,name)).catch(error=>say('Could not save '+name+': '+(error?.message||error)));return}
   return click.apply(this,arguments);
  };
 }
 return {enabled:true,label,parentLabel,open,from,closeSelf,saveBlob};
})();

