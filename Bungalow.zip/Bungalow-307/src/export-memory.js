
/* ====== Build 197: per-file export options, last export actions ====== */
var tipPendingTimer=0;
const ExportMemory=(()=>{
 const page=$('exportPage');if(!page)return {};
 const controls=()=>[...page.querySelectorAll('input[id],select[id]')].filter(el=>el.type!=='file'&&el.type!=='button'&&!el.closest('#exportBoardList'));
 const lsKey=()=>'bungExport:'+documentMeta.created,dirKey=()=>'exportdir:'+documentMeta.created;
 let restoring=false,defaults=null,last=null,directoryRequest=0;
 const capture=()=>{const values={};for(const el of controls())if(el.id!=='exportName')values[el.id]=el.type==='checkbox'||el.type==='radio'?el.checked:el.value;return {name:exportNameCustom?$('exportName').value.slice(0,100):'',values,last,iteration:ExportIterations.counter,at:Date.now()}};
 const clean=o=>{if(!o||typeof o!=='object')return null;const values={};for(const [k,v] of Object.entries(o.values||{}).slice(0,40))if(/^(?:export|png)[A-Za-z0-9]+$|^trn$/.test(k)&&(typeof v==='boolean'||typeof v==='string'&&v.length<=200))values[k]=v;
  const l=o.last&&typeof o.last==='object'&&typeof o.last.name==='string'?{name:o.last.name.slice(0,200),path:typeof o.last.path==='string'?o.last.path.slice(0,1000):'',at:Number.isFinite(o.last.at)?o.last.at:0}:null;
  return {name:typeof o.name==='string'?o.name.slice(0,100):'',values,last:l,iteration:Number.isInteger(o.iteration)&&o.iteration>=0&&o.iteration<999999?o.iteration:0,at:Number.isFinite(o.at)?o.at:0}};
 window.sanitizeExportMemory=clean;
 function save(){if(restoring||!documentMeta)return;const o=capture();documentMeta.export=o;try{localStorage.setItem(lsKey(),JSON.stringify(o))}catch(_){}}
 function apply(o){
  restoring=true;
  try{
   for(const [id,v] of Object.entries(o.values||{})){const el=$(id);if(!el||el.closest('#exportBoardList')||el.type==='file')continue;if(el.type==='checkbox'||el.type==='radio')el.checked=!!v;else if(el.tagName==='SELECT'){if([...el.options].some(op=>op.value===String(v)))el.value=v}else el.value=v;el.dispatchEvent(new Event('change',{bubbles:true}))}
   if(o.name){$('exportName').value=o.name;exportNameCustom=true}else{exportNameCustom=false;syncExportName()}
   last=o.last||null;ExportIterations.restore(o.iteration||0);
  }finally{restoring=false}
  syncLast();
 }
 async function restore(){
  const meta=documentMeta,request=++directoryRequest,folderKey=dirKey();
  const stored=(()=>{try{return JSON.parse(localStorage.getItem(lsKey())||'null')}catch(_){return null}})();
  const inFile=clean(documentMeta.export),here=clean(stored),o=inFile&&here?(here.at>inFile.at?here:inFile):inFile||here||defaults;if(o)apply(o);   // the newer of the file's copy and this machine's
  // the export folder follows the file too (the browser asks again for permission when it has expired)
  exportDirectory=null;syncExportLocation();
  let h=null;try{h=await instGetHandle(folderKey)}catch(_){}
  if(request!==directoryRequest||documentMeta!==meta)return;exportDirectory=h&&h.kind==='directory'?h:null;syncExportLocation();
 }
 const syncLast=()=>{for(const id of ['exportShowLast','exportOpenLast']){const b=$(id);if(b)b.disabled=!(last&&last.path)}const s=$('exportLastName');if(s)s.textContent=last?'Last export · '+last.name:''};
 async function opener(fn,path){const O=window.__TAURI__?.opener;if(O?.[fn])return O[fn](path);const I=window.__TAURI_INTERNALS__;if(!I?.invoke)throw Error('not available');return fn==='revealItemInDir'?I.invoke('plugin:opener|reveal_item_in_dir',{paths:[path]}):I.invoke('plugin:opener|open_path',{path})}
 async function act(fn){
  if(!TauriBridge.enabled){toast('Opening the last export needs the desktop app');return}
  if(!last?.path){toast(last?'This export was saved without a known location':'No export recorded for this file yet');return}
  try{await opener(fn,last.path)}catch(error){toast('Could not '+(fn==='openPath'?'open':'show')+' the file: '+(error?.message||error))}
 }
 // controls
 const row=document.createElement('div');row.className='export-location';row.innerHTML='<span id="exportLastName"></span><button id="exportShowLast" title="Show the last exported file in its folder">Show in folder</button><button id="exportOpenLast" title="Open the last exported file">Open</button>';
 $('exportLocationHint')?.before(row);$('exportShowLast').onclick=()=>act('revealItemInDir');$('exportOpenLast').onclick=()=>act('openPath');
 page.addEventListener('change',save);page.addEventListener('input',save);
 window.addEventListener('bungalow-download',e=>{const {path,name,documentCreated}=e.detail||{};if(documentCreated&&documentCreated!==documentMeta.created)return;if(!name||/\.bung$/i.test(name))return;last={name,path:path||'',at:Date.now()};save();syncLast()});
 // remember browser exports too (no path, but the name and time)
 {const deliver=window.deliverDocumentExport;window.deliverDocumentExport=async function(blob,name){const meta=documentMeta,r=await deliver.apply(this,arguments);if(documentMeta===meta&&(!TauriBridge.enabled||exportDirectory)){last={name:r||name,path:'',at:Date.now()};save();syncLast()}return r}}
 // the chosen export folder is stored with the file
 {const choose=$('chooseExportLocation'),reset=$('resetExportLocation');choose.onclick=async e=>{const meta=documentMeta,key=dirKey(),request=++directoryRequest;try{const folder=await window.showDirectoryPicker({id:'bungalow-exports',mode:'readwrite'});if(documentMeta!==meta||request!==directoryRequest)return;exportDirectory=folder;syncExportLocation();instPutHandle(key,folder)}catch(error){if(documentMeta===meta&&error.name!=='AbortError')toast('Could not choose export folder: '+error.message)}};const resetPrior=reset.onclick;reset.onclick=e=>{++directoryRequest;resetPrior.call(reset,e);instPutHandle(dirKey(),null)}}
 defaults=capture();defaults.last=null;
 addEventListener('bungalow-document-changed',restore);restore();
 return {capture,apply,get last(){return last},act,save};
})();
window.ExportMemory=ExportMemory;
ACTIONS.push({id:'showLastExport',g:'File',l:'Export · Show last export in folder',k:[],d:()=>ExportMemory.act('revealItemInDir')},{id:'openLastExport',g:'File',l:'Export · Open last export',k:[],d:()=>ExportMemory.act('openPath')});

