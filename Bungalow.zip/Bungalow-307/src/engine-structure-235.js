/* v235: DOM-free structural command planning. Snapshots contain only IDs,
 * hierarchy, visibility and selection. No pixels, node objects or UI resources.
 * The host owns the node/resource registry and authoritative history for now.
 */
const BungalowStructure=(()=>{
 'use strict';
 function snapshot(state){
  if(!state||state.version!==1||!['layers','groups','nodes','selection'].every(k=>Array.isArray(state[k])))throw new TypeError('Invalid structural state');
  const layers=[...state.layers],groups=[...state.groups],ids=[...layers,...groups],set=new Set(ids),groupSet=new Set(groups);
  if(!layers.length||ids.some(id=>typeof id!=='string'||!id)||set.size!==ids.length||state.nodes.length!==ids.length)throw new TypeError('Invalid structural node IDs');
  const nodes=state.nodes.map(n=>{
   if(!n||!set.has(n.id)||!['layer','group'].includes(n.kind)||groupSet.has(n.id)!==(n.kind==='group')||n.parent!==null&&!groupSet.has(n.parent)||typeof n.vis!=='boolean')throw new TypeError('Invalid structural node');
   if(n.kind==='group'&&(typeof n.collapsed!=='boolean'||n.emptyPosition!==null&&!Number.isFinite(n.emptyPosition)))throw new TypeError('Invalid group structure');
   const target=n.target??null;if(n.kind==='layer'&&target!==null&&!layers.includes(target))throw new TypeError('Invalid structural layer target');
   return {id:n.id,kind:n.kind,parent:n.parent,vis:n.vis,...(n.kind==='group'?{collapsed:n.collapsed,emptyPosition:n.emptyPosition}:{target})};
  });
  const byId=new Map(nodes.map(n=>[n.id,n]));if(byId.size!==ids.length)throw new TypeError('Duplicate structural node');
  const ancestors=new Map();
  for(const n of nodes){const seen=new Set([n.id]),parents=[];let p=n.parent;while(p!==null){if(seen.has(p)||parents.length>=64)throw new TypeError('Cyclic or excessively deep structure');seen.add(p);parents.push(p);p=byId.get(p).parent}ancestors.set(n.id,parents)}
  const membership=new Map(groups.map(id=>[id,[]]));layers.forEach((id,i)=>{for(const parent of ancestors.get(id))membership.get(parent).push(i)});
  for(const indices of membership.values())if(indices.length&&indices.at(-1)-indices[0]+1!==indices.length)throw new TypeError('Noncontiguous group layers');
  if(!layers.includes(state.active)||state.anchor!==null&&!set.has(state.anchor)||state.selection.some(id=>!set.has(id))||new Set(state.selection).size!==state.selection.length)throw new TypeError('Invalid structural selection');
  return {version:1,layers,groups,nodes:ids.map(id=>byId.get(id)),selection:[...state.selection],anchor:state.anchor,active:state.active};
 }
 function dispatch(state,request){
  const before=snapshot(state);
  if(!['ungroup','group','move','insert','delete'].includes(request?.type)||request.type!=='insert'&&!Array.isArray(request.ids))throw new TypeError('Unsupported structural command');
  if(request.type==='group')return group(before,request);
  if(request.type==='move')return move(before,request);
  if(request.type==='insert')return insert(before,request);
  if(request.type==='delete')return remove(before,request);
  const byId=new Map(before.nodes.map(n=>[n.id,n])),requested=new Set(request.ids);
  for(const id of requested)if(!before.groups.includes(id))throw new TypeError('Ungroup requires live group IDs');
  // Selecting an ancestor already includes its descendants; ungroup only roots.
  const roots=new Set([...requested].filter(id=>{for(let p=byId.get(id).parent;p!==null;p=byId.get(p).parent)if(requested.has(p))return false;return true}));
  if(!roots.size)return {version:1,type:'ungroup',changed:false,undo:before,redo:snapshot(before)};
  const children=new Map([...roots].map(id=>[id,before.nodes.filter(n=>n.parent===id).map(n=>n.id)]));
  const after=snapshot(before);
  after.nodes=after.nodes.filter(n=>!roots.has(n.id));after.groups=after.groups.filter(id=>!roots.has(id));
  for(const n of after.nodes)if(roots.has(n.parent)){const removed=byId.get(n.parent);n.parent=removed.parent;if(!removed.vis)n.vis=false}
  after.selection=[...new Set(before.selection.flatMap(id=>children.get(id)||[id]))];
  if(roots.has(after.anchor))after.anchor=after.selection.includes(after.active)?after.active:after.selection.at(-1)||null;
  return {version:1,type:'ungroup',changed:true,undo:before,redo:snapshot(after)};
 }
 // v233: group creation plans hierarchy and order without creating resources.
 function group(before,request){
  const byId=new Map(before.nodes.map(n=>[n.id,n])),requested=new Set(request.ids);
  for(const id of requested)if(!byId.has(id))throw new TypeError('Group requires live node IDs');
  const inside=(parent,id)=>{for(let p=byId.get(id).parent;p!==null;p=byId.get(p).parent)if(p===parent)return true;return false};
  const roots=[...requested].filter(id=>![...requested].some(g=>g!==id&&inside(g,id)));
  if(!roots.length)return {version:1,type:'group',changed:false,undo:before,redo:snapshot(before)};
  if(typeof request.id!=='string'||!request.id||byId.has(request.id))throw new TypeError('A fresh group ID is required');
  let parent=byId.get(roots[0]).parent;
  while(parent!==null&&!roots.every(id=>byId.get(id).parent===parent||inside(parent,id)))parent=byId.get(parent).parent;
  const members=id=>before.layers.filter(layer=>layer===id||inside(id,layer)),base=new Set(roots.flatMap(members)),moving=new Set(base),after=snapshot(before),afterById=new Map(after.nodes.map(n=>[n.id,n]));
  for(const id of before.groups){const list=members(id);if(list.length&&list.every(layer=>base.has(layer)))afterById.get(id).emptyPosition=before.layers.indexOf(list.at(-1))-.5}
  for(const id of before.layers){const target=byId.get(id).target;if(target&&moving.has(target))moving.add(id)}
  const block=before.layers.filter(id=>moving.has(id)),remaining=before.layers.filter(id=>!moving.has(id)),highest=block.length?before.layers.indexOf(block.at(-1)):before.layers.length;
  let index=before.layers.slice(0,highest+1).filter(id=>!moving.has(id)).length;
  for(const id of roots){let sibling=id;while(byId.get(sibling).parent!==null&&byId.get(sibling).parent!==parent)sibling=byId.get(sibling).parent;const rest=members(sibling).filter(layer=>!moving.has(layer));if(rest.length)index=Math.max(index,before.layers.slice(0,before.layers.indexOf(rest.at(-1))+1).filter(layer=>!moving.has(layer)).length)}
  remaining.splice(index,0,...block);after.layers=remaining;
  after.groups.push(request.id);after.nodes.push({id:request.id,kind:'group',parent,vis:true,collapsed:false,emptyPosition:null});
  for(const id of roots)afterById.get(id).parent=request.id;
  // Keep attached masks in their target's group; otherwise an interleaved mask
  // can split the new group's layers and produce an invalid saved hierarchy.
  for(const id of block){const target=byId.get(id).target;if(target&&moving.has(target))afterById.get(id).parent=afterById.get(target).parent}
  after.selection=[request.id];
  return {version:1,type:'group',changed:true,undo:before,redo:snapshot(after)};
 }
 // v234: reorder/reparent blocks and empty groups using document-space order.
 function move(before,request){
  const byId=new Map(before.nodes.map(n=>[n.id,n])),requested=new Set(request.ids),parent=request.parent??null,anchor=request.anchor??null,above=request.above??true;
  if(parent!==null&&!before.groups.includes(parent)||anchor!==null&&(!byId.has(anchor)||byId.get(anchor).parent!==parent)||typeof above!=='boolean')throw new TypeError('Invalid move destination');
  for(const id of requested)if(!byId.has(id))throw new TypeError('Move requires live node IDs');
  const inside=(p,id)=>{for(let g=byId.get(id).parent;g!==null;g=byId.get(g).parent)if(g===p)return true;return false};
  const roots=[...requested].filter(id=>![...requested].some(g=>g!==id&&inside(g,id))),noop=()=>({version:1,type:'move',changed:false,undo:before,redo:snapshot(before)});
  if(!roots.length||roots.some(id=>id===parent||parent!==null&&inside(id,parent)||id===anchor||anchor!==null&&inside(id,anchor)))return noop();
  const members=(id,order=before.layers)=>id===null?[]:order.filter(layer=>layer===id||inside(id,layer)),base=new Set(roots.flatMap(id=>members(id))),moving=new Set(base),after=snapshot(before),afterById=new Map(after.nodes.map(n=>[n.id,n]));
  for(const id of before.groups){const list=members(id);if(list.length&&list.every(layer=>base.has(layer)))afterById.get(id).emptyPosition=before.layers.indexOf(list.at(-1))-.5}
  for(const id of before.layers){const target=byId.get(id).target;if(target&&moving.has(target))moving.add(id)}
  const block=before.layers.filter(id=>moving.has(id)),remaining=before.layers.filter(id=>!moving.has(id)),target=anchor??parent;
  let reference=members(target).filter(id=>!moving.has(id));
  for(let p=parent===null?null:byId.get(parent).parent;!reference.length&&!Number.isFinite(afterById.get(target)?.emptyPosition)&&p!==null;p=byId.get(p).parent)reference=members(p).filter(id=>!moving.has(id));
  let index=remaining.length;
  if(reference.length)index=above?remaining.indexOf(reference.at(-1))+1:remaining.indexOf(reference[0]);
  else if(Number.isFinite(afterById.get(target)?.emptyPosition)){const position=afterById.get(target).emptyPosition;index=remaining.filter(id=>before.layers.indexOf(id)<position).length}
  else if(!above&&parent===null)index=0;
  remaining.splice(index,0,...block);after.layers=remaining;
  const position=id=>{const list=members(id,remaining);return list.length?remaining.indexOf(list.at(-1)):afterById.get(id).emptyPosition??Infinity};
  let emptyPosition=index-.5;
  if(anchor!==null){const at=position(anchor);if(Number.isFinite(at)){const peers=before.nodes.filter(n=>n.parent===parent&&!roots.includes(n.id)&&n.id!==anchor).map(n=>position(n.id)).filter(Number.isFinite),neighbours=peers.filter(p=>above?p>at:p<at),edge=neighbours.length?(above?Math.min(...neighbours):Math.max(...neighbours)):at+(above?1:-1);emptyPosition=(at+edge)/2}}
  const emptyRoots=roots.filter(id=>byId.get(id).kind==='group'&&!members(id).length).sort((a,b)=>position(a)-position(b));
  for(const id of roots){const node=afterById.get(id);node.parent=parent;if(emptyRoots.includes(id))node.emptyPosition=emptyPosition+(emptyRoots.indexOf(id)-(emptyRoots.length-1)/2)*.00001}
  for(const id of block){const target=byId.get(id).target;if(target&&moving.has(target))afterById.get(id).parent=afterById.get(target).parent}
  after.selection=roots;
  const redo=snapshot(after);return {version:1,type:'move',changed:JSON.stringify(before)!==JSON.stringify(redo),undo:before,redo};
 }
 // v235: insertion/removal operate on records; resource allocation stays with
 // the host. Explicit removal sets let composite operations retain their policy.
 function removeRecords(before,ids){
  const known=new Set(before.nodes.map(n=>n.id)),gone=new Set(ids);
  for(const id of gone)if(!known.has(id))throw new TypeError('Removal requires live node IDs');
  const after=snapshot(before),byId=new Map(before.nodes.map(n=>[n.id,n]));
  for(const G of after.nodes.filter(n=>n.kind==='group')){const members=before.layers.filter(id=>{for(let p=byId.get(id).parent;p!==null;p=byId.get(p).parent)if(p===G.id)return true;return false});if(members.length&&members.every(id=>gone.has(id)))G.emptyPosition=before.layers.indexOf(members.at(-1))-.5}
  after.layers=after.layers.filter(id=>!gone.has(id));after.groups=after.groups.filter(id=>!gone.has(id));after.nodes=after.nodes.filter(n=>!gone.has(n.id));
  for(const n of after.nodes)if(n.kind==='layer'&&gone.has(n.target))n.target=null;
  return {after,gone};
 }
 function insert(before,request){
  if(!Array.isArray(request.nodes)||!request.nodes.length||!Number.isInteger(request.index)||!Array.isArray(request.remove??[]))throw new TypeError('Invalid insert request');
  const known=new Set(before.nodes.map(n=>n.id)),added=request.nodes.map(n=>({...n}));
  for(const n of added){if(!n||typeof n.id!=='string'||known.has(n.id))throw new TypeError('Fresh insertion IDs required');known.add(n.id)}
  const {after}=removeRecords(before,request.remove??[]);
  let index=request.index;
  if(request.inside!==undefined&&request.inside!==null){
   const map=new Map(after.nodes.map(n=>[n.id,n])),G=map.get(request.inside);
   if(G?.kind!=='group'||added.some(n=>n.kind==='layer'&&n.parent!==G.id))throw new TypeError('Invalid inside insertion');
   const members=id=>after.layers.filter(layer=>{for(let p=map.get(layer).parent;p!==null;p=map.get(p).parent)if(p===id)return true;return false});
   const own=members(G.id);let scope=G,reference=own;
   while(!reference.length&&scope.parent!==null){scope=map.get(scope.parent);reference=members(scope.id)}
   index=own.length?after.layers.indexOf(own.at(-1))+1:Number.isFinite(G.emptyPosition)?Math.ceil(G.emptyPosition):reference.length?after.layers.indexOf(reference.at(-1))+1:after.layers.length;
   if(reference.length)index=Math.max(after.layers.indexOf(reference[0]),Math.min(index,after.layers.indexOf(reference.at(-1))+1));
  }
  if(index<0||index>after.layers.length)throw new TypeError('Invalid insertion index');
  const layers=added.filter(n=>n.kind==='layer').map(n=>n.id),groups=added.filter(n=>n.kind==='group');
  if(request.offsetGroups)for(const n of groups)n.emptyPosition=index+(n.emptyPosition||0);
  after.layers.splice(index,0,...layers);after.groups.push(...groups.map(n=>n.id));after.nodes.push(...added);
  after.active=request.active??after.active;after.selection=request.selection??[after.active];after.anchor=request.anchor===undefined?after.active:request.anchor;
  return {version:1,type:'insert',changed:true,undo:before,redo:snapshot(after)};
 }
 function remove(before,request){
  if(!request.ids.length)return {version:1,type:'delete',changed:false,undo:before,redo:snapshot(before)};
  const {after,gone}=removeRecords(before,request.ids);
  if(!after.layers.length){const n=request.fallback;if(!n||n.kind!=='layer'||before.nodes.some(node=>node.id===n.id))throw new TypeError('Deletion requires a fresh fallback layer');after.layers.push(n.id);after.nodes.push({...n})}
  else if(request.fallback)throw new TypeError('Fallback is only valid when deleting all layers');
  if(request.active!==undefined)after.active=request.active;
  else if(gone.has(before.active))after.active=after.layers[Math.max(0,Math.min(before.layers.indexOf(before.active),after.layers.length-1))];
  after.selection=request.selection??[after.active];after.anchor=request.anchor===undefined?after.active:request.anchor;
  return {version:1,type:'delete',changed:true,undo:before,redo:snapshot(after)};
 }
 function stateFor(command,direction){
  if(command?.version!==1||!['ungroup','group','move','insert','delete'].includes(command.type)||!['undo','redo'].includes(direction))throw new TypeError('Invalid structural history command');
  return snapshot(command[direction]);
 }
 return Object.freeze({snapshot,dispatch,stateFor});
})();
if(typeof module!=='undefined'&&module.exports)module.exports=BungalowStructure;
