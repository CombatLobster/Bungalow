
/* ====== Build 184: Ctrl+V pastes artboards · new modifier icon · compact artboard actions · focused "New artboards" dialog ====== */
// ---------- paste: the browser's paste event decides what Ctrl+V does, so artboards must answer it ----------
function clearArtboardClipboard(){artboardClipboard=null}
document.addEventListener('paste',e=>{
 if(!artboardToolActive()||clipboardTextTarget(e))return;
 const payload=readClipboardPayload(e);
 if(!payload.text.startsWith(ARTBOARD_CLIP)&&!payload.images.length&&!artboardClipboard?.items.length)return;
 e.preventDefault();e.stopImmediatePropagation();pasteArtboards(payload);
},true);
// ---------- icons ----------
if(!BungalowIcons.paths.resize&&typeof PIE_ICON_NEW!=='undefined'&&PIE_ICON_NEW.resize)BungalowIcons.paths.resize=PIE_ICON_NEW.resize;
BungalowIcons.paths.modifier='M2.5 11.5 11 7l8.5 4.5L11 16zM2.5 16 11 20.5 19.5 16M19 1.5l1 2.5 2.5 1-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1z';
for(const [id,key] of [['layerModifiers','modifier'],['groupModifiers','modifier']]){const b=$(id);if(b){b.classList.add('has-menu-icon');b.dataset.icon=key;b.style.setProperty('--menu-icon',BungalowIcons.url(key))}}
{const b=$('lcModifier');if(b)b.replaceChildren(BungalowIcons.node('modifier'))}
// ---------- the artboard panel: one row of equal icon buttons ----------
function artboardActionsSetup(){
 const m=$('artboardManagement'),list=$('artboardList');if(!m||!list||$('artboardActions'))return;
 const row=document.createElement('div');row.id='artboardActions';row.className='ab-actions';
 const defs=[['artboardNew','add','New artboards…','tone-create'],['artboardDuplicate','copy','Duplicate the selected artboards',''],['artboardDelete','trash','Delete the selected artboards','tone-danger'],['artboardTidy','tidy','Tidy artboards into a grid',''],['artboardSize','resize','Resize the selected artboards…','']];
 for(const [id,icon,title,tone] of defs){
  const src=$(id);if(!src)continue;src.hidden=true;const holder=src.parentElement;if(holder&&holder!==m&&[...holder.children].every(c=>c.hidden||c.tagName!=='BUTTON'))holder.hidden=true;
  const b=document.createElement('button');b.type='button';b.className='ab-icon'+(tone?' '+tone:'');b.dataset.for=id;b.dataset.title=title;b.append(BungalowIcons.node(icon));b.onclick=()=>src.click();row.append(b);
 }
 list.after(row);
 const sync=()=>{for(const b of row.children){const src=$(b.dataset.for);{const want=!!src?.disabled;if(b.disabled!==want)b.disabled=want}   /* assigning the same value still queues a mutation record, so only write real changes */const t=id=>b.dataset.title;b.title=b.dataset.for==='artboardSize'&&src?.textContent?src.textContent.replace(/…$/,'')+'…':b.dataset.title;b.setAttribute('aria-label',b.title)}};
 new MutationObserver(sync).observe(m,{subtree:true,attributes:true,attributeFilter:['disabled']});new MutationObserver(sync).observe($('artboardSize')||m,{childList:true,characterData:true,subtree:true});sync();
}
artboardActionsSetup();
// ---------- New artboards: a small dialog (how many, how big) instead of the document panel ----------
let newBoardUnit='pixels';
function syncNewBoardFields(){
 const u=$('artboardNewUnit').value,dpi=documentDPI;
 if(u!==newBoardUnit){for(const id of ['artboardNewWidth','artboardNewHeight']){const el=$(id),px=(+el.value)*AB_UNITS[newBoardUnit][0](dpi);el.value=+(px/AB_UNITS[u][0](dpi)).toFixed(AB_UNITS[u][1])}newBoardUnit=u}
 for(const id of ['artboardNewWidth','artboardNewHeight']){const step=AB_UNITS[u][1]?1/10**AB_UNITS[u][1]:1;$(id).step=String(step);$(id).min=String(step)}
}
function openNewBoardsDialog(){
 if(!artboardReady())return;const b=artboards.find(x=>x.id===activeArtboardId),d=b?ArtboardWorkspace.dimensions(b):{width:DW,height:DH};
 newBoardUnit='pixels';$('artboardNewUnit').value='pixels';$('artboardNewCount').value=1;$('artboardNewWidth').value=d.width;$('artboardNewHeight').value=d.height;syncNewBoardFields();
 $('artboardNewDialog').showModal();$('artboardNewCount').focus();$('artboardNewCount').select();
}
{const sel=$('artboardNewUnit');sel.replaceChildren(...[['pixels','Pixels'],['points','Points'],['picas','Picas'],['millimetres','Millimetres'],['centimetres','Centimetres'],['inches','Inches']].map(([v,t])=>new Option(t,v)));sel.onchange=syncNewBoardFields}
$('artboardNewCancel').onclick=()=>$('artboardNewDialog').close();
$('artboardNewForm').addEventListener('submit',e=>{
 e.preventDefault();if(!artboardReady())return;
 const f=AB_UNITS[newBoardUnit][0](documentDPI),count=Math.round(+$('artboardNewCount').value),w=Math.round(+$('artboardNewWidth').value*f),h=Math.round(+$('artboardNewHeight').value*f);
 if(!(count>=1)||artboards.length+count>64){toast(count>=1?'A project supports up to 64 artboards':'Enter how many artboards');return}
 if(![w,h].every(n=>Number.isInteger(n)&&n>=1&&n<=8192)||w*h>33554432){toast('Use sizes up to 8192 pixels per side and 32 million pixels per board');return}
 const gap=Math.max(0,Math.round(+$('artboardSnapGap')?.value||0)),all=artboards.filter(b=>b.visible!==false).map(artboardRect),x0=all.length?Math.max(...all.map(r=>r.x+r.width))+gap:0,y0=all.length?Math.min(...all.map(r=>r.y)):0,cols=Math.ceil(Math.sqrt(count)),ids=[];
 $('artboardNewDialog').close();
 groupedHistory(()=>{for(let i=0;i<count;i++){const x=x0+(i%cols)*(w+gap),y=y0+Math.floor(i/cols)*(h+gap);if(!createArtboard({width:w,height:h,white:true,x,y,fit:false}))break;ids.push(activeArtboardId)}});
 if(ids.length){commitBoards({selected:[...(ids)]});renderArtboards();fitArtboardWorkspace();drawArtboardHandles();uiNotice(ids.length===1?'Artboard added':ids.length+' artboards added')}
});
$('artboardNew').onclick=openNewBoardsDialog;

