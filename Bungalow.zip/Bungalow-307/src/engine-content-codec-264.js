/* v264: DOM-free codec for node content (layer instance data: text, shape/vector, file, clone, frame).
 * encode() turns a live instance object into plain JSON for the document store:
 *  - plain objects and arrays are copied; functions, undefined and keys starting with '_' (runtime caches) are dropped;
 *  - every other object (images, canvases, file handles, blobs, nodes, class instances) becomes
 *    {"$ref": "<kind>", "id": "<string>"} through an injected `refs.idOf(object)`; plain objects that
 *    `refs.isReference(object)` claims (e.g. layer nodes) are references too;
 *  - non-finite numbers are rejected.
 * decode() rebuilds the object graph with `refs.resolve(kind, id)`.
 */
const BungalowContentCodec=(()=>{
 'use strict';
 const plain=v=>{const p=Object.getPrototypeOf(v);return p===Object.prototype||p===null};
 function encode(value,refs,depth=0){
  if(depth>64)throw new TypeError('Content too deep');
  if(value===null||typeof value==='boolean'||typeof value==='string')return value;
  if(typeof value==='number'){if(!Number.isFinite(value))throw new TypeError('Content numbers must be finite');return value}
  if(Array.isArray(value))return value.map(v=>v===undefined||typeof v==='function'?null:encode(v,refs,depth+1));
  if(typeof value==='object'){
   if(!plain(value)||refs.isReference?.(value)){const r=refs.idOf(value);if(!r||typeof r.kind!=='string'||typeof r.id!=='string')throw new TypeError('Content reference without identity');return {$ref:r.kind,id:r.id}}
   const out={};for(const [k,v] of Object.entries(value)){if(k.startsWith('_')||v===undefined||typeof v==='function')continue;out[k]=encode(v,refs,depth+1)}return out;
  }
  return undefined; // bigint/symbol: dropped
 }
 function decode(json,refs,depth=0){
  if(depth>64)throw new TypeError('Content too deep');
  if(json===null||typeof json!=='object')return json;
  if(Array.isArray(json))return json.map(v=>decode(v,refs,depth+1));
  if(typeof json.$ref==='string'&&typeof json.id==='string'&&Object.keys(json).length===2)return refs.resolve(json.$ref,json.id);
  const out={};for(const [k,v] of Object.entries(json))out[k]=decode(v,refs,depth+1);return out;
 }
 // True when json is valid encoded content (plain JSON, finite numbers, well-formed $ref objects).
 function valid(json,depth=0){if(depth>64)return false;if(json===null||typeof json==='boolean'||typeof json==='string')return true;if(typeof json==='number')return Number.isFinite(json);if(Array.isArray(json))return json.every(v=>valid(v,depth+1));if(typeof json==='object'){if(!plain(json))return false;if('$ref' in json)return typeof json.$ref==='string'&&typeof json.id==='string'&&Object.keys(json).length===2;return Object.values(json).every(v=>valid(v,depth+1))}return false}
 // Structural equality of a live object and its decoded form, ignoring dropped keys.
 function same(a,b,refs){try{return JSON.stringify(encode(a,refs))===JSON.stringify(encode(b,refs))}catch(_){return false}}
 return Object.freeze({encode,decode,valid,same});
})();
if(typeof module!=='undefined'&&module.exports)module.exports=BungalowContentCodec;
