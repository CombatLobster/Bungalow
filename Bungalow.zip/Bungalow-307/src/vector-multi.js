
/* ====== Build 179: layer menu → one Modifiers submenu · multi-shape vector gizmo ====== */
// ---------- the layer menu: one submenu for every modifier ----------
for(const id of ['layerFilterMask','layerEditFilter','layerMirrorMask','layerMirrorApply','layerResetTransformMask','layerTransformMask'])$(id)?.classList.add('mm-gone');
{const b=$('layerModifiers');if(b){b.onclick=e=>{e.stopPropagation();openModifierMenu(b)};b.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){e.preventDefault();openModifierMenu(b)}});const d='filter';b.classList.add('has-menu-icon');b.dataset.icon=d;b.style.setProperty('--menu-icon',BungalowIcons.url(d))}}
// ---------- multi-shape gizmo: one box around every selected shape ----------
function vectorMultiTargets(){
 if(!vectoring||previewMode||document.body.classList.contains('nui')||vectorDrag)return [];
 const list=layers.filter(L=>selectedStack.has(L)&&L.instance?.type==='shape'&&layerVisible(L)&&(referenceLayersVisible||!referenceTagged(L))&&!layerLocked(L)&&!groupLocked(L.group));
 return list.length>=2?list:[];
}
function vectorMultiBox(list){
 let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
 for(const L of list){const b=vectorVisualBounds(L.instance,L.instance.shape);x0=Math.min(x0,b.x);y0=Math.min(y0,b.y);x1=Math.max(x1,b.x+b.width);y1=Math.max(y1,b.y+b.height)}
 return {x:x0,y:y0,w:x1-x0,h:y1-y0};
}
function vectorMultiGeometry(R){
 const cx=R.x+R.w/2,cy=R.y+R.h/2,pts={nw:{x:R.x,y:R.y},n:{x:cx,y:R.y},ne:{x:R.x+R.w,y:R.y},e:{x:R.x+R.w,y:cy},se:{x:R.x+R.w,y:R.y+R.h},s:{x:cx,y:R.y+R.h},sw:{x:R.x,y:R.y+R.h},w:{x:R.x,y:cy}};
 return {pts,c:{x:cx,y:cy},rot:{x:cx,y:R.y-28/Math.max(z,.001)}};
}
function vectorMultiHit(e,list){
 const g=vectorMultiGeometry(vectorMultiBox(list)),[px,py]=vectorPoint(e),limit=penLike(e)?22:18,cands=[[g.rot,{multi:true,type:'rotate'},0],[g.c,{multi:true,type:'move'},4]];
 for(const [k,[fx,fy]] of Object.entries(VG_HANDLES))cands.push([g.pts[k],{multi:true,type:'resize',fx,fy},0]);
 let best=null,score=Infinity;for(const [p,hit,bias] of cands){const d=Math.hypot(p.x-px,p.y-py)*z;if(d<=limit&&d-bias<score){score=d-bias;best=hit}}
 return best;
}
function vectorMultiDown(e,list){
 const hit=vectorMultiHit(e,list);if(!hit)return false;e.preventDefault();flushVectorColourEdit();
 if(!list.includes(AL))setActiveNode(list.at(-1));hit.L=AL;   /* BungalowVectors.sync cancels a gizmo drag unless it targets the active, selected layer */
 const B=list.map(L=>({L,I:L.instance,xf:L.instance.xf?[...L.instance.xf]:null})),R=vectorMultiBox(list),[sx0,sy0]=vectorPoint(e),C={x:R.x+R.w/2,y:R.y+R.h/2};
 const targets=globalSnapOn?prepareSnapTargets({items:list.map(L=>({layer:L}))}):null,snapTo=(x,y,ev)=>targets?snapTextPoint(x,y,targets,ev):{x,y};
 const controller=new AbortController(),options={capture:true,signal:controller.signal},drag=vectorGizmoDrag={hit,moved:false,angle0:Math.atan2(sy0-C.y,sx0-C.x)};let frame=0;
 const redraw=()=>{frame=0;for(const {L} of B)drawVectorLayer(L,true)},apply=xfs=>{B.forEach((b,i)=>{b.I.xf=xfs[i]?[...xfs[i]]:null});for(const {L} of B)drawVectorLayer(L);renderLayers();BungalowVectors.sync();startVectorGizmo()},before=B.map(b=>b.xf);
 const setT=T=>{for(const b of B)b.I.xf=instMul(T,b.xf||[1,0,0,1,0,0])};
 const finish=(cancel=false)=>{
  if(vectorGizmoDrag!==drag)return;vectorGizmoDrag=null;controller.abort();showVectorSnap(null,null);if(frame){cancelAnimationFrame(frame);frame=0}
  try{if(wrap.hasPointerCapture(e.pointerId))wrap.releasePointerCapture(e.pointerId)}catch(_){}
  if(cancel){apply(before);return}
  if(!drag.moved){startVectorGizmo();return}
  const after=B.map(b=>b.I.xf?[...b.I.xf]:null);for(const {L} of B)drawVectorLayer(L);
  doH({bytes:0,undo:()=>apply(before),redo:()=>apply(after)});renderLayers();BungalowVectors.sync();startVectorGizmo();
 };
 drag.cancel=()=>finish(true);wrap.setPointerCapture(e.pointerId);
 window.addEventListener('pointermove',ev=>{
  if(ev.pointerId!==e.pointerId)return;ev.preventDefault();ev.stopImmediatePropagation();
  const [mx,my]=vectorPoint(ev);if(!drag.moved&&Math.hypot(mx-sx0,my-sy0)*z<3)return;drag.moved=true;
  let T=[1,0,0,1,0,0],gx=null,gy=null;
  if(hit.type==='move'){
   let dx=mx-sx0,dy=my-sy0;if(ev.shiftKey){if(Math.abs(dx)>Math.abs(dy))dy=0;else dx=0}
   const q=snapTo(C.x+dx,C.y+dy,ev);if(Math.abs(q.x-(C.x+dx))>1e-6){dx=q.x-C.x;gx=q.x}if(Math.abs(q.y-(C.y+dy))>1e-6){dy=q.y-C.y;gy=q.y}
   T=[1,0,0,1,dx,dy];
  }else if(hit.type==='resize'){
   const q=snapTo(mx,my,{altKey:false,shiftKey:ev.shiftKey,ctrlKey:ev.ctrlKey,metaKey:ev.metaKey});if(Math.abs(q.x-mx)>1e-6)gx=q.x;if(Math.abs(q.y-my)>1e-6)gy=q.y;
   const box=vgResizeBox(R,hit.fx,hit.fy,{x:q.x,y:q.y},{ctrl:ev.altKey,shift:ev.shiftKey},1),kx=R.w>0?box.w/R.w:1,ky=R.h>0?box.h/R.h:1;
   T=[kx,0,0,ky,box.x-kx*R.x,box.y-ky*R.y];
  }else{
   let d=Math.atan2(my-C.y,mx-C.x)-drag.angle0;if(ev.shiftKey)d=Math.round(d/(Math.PI/12))*(Math.PI/12);
   const cos=Math.cos(d),sin=Math.sin(d);T=[cos,sin,-sin,cos,C.x-(cos*C.x-sin*C.y),C.y-(sin*C.x+cos*C.y)];
  }
  setT(T);showVectorSnap(gx,gy);startVectorGizmo();if(!frame)frame=requestAnimationFrame(redraw);
 },options);
 window.addEventListener('pointerup',ev=>{if(ev.pointerId!==e.pointerId)return;ev.preventDefault();ev.stopImmediatePropagation();finish()},options);
 window.addEventListener('pointercancel',ev=>{if(ev.pointerId===e.pointerId)finish(true)},options);
 window.addEventListener('lostpointercapture',ev=>{if(ev.pointerId===e.pointerId)finish(true)},options);
 window.addEventListener('blur',()=>finish(true),options);
 window.addEventListener('keydown',ev=>{if(ev.key==='Escape'){ev.preventDefault();ev.stopImmediatePropagation();finish(true)}},options);
 return true;
}
function vectorMultiDraw(list){
 const c=vectorGizmoCanvas,dpr=devicePixelRatio||1,w=wrap.clientWidth,h=wrap.clientHeight;
 if(c.width!==Math.round(w*dpr)||c.height!==Math.round(h*dpr)){c.width=Math.round(w*dpr);c.height=Math.round(h*dpr)}
 const g=c.getContext('2d');g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,w,h);
 const geo=vectorMultiGeometry(vectorMultiBox(list)),W=p=>gradToWrap(p);
 // every member gets a faint outline, then the shared box with the Transform tool's handles
 for(const L of list){const m=vectorGizmoGeometry(L),q=['nw','ne','se','sw'].map(k=>W(m.pts[k]));g.beginPath();q.forEach((p,i)=>i?g.lineTo(p.x,p.y):g.moveTo(p.x,p.y));g.closePath();g.lineWidth=1;g.setLineDash([4,3]);g.strokeStyle='rgba(109,169,228,.55)';g.stroke();g.setLineDash([])}
 const corners=['nw','ne','se','sw'].map(k=>W(geo.pts[k])),edges=['n','e','s','w'].map(k=>W(geo.pts[k]));
 g.beginPath();corners.forEach((p,i)=>i?g.lineTo(p.x,p.y):g.moveTo(p.x,p.y));g.closePath();g.lineWidth=1.5;g.strokeStyle='rgba(109,169,228,.9)';g.stroke();
 const n=W(geo.pts.n),k=W(geo.rot);g.beginPath();g.moveTo(n.x,n.y);g.lineTo(k.x,k.y);g.lineWidth=1;g.strokeStyle='#fff';g.stroke();
 g.fillStyle='#fff';g.strokeStyle='#111';g.lineWidth=1;g.beginPath();g.arc(k.x,k.y,6,0,7);g.fill();g.stroke();
 for(const p of corners){g.beginPath();g.rect(p.x-6,p.y-6,12,12);g.fill();g.stroke()}
 for(const p of edges){g.beginPath();g.arc(p.x,p.y,5,0,7);g.fill();g.stroke()}
 const c0=W(geo.c);g.beginPath();g.arc(c0.x,c0.y,8,0,7);g.fillStyle='#fff';g.fill();g.lineWidth=1;g.strokeStyle='#111';g.stroke();
 g.beginPath();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){g.moveTo(c0.x+dx*2,c0.y+dy*2);g.lineTo(c0.x+dx*5.2,c0.y+dy*5.2)}g.lineWidth=1.3;g.strokeStyle='#111';g.lineCap='round';g.stroke();g.lineCap='butt';
}
{const r=renderLayers;renderLayers=function(){const out=r.apply(this,arguments);if(vectoring)startVectorGizmo();return out}}


{const b=$('groupModifiers');if(b){b.onclick=e=>{e.stopPropagation();const G=groupMenuTarget;if(G){setStackSelection([G],{active:nodeLayers(G).at(-1)||AL});renderLayers()}openModifierMenu(b)};b.classList.add('has-menu-icon');b.dataset.icon='filter';b.style.setProperty('--menu-icon',BungalowIcons.url('filter'))}}
