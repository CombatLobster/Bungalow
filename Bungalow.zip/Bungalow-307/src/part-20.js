
/* Move original quick controls without replacing their handlers, IDs or preset marks. */
(function(global){
 const strip=$('toolContext'),quick=document.createElement('div'),native=document.createElement('div'),extra=document.createElement('div'),body=$('sl').querySelector('.panel-body');
 quick.id='contextQuick';quick.setAttribute('role','group');quick.setAttribute('aria-label','Quick tool controls');native.id='contextNative';extra.id='contextExtra';quick.append(native,extra);strip.append(quick);
 const rows=[...body.querySelectorAll(':scope>.vs')];let current='',refreshers=[],queued=false;const persistent=[];
 // Keep the original sliders for the optional floating quickbar; desktop fields share their state.
 $('ops').step='any';
 const BRUSH_LENGTH=lengthField('brush',{digitsPx:1}),valueSpecs=[{id:'szs',input:'desktop_brushSize',label:'Brush size',caption:'Size',unit:'px',min:1,max:MAXS,step:.1,dragStep:.25,digits:5,...BRUSH_LENGTH,get:()=>P.size,set:setSize,reset:()=>presetList().find(p=>p.id===activePreset)?.brush?.size||40},{id:'ops',input:'desktop_brushOpacity',label:'Brush opacity',caption:'Opacity',unit:'%',min:5,max:100,step:.1,dragStep:.25,digits:1,get:()=>OP*100,set:v=>{$('ops').value=v;$('ops').dispatchEvent(new Event('input',{bubbles:true}))},reset:()=>(presetList().find(p=>p.id===activePreset)?.brush?.opacity||1)*100}];
 for(const [i,spec]of valueSpecs.entries()){const field=document.createElement('div');field.className='desktop-brush-value';const caption=document.createElement('span');caption.className='desktop-value-label';caption.textContent=spec.caption;const api=BungalowDesktopValues.create({...spec,id:spec.input,getPresets:()=>({tool:quickSliderToolType(),saved:[...quickSliderStops[spec.id]]}),savePreset:()=>saveQuickSliderValue(spec.id),removePreset:v=>{quickSliderStops[spec.id]=quickSliderStops[spec.id].filter(n=>n!==v);persistQuickSliderStops();renderQuickSliderMarks(spec.id)}});field.append(caption,api.root);rows[i].append(field)}
 {const api=global.BungalowTextControls?.create('textSize');if(api){api.root.classList.add('desktop-value','length-field');const field=document.createElement('div');field.className='desktop-brush-value';const cap=document.createElement('span');cap.className='desktop-value-label';cap.textContent='Size';field.append(cap,api.root);$('textSize').after(field);persistent.push(()=>api.sync())}}
 function show(el,on){if(el.hidden===on)el.hidden=!on}
 function queue(){if(queued)return;queued=true;queueMicrotask(()=>{queued=false;sync()})}
 function button(label,fn,tone=''){const b=document.createElement('button');b.type='button';b.textContent=label;b.title=label;b.className=tone;b.onclick=()=>{fn();queue()};extra.append(b);return b}
 function bind(id,label){const source=$(id);if(!source)return;const field=document.createElement('label');field.className='context-field';field.textContent=label;const input=document.createElement(source.tagName==='SELECT'?'select':'input');input.id='context_'+id;input.setAttribute('aria-label',label);input.title=source.title||label;
  if(source.tagName==='SELECT')for(const option of source.options)input.add(new Option(option.text,option.value));else{input.type=source.type==='color'?'color':'number';for(const key of ['min','max','step'])if(source[key])input[key]=source[key]}
  for(const type of ['input','change'])input.addEventListener(type,()=>{source.value=input.value;source.dispatchEvent(new Event(type,{bubbles:true}));queue()});field.append(input);extra.append(field);refreshers.push(()=>{if(document.activeElement!==input&&input.value!==source.value)input.value=source.value;input.disabled=source.disabled});
 }
 function bindValue(id,label,{length=false}={}){
  const source=$(id);if(!source)return;
  const F=length?lengthField('vector'):null,min=+source.min||0,max=+source.max||1e6,step=+source.step||1;
  const api=createCompactValueControl({id:'context_'+id,label,get:()=>+source.value||0,set:v=>{source.value=v;source.dispatchEvent(new Event('input',{bubbles:true}));queue()},min,max,step,dragStep:step/2,reset:+source.defaultValue||min,digits:length?5:2,...(F?{parse:F.parse,format:F.format}:{})});
  const commit=()=>source.dispatchEvent(new Event('change',{bubbles:true}));api.input.addEventListener('change',commit);api.root.addEventListener('valuecommit',commit);
  api.root.classList.add('desktop-value');if(length)api.root.classList.add('length-field');
  const field=document.createElement('div');field.className='desktop-brush-value';const cap=document.createElement('span');cap.className='desktop-value-label';cap.textContent=label;field.append(cap,api.root);extra.append(field);
  refreshers.push(()=>{api.sync();api.input.disabled=source.disabled});
 }
 function vectorField(key,label){
  const api=global.BungalowVectors?.field(key,label);if(!api)return;api.root.classList.add('desktop-value','length-field');
  const field=document.createElement('div');field.className='desktop-brush-value';const cap=document.createElement('span');cap.className='desktop-value-label';cap.textContent=label;field.append(cap,api.root);extra.append(field);refreshers.push(()=>api.sync());
 }
 // Free transform, Perspective and Warp are one tool: the subtool list shows "Transform" and this chooses the mode.
 function transformModeSelect(){
  const source=$('transformmode');if(!source)return;
  const field=document.createElement('label');field.className='context-field';field.textContent='Mode';
  const select=document.createElement('select');select.id='context_transformMode';select.setAttribute('aria-label','Transform mode');select.title='Transform mode';
  for(const [value,label] of [['transform','Free transform'],['perspective','Perspective'],['warp','Warp']])select.add(new Option(label,value));
  select.onchange=()=>{source.value=select.value;source.dispatchEvent(new Event('change',{bubbles:true}));queue()};
  field.append(select);extra.append(field);refreshers.push(()=>{if(document.activeElement!==select&&select.value!==source.value)select.value=source.value;select.disabled=source.disabled});
 }
 function toggle(id,label,cls=''){const source=$(id);if(!source)return;const b=button(label,()=>{source.checked=!source.checked;source.dispatchEvent(new Event('input',{bubbles:true}));source.dispatchEvent(new Event('change',{bubbles:true}))},cls);b.id='context_'+id;refreshers.push(()=>{const value=String(source.checked);if(b.getAttribute('aria-pressed')!==value)b.setAttribute('aria-pressed',value);b.disabled=source.disabled})}
 function action(id,label,tone='',hideInvalid=false){const source=$(id);if(!source)return;const b=button(label,()=>source.click(),tone);b.id='context_'+id;if(hideInvalid)b.hidden=source.hidden;refreshers.push(()=>{b.disabled=source.disabled;if(hideInvalid)b.hidden=source.hidden;if(source.hasAttribute('aria-pressed'))b.setAttribute('aria-pressed',source.getAttribute('aria-pressed'))});return b}
 function iconToggle(id,label,icon){const source=$(id);if(!source)return;const b=document.createElement('button');b.type='button';b.id='context_'+id;b.className='context-icon';b.setAttribute('aria-label',label);b.append(BungalowIcons.node(icon));b.onclick=()=>{source.checked=!source.checked;source.dispatchEvent(new Event('input',{bubbles:true}));source.dispatchEvent(new Event('change',{bubbles:true}))};extra.append(b);refreshers.push(()=>{const v=String(source.checked);if(b.getAttribute('aria-pressed')!==v)b.setAttribute('aria-pressed',v);b.title=label+' · '+(source.checked?'on':'off');b.disabled=source.disabled});return b}
 function iconAction(id,label,icon){const source=$(id);if(!source)return;const b=document.createElement('button');b.type='button';b.id='context_'+id;b.className='context-icon';b.title=label;b.setAttribute('aria-label',label);b.append(BungalowIcons.node(icon));b.onclick=()=>{source.click();queue()};extra.append(b);refreshers.push(()=>{b.disabled=source.disabled;if(source.hasAttribute('aria-pressed'))b.setAttribute('aria-pressed',source.getAttribute('aria-pressed'))});return b}
 function gradient(){const type=document.createElement('select');type.id='context_gradientType';type.setAttribute('aria-label','Gradient type');for(const t of GK.TYPES)type.add(new Option(GRAD_TYPE_NAMES[t],t));type.onchange=()=>{gradBeginEdit();gradEd.type=type.value;gradEd.emit();gradEndEdit()};extra.append(type);
  const label=document.createElement('label');label.className='context-field';label.textContent='Opacity';const opacity=document.createElement('input');opacity.id='context_gradientOpacity';opacity.type='range';opacity.min=0;opacity.max=100;opacity.setAttribute('aria-label','Gradient opacity');opacity.oninput=()=>{gradBeginEdit();gradEd.opacity=+opacity.value/100;gradEd.emit()};opacity.onchange=gradEndEdit;label.append(opacity);extra.append(label);
  const apply=button('Apply',gradientFillApply,'tone-create'),cancel=button('Cancel',()=>gradientFillCancel());apply.id='context_gradientApply';refreshers.push(()=>{type.value=gradEd.type;if(document.activeElement!==opacity)opacity.value=Math.round(gradEd.opacity*100);apply.hidden=cancel.hidden=gradCtx.kind!=='fill';apply.disabled=!gradFill||!gradEd.geom||!!gradDrag;cancel.disabled=!gradFill});
 }
 function key(){return vectoring?'vectors:'+$('vectorMode').value:gradientEditingActive()?'gradient':texting?$('textMode').value==='annotation'?'annotation':'text':assisting?'assistant:'+assistMode():transforming?'transform:'+$('transformmode').value:filling?(selectionToolActive?'selection:':'fill:')+fillMode:'brush'}
 function build(k){extra.replaceChildren();refreshers=[];
  if(k.startsWith('vectors:')){if(k==='vectors:basic'){bind('vectorShape','Shape');vectorField('strokeWidth','Stroke');iconToggle('globalSnapEnabled','Snapping','magnet')}if(k==='vectors:pen'){iconAction('penFinish','Apply path (Enter)','tick');iconAction('penCancel','Cancel draft (Escape)','close')}if(k==='vectors:nodes'){iconAction('penCorner','Corner node','nodeCorner');iconAction('penSharp','Sharp corner node','nodeSharp');iconAction('penSmooth','Smooth node','nodeSmooth');iconAction('penSymmetric','Symmetric node','nodeSymmetric')}}
  else if(k==='gradient')gradient();
  else if(k.startsWith('fill:')||k.startsWith('selection:')){if(fillMode==='bucket'){bindValue('fillThreshold','Threshold');toggle('fillContiguous','Connected')}bindValue('fillFeather','Feather',{length:true});if(!selectionToolActive)toggle('fillErase','Erase','context-erase')}
  else if(k.startsWith('transform:')){if(['transform','perspective','warp'].includes($('transformmode').value))transformModeSelect();if($('transformmode').value==='liquify')bindValue('transformLiquifySize','Size',{length:true});iconToggle('globalSnapEnabled','Snapping','magnet');if($('transformmode').value==='transform'){iconAction('transformFlipX','Flip horizontal','flipH');iconAction('transformFlipY','Flip vertical','flipV')}if(['transform','perspective','warp','liquify'].includes($('transformmode').value))toggle('transformKeepStrokes','Keep strokes');action('transformApply','Apply','tone-create',true);action('transformCancel','Cancel','',true)}
  else if(k==='text')iconToggle('globalSnapEnabled','Snapping','magnet');
  else if(k==='annotation'){bind('annotationleaderColour','Line');bindValue('annotationleaderWidth','Width',{length:true});bind('annotationleaderShape','Route')}
  else if(k.startsWith('assistant:')){if(assistMode()==='references'){const b=action('referenceShow','Visible');refreshers.push(()=>b.setAttribute('aria-pressed',String(referenceShown)));action('referenceAdd','Place')}else if(assistMode()==='guides'){bind('guideAxis','Axis');bind('guideUnit','Unit');bind('guidePosition','Position');action('guideAdd','Add','tone-create')}else{bind('assistType','Assistant');if($('assistType').value==='grid')bind('assistGridType','Grid');toggle('assistShow','Visible')}}
  if(k!=='brush')button('Settings',()=>toggleToolSettings(true));
  global.BungalowSubtools?.sync();
 }
 function sync(){const k=key(),floating=!$('sl').classList.contains('panel-hidden'),target=floating?body:native;
  for(const row of rows)if(row.parentElement!==target)target.append(row);
  const brush=k==='brush',opacity=k.startsWith('fill:');for(const [i,row]of rows.entries())show(row,floating||brush||opacity&&i===1);
  show(native,!floating&&(brush||opacity));if(k!==current||(k.startsWith('assistant:')&&extra.dataset.assistant!==$('assistType').value)){current=k;build(k);extra.dataset.assistant=$('assistType').value}
  BungalowDesktopValues.sync();for(const update of persistent)update();for(const update of refreshers)update();show(extra,extra.childElementCount>0);quick.dataset.tool=k;global.BungalowSubtools?.sync();
 }
 new MutationObserver(queue).observe($('sl'),{attributes:true,attributeFilter:['class']});
 const tools=new MutationObserver(queue);for(const id of ['tb','era','filltool','selectiontool','transformtool','texttool','assisttool','vectorstool'])tools.observe($(id),{attributes:true,attributeFilter:['aria-pressed']});
 document.addEventListener('input',queue,true);document.addEventListener('change',queue,true);document.addEventListener('pointerup',queue,{passive:true});gradEd.addEventListener('change',queue);
 global.BungalowContext={sync};sync();
})(globalThis);
