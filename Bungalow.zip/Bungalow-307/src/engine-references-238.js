/* Pure reference collection commands. Image payloads stay in the adapter. */
const BungalowReferences=(()=>{
 function dispatch(ids,selected,command){
  if(!Array.isArray(ids)||ids.some(id=>typeof id!=='string'||!id)||new Set(ids).size!==ids.length)throw Error('Invalid reference IDs');
  if(!command||!['remove','duplicate','reorder'].includes(command.type))throw Error('Unknown reference command');
  if(command.type==='reorder'&&typeof command.front!=='boolean')throw Error('Invalid reference order');
  if(command.type==='duplicate'&&(typeof command.id!=='string'||!command.id||ids.includes(command.id)))throw Error('Invalid duplicate ID');
  const next=ids.slice(),index=next.indexOf(selected);
  if(index<0)return {ids:next,selected:null,changed:false};
  if(command.type==='remove'){next.splice(index,1);selected=next.at(-1)||null}
  else if(command.type==='duplicate'){if(typeof command.id!=='string'||!command.id||next.includes(command.id))throw Error('Invalid duplicate ID');next.push(command.id);selected=command.id}
  else if(command.type==='reorder'){next.splice(index,1);command.front?next.push(selected):next.unshift(selected)}
  else throw Error('Unknown reference command');
  return {ids:next,selected,changed:next.length!==ids.length||next.some((id,i)=>id!==ids[i])};
 }
 return Object.freeze({dispatch});
})();
if(typeof module!=='undefined')module.exports=BungalowReferences;
