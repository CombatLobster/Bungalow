
/* Desktop numeric controls build on the shared typed-input/scrubbing component. */
(function(global){
 const instances=new Set();
 function create({getPresets,savePreset,removePreset,...spec}){
  const api=createCompactValueControl({...spec,presets:[spec.min]});api.root.classList.add('desktop-value');
  const menu=api.root.querySelector('select'),baseSync=api.sync;let signature='';
  function refresh(force=false){if(!force&&document.activeElement===menu)return;const p=getPresets(),sig=JSON.stringify(p)+(spec.unitOf?spec.unitOf():'')+(typeof documentDPI==='number'?documentDPI:'');if(sig===signature)return;signature=sig;menu.replaceChildren(new Option('▾',''));
   const group=(label,values,prefix)=>{if(!values.length)return;const g=document.createElement('optgroup');g.label=label;for(const value of values)g.append(new Option(spec.format?spec.format(value):value+(spec.unit?' '+spec.unit:''),prefix+value));menu.append(g)};
   group('Saved · '+p.tool,p.saved,'saved:');menu.append(new Option('Save current value','save'));group('Remove saved value',p.saved,'remove:');menu.hidden=false;
  }
  menu.onchange=()=>{const value=menu.value;menu.value='';if(value==='save')savePreset();else if(value.startsWith('remove:'))removePreset(+value.slice(7));else if(value.startsWith('saved:'))api.apply(+value.slice(value.indexOf(':')+1));refresh(true);api.sync()};
  menu.addEventListener('pointerdown',()=>refresh(true));menu.addEventListener('focus',()=>refresh(true));menu.addEventListener('keydown',e=>{if(['ArrowDown','ArrowUp','Home','End','F4'].includes(e.key))refresh(true)});
  api.sync=()=>{baseSync();refresh()};api.refreshPresets=()=>refresh(true);api.menu=menu;instances.add(api);api.sync();return api;
 }
 global.BungalowDesktopValues={create,sync:()=>{for(const api of instances)api.sync()}};
})(globalThis);
