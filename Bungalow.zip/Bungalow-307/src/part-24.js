
/* ====== Build 166: "Book cover" document type: bleed | back cover | spine | front cover | bleed ====== */
const BOOK_DEFAULTS={pageW:152.4,pageH:228.6,spine:15,bleed:3};
// KDP paperback paper stocks: thickness of one page in inches (kdp.amazon.com/help/topic/G201953020)
const KDP_PAPER=[['white','White paper (B&W)',0.002252],['cream','Cream paper (B&W)',0.0025],['standard','Standard colour',0.002252],['premium','Premium colour',0.002347]];
function kdpSpineMm(pages,paper){const even=pages+(pages%2),t=(KDP_PAPER.find(p=>p[0]===paper)||KDP_PAPER[0])[2];return Math.round(even*t*25.4*1000)/1000}   // KDP rounds the page count up to an even number
function sanitizeBook(b){
 if(!b||typeof b!=='object')return null;
 const n=(v,lo,hi,d)=>Number.isFinite(v)?Math.min(hi,Math.max(lo,v)):d,i=v=>Number.isInteger(v)&&v>=0&&v<=100000;
 const px=b.px&&i(b.px.pageW)&&i(b.px.pageH)&&i(b.px.spine)&&i(b.px.bleed)?{pageW:b.px.pageW,pageH:b.px.pageH,spine:b.px.spine,bleed:b.px.bleed}:null;
 return {pageW:n(b.pageW,.1,3000,BOOK_DEFAULTS.pageW),pageH:n(b.pageH,.1,3000,BOOK_DEFAULTS.pageH),spine:n(b.spine,0,500,BOOK_DEFAULTS.spine),bleed:n(b.bleed,0,100,BOOK_DEFAULTS.bleed),extend:b.extend!==false,
  pages:Number.isInteger(b.pages)&&b.pages>0&&b.pages<=2000?b.pages:null,paper:KDP_PAPER.some(p=>p[0]===b.paper)?b.paper:'white',px};
}
const bookPx=(mm,dpi=documentDPI)=>mm*dpi/25.4,bookMm=(px,dpi=documentDPI)=>px*25.4/dpi;
// whole-pixel layout of the full cover for the given physical sizes
function bookLayout(b,dpi=documentDPI){ // whole pixels; the total size is exact (e.g. 11 × 8.25 in = 3300 × 2475 at 300 DPI) and the spine absorbs the rounding
 const r=v=>Math.round(bookPx(v,dpi)),bleed=r(b.bleed),pageW=Math.max(1,r(b.pageW));
 const W=Math.round(bookPx(2*b.bleed+2*b.pageW+b.spine,dpi)),H=Math.round(bookPx(2*b.bleed+b.pageH,dpi));
 let spine=W-2*bleed-2*pageW;if(spine<0)spine=0;
 return {bleed,pageW,pageH:Math.max(1,H-2*bleed),spine,W:2*bleed+2*pageW+spine,H:2*bleed+Math.max(1,H-2*bleed)};
}
// the layout the canvas has right now (re-derived if the canvas was resized elsewhere)
function bookCurrentLayout(){
 const s=documentMeta.book?.px;
 if(s&&2*s.bleed+2*s.pageW+s.spine===DW&&2*s.bleed+s.pageH===DH)return {...s,W:DW,H:DH};
 const tb=canvasCoordinates.bleed;let bleed=s?s.bleed:tb?Math.round(tb.left*DW):Math.round(bookPx(BOOK_DEFAULTS.bleed));
 bleed=Math.max(0,Math.min(bleed,Math.floor(Math.min(DW-2,DH-1)/2)));
 let spine=Math.min(s?s.spine:Math.round(bookPx(BOOK_DEFAULTS.spine)),Math.max(0,DW-2*bleed-2));
 const pageW=Math.max(1,Math.floor((DW-2*bleed-spine)/2));spine=Math.max(0,DW-2*bleed-2*pageW);
 return {bleed,pageW,pageH:Math.max(1,DH-2*bleed),spine,W:DW,H:DH};
}
// Old → new positions. Artwork stays attached to the spine: the left side moves with the spine's left edge, the right side with
// its right edge, the spine area itself stretches, and everything shifts vertically so the centre stays put.
function bookMapper(o,n){
 const sLo=o.bleed+o.pageW,sRo=sLo+o.spine,sLn=n.bleed+n.pageW,sRn=sLn+n.spine,dL=sLn-sLo,dR=sRn-sRo,dy=Math.floor((n.H-o.H)/2);
 const mapX=x=>x<sLo?x+dL:x>=sRo?x+dR:(o.spine>0?sLn+(x-sLo)*n.spine/o.spine:sLn+n.spine/2);
 return {sLo,sRo,sLn,sRn,dL,dR,dy,mapX,mapY:y=>y+dy};
}
function bookTransformCanvas(src,o,n,M,extend){
 const Wo=o.W,Ho=o.H,Wn=n.W,Hn=n.H,mid=document.createElement('canvas');mid.width=Wn;mid.height=Ho;
 const g=ctx2(mid,desync);g.imageSmoothingEnabled=false;
 g.drawImage(src,0,0,M.sLo,Ho,M.dL,0,M.sLo,Ho);                                     // left side, attached to the spine
 if(n.spine>0){g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';if(o.spine>0)g.drawImage(src,M.sLo,0,o.spine,Ho,M.sLn,0,n.spine,Ho);else g.drawImage(src,Math.min(M.sLo,Wo-1),0,1,Ho,M.sLn,0,n.spine,Ho);g.imageSmoothingEnabled=false}
 const rightW=Wo-M.sRo;if(rightW>0)g.drawImage(src,M.sRo,0,rightW,Ho,M.sRn,0,rightW,Ho);   // right side, attached to the spine
 if(extend){if(M.dL>0)g.drawImage(src,0,0,1,Ho,0,0,M.dL,Ho);const endX=M.sRn+rightW;if(endX<Wn&&rightW>0)g.drawImage(src,Wo-1,0,1,Ho,endX,0,Wn-endX,Ho)}
 const out=document.createElement('canvas');out.width=Wn;out.height=Hn;const h=ctx2(out,desync);h.imageSmoothingEnabled=false;h.drawImage(mid,0,M.dy);
 if(extend){if(M.dy>0)h.drawImage(mid,0,0,Wn,1,0,0,Wn,M.dy);const endY=M.dy+Ho;if(endY<Hn)h.drawImage(mid,0,Ho-1,Wn,1,0,endY,Wn,Hn-endY)}
 mid.width=mid.height=1;return out;
}
function bookLayerMeta(L,o,n,M,bounds){
 const meta=canvasNodeMetadata(L),I=L.instance;
 if(I){
  if(bounds&&bounds.width>=o.W*.95&&bounds.height>=o.H*.95)return rescaleCanvasNodeMetadata(L,n.W,n.H);   // full-wrap artwork stretches with the cover
  const cx=bounds?bounds.x+bounds.width/2:o.W/2;return offsetArtboardMetadata(meta,M.mapX(cx)-cx,M.dy);    // everything else moves with its side
 }
 return meta.retained?offsetArtboardMetadata(meta,M.mapX(meta.retained.x)-meta.retained.x,M.dy):meta;
}
function bookCoordinates(old,o,n,M){
 const next=structuredClone(old),W0=o.W,H0=o.H,W1=n.W,H1=n.H,pt=p=>({x:M.mapX(p.x*W0)/W1,y:M.mapY(p.y*H0)/H1});
 for(const c of next.cubes){Object.assign(c,pt(c));c.size*=Math.sqrt(W0*H0/(W1*H1))}
 for(const p of next.points)Object.assign(p,pt(p));
 for(const v of next.vanishing)Object.assign(v,pt(v));
 if(next.horizon)Object.assign(next.horizon,pt(next.horizon));
 for(const l of next.finder){Object.assign(l.a,pt(l.a));Object.assign(l.b,pt(l.b))}
 next.guides=next.guides.filter(g=>!g.book);
 for(const g of next.guides)g.position=g.axis==='x'?M.mapX(g.position*W0)/W1:M.mapY(g.position*H0)/H1;
 for(const g of next.grids){g.origin=pt(g.origin);for(const key of ['stepX','stepY'])g[key]={x:g[key].x*W0/W1,y:g[key].y*H0/H1}}
 next.bleed=n.bleed>0?{left:n.bleed/W1,right:n.bleed/W1,top:n.bleed/H1,bottom:n.bleed/H1,visible:true,guide:true}:null;
 for(const [name,x,tier] of [['Back cover · centre',n.bleed+n.pageW/2,'secondary'],['Spine · back fold',M.sLn,'main'],['Spine · front fold',M.sRn,'main'],['Front cover · centre',M.sRn+n.pageW/2,'secondary']])next.guides.push({id:crypto.randomUUID(),axis:'x',position:x/W1,book:true,locked:true,name,tier,...BOOK_GUIDE_STYLE[tier]});
 return next;
}
// Main guides (the spine folds that separate back / spine / front) are solid, heavier and warm; secondary guides (cover centres) are thin, dashed and cool.
const BOOK_GUIDE_STYLE={main:{colour:'#ff5a1f',width:2,dash:false,opacity:1},secondary:{colour:'#6fa8ff',width:1,dash:true,opacity:.75}};
let bookBusy=false;
function bookApply(spec,{adopt=false}={}){
 if(bookBusy||canvasBusy()||editBlocked())return false;
 const b=sanitizeBook(spec),n=bookLayout(b),o=bookCurrentLayout();
 if(n.W<3||n.H<1||n.W>8192||n.H>8192||n.W*n.H>33554432){toast('A cover of '+n.W+' × '+n.H+' px is outside the limit (8192 per side, 32 million pixels)');return false}
 bookBusy=true;
 try{
  const beforeBook=documentMeta.book?structuredClone(documentMeta.book):null,M=bookMapper(o,n),keep={...b,px:{bleed:n.bleed,pageW:n.pageW,pageH:n.pageH,spine:n.spine}};
  const sameLayout=o.bleed===n.bleed&&o.pageW===n.pageW&&o.pageH===n.pageH&&o.spine===n.spine&&n.W===DW&&n.H===DH;
  if(sameLayout){ // nothing to resize: only (re)place the guides and trim bounds
   const before=structuredClone(canvasCoordinates),after=CanvasCoordinates.validate(bookCoordinates(before,o,n,M));
   const set=(coords,book)=>{commitCoordinates(coords);documentMeta.book=book?structuredClone(book):null;projectDirty=true;syncLayoutControls();syncDocumentForm(true)};
   set(after,keep);doH({undo:()=>set(before,beforeBook),redo:()=>set(after,keep)});
   if(!adopt)uiNotice('Cover guides placed');return true;
  }
  const before=canvasState(),bounds=new Map();
  for(const L of layers)if(L.instance){try{bounds.set(L,layerContentBounds(L))}catch(_){}}
  let after;
  try{
   after={width:n.W,height:n.H,dpi:documentDPI,coordinates:CanvasCoordinates.validate(bookCoordinates(before.coordinates,o,n,M)),
    items:layers.map(L=>canvasGeometryItem(L,cv=>bookTransformCanvas(cv,o,n,M,b.extend),bookLayerMeta(L,o,n,M,bounds.get(L)||null))),
    references:referenceState().map(r=>({...r,x:M.mapX(r.x),y:r.y+M.dy})),selection:null};
  }catch(e){toast('Could not allocate the resized cover');return false}
  const view=userView?{z,tx,ty,userView}:undefined;
  const put=(state,book)=>{restoreCanvasState(state,view?{viewState:view}:{});documentMeta.book=book?structuredClone(book):null;for(const L of layers)if(L.instance){try{instanceRedraw(L)}catch(_){}}projectDirty=true;syncDocumentForm(true)};
  put(after,keep);
  doH({bytes:canvasStateBytes(before,after),undo:()=>put(before,beforeBook),redo:()=>put(after,keep)});
  uiNotice('Book cover · '+n.W+' × '+n.H+' px');return true;
 }finally{bookBusy=false}
}
// Choosing "Book cover" for an existing canvas adopts it as it is: no resize, just the guides and trim bounds.
function bookAdopt(){
 const L=bookCurrentLayout();
 return bookApply({pageW:bookMm(L.pageW),pageH:bookMm(L.pageH),spine:bookMm(L.spine),bleed:bookMm(L.bleed),extend:true},{adopt:true});
}
const bookUI={built:false,controls:{},paper:null,pending:{...BOOK_DEFAULTS,pages:0,paper:'white'}};
function bookSummary(){
 const p=bookUI.pending,n=bookLayout(p),dpi=documentDPI,mm=v=>(v/dpi*25.4).toFixed(1),el=$('bookSummary'),fit=$('bookFit'),note=$('bookSpineNote');
 const tooBig=n.W>8192||n.H>8192||n.W*n.H>33554432,mismatch=!!documentMeta.book&&(n.W!==DW||n.H!==DH);
 el.textContent=(tooBig?'Too large: ':'Full cover: ')+n.W+' × '+n.H+' px · '+mm(n.W)+' × '+mm(n.H)+' mm at '+dpi+' DPI'+(tooBig?' (limit 8192 per side)':'');
 el.className='smoothing-note'+(tooBig?' book-bad':'');fit.hidden=!mismatch||tooBig;
 if(p.pages>0){const even=p.pages+(p.pages%2),t=KDP_PAPER.find(x=>x[0]===p.paper)[2];
  note.hidden=false;note.textContent=even+' pages × '+t+' in = '+(even*t*25.4).toFixed(2)+' mm'+(p.pages<24?' · under 24 pages':p.pages<79?' · no spine text under 79 pages':'');
  note.className='smoothing-note'+(p.pages<24?' book-bad':'')}
 else{note.textContent='';note.hidden=true}
}
function bookBuild(){
 const host=$('bookFields'),F=lengthField('book',{fallback:'mm'});
 const row=(label,tip)=>{const r=document.createElement('div');r.className='book-row';const c=document.createElement('span');c.className='desktop-value-label';c.textContent=label;c.title=tip;r.append(c);host.append(r);return r};
 const control=(key,label,tip,min)=>{const r=row(label,tip);
  const api=createCompactValueControl({id:'book_'+key,label,get:()=>bookPx(bookUI.pending[key]),set:v=>{bookUI.pending[key]=Math.max(min?.1:0,Math.round(bookMm(v)*1000)/1000);bookSummary()},min:0,max:8192,step:1,dragStep:.5,reset:bookPx(BOOK_DEFAULTS[key]),digits:3,parse:F.parse,format:F.format});
  api.root.classList.add('desktop-value','length-field');const commit=()=>bookCommit(key);api.input.addEventListener('change',commit);api.root.addEventListener('valuecommit',commit);r.append(api.root);bookUI.controls[key]=api};
 control('pageW','Page width','Width of one cover at trim size',1);control('pageH','Page height','Height of the cover at trim size',1);
 {const r=row('Page count','Number of interior pages: the spine width is calculated from it (KDP paperback paper thickness)');
  const api=createCompactValueControl({id:'book_pages',label:'Page count',get:()=>bookUI.pending.pages||0,set:v=>{bookUI.pending.pages=Math.max(0,Math.min(2000,Math.round(v)));bookSummary()},min:0,max:2000,step:2,dragStep:.25,reset:0,digits:0,
   parse:t=>/^\s*(off|none|-+)?\s*$/i.test(t)?0:parseFloat(t),format:v=>v>0?String(Math.round(v)):'Off'});
  api.root.classList.add('desktop-value');const commit=()=>bookCommit('pages');api.input.addEventListener('change',commit);api.root.addEventListener('valuecommit',commit);r.append(api.root);bookUI.controls.pages=api}
 {const r=row('Paper','KDP paper stock: the thickness of one page');const sel=document.createElement('select');sel.id='bookPaper';sel.className='canvas-select';sel.setAttribute('aria-label','KDP paper stock');
  for(const [v,l,t] of KDP_PAPER)sel.add(new Option(l+' · '+t+' in/page',v));sel.onchange=()=>{bookUI.pending.paper=sel.value;bookCommit('paper')};r.append(sel);bookUI.paper=sel}
 control('spine','Spine width','Width of the spine between the covers (set by the page count when one is entered)',0);control('bleed','Bleed','Extra area outside the trim on every outer edge',0);
 $('bookExtend').addEventListener('change',e=>{if(documentMeta.book){documentMeta.book.extend=e.target.checked;projectDirty=true}});
 $('bookGuides').onclick=()=>{if(documentMeta.book)bookApply(documentMeta.book);else bookAdopt()};
 $('bookFit').onclick=()=>{if(bookApply({...bookUI.pending,pages:bookUI.pending.pages>0?bookUI.pending.pages:null,extend:$('bookExtend').checked}))bookSync()};
 bookUI.built=true;
}
function bookCommit(source){
 const cur=documentMeta.book,p=bookUI.pending,keys=['pageW','pageH','spine','bleed'];
 if(source==='spine'&&p.pages>0&&cur&&Math.abs(cur.spine-p.spine)>1e-6)p.pages=0;                    // typing a spine width takes over from the page count
 if((source==='pages'||source==='paper')&&p.pages>0)p.spine=kdpSpineMm(p.pages,p.paper);           // the page count sets the spine
 if(cur&&keys.every(k=>Math.abs(cur[k]-p[k])<1e-6)&&(cur.pages||0)===(p.pages||0)&&cur.paper===p.paper){bookSync();return}
 if(!bookApply({...p,pages:p.pages>0?p.pages:null,extend:$('bookExtend').checked})){const b=documentMeta.book||BOOK_DEFAULTS;for(const k of keys)p[k]=b[k];p.pages=b.pages||0;p.paper=b.paper||'white'}
 bookSync();
}
function bookSync(){
 if($('bookCoverGroup').hidden)return;if(!bookUI.built)bookBuild();
 const b=documentMeta.book;if(b){for(const k of ['pageW','pageH','spine','bleed'])bookUI.pending[k]=b[k];bookUI.pending.pages=b.pages||0;bookUI.pending.paper=b.paper||'white';$('bookExtend').checked=b.extend!==false}
 bookUI.paper.value=bookUI.pending.paper;for(const api of Object.values(bookUI.controls))api.sync();bookSummary();
}
// A ready-made cover: set up from exact physical sizes (mm) right after the new document exists.
function bookTemplate(mm){
 const b=sanitizeBook({...mm,extend:true,pages:null,paper:'white'}),L=bookLayout(b);
 documentMeta.type='book';
 documentMeta.book=L.W===DW&&L.H===DH?{...b,px:{bleed:L.bleed,pageW:L.pageW,pageH:L.pageH,spine:L.spine}}:b;
 bookApply(documentMeta.book,{adopt:true});syncDocumentForm(true);
}
const LANDING_TEMPLATES=[{id:'cover5x8',title:'5 × 8 in book cover',sub:'11 × 8.25 in · 0.75 in spine · 0.125 in bleed · 300 DPI'}];
{const host=$('landingTemplates');if(host)for(const t of LANDING_TEMPLATES){
 const b=document.createElement('button');b.type='button';b.className='template-card';b.title='Create a '+t.title+' cover with guides for the back, spine and front';
 b.innerHTML='<svg viewBox="0 0 66 44" width="66" height="44" aria-hidden="true"><rect x="1.5" y="1.5" width="63" height="41" rx="3" fill="none" stroke="currentColor" stroke-width="1.5"/><rect x="3.5" y="3.5" width="59" height="37" fill="none" stroke="#be8af3" stroke-width="1" stroke-dasharray="3 2"/><line x1="29" y1="3.5" x2="29" y2="40.5" stroke="#ff5a1f" stroke-width="2"/><line x1="37" y1="3.5" x2="37" y2="40.5" stroke="#ff5a1f" stroke-width="2"/><line x1="16" y1="3.5" x2="16" y2="40.5" stroke="#6fa8ff" stroke-width="1" stroke-dasharray="3 2"/><line x1="50" y1="3.5" x2="50" y2="40.5" stroke="#6fa8ff" stroke-width="1" stroke-dasharray="3 2"/></svg>';
 const text=document.createElement('span');text.className='template-text';const h=document.createElement('b');h.textContent=t.title;const d=document.createElement('small');d.textContent=t.sub;text.append(h,d);b.append(text);
 b.onclick=()=>{$('newDocumentPreset').value=t.id;$('newDocumentPreset').dispatchEvent(new Event('change',{bubbles:true}));createNewDocument()};host.append(b)}}
$('docTypeSelect').addEventListener('change',()=>{if(documentMeta.type==='book'){if(!documentMeta.book)bookAdopt();else bookSync()}});

