/* v304: layers being decoded by the core after opening a file (adoptProject) count as pending, and reads that skip the
 *       queue (binaryNow) wait for those decodes, so parking never reads a surface the core has not loaded yet.
 * v300: the save preview no longer comes from the core (project.thumbnail removed): app.js savePreview() takes the GPU
 *       display's overview instead.
 * v299: cleanup. One core mode remains (lazy): the per-edit "eager" mirroring, the core-drawn canvas (NativeDisplay,
 *       raster.display) and the core Standard/Sketch/Bristle brush engines were removed (archived separately as
 *       Bungalow-core-brushes-archive-299). Shadow mode (?nativeShadow: per-op mirroring with verification) is unchanged.
 * v293: saving encodes in the core with cached PNGs of unchanged tiles (the opened file's own tiles to start) and in
 *       parallel; opening no longer waits for the core to decode (adoptProject queues it in the background).
 * v292: lazy flush without UI-thread stalls (desktop log: 45-220 ms tasks during brush travel). Tiles are snapshotted
 *       with createImageBitmap and read back in a worker (no getImageData on the UI thread, no GPU sync there); sent
 *       in small batches (4 tiles, ~1 MB), one at a time, only while input is idle (a stroke pauses the flush);
 *       whole-surface syncs stream the same way (writeTiles {replace}) instead of hashing every tile.
 * v291: (A) raw transport: bungalow_core_raw takes the request as bytes with pixel/file attachments and answers as bytes
 *       (Core::handle_raw), so nothing large is base64-encoded or JSON-parsed on the UI thread; the Tauri commands are
 *       async (they no longer run on the window's main thread). Falls back to the JSON command without it.
 *       (B) lazy core mode (the default in Tauri; localStorage bungalowNativeCore: '1'/'lazy' on, '0' off;
 *       tests: ?nativeCore): the browser paints alone; pixel writes only
 *       mark changed 256px tiles, which reach the core in small batches once input pauses (raster.writeTiles). History
 *       stays in the app. (C) saving flushes once, then the core encodes the layers (project.encodeTiles).
 * v280: binary results (NativeShadow.binary): Tauri's bungalow_core_bin returns raw bytes (ArrayBuffer) for composites,
 *       surface reads and PNG tile encoding; other transports use {method:'binary'} with base64. Project saving uses it.
 * v267: native shadow mode (stage 6). v268: also mirrors raster pixels (see the raster section below).
 * v273: modifier layers composite natively; ops the core reports as `approximate` (rotated/skewed transforms: edge
 *       anti-aliasing is modelled, not bit-exact) allow edge near misses on up to APPROX_SHARE of channels (±NEAR_MAX).
 * v270: with ?nativeShadow=full (or localStorage bungalowNativeShadow=full) the native compositor also renders the
 *       whole document at each history step and is compared with the app's CPU compositor (see the composite section).
 * v269: history snapshots and swaps, surface replace/restore, putPixels and 1:1 placeImage are replayed natively.
 * When enabled (URL ?nativeShadow or localStorage bungalowNativeShadow=1) and a native transport exists
 * (Tauri: invoke('bungalow_core', {request}); tests: window.__bungalowNativeInvoke), every outermost document-store
 * call is replayed in the native core (native/bungalow-core) with the JS outcome as the expectation, and at every
 * history step the native snapshot is compared with the JS one. The JS store stays authoritative; divergences are
 * collected in NativeShadow.stats() and logged to the console. Off by default: no cost beyond a null check.
 */
const NativeShadow=(()=>{
 const tauri=()=>!!(window.__TAURI__?.core?.invoke||window.__TAURI_INTERNALS__?.invoke);
 // v299: one core mode (lazy). The per-edit 'eager' mirroring was removed; 'eager' and a bare ?nativeCore now mean lazy.
 const coreSetting=()=>{try{const q=new URLSearchParams(location.search);if(q.has('nativeShadow'))return null;if(q.has('nativeCore'))return 'lazy';const v=localStorage.getItem('bungalowNativeCore');if(v==='0')return null;if(v==='1'||v==='lazy'||v==='eager')return 'lazy';return tauri()&&!localStorage.getItem('bungalowNativeShadow')?'lazy':null}catch(_){return null}};
 const coreFlag=()=>!!coreSetting();
 const flag=()=>{try{const q=new URLSearchParams(location.search);return coreFlag()||q.has('nativeShadow')||['1','full'].includes(localStorage.getItem('bungalowNativeShadow'))}catch(_){return false}};
 const fullMode=()=>{if(core)return false;try{return new URLSearchParams(location.search).get('nativeShadow')==='full'||localStorage.getItem('bungalowNativeShadow')==='full'}catch(_){return false}};
 // v291 (A): attachments. packImage() gives {width, height, __raw: bytes}; {__bytes: bytes} is a raw byte value. The raw
 // transport moves them into the attachment area ({$bin: [offset, length]}); the JSON transport base64-encodes them.
 const rawTransport=()=>window.__TAURI__?.core?.invoke?b=>window.__TAURI__.core.invoke('bungalow_core_raw',b):window.__TAURI_INTERNALS__?.invoke?b=>window.__TAURI_INTERNALS__.invoke('bungalow_core_raw',b):typeof window.__bungalowNativeInvokeRaw==='function'?b=>window.__bungalowNativeInvokeRaw(b):null;
 let rawOff=false;
 const b64of=bytes=>{let s='';for(let i=0;i<bytes.length;i+=0x8000)s+=String.fromCharCode.apply(null,bytes.subarray(i,i+0x8000));return btoa(s)};
 function attach(v,parts,state){if(!v||typeof v!=='object')return v;if(Array.isArray(v))return v.map(x=>attach(x,parts,state));
  if(v.__raw instanceof Uint8Array){const {__raw,...o}=v;if(parts){o.data={$bin:[state.off,__raw.length]};parts.push(__raw);state.off+=__raw.length}else o.data=b64of(__raw);return o}
  if(v.__bytes instanceof Uint8Array){if(parts){const o={$bin:[state.off,v.__bytes.length]};parts.push(v.__bytes);state.off+=v.__bytes.length;return o}return b64of(v.__bytes)}
  if(Object.getPrototypeOf(v)!==Object.prototype)return v;let out=null;for(const k in v){const x=v[k],y=attach(x,parts,state);if(y!==x){out=out||{...v};out[k]=y}}return out||v}
 const enc8=new TextEncoder(),dec8=new TextDecoder();
 function rawCall(tr,req,binaryResult=false){const t0=performance.now(),parts=[],state={off:0},body=attach(binaryResult?{...req,binary:true}:req,parts,state),j=enc8.encode(JSON.stringify(body)),buf=new Uint8Array(4+j.length+state.off);new DataView(buf.buffer).setUint32(0,j.length,true);buf.set(j,4);let o=4+j.length;for(const p of parts){buf.set(p,o);o+=p.length}const bt=performance.now()-t0;if(bt>(stats.raster.maxBodyMs||0))stats.raster.maxBodyMs=+bt.toFixed(1);
  return tr(buf).then(r=>{const u=r instanceof ArrayBuffer?new Uint8Array(r):r instanceof Uint8Array?r:Array.isArray(r)?Uint8Array.from(r):null;if(!u)throw Error('unexpected raw response');const n=new DataView(u.buffer,u.byteOffset,u.byteLength).getUint32(0,true),resp=JSON.parse(dec8.decode(u.subarray(4,4+n)));if(binaryResult){if(!resp.ok)throw Error(resp.error||'no response');return u.subarray(4+n)}return resp})}
 // invoke(req) for everything on the queue: raw when available, JSON otherwise (attachments base64-encoded).
 function wrapTransport(json){const tr=rawTransport();return req=>{if(tr&&!rawOff)return rawCall(tr,req).catch(e=>{const m=String(e?.message||e);if(/not found|unknown command|not allowed|denied/i.test(m)){rawOff=true;console.info('Native core: bungalow_core_raw unavailable, using the JSON transport');return json(attach(req,null))}throw e});return json(attach(req,null))}}
 const transport=()=>window.__TAURI__?.core?.invoke?req=>window.__TAURI__.core.invoke('bungalow_core',{request:req}):window.__TAURI_INTERNALS__?.invoke?req=>window.__TAURI_INTERNALS__.invoke('bungalow_core',{request:req}):/* v268: Tauri without withGlobalTauri */typeof window.__bungalowNativeInvoke==='function'?req=>window.__bungalowNativeInvoke(req):null;
 // JSON-safe argument encoding; undefined and non-finite numbers become sentinel objects.
 const enc=v=>v===undefined?{$undefined:true}:v instanceof Set?[...v].map(enc):Array.isArray(v)?v.map(enc):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,enc(x)])):typeof v==='number'&&!Number.isFinite(v)?{$nonFinite:String(v)}:v;
 const same=(a,b)=>{if(typeof a==='number'&&typeof b==='number')return a===b;if(Array.isArray(a)||Array.isArray(b))return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((x,i)=>same(x,b[i]));if(a&&b&&typeof a==='object'&&typeof b==='object'){const ka=Object.keys(a),kb=Object.keys(b);return ka.length===kb.length&&ka.every(k=>k in b&&same(a[k],b[k]))}return a===b};
 const firstDiff=(a,b,path='')=>{if(same(a,b))return null;if(a&&b&&typeof a==='object'&&typeof b==='object'){for(const k of new Set([...Object.keys(a),...Object.keys(b)])){const d=firstDiff(a[k],b[k],path+'.'+k);if(d)return d}}return path||'.'};
 const stats={enabled:false,calls:0,compares:0,divergences:[],errors:[],composite:{compared:0,skipped:0,nearMisses:0,maxDiff:0,reasons:[]},raster:{mirrored:0,synced:0,compared:0,created:0,maxDiff:0,ops:{}}};let invoke=null,chain=Promise.resolve(),core=false,lazy=false;
 const note=(kind,detail)=>{const d={kind,...detail};if(stats.divergences.length<50)stats.divergences.push(d);try{console.warn('[Bungalow native shadow] divergence',d)}catch(_){}};
 // v283: one queue step that may issue a follow-up request (returned promise) before the next queued request runs.
 const sendStep=(req,follow)=>{chain=chain.then(()=>invoke(req)).then(resp=>follow(resp)).catch(e=>{stats.errors.push(String(e?.message||e))});return chain};
 // v283: tile content hash over the readback premultiplied the core's way; must match tile_hash in native/bungalow-core/src/surfaces.rs.
 function tileHash(im){const d=im.data,n=d.length,p=new Uint8Array(n);for(let i=0;i<n;i+=4){const a=d[i+3];if(a===255){p[i]=d[i];p[i+1]=d[i+1];p[i+2]=d[i+2]}else if(a){p[i]=(d[i]*a+127)/255|0;p[i+1]=(d[i+1]*a+127)/255|0;p[i+2]=(d[i+2]*a+127)/255|0}p[i+3]=a}
  const u=new Uint32Array(p.buffer);let a=(0x811c9dc5^im.width)>>>0,b=(0x9747b28c^im.height)>>>0;for(let i=0;i<u.length;i++){const v=u[i];a=Math.imul(a^v,0x01000193);let t=b^Math.imul(v,0xcc9e2d51);t=t<<13|t>>>19;b=Math.imul(t,5)+0xe6546b64|0}
  return (a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0')}
 const send=(req,check)=>{chain=chain.then(()=>invoke(req)).then(resp=>{try{check&&check(resp)}catch(e){stats.errors.push(String(e))}}).catch(e=>{stats.errors.push(String(e?.message||e))});return chain};
 function jsReports(){return {tree:documentStore.verify(),collections:documentStore.verifyCollections(),props:documentStore.verifyProps(),records:documentStore.verifyRecords(),parked:documentStore.verifyParked()}}
 // Compare native and JS documents (state + consistency reports). Revisions are not compared: the JS store
 // ran startup commits before shadowing began.
 function checkpoint(label='checkpoint'){if(!stats.enabled)return;if(!lazy)mirror({method:'raster.checkpoint',args:[]}); // v283: the core's checkpoint tile cache starts over (see adoptTiles {live})
if(lazy){scheduleFlush();return}const js={state:documentStore.snapshotDocument(),verify:jsReports()};if(typeof RasterResources!=='undefined'){checkRasters(label);if(fullMode())checkComposite(label)}stats.compares++;send({method:'snapshot'},resp=>{const nat=resp.result;if(!nat){note('snapshot-failed',{label,error:resp.error});return}if(!same(nat.state,js.state))note('state',{label,path:firstDiff(nat.state,js.state)});else if(!same(nat.verify,js.verify))note('verify',{label,path:firstDiff(nat.verify,js.verify)})})}
 // ---- v268: raster shadow ----------------------------------------------------------------------------
 // RasterResources reports each named write. Replayed natively from their inputs (the parity under test):
 // composeRegion, fillRegion, fillTiles, clearRegion, writeRegion, putPixels, placeImage at 1:1, replaceSurface,
 // installTiles, detachTiles, and (v269) tile snapshots + swapTiles and surface snapshots + restoreSurface.
 // Still copied from JS ("synced"): fillGeometry (vector rasterisation), scaled placeImage, and swaps or restores of
 // snapshots taken before shadowing started. At each history
 // step every surface written since the last step is compared (premultiplied, tolerance RASTER_TOLERANCE) and then
 // resynced from JS, so rounding never accumulates. Surfaces created or given new storage (setPart) during a
 // step are re-read at its checkpoint instead of compared and each step is checked on its own.
 const RASTER_TOLERANCE=3,NATIVE_OPS=new Set(['source-over','destination-out','source-atop','copy']);
 const knownSnaps=new Set(),reinit=new Set(),fresh=new Set()/* v284: attached since the last checkpoint (callers may fill a new canvas directly) */,known=new Set(),dirty=new Set(),recent=new Map(); // recent: ops per surface since the last compare (diagnostics)
 const b64=bytes=>{let s='';for(let i=0;i<bytes.length;i+=0x8000)s+=String.fromCharCode.apply(null,bytes.subarray(i,i+0x8000));return btoa(s)};
 const packImage=im=>im&&{width:im.width,height:im.height,__raw:new Uint8Array(im.data.buffer,im.data.byteOffset,im.data.byteLength)}; // v291: attachment (see attach())
 // Pixels of any drawable (canvas, bitmap, ImageData) as a packed image.
 // v283: raw ImageData of a drawable (pixelsOf packs it as base64)
 function drawablePixels(src){if(typeof ImageData!=='undefined'&&src instanceof ImageData)return src;const w=src.width|0,h=src.height|0;if(!(w>0&&h>0))return null;const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d',{willReadFrequently:true});g.drawImage(src,0,0);return g.getImageData(0,0,w,h)}
 function pixelsOf(src){if(!src)return null;if(typeof ImageData!=='undefined'&&src instanceof ImageData)return packImage(src);const w=src.width|0,h=src.height|0;if(!(w>0&&h>0))return null;const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d',{willReadFrequently:true});g.drawImage(src,0,0);return packImage(g.getImageData(0,0,w,h))}
 let colourCtx=null;
 function rgba(colour){if(!colourCtx){const c=document.createElement('canvas');c.width=c.height=1;colourCtx=c.getContext('2d',{willReadFrequently:true})}const g=colourCtx;g.globalCompositeOperation='copy';g.fillStyle='#000';g.fillStyle=colour;g.fillRect(0,0,1,1);return [...g.getImageData(0,0,1,1).data]}
 // Whole-store pixels (tiles composed) and an ImageData sub-rectangle.
 function storePixels(store){const c=document.createElement('canvas');c.width=store.width;c.height=store.height;const g=c.getContext('2d',{willReadFrequently:true});for(const [k,tile] of store.tiles){const [x,y]=k.split(':').map(Number);g.drawImage(tile,x,y)}return packImage(g.getImageData(0,0,c.width,c.height))}
 function cropImage(im,d){if(!d||d.x===0&&d.y===0&&d.w===im.width&&d.h===im.height)return packImage(im);const out=new ImageData(d.w,d.h);for(let y=0;y<d.h;y++)out.data.set(im.data.subarray(((d.y+y)*im.width+d.x)*4,((d.y+y)*im.width+d.x+d.w)*4),y*d.w*4);return packImage(out)}
 const rasterNote=(kind,how)=>{const o=stats.raster.ops;o[kind]=(o[kind]||0)+1;stats.raster[how]++};
 // v278: only painted 256×256 tiles travel (new and sparse layers are mostly empty)
 // v284: tiles travel as content hashes ({live}); the core takes any identical tile it holds at that position (duplicated
 // layers, unchanged resyncs) and the misses follow in the same queue step (raster.patchTiles).
 // v285: core mode renders retained vector layers itself from their recorded geometry (src/native-vector-285.js).
 function ownerOf(id){const all=typeof residentArtboardLayers==='function'?residentArtboardLayers():layers;return all.find(L=>L.rasterId===id)||null}
 // v286: clone layers are drawn in the core from their source surface (raster.cloneFrom) when the source is a plain
 // raster layer and the clone has no deformations; the source is brought up to date first.
 let cloneDepth=0;
 function syncClone(id){if(!core)return false;const L=ownerOf(id),I=L?.instance;if(I?.type!=='clone'||!I.src||I.src.instance||I.deformations?.length||!I.src.rasterId)return false;
  const P=RasterResources.payload(id),S=RasterResources.payload(I.src.rasterId),dims=p=>p?[p.sparse?.width||p.canvas?.width,p.sparse?.height||p.canvas?.height]:null,a=dims(P),b=dims(S);if(!a||!b||a[0]!==b[0]||a[1]!==b[1])return false;
  const sid=I.src.rasterId;if((!known.has(sid)||reinit.has(sid)||fresh.has(sid))&&cloneDepth<4){cloneDepth++;try{syncSurface(sid)}finally{cloneDepth--}reinit.delete(sid);fresh.delete(sid)}
  const W=a[0],H=a[1],cx=W/2,cy=H/2,fx=I.flipH?-1:1,fy=I.flipV?-1:1,mul=(A,B)=>[A[0]*B[0]+A[2]*B[1],A[1]*B[0]+A[3]*B[1],A[0]*B[2]+A[2]*B[3],A[1]*B[2]+A[3]*B[3],A[0]*B[4]+A[2]*B[5]+A[4],A[1]*B[4]+A[3]*B[5]+A[5]];
  let M=I.xf?I.xf.slice():[1,0,0,1,0,0];M=mul(M,[1,0,0,1,cx+(I.dx||0),cy+(I.dy||0)]);M=mul(M,[fx,0,0,fy,0,0]);M=mul(M,[1,0,0,1,-cx,-cy]);
  known.add(id);stats.raster.cloneLayers=(stats.raster.cloneLayers||0)+1;send({method:'raster.cloneFrom',args:[id,sid,M]},resp=>{if(!resp.ok)stats.errors.push('raster.cloneFrom '+resp.error)});return true}
 function syncVector(id){if(!core||typeof NativeVector==='undefined')return false;const L=ownerOf(id);if(L?.instance?.type!=='shape')return false;const r=NativeVector.record(L);if(r.unsupported)return false;
  known.add(id);stats.raster.vectorLayers=(stats.raster.vectorLayers||0)+1;send({method:'vector.layer',args:[id,r.w,r.h,{draws:r.draws,clips:r.clips}]},resp=>{if(!resp.ok)stats.errors.push('vector.layer '+resp.error)});return true}
 // v289: sparse layers are read tile by tile (only painted tiles; no document-sized readback, which took ~0.2 s per
 // layer at 5000x2000); dense surfaces are read whole as before.
 function surfaceTiles(id){const P=RasterResources.payload(id),T=256;if(!P)return null;const out={};
  if(P.sparse&&P.sparse.tileSize===T){for(const [k,tile] of P.sparse.tiles){if(!tile?.width)continue;const t=tile.getContext('2d',{willReadFrequently:true}).getImageData(0,0,tile.width,tile.height);let any=false;for(let i=3;i<t.data.length;i+=4)if(t.data[i]){any=true;break}if(any)out[k]=t}return {width:P.sparse.width,height:P.sparse.height,tiles:out}}
  const im=RasterResources.readRegion(id);if(!im)return null;const d=im.data;
  for(let ty=0;ty<im.height;ty+=T)for(let tx=0;tx<im.width;tx+=T){const tw=Math.min(T,im.width-tx),th=Math.min(T,im.height-ty);let any=false;for(let y=0;y<th&&!any;y++){const row=((ty+y)*im.width+tx)*4;for(let x=3;x<tw*4;x+=4)if(d[row+x]){any=true;break}}
   if(any){const t=new ImageData(tw,th);for(let y=0;y<th;y++)t.data.set(d.subarray(((ty+y)*im.width+tx)*4,((ty+y)*im.width+tx+tw)*4),y*tw*4);out[tx+':'+ty]=t}}
  return {width:im.width,height:im.height,tiles:out}}
 function syncSurface(id){if(syncVector(id)||syncClone(id))return;const S=surfaceTiles(id);if(!S)return;known.add(id);const tiles={},raw={};
  for(const [k,t] of Object.entries(S.tiles)){raw[k]=t;tiles[k]={live:tileHash(t)}}const im={width:S.width,height:S.height};
  sendStep({method:'raster.setTiles',args:[id,im.width,im.height,tiles]},resp=>{if(!resp.ok){stats.errors.push('raster.setTiles '+resp.error);return}const miss=resp.result?.missing||[];stats.raster.syncLive=(stats.raster.syncLive||0)+Object.keys(raw).length-miss.length;if(!miss.length)return;stats.raster.syncPatched=(stats.raster.syncPatched||0)+miss.length;
   const patch={};for(const k of miss)patch[k]=packImage(raw[k]);return invoke({method:'raster.patchTiles',args:[id,patch]}).then(r=>{if(!r.ok)stats.errors.push('raster.patchTiles '+r.error)})})}
 // v284: large writes (fills, filters, whole-layer edits) travel per tile-grid chunk: chunks whose pixels the core already
 // has (same content hash) are skipped and only changed chunks are uploaded, in the same queue step.
 function subImage(im,d){const out=new ImageData(d.w,d.h);for(let y=0;y<d.h;y++)out.data.set(im.data.subarray(((d.y+y)*im.width+d.x)*4,((d.y+y)*im.width+d.x+d.w)*4),y*d.w*4);return out}
 function writeChunked(id,im,x,y){x=Math.floor(x);y=Math.floor(y);if(im.width*im.height<131072){mirror({method:'raster.writeRegion',args:[id,packImage(im),x,y]});return}
  const T=256,chunks=[],parts=[];for(let gy=Math.floor(y/T)*T;gy<y+im.height;gy+=T)for(let gx=Math.floor(x/T)*T;gx<x+im.width;gx+=T){const x0=Math.max(gx,x),y0=Math.max(gy,y),x1=Math.min(gx+T,x+im.width),y1=Math.min(gy+T,y+im.height);if(x1<=x0||y1<=y0)continue;const part=subImage(im,{x:x0-x,y:y0-y,w:x1-x0,h:y1-y0});parts.push(part);chunks.push([x0,y0,x1-x0,y1-y0,tileHash(part),null])}
  sendStep({method:'raster.writeChunks',args:[id,chunks]},resp=>{if(!resp.ok){stats.errors.push('raster.writeChunks '+resp.error);return}const miss=resp.result?.missing||[];stats.raster.chunksSkipped=(stats.raster.chunksSkipped||0)+chunks.length-miss.length;if(!miss.length)return;
   return invoke({method:'raster.writeChunks',args:[id,miss.map(i=>[chunks[i][0],chunks[i][1],chunks[i][2],chunks[i][3],null,packImage(parts[i])])]}).then(r=>{if(!r.ok)stats.errors.push('raster.writeChunks '+r.error)})})}
 function syncRect(id,x,y,w,h){const im=RasterResources.readRegion(id,{x:Math.floor(x),y:Math.floor(y),w:Math.ceil(w),h:Math.ceil(h)});if(!im)return;send({method:'raster.writeRegion',args:[id,packImage(im),Math.floor(x),Math.floor(y)]})}
 const mirror=req=>send(req,resp=>{if(!resp.ok)stats.errors.push(req.method+' '+resp.error)});
 // ---- v291 (B): lazy core mode -------------------------------------------------------------------------------
 // Pixel writes mark the 256px tiles they touch; nothing is sent while the user works. Once input pauses, marked tiles
 // reach the core in batches (raster.writeTiles, ~16 MB per request, yielding between requests); surfaces with unknown
 // or replaced content are synced whole (setTiles with content hashes); vector and clone layers are drawn by the core.
 const TILE=256,BATCH=4,pendingTiles=new Map(),pendingFull=new Set(),pendingVerify=new Map();let flushTimer=0,flushing=null,holds=0;
 function markTiles(id,r){if(!r||!(r.w>0&&r.h>0)){pendingFull.add(id);return}let set=pendingTiles.get(id);if(!set)pendingTiles.set(id,set=new Set());
  for(let y=Math.max(0,Math.floor(r.y/TILE)*TILE);y<r.y+r.h;y+=TILE)for(let x=Math.max(0,Math.floor(r.x/TILE)*TILE);x<r.x+r.w;x+=TILE)set.add(x+':'+y)}
 // The area a named write touches (null: unknown, sync the whole surface).
 function writeArea(name,a){const sz=v=>v&&{w:v.width|0,h:v.height|0};const R=r=>r&&{x:Math.floor(r.x),y:Math.floor(r.y),w:Math.ceil(r.w+(r.x-Math.floor(r.x))),h:Math.ceil(r.h+(r.y-Math.floor(r.y)))};
  switch(name){case 'composeRegion':case 'fillRegion':case 'fillTiles':case 'clearRegion':return R(a[1]);
   case 'writeRegion':{const z=sz(a[1]);return z&&{x:Math.floor(a[2]||0),y:Math.floor(a[3]||0),w:z.w+1,h:z.h+1}}
   case 'floodFill':{const z=sz(a[1]);return z&&{x:a[2]|0,y:a[3]|0,w:z.w,h:z.h}}
   case 'putPixels':{const d=a[4]||{x:0,y:0,w:a[1].width,h:a[1].height};return {x:(a[2]||0)+d.x,y:(a[3]||0)+d.y,w:d.w,h:d.h}}
   case 'placeImage':return R({x:a[2],y:a[3],w:a[4],h:a[5]});case 'fillGeometry':return a[2]?R(a[2]):null;
   case 'swapTiles':{const m=RasterResources.tiles(a[1]);if(!m)return null;return {keys:[...m.keys()]}}
   default:return null}}
 function lazyRaster(name,id,a){
  // v293: a storage swap (setPart: dense <-> sparse) of a surface the core holds keeps its pixels: resend its tiles as
  // tile writes; the core skips identical ones (their cached PNGs survive for the next save).
  if(name==='setPart'&&known.has(id)){const P=RasterResources.payload(id);if(P){let set=pendingVerify.get(id);if(!set)pendingVerify.set(id,set=new Set());for(const k of allTileKeys(P))set.add(k);scheduleFlush();return}}
  if(name==='attach'||name==='setPart'||name==='replaceSurface'||name==='installTiles'||name==='restoreSurface'||name==='detachTiles'){pendingFull.add(id);scheduleFlush();return}
  const r=writeArea(name,a);if(r?.keys){let set=pendingTiles.get(id);if(!set)pendingTiles.set(id,set=new Set());for(const k of r.keys)set.add(k)}else markTiles(id,r);scheduleFlush()}
 // v296: only real input pauses the background flush. canvasBusy() also counts a save in progress (projectIOBusy),
 // history steps and open dialogs: a flush waiting on those while a save waited on the flush froze saving
 // ("Preparing project…", two artboards on desktop).
 const inputBusy=()=>{try{return !!(drawing||(typeof panning!=='undefined'&&panning)||(typeof shapeDrag!=='undefined'&&shapeDrag)||(typeof transformSession!=='undefined'&&transformSession))}catch(_){return false}};
 const adopting=new Set();let adoptDone=Promise.resolve(); // v304: surfaces still being decoded from an opened file
 let urgentWanted=0; // a save is waiting: background flushes stop waiting for idle input
 function scheduleFlush(delay=500){clearTimeout(flushTimer);flushTimer=setTimeout(()=>{if(holds||inputBusy()){scheduleFlush(300);return}flush()},delay)}
 const yieldTask=()=>new Promise(r=>setTimeout(r,0));
 // Worker readback: ImageBitmaps in, straight RGBA out (null for fully transparent tiles).
 let reader=null,readerReady=false,readerSeq=0;const readerWaits=new Map(); // readerReady: the worker answered a ping (a CSP may block blob workers)
 function readerWorker(){if(reader!==null)return reader;try{const src=`onmessage=e=>{if(e.data==='ping'){postMessage('pong');return}const {seq,items}=e.data,out=[],tr=[];let oc=null,g=null;for(const it of items){const b=it.bmp;if(!oc){oc=new OffscreenCanvas(b.width,b.height);g=oc.getContext('2d',{willReadFrequently:true})}if(oc.width!==b.width||oc.height!==b.height){oc.width=b.width;oc.height=b.height}g.clearRect(0,0,oc.width,oc.height);g.drawImage(b,0,0);b.close();const d=g.getImageData(0,0,oc.width,oc.height).data;let any=false;for(let i=3;i<d.length;i+=4)if(d[i]){any=true;break}let hash=null;if(any&&e.data.hash){const n=d.length,p=new Uint8Array(n);for(let i=0;i<n;i+=4){const a=d[i+3];if(a===255){p[i]=d[i];p[i+1]=d[i+1];p[i+2]=d[i+2]}else if(a){p[i]=(d[i]*a+127)/255|0;p[i+1]=(d[i+1]*a+127)/255|0;p[i+2]=(d[i+2]*a+127)/255|0}p[i+3]=a}const u=new Uint32Array(p.buffer);let A=(0x811c9dc5^oc.width)>>>0,B=(0x9747b28c^oc.height)>>>0;for(let i=0;i<u.length;i++){const v=u[i];A=Math.imul(A^v,0x01000193);let t=B^Math.imul(v,0xcc9e2d51);t=t<<13|t>>>19;B=Math.imul(t,5)+0xe6546b64|0}hash=(A>>>0).toString(16).padStart(8,'0')+(B>>>0).toString(16).padStart(8,'0')}if(any){out.push({k:it.k,w:oc.width,h:oc.height,buf:d.buffer,hash});tr.push(d.buffer)}else out.push({k:it.k,w:0,h:0,buf:null})}postMessage({seq,out},tr)}`;
  reader=new Worker(URL.createObjectURL(new Blob([src],{type:'text/javascript'})));reader.onmessage=e=>{if(e.data==='pong'){readerReady=true;return}const w=readerWaits.get(e.data.seq);readerWaits.delete(e.data.seq);w?.(e.data.out)};reader.onerror=()=>{reader=false;readerReady=false};reader.postMessage('ping')}catch(_){reader=false}return reader}
 // Snapshot tiles of a surface now (bitmaps), then read them off the UI thread. Resolves to {k: ImageData|null}.
 async function readTiles(P,keys,hash=false,sources=null){const items=[];if(sources){for(const {k,src} of sources)items.push({k,p:src?.width?createImageBitmap(src):null})}else for(const k of keys){const [x,y]=k.split(':').map(Number);let src=null,sx=0,sy=0,w=TILE,h=TILE;
   if(P.sparse){const t=P.sparse.tiles.get(k);if(t?.width){src=t;w=t.width;h=t.height}}else if(P.canvas){const W=P.canvas.width,H=P.canvas.height;if(x<W&&y<H){src=P.canvas;sx=x;sy=y;w=Math.min(TILE,W-x);h=Math.min(TILE,H-y)}}
   items.push({k,p:src?createImageBitmap(src,sx,sy,w,h):null})}
  if(sources)keys=sources.map(x=>x.k);
  const ready=[];for(const it of items){try{ready.push({k:it.k,bmp:it.p?await it.p:null})}catch(_){ready.push({k:it.k,bmp:null})}}
  const out={},withBmp=ready.filter(r=>r.bmp);for(const r of ready)if(!r.bmp)out[r.k]=null;if(!withBmp.length)return out;
  const wk=readerWorker()&&readerReady?reader:null;
  if(!wk){for(const r of withBmp){const c=document.createElement('canvas');c.width=r.bmp.width;c.height=r.bmp.height;const g=c.getContext('2d',{willReadFrequently:true});g.drawImage(r.bmp,0,0);r.bmp.close();const im=g.getImageData(0,0,c.width,c.height);let any=false;for(let i=3;i<im.data.length;i+=4)if(im.data[i]){any=true;break}out[r.k]=any?im:null;if(any&&hash)im.hash=tileHash(im)}return out}
  const seq=++readerSeq,res=await new Promise(done=>{readerWaits.set(seq,done);wk.postMessage({seq,items:withBmp,hash},withBmp.map(r=>r.bmp))});
  for(const r of res){out[r.k]=r.buf?new ImageData(new Uint8ClampedArray(r.buf),r.w,r.h):null;if(r.hash&&out[r.k])out[r.k].hash=r.hash}return out}
 const waitIdleInput=async()=>{while(!urgentWanted&&(inputBusy()||holds))await new Promise(r=>setTimeout(r,120))};
 // Send the tiles of one surface in batches; replace: start from a transparent surface (whole-surface sync).
 async function streamTiles(id,keys,replace,urgent){const slice=t=>{const d=performance.now()-t;if(d>(stats.raster.maxSliceMs||0))stats.raster.maxSliceMs=+d.toFixed(1)};const P=RasterResources.payload(id);if(!P)return;const W=P.sparse?.width||P.canvas?.width|0,H=P.sparse?.height||P.canvas?.height|0;
  keys=keys.filter(k=>{const [x,y]=k.split(':').map(Number);return x<W&&y<H});if(replace&&!keys.length){mirror({method:'raster.writeTiles',args:[id,W,H,{},{replace:true}]});known.add(id);return}
  const step=urgent||urgentWanted?32:BATCH; // v296: a save sends larger batches (nobody is painting)
  for(let i=0;i<keys.length;i+=step){if(!urgent)await waitIdleInput();const t1=performance.now(),pr=readTiles(P,keys.slice(i,i+step));slice(t1);const tiles=await pr,t2=performance.now(),packed={};for(const k in tiles)packed[k]=tiles[k]?packImage(tiles[k]):null;slice(t2);
   mirror({method:'raster.writeTiles',args:[id,W,H,packed,i===0&&replace?{replace:true}:{}]});known.add(id);stats.raster.lazyTiles=(stats.raster.lazyTiles||0)+keys.slice(i,i+step).length;
   await chain} } // one batch in flight: the next is read only after the core has this one
 // v293: verify a surface the core already holds (storage swaps keep the pixels): content hashes travel, and only
 // tiles that differ are sent. Hashing happens in the worker.
 async function verifyTiles(id,keys){const P=RasterResources.payload(id);if(!P)return;const W=P.sparse?.width||P.canvas?.width|0,H=P.sparse?.height||P.canvas?.height|0;keys=keys.filter(k=>{const [x,y]=k.split(':').map(Number);return x<W&&y<H});
  for(let i=0;i<keys.length;i+=32){await waitIdleInput();const tiles=await readTiles(P,keys.slice(i,i+32),true),req={};for(const k in tiles)req[k]=tiles[k]?{live:tiles[k].hash}:null;
   sendStep({method:'raster.writeTiles',args:[id,W,H,req,{}]},resp=>{if(!resp.ok){stats.errors.push('raster.writeTiles '+resp.error);return}const miss=resp.result?.missing||[];stats.raster.verifiedTiles=(stats.raster.verifiedTiles||0)+Object.keys(req).length-miss.length;if(!miss.length)return;
    const patch={};for(const k of miss)patch[k]=tiles[k]?packImage(tiles[k]):null;stats.raster.lazyTiles=(stats.raster.lazyTiles||0)+miss.length;return invoke({method:'raster.writeTiles',args:[id,W,H,patch,{}]}).then(r=>{if(!r.ok)stats.errors.push('raster.writeTiles '+r.error)})});await chain}}
 const allTileKeys=P=>{if(P.sparse)return [...P.sparse.tiles.keys()];const W=P.canvas?.width|0,H=P.canvas?.height|0,o=[];for(let y=0;y<H;y+=TILE)for(let x=0;x<W;x+=TILE)o.push(x+':'+y);return o};
 // ---- v295 (E): history tiles kept by the core ------------------------------------------------------------------
 const KEEP=3,stashed=new Map(),inflight=new Map();let offloading=false; // stashed: snapshot id -> handle
 const isRemote=c=>!!c&&c.__remote===true;
 // A marker in place of a freed canvas; width x height carries the PNG size so history budgets stay meaningful.
 const remoteMark=bytes=>({__remote:true,width:Math.max(1,Math.ceil(bytes/4)),height:1});
 async function offloadHistory(){if(!lazy||offloading||holds)return;offloading=true;try{
  const H=typeof hist!=='undefined'?hist:[],cur=typeof hp!=='undefined'?hp:H.length,live=new Set();
  for(let i=0;i<H.length;i++){const e=H[i],h=e?._snapshot;if(!h)continue;live.add(h.id);if(Math.abs(i-cur)<=KEEP||stashed.has(h.id)||inflight.has(h.id))continue;
   const map=RasterResources.tiles(h);if(!(map instanceof Map)||!map.size||[...map.values()].some(isRemote))continue;
   if(inputBusy())break;
   const sources=[...map].map(([k,c])=>({k,src:c||null})),read=await readTiles(null,null,false,sources),tiles={};let bytes=0;
   for(const {k,src} of sources){if(map.get(k)!==src){/* swapped meanwhile */tiles.__stale=true;break}const im=read[k];tiles[k]=im?packImage(im):null}
   if(tiles.__stale)continue;
   const p=new Promise(done=>sendStep({method:'raster.stash',args:[h.resource,h.id,tiles]},resp=>{if(!resp.ok){stats.errors.push('raster.stash '+resp.error);done(false);return}bytes=resp.result?.bytes||0;
    // still the same canvases: free them; otherwise the step was used meanwhile and the stash is dropped
    if(sources.some(({k,src})=>map.get(k)!==src)){send({method:'raster.dropStash',args:[null,[h.id]]});done(false);return}
    const per=Math.max(1,bytes/Math.max(1,sources.filter(x=>x.src).length));for(const {k,src} of sources){if(src){map.set(k,remoteMark(per));src.width=src.height=0}}stashed.set(h.id,h);stats.raster.stashedSteps=(stats.raster.stashedSteps||0)+1;stats.raster.stashedBytes=(stats.raster.stashedBytes||0)+bytes;done(true)}));
   inflight.set(h.id,p);await p;inflight.delete(h.id);await yieldTask()}
  const gone=[...stashed.keys()].filter(id=>!live.has(id));if(gone.length){for(const id of gone)stashed.delete(id);send({method:'raster.dropStash',args:[null,gone]})}
 }finally{offloading=false}}
 // Before a history step runs: bring its tiles back from the core if they were stashed.
 async function ensureLocal(entry){const h=entry?._snapshot;if(!h)return;if(inflight.has(h.id))await inflight.get(h.id);const map=RasterResources.tiles(h);if(!(map instanceof Map)||![...map.values()].some(isRemote))return;
  const u=await binary({method:'raster.unstash',args:[h.id]}),dv=new DataView(u.buffer,u.byteOffset,u.byteLength);let o=4;const n=dv.getUint32(0,true),dec=new TextDecoder();
  for(let i=0;i<n;i++){const kl=dv.getUint32(o,true);o+=4;const k=dec.decode(u.subarray(o,o+kl));o+=kl;const w=dv.getUint32(o,true),hh=dv.getUint32(o+4,true);o+=8;
   if(!w||!hh){map.set(k,null);continue}const c=document.createElement('canvas');c.width=w;c.height=hh;c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(u.slice(o,o+w*hh*4).buffer),w,hh),0,0);c.__occ=null;map.set(k,c);o+=w*hh*4}
  for(const [k,c] of map)if(isRemote(c))map.set(k,null);stashed.delete(h.id);stats.raster.restoredSteps=(stats.raster.restoredSteps||0)+1}
 // Send everything marked so far. Resolves when the core has it (ordered on the queue). urgent: do not wait for idle input (saving).
 function flush(urgent=false){if(!lazy||!stats.enabled)return chain;if(flushing){if(urgent){urgentWanted++;return flushing.finally(()=>{urgentWanted--}).then(()=>pendingTiles.size||pendingFull.size||pendingVerify.size?flush(true):chain)}return flushing.then(()=>pendingTiles.size||pendingFull.size||pendingVerify.size?flush(urgent):chain)}clearTimeout(flushTimer);
  flushing=(async()=>{try{
   const live=new Map(RasterResources.surfaces().map(x=>[x.id,x])),{derived}=ownership();
   for(const id of [...known])if(!live.has(id)){known.delete(id);send({method:'raster.release',args:[id]})}
   for(const id of live.keys())if(!known.has(id)||reinit.has(id)||fresh.has(id))pendingFull.add(id);reinit.clear();fresh.clear();
   for(const id of live.keys())if(derived.has(id)&&(dirty.has(id)||pendingTiles.has(id)))pendingFull.add(id);dirty.clear();
   // v299: a clone follows its source (clone renders draw straight into the clone's canvas, so only the source is marked; eager mode's syncRasters did this)
   for(const id of derived){const I=live.has(id)?ownerOf(id)?.instance:null,sid=I?.type==='clone'&&I.src?.rasterId;if(sid&&(pendingTiles.has(sid)||pendingFull.has(sid)))pendingFull.add(id)}
   // v299: derived layers (clones, vectors) are rebuilt in the core after every plain surface has been sent: a clone
   // drawn from its source before the source's pending tiles arrived kept the old pixels.
   const later=[];
   for(const id of [...pendingFull]){pendingFull.delete(id);pendingTiles.delete(id);pendingVerify.delete(id);if(!live.has(id))continue;stats.raster.lazyFull=(stats.raster.lazyFull||0)+1;
    if(derived.has(id)){later.push(id);continue}if(syncVector(id)||syncClone(id))continue;const P=RasterResources.payload(id);if(P)await streamTiles(id,allTileKeys(P),true,urgent)}
   for(const [id,set] of [...pendingTiles]){pendingTiles.delete(id);pendingVerify.get(id)&&[...set].forEach(k=>pendingVerify.get(id).delete(k));if(live.has(id))await streamTiles(id,[...set],false,urgent)}
   for(const id of later){if(syncVector(id)||syncClone(id))continue;const P=RasterResources.payload(id);if(P)await streamTiles(id,allTileKeys(P),true,urgent)}
   for(const [id,set] of [...pendingVerify]){pendingVerify.delete(id);if(live.has(id))await verifyTiles(id,[...set])}
   await chain}finally{flushing=null}if(!urgent)setTimeout(()=>{if(!flushing)offloadHistory()},0)})();return flushing}
  function onRaster(name,id,a,result){
  if(lazy){if(name==='snapshotStore'||name==='adoptTiles'||name==='asSnapshot'||name==='adoptSurface')return;if(typeof id!=='string'||!/^res_/.test(id))return;lazyRaster(name,id,a);return} // v291 (B)
  // v269: snapshot creation (tile capture is replayed natively; adopted tiles and surfaces carry their pixels)
  if(name==='snapshotStore'||name==='adoptTiles'||name==='asSnapshot'||name==='adoptSurface'){onSnapshot(name,a,result);return}
  if(typeof id!=='string'||!/^res_/.test(id))return;dirty.add(id);if(name==='setPart'){reinit.add(id);rasterNote(name,'synced');syncSurface(id);return} // storage replaced: read now (later writes and snapshots build on it) and again at the checkpoint, since callers may still fill a new canvas directly
  {const l=recent.get(id)||[];if(l.length<12)l.push(name);recent.set(id,l)}
  if(name==='attach')fresh.add(id);
  if(!known.has(id)||name==='attach'){syncSurface(id);rasterNote(name,'synced');return}
  if(name==='replaceSurface'){const im=pixelsOf(a[1]);if(im){mirror({method:'raster.set',args:[id,im]});rasterNote(name,'mirrored')}else{syncSurface(id);rasterNote(name,'synced')}return}
  if(name==='installTiles'){mirror({method:'raster.set',args:[id,storePixels(a[1])]});rasterNote(name,'mirrored');return}
  if(name==='detachTiles'){const P=RasterResources.payload(id),s=P?.sparse;mirror({method:'raster.clearRegion',args:[id,{x:0,y:0,w:s?.width||1,h:s?.height||1}]});rasterNote(name,'mirrored');return}
  if(name==='swapTiles'||name==='restoreSurface'){const h=name==='swapTiles'?a[1]:a[0];if(h?.id&&knownSnaps.has(h.id)){mirror({method:'raster.'+name,args:[id,h.id]});rasterNote(name,'mirrored')}else{syncSurface(id);rasterNote(name,'synced')}return}
  if(name==='putPixels'){const im=a[1],d=a[4]||{x:0,y:0,w:im.width,h:im.height};writeChunked(id,d.x===0&&d.y===0&&d.w===im.width&&d.h===im.height?im:subImage(im,d),(a[2]||0)+d.x,(a[3]||0)+d.y);rasterNote(name,'mirrored');return}
  if(name==='placeImage'){const [,img,x,y,w,h]=a;if(Number.isInteger(x)&&Number.isInteger(y)&&w===img?.width&&h===img?.height){const im=pixelsOf(img);if(im){mirror({method:'raster.composeRegion',args:[id,{x,y,w,h},im,x,y,'source-over',1]});rasterNote(name,'mirrored');return}}}
  const rect=a[1],r=rect&&{x:rect.x,y:rect.y,w:rect.w,h:rect.h};
  if(name==='composeRegion'&&NATIVE_OPS.has(a[5]||'source-over')){const im=pixelsOf(a[2]);if(im){mirror({method:'raster.composeRegion',args:[id,r,im,a[3]||0,a[4]||0,a[5]||'source-over',a[6]??1]});rasterNote(name,'mirrored');return}}
  else if((name==='fillRegion'||name==='fillTiles')&&NATIVE_OPS.has(a[3]||'source-over')){const c=rgba(a[2]);mirror({method:'raster.fillRegion',args:[id,r,c.slice(0,3),a[3]||'source-over',(a[4]??1)*c[3]/255]});rasterNote(name,'mirrored');return}
  else if(name==='floodFill'){const im=drawablePixels(a[1]),x=a[2]|0,y=a[3]|0,f=a[4]||{};if(!im)return;
   if(fresh.has(id)||reinit.has(id)){writeChunked(id,im,x,y);rasterNote(name,'mirrored');return}
   // v284: the core repeats the fill; if its region differs from the app's, the pixels follow in the same queue step
   const {region,...spec}=f;sendStep({method:'raster.floodFill',args:[id,spec,region]},resp=>{if(!resp.ok){stats.errors.push('raster.floodFill '+resp.error);return}if(!resp.result?.mismatch){stats.raster.nativeFills=(stats.raster.nativeFills||0)+1;return}
    stats.raster.fillFallbacks=(stats.raster.fillFallbacks||0)+1;return invoke({method:'raster.writeRegion',args:[id,packImage(im),x,y]}).then(r=>{if(!r.ok)stats.errors.push('raster.writeRegion '+r.error)})});rasterNote(name,'mirrored');return}
  else if(name==='invertPixels'&&!a[1]&&!fresh.has(id)&&!reinit.has(id)){mirror({method:'raster.invert',args:[id]});rasterNote(name,'mirrored');return} // v284: replayed natively (with a selection the result is sent)
  else if(name==='clearRegion'){mirror({method:'raster.clearRegion',args:[id,r]});rasterNote(name,'mirrored');return}
  else if(name==='writeRegion'){const im=drawablePixels(a[1]);if(im){writeChunked(id,im,a[2]||0,a[3]||0);rasterNote(name,'mirrored');return}}
  // Not replayed natively: send the written area (or the whole surface when the area is unknown).
  const area=name==='putPixels'?(()=>{const d=a[4]||{x:0,y:0,w:a[1].width,h:a[1].height};return [(a[2]||0)+d.x,(a[3]||0)+d.y,d.w,d.h]})():name==='placeImage'?[a[2],a[3],a[4],a[5]]:name==='fillGeometry'&&a[2]?[a[2].x,a[2].y,a[2].w,a[2].h]:r?[r.x,r.y,r.w,r.h]:null;
  if(area)syncRect(id,...area);else syncSurface(id);rasterNote(name,'synced');
 }
 function onSnapshot(name,a,h){
  if(h instanceof RasterSnapshot)dirty.add(h.resource); // a snapshot means its surface is being edited: compare it at this step
  if(!(h instanceof RasterSnapshot)||knownSnaps.has(h.id)||!known.has(h.resource))return;
  if(name==='asSnapshot'&&!(a[1] instanceof Map))return;
  const P=RasterResources.payload(h.resource),tile=P?.sparse?.tileSize||256;
  if(name==='snapshotStore'){mirror({method:'raster.captureTiles',args:[h.resource,h.id,[...RasterResources.tiles(h).keys()],tile]});knownSnaps.add(h.id);rasterNote('captureTiles','mirrored');return}
  if(name==='adoptSurface'){const st=a[1]||{},im=st.sparse?storePixels(st.sparse):pixelsOf(st.cv);if(im){mirror({method:'raster.adoptSurface',args:[h.resource,h.id,im]});knownSnaps.add(h.id)}return}
  const map=RasterResources.tiles(h);if(!map)return;
  // v283: adopted tiles are usually the surface just before an edit, which the core already holds: send a content hash
  // ({live}) per tile and upload only the tiles the core reports missing, in the same queue step (before any undo).
  const tiles={},raw={};for(const [k,c] of map){if(!c){tiles[k]=null;continue}const im=drawablePixels(c);if(!im){tiles[k]=null;continue}raw[k]=im;tiles[k]={live:tileHash(im)}}
  sendStep({method:'raster.adoptTiles',args:[h.resource,h.id,tiles,tile]},resp=>{if(!resp.ok){stats.errors.push('raster.adoptTiles '+resp.error);return}const miss=resp.result?.missing||[];stats.raster.liveTiles=(stats.raster.liveTiles||0)+Object.keys(raw).length-miss.length;if(!miss.length)return;stats.raster.patchedTiles=(stats.raster.patchedTiles||0)+miss.length;
   const patch={};for(const k of miss)patch[k]=packImage(raw[k]);return invoke({method:'raster.patchSnapshot',args:[h.resource,h.id,patch]}).then(r=>{if(!r.ok)stats.errors.push('raster.patchSnapshot '+r.error)})});knownSnaps.add(h.id);
 }
 // Surfaces that are render caches of instance content (file, clone, text, vector layers) are derived from document
 // data, not edited pixels: they are resynced, never compared. Surfaces of nodes no longer in the document stay in the
 // registry until garbage collection; they are only compared while still being written.
 function ownership(){const derived=new Set(),reachable=new Set();try{const seen=new Set(),visit=L=>{if(!L||seen.has(L))return;seen.add(L);if(L.rasterId){reachable.add(L.rasterId);if(L.instance)derived.add(L.rasterId)}visit(L.mask);if(L.instance?.src)visit(L.instance.src)};(typeof residentArtboardLayers==='function'?residentArtboardLayers():layers).forEach(visit);const m=RasterResources.selectionMaskId();if(m)reachable.add(m)}catch(_){}return {derived,reachable}}
 // Compare surfaces (dirty only, or all) with native, then resync; drop native surfaces whose resource is gone.
 function checkRasters(label,all=false){
  const live=new Map(RasterResources.surfaces().map(s=>[s.id,s])),{derived,reachable}=ownership();
  for(const id of [...known])if(!live.has(id)){known.delete(id);send({method:'raster.release',args:[id]})}
  for(const id of live.keys()){
   if(!known.has(id)){syncSurface(id);continue}
   if(!dirty.has(id)&&(!all||!reachable.has(id)))continue;
   const im=RasterResources.readRegion(id);if(!im)continue;stats.raster.compared++;const ops=recent.get(id)||[];recent.delete(id);
   // A surface created in this step (only attach/storage set-up seen) is initialised here, not compared: new layers
   // are filled by their constructors (duplicate, paste, import) before any committed write.
   if(derived.has(id)||reinit.has(id)||ops.includes('attach')&&ops.every(o=>o==='attach'||o==='setPart')){stats.raster.compared--;stats.raster.created++;send({method:'raster.set',args:[id,packImage(im)]});continue}
   send({method:'raster.compare',args:[id,packImage(im),{tolerance:RASTER_TOLERANCE,resync:true}]},resp=>{const c=resp.result;if(!resp.ok||!c){note('raster-compare-failed',{label,id,error:resp.error});return}if(!c.sizeMatch){note('raster-size',{label,id,native:c.native,js:c.js});return}stats.raster.maxDiff=Math.max(stats.raster.maxDiff,c.maxDiff);if(c.over)note('raster',{label,id,maxDiff:c.maxDiff,over:c.over,first:c.first,ops})});
  }
  dirty.clear();reinit.clear();fresh.clear();
 }
 // ---- v270: composite shadow -------------------------------------------------------------------------
 // The native compositor builds the layer scene from its own document store and renders its surfaces; the app's
 // CPU compositor renders the same document (flat(true): stored sources, transparent background). Surfaces were
 // resynced just before, so this isolates compositor parity. Unsupported documents (mask/filter layers for now)
 // are counted as skipped with their reasons.
 // Tolerance: ±3 per premultiplied channel. Native surfaces arrive through getImageData (straight 8-bit), so a
 // pixel at very low alpha can be off by one premultiplied step before compositing; steep modes (vivid-light,
 // divide, colour-dodge/burn) amplify that. Up to 0.1% of channels within ±8 are therefore counted as near
 // misses, not divergences.
 const COMPOSITE_TOLERANCE=3,NEAR_SHARE=.001,NEAR_MAX=8,APPROX_SHARE=.02;
 function checkComposite(label){
  try{if(typeof isolation!=='undefined'&&isolation)return}catch(_){}
  let im;try{const c=flat(true);im=c.getContext('2d').getImageData(0,0,c.width,c.height);c.width=c.height=1}catch(e){stats.errors.push('composite '+(e?.message||e));return}
  send({method:'raster.composite',args:[{compare:packImage(im),tolerance:COMPOSITE_TOLERANCE}]},resp=>{const c=resp.result;if(!resp.ok||!c){note('composite-failed',{label,error:resp.error});return}
   if(!c.supported){stats.composite.skipped++;for(const r of c.reasons||[])if(stats.composite.reasons.length<10&&!stats.composite.reasons.includes(r))stats.composite.reasons.push(r);return}
   stats.composite.compared++;if(!c.sizeMatch){note('composite-size',{label,native:c.native,js:c.js});return}stats.composite.maxDiff=Math.max(stats.composite.maxDiff,c.maxDiff);if(c.approximate?.length)stats.composite.approximate=(stats.composite.approximate||0)+1;if(c.over){if(c.maxDiff<=NEAR_MAX&&c.over<=(c.approximate?.length?APPROX_SHARE:NEAR_SHARE)*im.data.length){stats.composite.nearMisses++;return}note('composite',{label,maxDiff:c.maxDiff,over:c.over,first:c.first})}});
 }
 // v280: raw-bytes transport for bulky results, ordered with everything else on the queue.
 const binTransport=()=>window.__TAURI__?.core?.invoke?req=>window.__TAURI__.core.invoke('bungalow_core_bin',{request:req}):window.__TAURI_INTERNALS__?.invoke?req=>window.__TAURI_INTERNALS__.invoke('bungalow_core_bin',{request:req}):null;
 let binOff=false;
 function binary(req){{const tr=rawTransport();if(tr&&!rawOff){const r=chain.then(()=>rawCall(tr,req,true));chain=r.then(()=>{},()=>{});return r}} // v291: raw transport
  const tb=binOff?null:binTransport();
  const json=()=>invoke({method:'binary',args:[req]}).then(r=>{if(!r||!r.ok)throw Error(r?.error||'no response');const bin=atob(r.result.data),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return u});
  const raw=()=>tb(req).then(b=>b instanceof ArrayBuffer?new Uint8Array(b):b instanceof Uint8Array?b:Array.isArray(b)?Uint8Array.from(b):(()=>{throw Error('unexpected binary response')})(),
   e=>{const m=String(e?.message||e);if(/not found|unknown command|not allowed|denied/i.test(m)){binOff=true;console.info('Native core: bungalow_core_bin unavailable, using the JSON transport');return json()}throw Error(m)}); // shells without the v280 command keep working
  const r=chain.then(tb?raw:json);chain=r.then(()=>{},()=>{});return r}
 function start(){
  if(stats.enabled||!flag())return false;{const j=transport();if(!j)return false;invoke=wrapTransport(j)}stats.enabled=true;core=coreFlag();lazy=core; // v299: core mode is always lazy
  send({method:'reset'});send({method:'restoreDocument',args:[documentStore.snapshotDocument()]},resp=>{if(!resp.ok)note('sync-failed',{error:resp.error})});
  documentStore.setTracer((method,args,ok,error)=>{stats.calls++;send({method,args:args.map(enc),expect:{ok,error}},resp=>{if(resp.matchesExpectation===false)note('outcome',{method,jsOk:ok,jsError:error,nativeOk:resp.ok,nativeError:resp.error})})});
  if(typeof RasterResources!=='undefined'){RasterResources.setObserver(onRaster);if(lazy)scheduleFlush(1000);else for(const s of RasterResources.surfaces())syncSurface(s.id) /* shadow mode */}
  checkpoint('start');return true;
 }
 // verifyRasters(): compare every live surface now (tests call it at the end of a scenario).
 // nativeComposite(): the document as rendered by the Rust compositor (ImageData), or null when unsupported. First
 // step towards a native display path; usable from the console to eyeball native output.
 async function nativeComposite(){if(!stats.enabled)return null;checkRasters('display',true);let out=null;await send({method:'raster.composite',args:[{}]},resp=>{const c=resp.result;if(!c?.supported)return;const bin=atob(c.image.data),u=new Uint8ClampedArray(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);out=new ImageData(u,c.image.width,c.image.height)});return out}
 return Object.freeze({start,checkpoint,coreMode:()=>stats.enabled&&core,binary,transport:()=>rawTransport()&&!rawOff?'raw':binOff||!binTransport()?'json':'binary',lazy:()=>stats.enabled&&lazy,
  // v278: send a request on the mirror's queue (one ordered channel for brushes and mirroring); resolves to the response
  // v287: core mode, opening a .bung: the core decodes the layers from the file bytes itself (project.loadData, PNG tiles
  // stay compressed in transit) instead of receiving every decoded pixel. entries: [[doc, layer index, rasterId]...].
  // v293: claims the layers at once and decodes in the background (opening no longer waits for the core); the request
  // is queued before any later edit. On failure the layers are synced the normal way.
  adoptProject:(file,entries)=>{if(!stats.enabled||!core||!entries.length)return Promise.resolve(false);
   for(const [,,id] of entries)adopting.add(id);
   for(const [,,id] of entries){known.add(id);fresh.delete(id);reinit.delete(id);dirty.delete(id);pendingFull.delete(id);pendingTiles.delete(id)}
   const fail=e=>{stats.errors.push('project.loadData '+e);for(const [,,id] of entries){known.delete(id);pendingFull.add(id)}scheduleFlush();return false};
   const bytesP=file.arrayBuffer().then(b=>new Uint8Array(b));
   const r=chain.then(()=>bytesP).then(bytes=>invoke({method:'project.loadData',args:[{__bytes:bytes},entries]})).then(r=>{if(!r?.ok)return fail(r?.error||'no response');stats.raster.projectLayers=(stats.raster.projectLayers||0)+entries.length;return true},e=>fail(e?.message||e));
   adoptDone=r.then(()=>{},()=>{}).finally(()=>{for(const [,,id] of entries)adopting.delete(id)});chain=r.then(()=>{},()=>{});return r},
  request:req=>{const r=chain.then(()=>invoke(req)).catch(e=>({ok:false,error:String(e?.message||e)}));chain=r.then(()=>{});return r},resync:()=>{if(stats.enabled)for(const s of RasterResources.surfaces())syncSurface(s.id);return chain},nativeComposite,verifyComposite:(label='composite')=>{if(stats.enabled&&typeof RasterResources!=='undefined'){checkRasters(label,true);checkComposite(label)}return chain},verifyRasters:(label='verify')=>{if(stats.enabled)checkRasters(label,true);return chain},stats:()=>({...stats,divergences:[...stats.divergences],errors:[...stats.errors],raster:{...stats.raster,ops:{...stats.raster.ops}},composite:{...stats.composite,reasons:[...stats.composite.reasons]}}),enabled:()=>stats.enabled,whenIdle:()=>lazy&&!holds?flush():chain,
  // v291 (C): saving. flushForSave() sends every pending tile; hold()/release() pause background flushing while a save
  // reads the core, so the saved layers match the document as captured.
  ensureLocal:entry=>lazy?ensureLocal(entry):undefined,offloadHistory,
  // v301: the core already holds these surfaces' current pixels (a transform committed in the core): drop their pending
  // tile writes. resend(): the opposite, the app's pixels go to the core again (a core commit that was not applied).
  pendingFor:id=>pendingTiles.has(id)||pendingFull.has(id)||pendingVerify.has(id)||!known.has(id)||adopting.has(id), // v301: parking needs the core to hold the layer
  // v302: reads of parked layers (previews, display tiles, bringing a layer back) skip the queue: those surfaces get no
  // further writes while parked, so they need not wait behind background flushes and history stashing.
  binaryNow:req=>adoptDone.then(()=>{const tr=rawTransport();return tr&&!rawOff?rawCall(tr,req,true):binary(req)}),
  coreHas:ids=>{for(const id of ids){pendingTiles.delete(id);pendingFull.delete(id);pendingVerify.delete(id)}},
  resend:ids=>{for(const id of ids)pendingFull.add(id);scheduleFlush()},
  flush,flushForSave:()=>lazy?flush(true):chain,hold:()=>{holds++},release:()=>{holds=Math.max(0,holds-1);if(!holds&&(pendingTiles.size||pendingFull.size||pendingVerify.size))scheduleFlush()},pending:()=>({tiles:[...pendingTiles.values()].reduce((n,s)=>n+s.size,0),full:pendingFull.size,verify:[...pendingVerify.values()].reduce((n,s)=>n+s.size,0)})});
})();
NativeShadow.start();
