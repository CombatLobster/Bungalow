/* v236: authoritative DOM-free history order and cursor. The browser registry
 * retains execution callbacks/resources; this module stores only plain IDs and
 * document scope. A replay ticket advances the cursor only after execution.
 */
const BungalowHistory=(()=>{
 'use strict';
 function create(){
  let entries=[],cursor=0,revision=0,serial=0;
  const meta=value=>{const workspace=!!value?.workspace,artboard=workspace?null:value?.artboard??null;if(artboard!==null&&(typeof artboard!=='string'||!artboard||artboard.length>160))throw new TypeError('Invalid history document scope');return {artboard,workspace}};
  const id=()=> 'history_'+(++serial).toString(36);
  const inspect=()=>({version:1,entries:entries.map(e=>({...e})),cursor,revision});
  function append(value){const scope=meta(value),removed=entries.slice(cursor).map(e=>e.id),entry={id:id(),...scope};entries=entries.slice(0,cursor);entries.push(entry);cursor=entries.length;revision++;return {id:entry.id,removed}}
  function next(redo=false){if(typeof redo!=='boolean')throw new TypeError('Invalid history direction');const at=redo?cursor:cursor-1,entry=entries[at];return entry?{...entry,redo,from:cursor,to:redo?cursor+1:cursor-1,revision}:null}
  function commit(ticket){const expected=next(ticket?.redo);if(!expected||!ticket||['id','from','to','revision'].some(k=>ticket[k]!==expected[k]))throw new Error('Stale history replay ticket');cursor=ticket.to;revision++;}
  function trim(metrics,{budget=256*1024*1024,maxEntries=200}={}){
   if(!Array.isArray(metrics)||metrics.length!==entries.length||metrics.some((m,i)=>m?.id!==entries[i].id||!Number.isFinite(m.bytes)||m.bytes<0)||!Number.isFinite(budget)||budget<0||!Number.isInteger(maxEntries)||maxEntries<1)throw new TypeError('Invalid history resource metrics');
   let bytes=metrics.reduce((sum,m)=>sum+m.bytes,0);const sizes=new Map(metrics.map(m=>[m.id,m.bytes])),removed=[];
   while(entries.length>1&&(entries.length>maxEntries||bytes>budget)){
    let entry;if(cursor>1){entry=entries.shift();cursor--}else if(entries.length>cursor)entry=entries.pop();else break;
    bytes-=sizes.get(entry.id);removed.push(entry.id);
   }
   if(removed.length)revision++;return removed;
  }
  function reset(){const removed=entries.map(e=>e.id);entries=[];cursor=0;revision++;return removed}
  function beginGroup(){return {at:cursor,prefix:entries.slice(0,cursor).map(e=>e.id)}}
  function groupEntries(token){
   if(!token||!Number.isInteger(token.at)||token.at<0||!Array.isArray(token.prefix)||token.prefix.length!==token.at||cursor<token.at||token.prefix.some((id,i)=>entries[i]?.id!==id))throw new Error('Stale history group');
   const ids=entries.slice(token.at,cursor).map(e=>e.id);if(ids.length&&cursor!==entries.length)throw new Error('Cannot group partially applied history');return ids;
  }
  function collapseGroup(token,value){
   const requestedScope=meta(value),children=groupEntries(token);if(children.length<2)return {id:children[0]??null,children,collapsed:false};
   const scoped=entries.slice(token.at,cursor),boards=new Set(scoped.map(e=>e.artboard).filter(Boolean)),scope=meta({workspace:requestedScope.workspace||scoped.some(e=>e.workspace)||boards.size>1,artboard:boards.size===1?[...boards][0]:requestedScope.artboard});
   const entry={id:id(),...scope};entries.splice(token.at,children.length,entry);cursor=token.at+1;revision++;return {id:entry.id,children,collapsed:true,scope};
  }
  return Object.freeze({inspect,append,next,commit,trim,reset,beginGroup,groupEntries,collapseGroup});
 }
 return Object.freeze({create});
})();
if(typeof module!=='undefined'&&module.exports)module.exports=BungalowHistory;
