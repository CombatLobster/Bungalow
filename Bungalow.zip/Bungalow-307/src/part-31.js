
/* ====== Build 175: protect layers when updating an embedded source · convert groups to file layers · batch rename ====== */
const safeFileBase=n=>String(n||'').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').replace(/\s+/g,' ').trim().slice(0,80)||'Untitled';
// ---------- 1. updating an embedded source that now has layers ----------
function sourceEditNeedsChoice(){return layers.length>1||layerGroups.length>0||layers.some(L=>L.instance||L.mask)}
function sourceEditChoice(info){
 return new Promise(resolve=>{
  const dlg=$('sourceFlattenDialog'),n=layers.length,g=layerGroups.length,deps=info.independent?1:(info.count||1);
  $('sourceFlattenText').textContent='This source now has '+n+' layer'+(n===1?'':'s')+(g?' in '+g+' group'+(g===1?'':'s'):'')+'. Updating stores a single flattened image, so layers'+(g?', groups':'')+' and masks are lost and only the picture is kept.';
  $('sourceFlattenSave').textContent='Save as file and relink '+deps+' layer'+(deps===1?'':'s')+'…';
  $('sourceFlattenHint').textContent='Saves this document as a Bungalow file (layers kept) and points '+(deps===1?'the layer':'all '+deps+' dependent layers')+' at it. You can still edit or unpack it later.';
  $('sourceFlattenSave').disabled=!window.showSaveFilePicker;$('sourceFlattenSave').title=window.showSaveFilePicker?'':'This browser cannot write files directly: use Save project as…, then Relink from the File tab';
  const done=v=>{dlg.close();resolve(v)};
  $('sourceFlattenSave').onclick=()=>done('save');$('sourceFlattenFlatten').onclick=()=>done('flatten');$('sourceFlattenCancel').onclick=()=>done('cancel');
  dlg.oncancel=e=>{e.preventDefault();done('cancel')};
  dlg.showModal();$(window.showSaveFilePicker?'sourceFlattenSave':'sourceFlattenCancel').focus();
 });
}
async function saveSourceAndRelink(info){
 if(!window.opener||window.opener.closed){toast('The parent window is closed. Save this document to keep your edits.');return}
 const previous=projectHandle;projectFilename=safeFileBase(info.name)+'.bung';
 info.busy=true;
 try{
  await saveProject(true);
  if(!projectHandle||projectHandle===previous||projectDirty){return}      // cancelled or failed: stay in the editor
  const file=await projectHandle.getFile(),token=crypto.randomUUID();
  await dropTransfer('put',token,{file,handle:projectHandle,created:Date.now()});
  window.opener.postMessage({type:'bung-source-relink',token:info.token,transfer:token},'*');
  info.relinking=true;
 }catch(error){toast('Could not relink: '+error.message)}
 finally{if(!info.relinking)info.busy=false}
}
async function relinkFromEditor(session,transferToken){
 if(session.epoch!==artboardWorkspaceEpoch||!residentArtboardLayers().includes(session.L))throw Error('The parent source changed or was removed.');
 if(canvasBusy())throw Error('Finish the parent document gesture, then try again.');
 const entry=await dropTransfer('get',transferToken);if(!entry?.file)throw Error('The saved file could not be read.');
 const {file,handle}=entry,img=await decodeFileLayerSource(file);if(!relinkSizeOk(img))throw Error('The saved file is too large for the memory budget.');
 const targets=session.independent?[session.L]:residentArtboardLayers().filter(C=>C.instance?.type==='file'&&C.instance.embedded&&C.instance.img===session.img);
 if(!targets.length)throw Error('No dependent layers remain.');
 if(!relinkSources(targets,{kind:'file',embed:false,file:{img,name:file.name,handle,mtime:file.lastModified,size:file.size}}))throw Error('The layers could not be relinked.');
 try{await dropTransfer('delete',transferToken)}catch(_){}
 return targets.length;
}
addEventListener('message',async e=>{
 const d=e.data;if(d?.type!=='bung-source-relink')return;
 const s=SourceLayerUI.session?.(d.token);if(!s||!TauriBridge.from(e,s.win)||s.busy)return;
 s.busy=true;
 try{const n=await relinkFromEditor(s,d.transfer);s.win.postMessage({type:'bung-source-result',token:s.token,ok:true},'*');toast('Relinked '+n+' layer'+(n===1?'':'s')+' to the saved file · layers are kept in it')}
 catch(error){s.win.postMessage({type:'bung-source-result',token:s.token,ok:false,error:error.message},'*')}
 finally{s.busy=false}
});
// ---------- 2. convert a group or layer to a file layer ----------
// The group's layers become their own Bungalow document (blend modes, opacity and nested groups kept); the group is replaced by a file layer.
function nodesAsDocumentState(roots,items,groups){
 const rootSet=new Set(roots),inner=groups.filter(G=>!rootSet.has(G)),gmap=new Map(),lmap=new Map(),own=(o,k,v)=>Object.defineProperty(o,k,{value:v,writable:true,configurable:true,enumerable:true});
 for(const G of inner)gmap.set(G,Object.create(G));
 for(const G of inner)own(gmap.get(G),'group',gmap.get(G.group)||null);
 for(const L of items)lmap.set(L,Object.create(L));
 for(const L of items){const P=lmap.get(L);own(P,'group',gmap.get(L.group)||null);own(P,'maskTarget',L.maskTarget?(lmap.get(L.maskTarget)||gmap.get(L.maskTarget)||null):null);if(L.instance?.type==='clone'){const src=lmap.get(L.instance.src);own(P,'instance',src?{...L.instance,src}:null)}}
 const stack=items.map(L=>lmap.get(L));
 return {width:DW,height:DH,dpi:documentDPI,layers:stack,groups:inner.map(G=>gmap.get(G)),active:stack.at(-1),selected:new Set(),coordinates:structuredClone(canvasCoordinates),selection:null,references:[],referenceShown:true,referenceLayersVisible:true};
}
async function encodeNodesAsBung(roots,items,groups,name){
 const state=nodesAsDocumentState(roots,items,groups);projectSaveSerial++;const sink=projectSink();
 const meta=await encodeDocumentState(state,name,null,sink);meta.meta={...newDocumentMeta(),title:name};
 Object.defineProperty(meta,'__tiles',{value:{dataLength:sink.offset},configurable:true});validateProject(meta);pruneProjectTileCache();SourceLayers.pack(meta);
 const json=new TextEncoder().encode(JSON.stringify(meta)),head=new Uint8Array(16);if(json.length>64*1024*1024)projectError('Source metadata exceeds the 64 MB limit');head.set(BUNG2_MAGIC);new DataView(head.buffer).setUint32(12,json.length,true);
 return new Blob([head,json,...sink.parts],{type:'application/octet-stream'});
}
const convertState={node:null};
function openConvertDialog(node=null){
 if(editBlocked())return;const nodes=node?[node]:selectedStackNodes();
 if(nodes.length!==1||!nodes[0]){toast('Select one group or layer to convert');return}
 const N=nodes[0],{groups,items}=stackOperationTargets([N]);
 if(groups.some(groupLocked)||items.some(layerLocked)){toast('Unlock “'+N.name+'” first');return}
 if(!items.length){toast('“'+N.name+'” has no layers to convert');return}
 convertState.node=N;const canWrite=!!window.showSaveFilePicker;
 $('convertTitle').textContent='Convert “'+N.name+'” to a file layer';$('convertName').value=N.name;
 $('convertInfo').textContent=items.length+' layer'+(items.length===1?'':'s')+(groups.length>1?' in '+(groups.length-1)+' group'+(groups.length===2?'':'s'):'')+' · the new layer takes its place in the stack, with the same opacity, blend mode and visibility.';
 $('convertBung').disabled=!canWrite;$('convertBungText').textContent=canWrite?'Linked Bungalow file (.bung): keeps every layer and group inside the file':'Linked Bungalow file (this browser cannot write files)';
 $('convertBung').checked=canWrite;$('convertEmbedded').checked=!canWrite;$('convertKeep').checked=!canWrite;
 $('convertKeepNote').textContent=canWrite?'The layers live on in the file: use “Unpack source into layers” to bring them back.':'An embedded image is flattened. Keeping the original group (hidden) preserves its layers.';
 $('convertApply').disabled=false;$('convertDialog').showModal();$('convertName').focus();$('convertName').select();
}
async function runConvert(){
 const N=convertState.node,store=$('convertBung').checked?'bung':'embedded',keep=$('convertKeep').checked,name=($('convertName').value.trim()||N.name).slice(0,80);
 if(!N||canvasBusy())return false;
 const {roots,groups,items:found}=stackOperationTargets([N]),items=[...new Set([...found,...layers.filter(M=>M.mask&&M.maskTarget&&found.includes(M.maskTarget))])];
 if(groups.some(groupLocked)||items.some(layerLocked)){toast('Unlock “'+N.name+'” first');return false}
 let instance;setProjectBusy(true,'Converting “'+name+'”…');
 try{
  const raster=OpenRaster.rasterNode(N,true),img=document.createElement('canvas');img.width=DW;img.height=DH;img.getContext('2d').drawImage(raster,0,0);
  if(store==='bung'){
   const blob=await encodeNodesAsBung(roots,items,groups,name),handle=await window.showSaveFilePicker({suggestedName:safeFileBase(name)+'.bung',types:[{description:'Bungalow project',accept:{'application/json':['.bung']}}]});
   const writer=await handle.createWritable();try{await writer.write(blob);await writer.close()}catch(error){try{await writer.abort()}catch(_){}throw error}
   const file=await handle.getFile();instance={type:'file',name:handle.name,id:crypto.randomUUID(),handle,mtime:file.lastModified,size:file.size,mode:'original',flipH:false,flipV:false,dx:0,dy:0,img:await decodeFileLayerSource(file)};
   instPutHandle(instance.id,handle);
  }else instance={type:'file',embedded:true,name:safeFileBase(name)+'.png',id:crypto.randomUUID(),handle:null,mtime:0,size:0,mode:'original',flipH:false,flipV:false,dx:0,dy:0,img,_embeddedImage:img,embeddedSource:SourceLayers.record(img)};
 }catch(error){if(error.name!=='AbortError')toast('Could not convert: '+(error.message||error));return false}
 finally{setProjectBusy(false)}
 const L=newLayer(name);L.instance=instance;L.group=commonStackParent(roots);L.op=N.op??1;L.blend=N.blend||'normal';L.vis=N.vis!==false;L.reference=!!N.reference;L.inheritAlpha=!!N.inheritAlpha;drawFileLayer(L);
 groupedHistory(()=>{
  const original=[...layers],removed=new Set(keep?[]:items),parent=L.group,boundary=Math.max(...items.map(item=>{let node=item;while(node.group&&node.group!==parent)node=node.group;return original.indexOf(nodeLayers(node).at(-1))+1})),index=original.slice(0,boundary).filter(item=>!removed.has(item)).length;
  insertEngineNodes([L],[],index,{remove:keep?[]:[...groups,...items],bytes:layerRasterBytes(L)+[...removed].reduce((n,L)=>n+layerRasterBytes(L),0)});
  // v230: keep-original visibility is a property command inside the conversion's grouped history.
  if(keep)editLayerProperties(roots,'vis',{type:'set',value:false},refreshLayerPropertyDisplay)
 });
 flashSelectedLayer?.(L);uiNotice('“'+N.name+'” converted to a file layer'+(store==='bung'?' · '+instance.name:' · embedded')+(keep?' · original kept hidden':''));return true;
}
$('convertForm').addEventListener('submit',async e=>{e.preventDefault();$('convertApply').disabled=true;const ok=await runConvert();$('convertApply').disabled=false;if(ok)$('convertDialog').close()});
$('convertCancel').onclick=()=>$('convertDialog').close();
for(const id of ['convertBung','convertEmbedded'])$(id).addEventListener('change',()=>{const b=$('convertBung').checked;$('convertKeep').checked=!b;$('convertKeepNote').textContent=b?'The layers live on in the file: use “Unpack source into layers” to bring them back.':'An embedded image is flattened. Keeping the original group (hidden) preserves its layers.'});
for(const [id,close,get] of [['groupConvertFile',()=>closeGroupMenu(),()=>groupMenuTarget],['layerConvertFile',()=>closeLayerMenu(),()=>layerMenuTarget]])$(id).onclick=()=>{const node=get();close();openConvertDialog(node&&selectedStackNodes().length<2?node:null)};
// ---------- 3. batch rename (Alt+F2) ----------
const renameEsc=s=>String(s).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
function renameCandidates(withContents){
 let set=new Set(selectedStackNodes());
 if(withContents)for(const n of [...set])if(!n._canvas){for(const L of nodeLayers(n))set.add(L);for(const G of layerGroups)if(groupContains(n,G))set.add(G)}
 return [...$('ll').children].map(r=>r._node).filter(n=>n&&set.has(n));
}
function renameOptions(){
 const num=el=>{const v=Math.round(+$(el).value);return Number.isFinite(v)?v:0};
 return {mode:$('renameReplace').checked?'replace':'keep',base:$('renameBase').value,find:$('renameFind').value,repl:$('renameRepl').value,caseSens:$('renameCase').checked,prefix:$('renamePrefix').value,suffix:$('renameSuffix').value,numbering:$('renameNumbering').value,start:num('renameStart'),step:num('renameStep')||1,digits:Math.max(1,Math.min(8,num('renameDigits')||1)),sep:$('renameSep').value,direction:$('renameOrder').value,contents:$('renameContents').checked};
}
function computeBatchNames(nodes,o){
 const order=o.direction==='bottom'?[...nodes].reverse():nodes,out=new Map();let n=o.start;
 const re=o.find?new RegExp(renameEsc(o.find),o.caseSens?'g':'gi'):null;
 for(const node of order){
  let name=o.mode==='replace'?(o.base||node.name):node.name;if(re)name=name.replace(re,()=>o.repl);
  name=o.prefix+name+o.suffix;const num=String(n).padStart(o.digits,'0');n+=o.step;
  if(o.numbering==='prefix')name=num+o.sep+name;else if(o.numbering==='suffix')name=name+o.sep+num;
  out.set(node,(name.trim().slice(0,120))||node.name);
 }
 return out;
}
function renamePreview(){
 const o=renameOptions(),nodes=renameCandidates(o.contents),names=computeBatchNames(nodes,o),box=$('renamePreview');box.replaceChildren();
 $('renameCount').textContent=nodes.length+' item'+(nodes.length===1?'':'s')+' selected';
 for(const node of nodes.slice(0,12)){const row=document.createElement('div'),a=document.createElement('span'),b=document.createElement('span');a.textContent=node.name;b.textContent=names.get(node);row.className=names.get(node)===node.name?'same':'';row.append(a,document.createTextNode(' → '),b);box.append(row)}
 if(nodes.length>12){const more=document.createElement('div');more.className='more';more.textContent='… and '+(nodes.length-12)+' more';box.append(more)}
 $('renameApply').disabled=!nodes.length||nodes.every(n=>names.get(n)===n.name);
}
function openBatchRename(){
 if(editBlocked())return;if(!selectedStackNodes().length){toast('Select the layers or groups to rename');return}
 $('renameContents').checked=false;renamePreview();$('renameDialog').showModal();$('renamePrefix').focus();
}
function applyBatchRename(){
 const o=renameOptions(),all=renameCandidates(o.contents),nodes=all.filter(n=>n._canvas?!layerLocked(n):!groupLocked(n)),skipped=all.length-nodes.length,names=computeBatchNames(nodes,o);
 // v230: one validated engine command holds each item's distinct new name.
 if(!editLayerPropertyValues(nodes,'name',n=>names.get(n),()=>{for(const n of nodes)if(n._canvas&&n.th)n.th.title='Thumbnail: '+n.name;renderLayers()}))return false;
 uiNotice('Renamed '+nodes.length+' item'+(nodes.length===1?'':'s')+(skipped?' · '+skipped+' locked skipped':''));return true;
}
$('renameForm').addEventListener('submit',e=>{e.preventDefault();if(applyBatchRename())$('renameDialog').close()});
$('renameCancel').onclick=()=>$('renameDialog').close();
for(const el of $('renameDialog').querySelectorAll('input,select'))el.addEventListener('input',renamePreview);
$('layerBatchRename').onclick=()=>{closeLayerMenu();openBatchRename()};

