/* v231: DOM-free node identity rules. Allocation is injected by the host.
 * IDs are unique across layers and groups within one artboard document.
 * Native open preserves IDs; legacy records allocate them; copy/import renews.
 */
const BungalowEngineNodes=(()=>{
 'use strict';
 const valid=id=>typeof id==='string'&&/^node_[0-9a-f]{32}$/.test(id);
 function validate(ids){
  const seen=new Set();
  for(const id of ids){if(id===undefined)continue;if(!valid(id))throw new TypeError('Invalid engine node ID');if(seen.has(id))throw new TypeError('Duplicate engine node ID');seen.add(id)}
 }
 function normalise(ids,allocate,{fresh=false}={}){
  validate(ids);const reserved=new Set(ids.filter(id=>id!==undefined));
  return ids.map(id=>{
   if(!fresh&&id!==undefined)return id;
   for(let tries=0;tries<64;tries++){const candidate=allocate();if(!valid(candidate))throw new TypeError('Invalid allocated engine node ID');if(!reserved.has(candidate)){reserved.add(candidate);return candidate}}
   throw new Error('Could not allocate a unique engine node ID');
  });
 }
 // Resolve the entire batch before the adapter writes any property.
 function resolve(ids,targets){
  validate(ids);if(ids.some(id=>id===undefined))throw new TypeError('Missing engine node ID');
  const index=new Map(ids.map((id,i)=>[id,i]));
  return targets.map(id=>{if(!index.has(id))throw new Error('Engine command refers to a missing node');return index.get(id)});
 }
 return Object.freeze({valid,validate,normalise,resolve});
})();
if(typeof module!=='undefined'&&module.exports)module.exports=BungalowEngineNodes;
