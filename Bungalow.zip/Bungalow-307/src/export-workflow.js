// Iterative exports reuse the current format, scope, location and encoding controls.
(function(global){
 let owner=documentMeta,counter=0,active=null;
 const clean=n=>Number.isInteger(n)&&n>=0&&n<999999?n:0;
 function restore(n){owner=documentMeta;counter=clean(n)}
 function decorateName(name){if(!active)return name;if(documentMeta!==active.meta)throw Error('Document changed during export');const dot=name.lastIndexOf('.');return dot>0?name.slice(0,dot)+active.suffix+name.slice(dot):name+active.suffix}
 async function run(){
  if(active||canvasBusy()||exportBoardsBusy){toast('Finish the current operation before exporting');return}
  if(owner!==documentMeta)restore(documentMeta.export?.iteration);
  if(counter>=999998){toast('Iterative export limit reached');return}
  const version=counter+1,job={meta:documentMeta,suffix:'_'+String(version).padStart(3,'0'),deliveries:0,expected:$('exportBoardScope').value==='active'||$('exportZip').checked?1:exportTargetBoards().length};active=job;
  try{const id={png:'sav',jpg:'exportJPEG',nodes:'exportSelectedNodes',kra:'exportKrita',ora:'exportORA',psd:'exportPSD'}[$('exportFormat').value];if(!id)throw Error('Choose an export format');await $(id).onclick();if(job.deliveries&&documentMeta===job.meta){counter=version;global.ExportMemory?.save();toast((job.deliveries===job.expected?'Exported iterative version ':'Partially exported iterative version ')+String(version).padStart(3,'0')+' · '+job.deliveries+' file'+(job.deliveries===1?'':'s'))}}
  catch(e){if(e.name!=='AbortError')toast('Iterative export failed: '+e.message)}finally{active=null}
 }
 global.ExportIterations={run,restore,decorateName,delivered:()=>{if(active)active.deliveries++},get counter(){return owner===documentMeta?counter:0}};
 const b=document.createElement('button');b.id='exportIterative';b.className='wide';b.textContent='Export iterative version';b.title='Export with the current settings and append _001, _002…';$('exportPage').append(b);
 b.onclick=run;
})(globalThis);
