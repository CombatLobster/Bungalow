/* Vector brush v175: bounded geometry fitting; brush dynamics use a separate profile. */
(function(G){
 const ATTR=['r','p','o','spaceF','flowF','scatF','varF','opacityFactor','tilt','inputAngle','followAngle','texIn','pressure','sizeFactor'];
 const mix=(a,b,t)=>{const q={x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t};for(const k of ATTR)if(Number.isFinite(a[k])||Number.isFinite(b[k])){const u=a[k]??b[k],v=b[k]??u;q[k]=u+(k.includes('Angle')?Math.atan2(Math.sin(v-u),Math.cos(v-u)):v-u)*t}return q};
 function fit(points,tolerance=1,limit=256,attributes=false){
  if(points.length<=1)return points.map(p=>({...p}));
  const split=(a,b)=>{let error=-1,index=-1;const A=points[a],B=points[b],dx=B.x-A.x,dy=B.y-A.y,den=dx*dx+dy*dy;
   for(let i=a+1;i<b;i++){const p=points[i],t=den?Math.max(0,Math.min(1,((p.x-A.x)*dx+(p.y-A.y)*dy)/den)):(i-a)/(b-a);let e=Math.hypot(p.x-A.x-dx*t,p.y-A.y-dy*t);
    if(attributes){const q=mix(A,B,t);for(const k of ATTR)if(Number.isFinite(p[k])&&Number.isFinite(q[k]))e=Math.max(e,Math.abs(p[k]-q[k])*(k==='r'?2:k.includes('Angle')?4:20))}
    if(e>error){error=e;index=i}}
   return {a,b,error,index};};
  const spans=[split(0,points.length-1)],keep=new Set([0,points.length-1]);
  while(keep.size<limit){let best=-1;for(let i=0;i<spans.length;i++)if(spans[i].index>=0&&spans[i].error>tolerance&&(best<0||spans[i].error>spans[best].error))best=i;if(best<0)break;
   const s=spans[best];keep.add(s.index);spans.splice(best,1,split(s.a,s.index),split(s.index,s.b));}
  return [...keep].sort((a,b)=>a-b).map(i=>({...points[i]}));
 }
 function nodes(points){return points.map((p,i)=>{const a=points[i-1]||p,b=points[i+1]||p;return {x:p.x,y:p.y,ix:p.x+(a.x-p.x)/3,iy:p.y+(a.y-p.y)/3,ox:p.x+(b.x-p.x)/3,oy:p.y+(b.y-p.y)/3}})}
 function cubic(a,b,t){const u=1-t;return {x:u*u*u*a.x+3*u*u*t*a.ox+3*u*t*t*b.ix+t*t*t*b.x,y:u*u*u*a.y+3*u*u*t*a.oy+3*u*t*t*b.iy+t*t*t*b.y}}
 // Adaptive flattening, with a hard global sample budget; endpoints are always retained.
 function flatten(ns,w,h,budget=8192){const out=[{x:ns[0].x*w,y:ns[0].y*h}],cap=Math.max(1,Math.floor((budget-1)/Math.max(1,ns.length-1)));
  for(let i=1;i<ns.length;i++){const a=ns[i-1],b=ns[i],length=Math.hypot((a.ox-a.x)*w,(a.oy-a.y)*h)+Math.hypot((b.ix-a.ox)*w,(b.iy-a.oy)*h)+Math.hypot((b.x-b.ix)*w,(b.y-b.iy)*h),n=Math.min(cap,Math.max(1,Math.ceil(length/2)));
   for(let j=1;j<=n;j++){const p=cubic(a,b,j/n);out.push({x:p.x*w,y:p.y*h})}}
  return out;}
 function profile(points){let length=0;const out=points.map((p,i)=>{if(i)length+=Math.hypot(p.x-points[i-1].x,p.y-points[i-1].y);return {...p,x:length,y:0}});for(const p of out)p.x=length?p.x/length:0;return fit(out,.15,2048,true)}
 function sample(path,profile){let length=0,i=0;const ds=path.map((p,j)=>length+=j?Math.hypot(p.x-path[j-1].x,p.y-path[j-1].y):0);return path.map((p,j)=>{const t=length?ds[j]/length:0;while(i<profile.length-2&&profile[i+1].x<t)i++;const a=profile[i],b=profile[Math.min(i+1,profile.length-1)],q=mix(a,b,b.x>a.x?Math.max(0,Math.min(1,(t-a.x)/(b.x-a.x))):0);return {...q,...p}})}
 // Optional curve smoothing uses neighbouring arc lengths, preserving endpoints and sharp turns.
 function smoothNodes(points,amount=1){const ns=nodes(points);for(let i=1;i<ns.length-1;i++){const a=points[i-1],n=ns[i],b=points[i+1],la=Math.hypot(n.x-a.x,n.y-a.y),lb=Math.hypot(b.x-n.x,b.y-n.y);if(la<1e-5||lb<1e-5)continue;const ux=(n.x-a.x)/la,uy=(n.y-a.y)/la,vx=(b.x-n.x)/lb,vy=(b.y-n.y)/lb;if(ux*vx+uy*vy<.25)continue;const tx=ux+vx,ty=uy+vy,len=Math.hypot(tx,ty)||1,ri=la/3*amount,ro=lb/3*amount;n.ix=n.x-tx/len*ri;n.iy=n.y-ty/len*ri;n.ox=n.x+tx/len*ro;n.oy=n.y+ty/len*ro}return ns}

 // Least-squares cubic fitting with chord-length parameters and bounded adaptive splits.
 // Brush attributes are deliberately excluded: their independent profile preserves pressure detail.
 function fitCurves(input,tolerance=4,limit=128,amount=.85){
  let points=[];for(const p of input)if(!points.length||Math.hypot(p.x-points.at(-1).x,p.y-points.at(-1).y)>.01)points.push({x:p.x,y:p.y});
  if(points.length<2)return nodes(points.length?points:[{x:0,y:0}]);
  const unit=(x,y)=>{const d=Math.hypot(x,y)||1;return {x:x/d,y:y/d}},dot=(a,b)=>a.x*b.x+a.y*b.y;
  // Distance-window filtering removes sampling wobble before fitting; exact endpoints stay fixed.
  if(amount>0&&points.length>3){const arc=[0];for(let i=1;i<points.length;i++)arc.push(arc[i-1]+Math.hypot(points[i].x-points[i-1].x,points[i].y-points[i-1].y));const radius=tolerance*(1+amount*2);
   points=points.map((p,i)=>{if(!i||i===points.length-1)return p;let x=p.x,y=p.y,sum=1;for(const dir of [-1,1])for(let j=i+dir;j>=0&&j<points.length&&Math.abs(arc[j]-arc[i])<radius;j+=dir){const w=1-Math.abs(arc[j]-arc[i])/radius;x+=points[j].x*w;y+=points[j].y*w;sum+=w}return {x:p.x+(x/sum-p.x)*amount,y:p.y+(y/sum-p.y)*amount}});
  }
  function segment(a,b,t0,t1){const A=points[a],D=points[b],span=Math.hypot(D.x-A.x,D.y-A.y);let total=0;const us=[0];for(let i=a+1;i<=b;i++){total+=Math.hypot(points[i].x-points[i-1].x,points[i].y-points[i-1].y);us.push(total)}for(let i=1;i<us.length;i++)us[i]=total?us[i]/total:i/(us.length-1);
   let c00=0,c01=0,c11=0,x0=0,x1=0;for(let i=a;i<=b;i++){const u=us[i-a],v=1-u,b0=v*v*v,b1=3*u*v*v,b2=3*u*u*v,b3=u*u*u,aa={x:t0.x*b1,y:t0.y*b1},bb={x:t1.x*b2,y:t1.y*b2},q={x:points[i].x-A.x*(b0+b1)-D.x*(b2+b3),y:points[i].y-A.y*(b0+b1)-D.y*(b2+b3)};c00+=dot(aa,aa);c01+=dot(aa,bb);c11+=dot(bb,bb);x0+=dot(aa,q);x1+=dot(bb,q)}
   const det=c00*c11-c01*c01;let h0=det>1e-10?(x0*c11-x1*c01)/det:span/3,h1=det>1e-10?(c00*x1-c01*x0)/det:span/3;if(h0<span*1e-4||h1<span*1e-4||h0>total*2||h1>total*2)h0=h1=span/3;
   const n0={x:A.x,y:A.y,ox:A.x+t0.x*h0,oy:A.y+t0.y*h0},n1={x:D.x,y:D.y,ix:D.x+t1.x*h1,iy:D.y+t1.y*h1};let error=0,index=Math.floor((a+b)/2);for(let i=a+1;i<b;i++){const q=cubic(n0,n1,us[i-a]),e=Math.hypot(q.x-points[i].x,q.y-points[i].y);if(e>error){error=e;index=i}}return {a,b,t0,t1,n0,n1,error,index};
  }
  const start=unit(points[1].x-points[0].x,points[1].y-points[0].y),end=unit(points.at(-2).x-points.at(-1).x,points.at(-2).y-points.at(-1).y),segments=[segment(0,points.length-1,start,end)];
  while(segments.length<limit-1){let best=-1;for(let i=0;i<segments.length;i++)if(segments[i].b-segments[i].a>1&&segments[i].error>tolerance&&(best<0||segments[i].error>segments[best].error))best=i;if(best<0)break;const s=segments[best],k=s.index,t=unit(points[k-1].x-points[k+1].x,points[k-1].y-points[k+1].y);segments.splice(best,1,segment(s.a,k,s.t0,t),segment(k,s.b,{x:-t.x,y:-t.y},s.t1));}
  const result=[];for(const s of segments){if(!result.length)result.push({x:s.n0.x,y:s.n0.y,ix:s.n0.x,iy:s.n0.y,ox:s.n0.ox,oy:s.n0.oy});else Object.assign(result.at(-1),{ox:s.n0.ox,oy:s.n0.oy});result.push({x:s.n1.x,y:s.n1.y,ix:s.n1.ix,iy:s.n1.iy,ox:s.n1.x,oy:s.n1.y})}return result;
 }


 // Remove an anchor by fitting its two adjacent arcs to one cubic. Endpoint positions
 // and tangent directions stay fixed; iterative closest-point fitting preserves the arc.
 function removeNodePreserve(input,index){const ns=input.map(n=>({...n}));if(index<0||index>=ns.length)return ns;if(!index||index===ns.length-1){ns.splice(index,1);return ns}
  const A=ns[index-1],N=ns[index],B=ns[index+1],samples=[];for(let k=0;k<=32;k++)samples.push(cubic(A,N,k/32));for(let k=1;k<=32;k++)samples.push(cubic(N,B,k/32));
  const unit=(x,y,f)=>{const d=Math.hypot(x,y);return d>1e-6?{x:x/d,y:y/d}:f},fallback={x:1,y:0},ta=unit(A.ox-A.x,A.oy-A.y,unit(samples[1].x-A.x,samples[1].y-A.y,fallback)),tb=unit(B.ix-B.x,B.iy-B.y,unit(samples.at(-2).x-B.x,samples.at(-2).y-B.y,{x:-1,y:0}));
  let length=0;const us=[0];for(let i=1;i<samples.length;i++){length+=Math.hypot(samples[i].x-samples[i-1].x,samples[i].y-samples[i-1].y);us.push(length)}for(let i=1;i<us.length;i++)us[i]=length?us[i]/length:i/(us.length-1);
  const dot=(a,b)=>a.x*b.x+a.y*b.y;
  function fit(){let c00=0,c01=0,c11=0,x0=0,x1=0;for(let i=0;i<samples.length;i++){const t=us[i],v=1-t,b0=v*v*v,b1=3*t*v*v,b2=3*t*t*v,b3=t*t*t,a={x:ta.x*b1,y:ta.y*b1},b={x:tb.x*b2,y:tb.y*b2},q={x:samples[i].x-A.x*(b0+b1)-B.x*(b2+b3),y:samples[i].y-A.y*(b0+b1)-B.y*(b2+b3)};c00+=dot(a,a);c01+=dot(a,b);c11+=dot(b,b);x0+=dot(a,q);x1+=dot(b,q)}const det=c00*c11-c01*c01;let ha=det>1e-10?(x0*c11-x1*c01)/det:length/3,hb=det>1e-10?(c00*x1-c01*x0)/det:length/3;ha=Math.max(.0001,Math.min(length*3,ha));hb=Math.max(.0001,Math.min(length*3,hb));A.ox=A.x+ta.x*ha;A.oy=A.y+ta.y*ha;B.ix=B.x+tb.x*hb;B.iy=B.y+tb.y*hb}
  fit();for(let pass=0;pass<8;pass++){const next=[0];for(let i=1;i<samples.length-1;i++){const t=us[i],v=1-t,p=cubic(A,B,t),d={x:3*((A.ox-A.x)*v*v+2*(B.ix-A.ox)*v*t+(B.x-B.ix)*t*t),y:3*((A.oy-A.y)*v*v+2*(B.iy-A.oy)*v*t+(B.y-B.iy)*t*t)},dd={x:6*((B.ix-2*A.ox+A.x)*v+(B.x-2*B.ix+A.ox)*t),y:6*((B.iy-2*A.oy+A.y)*v+(B.y-2*B.iy+A.oy)*t)},delta={x:p.x-samples[i].x,y:p.y-samples[i].y},den=dot(d,d)+dot(delta,dd),u=Math.abs(den)>1e-9?t-dot(delta,d)/den:t;next.push(Math.max(next.at(-1)+1e-6,Math.min(us[i+1]-1e-6,u)))}next.push(1);for(let i=0;i<us.length;i++)us[i]=next[i];fit()}
  ns.splice(index,1);return ns;
 }

 // Lightweight node modes: corners collapse tangents; smoothing aligns them to nearby anchors.
 function isSharp(n){if(typeof n.corner==='boolean')return n.corner;const ax=n.x-n.ix,ay=n.y-n.iy,bx=n.ox-n.x,by=n.oy-n.y,la=Math.hypot(ax,ay),lb=Math.hypot(bx,by);return la>1e-5&&lb>1e-5?(ax*bx+ay*by)/(la*lb)<.995:la<1e-5&&lb<1e-5}
 function toggleNode(input,index){const ns=input.map(n=>({...n})),n=ns[index];if(!n)return ns;if(!isSharp(n)){n.corner=true;n.ix=n.ox=n.x;n.iy=n.oy=n.y;return ns}
  n.corner=false;const a=ns[Math.max(0,index-1)],b=ns[Math.min(ns.length-1,index+1)],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,li=Math.hypot(n.x-a.x,n.y-a.y)/3,lo=Math.hypot(b.x-n.x,b.y-n.y)/3;n.ix=n.x-dx/d*li;n.iy=n.y-dy/d*li;n.ox=n.x+dx/d*lo;n.oy=n.y+dy/d*lo;return ns;
 }
 // Pick a bounded parameter on the nearest cubic, once per gesture (no added nodes).
 function nearestCurve(ns,p){let best=null,distance=Infinity;for(let i=0;i<ns.length-1;i++){for(let k=0;k<=24;k++){const q=cubic(ns[i],ns[i+1],k/24),d=(q.x-p.x)**2+(q.y-p.y)**2;if(d<distance){distance=d;best={index:i,t:k/24}}} }if(!best)return null;
  let lo=Math.max(0,best.t-1/24),hi=Math.min(1,best.t+1/24);const dist=t=>{const q=cubic(ns[best.index],ns[best.index+1],t);return(q.x-p.x)**2+(q.y-p.y)**2};for(let k=0;k<18;k++){const a=lo+(hi-lo)/3,b=hi-(hi-lo)/3;if(dist(a)<dist(b))hi=b;else lo=a}best.t=Math.max(.05,Math.min(.95,(lo+hi)/2));return best;
 }
 // Minimum-norm handle displacement puts the picked curve point under the drag.
 // Anchors stay fixed. Opposite handles at smooth joins rotate to retain their tangent.
 function reshapeCurve(input,pick,dx,dy){const ns=input.map(n=>({...n}));if(!pick)return ns;const a=ns[pick.index],b=ns[pick.index+1],t=pick.t,u=1-t,w0=3*u*u*t,w1=3*u*t*t,den=w0*w0+w1*w1;
  function move(n,key,other,w){const length=Math.hypot(n[other+'x']-n.x,n[other+'y']-n.y),smooth=!isSharp(n);n[key+'x']+=dx*w/den;n[key+'y']+=dy*w/den;if(smooth&&length>1e-5){const vx=n[key+'x']-n.x,vy=n[key+'y']-n.y,l=Math.hypot(vx,vy)||1;n[other+'x']=n.x-vx/l*length;n[other+'y']=n.y-vy/l*length}}
  move(a,'o','i',w0);move(b,'i','o',w1);return ns;
 }
 G.VectorBrushMath={isSharp,toggleNode,nearestCurve,reshapeCurve,removeNodePreserve,fitCurves,smoothNodes,ATTR,fit,nodes,cubic,flatten,profile,sample};
})(globalThis);
