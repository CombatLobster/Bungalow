
/* ====== Build 180: artboard tool modes (Manipulate / Draw), Tidy, Align and Lock ====== */
// ---------- Lock ----------
function activeBoardLocked(){return !!artboards.find(b=>b.id===activeArtboardId)?.locked}
function setBoardsLocked(boards,value){
 if(!artboardReady()||!boards.length)return;
 commitBoardProperty(boards,'locked',boards.map(()=>!!value),()=>{renderArtboards();syncArtboardUi();renderLayers()});
}
function toggleArtboardLock(id){const boards=id?artboards.filter(b=>b.id===id):selectedBoardList();if(!boards.length)return;setBoardsLocked(boards,!boards.every(b=>b.locked))}
{const base=layerLocked;layerLocked=function(L){return activeBoardLocked()||base.apply(this,arguments)}}
let lockBypass=0;
for(const name of ['undo','redoF']){const fn=window[name];if(typeof fn==='function')window[name]=function(){lockBypass++;try{return fn.apply(this,arguments)}finally{lockBypass--}}}   /* undo and redo always work, even on a locked board */
{const base=editBlocked;editBlocked=function(){if(base.apply(this,arguments))return true;if(!lockBypass&&activeBoardLocked()){const b=artboards.find(b=>b.id===activeArtboardId);toast('Artboard “'+b.name+'” is locked');return true}return false}}
{const del=deleteArtboard;deleteArtboard=function(){if(activeBoardLocked()){toast('Unlock the artboard first');return}return del.apply(this,arguments)}}
{const ren=renameArtboard;renameArtboard=function(value,id=activeArtboardId){if(artboards.find(b=>b.id===id)?.locked){toast('Unlock the artboard first');renderArtboards(true);return}return ren.call(this,value,id)}}
{const rs=resizeArtboardRecords;resizeArtboardRecords=function(records,scale,anchor){const free=records.filter(r=>!artboards.find(b=>b.id===r.id)?.locked);if(!free.length){toast('Unlock the artboard first');return false}return rs.call(this,free,scale,anchor)}}
// a padlock in every row of the board list
const padlock=locked=>{const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');svg.innerHTML=(locked?'<path d="M7.5 11V8a4.5 4.5 0 0 1 9 0v3"/>':'<path d="M7.5 11V8a4.5 4.5 0 0 1 8.6-1.8"/>')+'<rect x="5" y="11" width="14" height="9.5" rx="2"/>';return svg};
function decorateArtboardRows(){
 for(const row of $('artboardList').children){
  const board=artboards.find(b=>b.id===row.dataset.board);if(!board)continue;
  let b=row.querySelector('.artboard-lock');if(!b){b=document.createElement('button');b.type='button';b.className='artboard-lock';b.onclick=e=>{e.stopPropagation();toggleArtboardLock(board.id)};row.append(b)}   /* last child: the board list updates name and size by index */
  const on=!!board.locked;if(b.dataset.on!==String(on)){b.dataset.on=String(on);b.replaceChildren(padlock(on))}
  b.title=on?'Unlock artboard':'Lock artboard';b.setAttribute('aria-label',b.title);b.setAttribute('aria-pressed',String(on));row.classList.toggle('locked',on);row.classList.toggle('grouped',!!board.group);{const d=ArtboardWorkspace.dimensions(board);row.title=board.name+' · '+d.width+' × '+d.height+(on?' · locked':'')}
 }
}
// ---------- Align and Tidy ----------
function movableBoards(){return selectedBoardList().filter(b=>b.visible!==false&&!b.locked)}
function moveBoards(records,label){
 const before=records.map(r=>{const b=artboards.find(b=>b.id===r.id);return {id:b.id,x:b.x,y:b.y}});
 if(records.every((r,i)=>r.x===before[i].x&&r.y===before[i].y))return false;
 commitArtboardPositions(before,records);if(label)uiNotice(label);return true;
}
function alignArtboards(op){
 if(!artboardReady())return;const boards=movableBoards();if(boards.length<2){toast(selectedBoardList().some(b=>b.locked)?'Unlock the artboards first':'Select two or more artboards');return}
 const rects=boards.map(artboardRect),B=artboardSelectionBounds(rects),out=[];
 if(op==='distribute-x'||op==='distribute-y'){
  const ax=op==='distribute-x'?'x':'y',size=ax==='x'?'width':'height';if(rects.length<3){toast('Select three or more artboards to distribute');return}
  const sorted=[...rects].sort((a,b)=>a[ax]-b[ax]),gap=(B[size]-sorted.reduce((n,r)=>n+r[size],0))/(sorted.length-1);let pos=B[ax];
  for(const r of sorted){out.push({...r,[ax]:Math.round(pos)});pos+=r[size]+gap}
 }else for(const r of rects){
  let x=r.x,y=r.y;
  if(op==='left')x=B.x;else if(op==='centre-x')x=B.x+(B.width-r.width)/2;else if(op==='right')x=B.x+B.width-r.width;
  else if(op==='top')y=B.y;else if(op==='centre-y')y=B.y+(B.height-r.height)/2;else if(op==='bottom')y=B.y+B.height-r.height;
  out.push({...r,x:Math.round(x),y:Math.round(y)});
 }
 moveBoards(out,'Artboards aligned');
}
// Grid placement: reading order, near-square, one column width and row height each, spaced by the spacing increment.
function tidyArtboards(){
 if(!artboardReady())return;
 let boards=selectedBoardList().filter(b=>b.visible!==false);if(boards.length<2)boards=artboards.filter(b=>b.visible!==false);
 const free=boards.filter(b=>!b.locked);if(free.length<2){toast(boards.length-free.length?'Unlock the artboards first':'Add a second artboard to tidy');return}
 const rects=free.map(artboardRect),B=artboardSelectionBounds(rects),gap=Math.max(0,Math.min(10000,Math.round(+$('artboardSnapGap')?.value||0)));
 const byY=[...rects].sort((a,b)=>a.y-b.y||a.x-b.x),rows=[];
 for(const r of byY){const row=rows.at(-1);if(row&&Math.abs(r.y-row.y)<Math.min(r.height,row.h)/2)row.items.push(r);else rows.push({y:r.y,h:r.height,items:[r]})}
 const order=rows.flatMap(row=>row.items.sort((a,b)=>a.x-b.x)),cols=Math.ceil(Math.sqrt(order.length)),grid=[];
 for(let i=0;i<order.length;i+=cols)grid.push(order.slice(i,i+cols));
 const rowH=grid.map(r=>Math.max(...r.map(b=>b.height))),snapTo=v=>gap>0?Math.round(v/gap)*gap:Math.round(v);
 // every neighbour is exactly one spacing increment apart (even gaps); the grid itself sits on a multiple of the increment
 const place=(ox,oy)=>{const out=[];let y=oy;grid.forEach((row,ri)=>{let x=ox;for(const r of row){out.push({...r,x:Math.round(x),y:Math.round(y)});x+=r.width+gap}y+=rowH[ri]+gap});return out};
 // the grid starts where the selection started; if boards that stay put (locked or not selected) are in the way it moves clear of them
 const stay=otherBoardRects(rects.map(r=>r.id)),ox=snapTo(B.x),oy=snapTo(B.y);let out=place(ox,oy);
 if(overlapsOthers(out)&&stay.length){const right=snapTo(Math.max(...stay.map(r=>r.x+r.width))+gap),bottom=snapTo(Math.max(...stay.map(r=>r.y+r.height))+gap);out=[place(right,oy),place(ox,bottom),place(right,bottom)].find(c=>!overlapsOthers(c))||out}
 if(moveBoards(out,'Artboards tidied · '+grid.length+' × '+cols))fitArtboardWorkspace();
}
// ---------- tool modes ----------
let artboardMode='manipulate';try{if(localStorage.getItem('llArtboardMode')==='draw')artboardMode='draw'}catch(_){}
function setArtboardMode(mode){artboardMode=mode==='draw'?'draw':'manipulate';try{localStorage.setItem('llArtboardMode',artboardMode)}catch(_){}syncArtboardUi();drawArtboardHandles()}
const abOverlay=document.createElement('div');abOverlay.id='artboardRubber';abOverlay.hidden=true;abOverlay.setAttribute('aria-hidden','true');wrap.append(abOverlay);
function worldToScreen(p,m=artboardWorldMatrix()){return {x:m.a*p.x+m.c*p.y+m.e,y:m.b*p.x+m.d*p.y+m.f}}
function showRubber(r,text,draw){const m=artboardWorldMatrix(),a=worldToScreen({x:r.x,y:r.y},m),b=worldToScreen({x:r.x+r.width,y:r.y+r.height},m);abOverlay.hidden=false;abOverlay.className=draw?'draw':'select';Object.assign(abOverlay.style,{left:Math.min(a.x,b.x)+'px',top:Math.min(a.y,b.y)+'px',width:Math.abs(b.x-a.x)+'px',height:Math.abs(b.y-a.y)+'px'});abOverlay.dataset.label=text||''}
function hideRubber(){abOverlay.hidden=true}
function trackPointer(e,move,end){
 const id=e.pointerId,controller=new AbortController(),o={capture:true,signal:controller.signal};wrap.setPointerCapture(id);
 const finish=(ev,cancel)=>{controller.abort();try{if(wrap.hasPointerCapture(id))wrap.releasePointerCapture(id)}catch(_){}hideRubber();end(ev,cancel)};
 window.addEventListener('pointermove',ev=>{if(ev.pointerId!==id)return;ev.preventDefault();ev.stopImmediatePropagation();move(ev)},o);
 window.addEventListener('pointerup',ev=>{if(ev.pointerId!==id)return;ev.preventDefault();ev.stopImmediatePropagation();finish(ev,false)},o);
 for(const t of ['pointercancel','lostpointercapture'])window.addEventListener(t,ev=>{if(ev.pointerId===id)finish(ev,true)},o);
 window.addEventListener('blur',()=>finish(null,true),o);
 window.addEventListener('keydown',ev=>{if(ev.key==='Escape'){ev.preventDefault();ev.stopImmediatePropagation();finish(null,true)}},o);
}
// Manipulate: drag on empty space to select every artboard the box touches (Shift/Ctrl adds)
function startArtboardMarquee(e){
 e.preventDefault();e.stopImmediatePropagation();if(!artboardReady())return;
 const start=artboardWorldPoint(e),base=e.shiftKey||e.ctrlKey||e.metaKey?new Set(selectedArtboards):new Set();let moved=false,hit=new Set(base);
 trackPointer(e,ev=>{
  const p=artboardWorldPoint(ev);if(!moved&&Math.hypot(p.x-start.x,p.y-start.y)*z<3)return;moved=true;
  const r={x:Math.min(start.x,p.x),y:Math.min(start.y,p.y),width:Math.abs(p.x-start.x),height:Math.abs(p.y-start.y)};showRubber(r);
  hit=new Set(base);for(const b of artboards){if(b.visible===false)continue;const q=artboardRect(b);if(q.x<r.x+r.width&&q.x+q.width>r.x&&q.y<r.y+r.height&&q.y+q.height>r.y)hit.add(b.id)}
  commitBoards({selected:[...hit]});renderArtboards();drawArtboardHandles();
 },(ev,cancel)=>{
  if(cancel){commitBoards({selected:[...(base.size?base:[activeArtboardId])]});renderArtboards();drawArtboardHandles();return}
  if(!moved)return;if(!hit.size){commitBoards({selected:[...([activeArtboardId])]});renderArtboards();drawArtboardHandles();return}
  if(!hit.has(activeArtboardId))activateArtboard([...hit].at(-1),false,true);commitBoards({selected:[...hit]});renderArtboards();drawArtboardHandles();
 });
}
// Draw: drag out a new artboard; edges, centres and the spacing increment snap (Alt bypasses, Shift keeps it square)
function startArtboardDraw(e){
 e.preventDefault();e.stopImmediatePropagation();if(!artboardReady())return;
 if(artboards.length>=64){toast('A project supports up to 64 artboards');return}
 const sn=prepareArtboardSnap([]),tol=8/Math.max(z,.001),xs=[],ys=[];
 for(const r of sn.others){xs.push(r.x,r.x+r.width/2,r.x+r.width);ys.push(r.y,r.y+r.height/2,r.y+r.height)}
 const snap=(p,ev)=>{if(ev.altKey||!sn.enabled)return {x:Math.round(p.x),y:Math.round(p.y)};const near=(v,list)=>{let best=null,d=tol;for(const c of list){const k=Math.abs(c-v);if(k<d){d=k;best=c}}return best};
  let x=near(p.x,xs),y=near(p.y,ys);if(x==null&&sn.increment>0){const g=Math.round(p.x/sn.increment)*sn.increment;if(Math.abs(g-p.x)<tol)x=g}if(y==null&&sn.increment>0){const g=Math.round(p.y/sn.increment)*sn.increment;if(Math.abs(g-p.y)<tol)y=g}
  return {x:Math.round(x??p.x),y:Math.round(y??p.y)}};
 const a=snap(artboardWorldPoint(e),e);let rect=null,moved=false;
 const shape=(p,ev)=>{let w=p.x-a.x,h=p.y-a.y;if(ev.shiftKey){const k=Math.max(Math.abs(w),Math.abs(h));w=Math.sign(w||1)*k;h=Math.sign(h||1)*k}w=Math.max(-8192,Math.min(8192,w));h=Math.max(-8192,Math.min(8192,h));return {x:Math.min(a.x,a.x+w),y:Math.min(a.y,a.y+h),width:Math.abs(w),height:Math.abs(h)}};
 trackPointer(e,ev=>{const p=snap(artboardWorldPoint(ev),ev);if(!moved&&Math.hypot(p.x-a.x,p.y-a.y)*z<3)return;moved=true;rect=shape(p,ev);showRubber(rect,rect.width+' × '+rect.height,true)},(ev,cancel)=>{
  if(cancel||!rect)return;if(rect.width<16||rect.height<16){toast('Drag a larger area to draw an artboard');return}
  const m=artboardWorldMatrix();let board=null;
  groupedHistory(()=>{if(createArtboard({width:rect.width,height:rect.height,white:true})){board=artboards.find(b=>b.id===activeArtboardId)}});
  if(board){board.x=rect.x;board.y=rect.y;artboardRevision++;commitBoards({selected:[...([board.id])]});renderArtboards();drawArtboardHandles()}
 });
}
{const base=beginArtboardDrag;beginArtboardDrag=function(e){
  if(artboardMode==='draw'){startArtboardDraw(e);return}
  const bounds=artboardSelectionBounds(),point={x:e.clientX-wr.left,y:e.clientY-wr.top},onCorner=artboardScreenCorners(bounds).some(p=>Math.hypot(p.x-point.x,p.y-point.y)<=12),label=e.target.closest?.('.artboard-label');
  if(!onCorner&&!label&&!artboardAtPointer(e)){startArtboardMarquee(e);return}
  return base.apply(this,arguments);
 }}
{const draw=drawArtboardHandles;drawArtboardHandles=function(){const out=draw.apply(this,arguments);if(artboardMode==='draw'&&artboardHandleOverlay)artboardHandleOverlay.style.display='none';return out}}
// ---------- the controls: modes and align in the top bar strip, Tidy and Lock in the board panel ----------
function abButton(label,title,onclick,icon){const b=document.createElement('button');b.type='button';b.title=title||label;b.setAttribute('aria-label',title||label);if(icon)b.append(BungalowIcons.node(icon));else b.textContent=label;b.onclick=onclick;return b}
function artboardStripSetup(){
 const tc=$('toolContext');if(!tc||$('artboardStrip'))return;
 const g=document.createElement('div');g.id='artboardStrip';g.hidden=true;g.setAttribute('role','group');g.setAttribute('aria-label','Artboard tool');
 const seg=document.createElement('div');seg.className='ab-seg';seg.setAttribute('role','group');
 for(const [m,label,title] of [['manipulate','Manipulate','Select, move and scale artboards'],['draw','Draw','Drag to draw a new artboard']]){const b=abButton(label,title,()=>setArtboardMode(m));b.dataset.mode=m;seg.append(b)}
 const sep=document.createElement('span');sep.className='ab-sep';
 const align=document.createElement('div');align.className='ab-align';for(const [op,label,icon] of ALIGN_OPS){const b=abButton(label,label,()=>alignArtboards(op),icon);b.dataset.align=op;align.append(b)}
 g.append(seg,sep,align);tc.append(g);new MutationObserver(()=>{if(g.parentElement!==tc)tc.append(g)}).observe(tc,{childList:true});
}
function artboardPanelSetup(){
 const m=$('artboardManagement');if(!m||$('artboardTidy'))return;
 const row=document.createElement('div');row.className='layout-buttons';
 const tidy=abButton('Tidy','Place the selected artboards in a tidy grid (all artboards when fewer than two are selected)',tidyArtboards);tidy.id='artboardTidy';
 tidy.classList.add('wide');row.append(tidy);$('artboardFitAll').before(row);
}
function syncArtboardUi(){
 const active=artboardToolActive(),sel=selectedBoardList(),free=movableBoards();
 const strip=$('artboardStrip');if(strip){strip.hidden=!active;for(const b of strip.querySelectorAll('[data-mode]'))b.setAttribute('aria-pressed',String(b.dataset.mode===artboardMode));
  for(const b of strip.querySelectorAll('[data-align]'))b.disabled=b.dataset.align.startsWith('distribute')?free.length<3:free.length<2}
 
 const tidy=$('artboardTidy');if(tidy)tidy.disabled=artboards.filter(b=>b.visible!==false&&!b.locked).length<2;
 document.body.classList.toggle('artboard-draw',active&&artboardMode==='draw');
}
{const r=renderArtboards;renderArtboards=function(){const out=r.apply(this,arguments);try{decorateArtboardRows();syncArtboardUi()}catch(_){}return out}}
artboardStripSetup();artboardPanelSetup();decorateArtboardRows();syncArtboardUi();
$('transformmode')?.addEventListener('change',()=>setTimeout(()=>{syncArtboardUi();drawArtboardHandles()},0));
BackgroundTicker.add('artboard-ui',200,syncArtboardUi);

