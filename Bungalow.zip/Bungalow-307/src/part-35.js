
/* ====== Build 178: Ctrl+click a thumbnail to select its pixels ====== */
function selectNodePixels(node,e){
 if(canvasBusy()||editBlocked())return false;
 if(node.mask&&isModifierKind(node.maskKind)){toast('Modifiers have no pixels to select');return false}
 const raster=node._canvas?layerExportPixels(node):OpenRaster.rasterNode(node,true);
 if(!raster){toast('Nothing to select');return false}
 const mode=e.shiftKey&&e.altKey?'intersect':e.shiftKey?'add':e.altKey?'subtract':'replace';
 const incoming=AlphaMask.raster(raster,DW,DH,0,0,0);
 changeSelection(AlphaMask.combine(selectionMask,incoming,mode),mode==='add'?'Added “'+node.name+'”':mode==='subtract'?'Removed “'+node.name+'”':mode==='intersect'?'Intersected “'+node.name+'”':'Selected “'+node.name+'”');
 return true;
}
$('ll').addEventListener('click',e=>{
 if(!(e.ctrlKey||e.metaKey))return;
 const row=e.target.closest?.('.lr,.group-row'),node=row?._node,th=row?.querySelector('canvas');if(!node||!th)return;
 const r=th.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)return;   /* the row captures the pointer, so test the position */
 e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();selectNodePixels(node,e);
},true);

