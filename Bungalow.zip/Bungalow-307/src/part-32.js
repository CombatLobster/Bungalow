
/* ====== Build 176: modifiers share one set of compositing options · random colour is one modifier with a colour per layer · compact modifier panel ====== */
const OP_BLENDS=['multiply','screen','overlay','darken','lighten','color-dodge','color-burn','hard-light','soft-light','difference','exclusion','hue','saturation','color','luminosity'];
// ---------- Random colour: ONE modifier; each layer in its scope gets its own colour ----------
function randomColourModifier(){
 if(editBlocked())return;
 const nodes=selectedStackNodes();if(!nodes.length){toast('Select the layers or group to colour');return}
 const targets=[...new Set(nodes.flatMap(nodeLayers))].filter(L=>!L.mask);
 if(!targets.length){toast('Select paint, text or file layers to colour');return}
 if(layers.length+1>1024){toast('Too many layers to add a colour modifier');return}
 if(nodes.some(n=>n._canvas?layerLocked(n):groupLocked(n))){toast('Unlock the selected layers first');return}
 // A single selected group gets the modifier inside it (it affects only that group); otherwise it sits just above the
 // highest selected layer and, like every modifier, affects the entire stack below it.
 const single=nodes.length===1&&!nodes[0]._canvas?nodes[0]:null,parent=single||commonStackParent(nodes);
 const highest=Math.max(...nodes.map(n=>layers.indexOf(nodeLayers(n).at(-1))));
 const M=newLayer('Randomise colour'+(single?' · '+single.name:''),null,nativeSparseActive()?{w:DW,h:DH}:false);
 M.mask=true;M.maskKind='colour';M.maskTarget=null;M.maskDirect=false;M.group=parent;
 const seed=crypto.getRandomValues(new Uint32Array(1))[0];
 M.maskColour=ColourMod.normalise({amount:1,random:{base:hex(H,S,V),hue:true,saturation:true,lightness:true,strength:1,seed,index:0}});
 insertEngineNodes([M],[],highest+1,{bytes:layerRasterBytes(M),newLayerThumbs:true,inside:single});
 toggleModifierPanel(true);const reached=layers.filter(L=>!L.mask&&maskReaches(M,L,layers,()=>true)).length;uiNotice('Randomise colour · one colour for each of the '+reached+' layer'+(reached===1?'':'s')+(single?' in “'+single.name+'”':' below it'));
}
// ---------- the modifier panel ----------
const modPills=[];
function modPill(inputId,label,o){
 const input=$(inputId);if(!input||input.dataset.pilled)return null;input.dataset.pilled='1';
 const step=o.step||1,dec=o.decimals??0,unit=o.unit||'',lab=input.closest('label'),row=document.createElement('div');row.className='mod-row';
 const cap=document.createElement('span');cap.className='desktop-value-label';cap.textContent=label;
 const api=createCompactValueControl({id:'mod_'+inputId,label,get:()=>+input.value||0,
  set:v=>{const n=Math.min(o.max,Math.max(o.min,Math.round(v/step)*step));input.value=String(+n.toFixed(4));input.dispatchEvent(new Event('input',{bubbles:true}))},
  min:o.min,max:o.max,step,dragStep:step/2,reset:o.reset??o.min,digits:dec,format:v=>(+(+v).toFixed(dec))+unit,parse:t=>parseFloat(t)});
 api.root.classList.add('desktop-value');const commit=()=>input.dispatchEvent(new Event('change',{bubbles:true}));
 api.root.addEventListener('valuecommit',commit);api.input.addEventListener('change',commit);
 row.append(cap,api.root);if(lab){lab.after(row);lab.hidden=true}else input.after(row);
 modPills.push({api,row,input});return row;
}
function modifierPanelSetup(){
 const body=document.querySelector('#modifierPanel .panel-body');if(!body||body.dataset.ready)return;body.dataset.ready='1';
 // --- shared compositing options, the same for every kind of modifier ---
 const scope=$('modScope'),direct=$('modDirect'),detach=$('modDetach'),note=$('modScopeNote');   // existing controls keep their handlers
 const mkRow=(caption,control,id)=>{const r=document.createElement('div');r.className='mod-row';if(id)r.id=id;const c=document.createElement('span');c.className='desktop-value-label';c.textContent=caption;r.append(c);if(control)r.append(control);return r};
 const scopeSel=document.createElement('select');scopeSel.id='modScopeSelect';scopeSel.className='canvas-select';scopeSel.setAttribute('aria-label','Modifier scope');
 for(const [v,t] of [['stack','Entire stack below'],['direct','Layer directly below'],['attached','Attached layer']])scopeSel.add(new Option(t,v));scopeSel.querySelector('option[value=attached]').hidden=true;scopeSel.querySelector('option[value=attached]').disabled=true;
 const blendSel=document.createElement('select');blendSel.id='modBlend';blendSel.className='canvas-select';blendSel.setAttribute('aria-label','Modifier blend mode');blendSel.add(new Option('Normal','normal'));
 for(const b of OP_BLENDS)blendSel.add(new Option(b.replace(/(^|-)(\w)/g,(m,a,c)=>(a?' ':'')+c.toUpperCase()),b));
 const heading=document.createElement('h4');heading.textContent='Applies to';direct.hidden=true;direct.closest('label')?.remove();
 scope.replaceChildren(heading,mkRow('Scope',scopeSel),direct,mkRow('Opacity',null,'modOpacityRow'),mkRow('Blend',blendSel),note,detach);
 const opacity=createCompactValueControl({id:'mod_opacity',label:'Opacity',get:()=>Math.round((modifierSel()?.op??1)*100),set:v=>{const n=Math.min(100,Math.max(0,Math.round(v)));if(!changeLayerControl('op',n/100,false))syncMirrorPanel()},min:0,max:100,step:1,dragStep:.5,reset:100,digits:0,format:v=>Math.round(v)+' %',parse:t=>parseFloat(t)});
 opacity.root.classList.add('desktop-value');opacity.root.addEventListener('valuecommit',()=>commitLayerControlHistory());opacity.input.addEventListener('change',()=>commitLayerControlHistory());
 $('modOpacityRow').append(opacity.root);modPills.push({api:opacity});
 $('modScopeSelect').onchange=e=>{const c=$('modDirect');c.checked=e.target.value==='direct';c.dispatchEvent(new Event('change',{bubbles:true}))};
 $('modBlend').onchange=e=>{if(!changeLayerControl('blend',e.target.value,false))syncMirrorPanel();commitLayerControlHistory()};
 // --- colour modifiers, in reading order ---
 const colour=$('modSecColour'),rc=$('randomColourControls');
 modPill('randomColourStrength','Randomness',{min:0,max:100,unit:' %',reset:100});
 modPill('randomColourSeed','Seed',{min:0,max:4294967295,reset:1});
 const seedRow=modPills.find(p=>p.input?.id==='randomColourSeed')?.row;if(seedRow){for(const sel of ['.compact-value-drag','.compact-value-reset'])seedRow.querySelector(sel)?.setAttribute('hidden','');const re=$('randomColourReseed');re.classList.remove('wide');re.classList.add('mod-icon');re.title='Pick new random colours';re.replaceChildren(BungalowIcons.node('random'));seedRow.append(re);seedRow.classList.add('with-icon')}
 modPill('colAmount','Strength',{min:0,max:100,unit:' %',reset:100});
 {const all=$('randomColourAll')?.closest('label'),rc2=$('randomColourControls'),strengthRow=modPills.find(p=>p.input?.id==='colAmount')?.row;if(all&&strengthRow){all.classList.add('mod-all');strengthRow.after(all)}const note=colour.querySelector('.mirror-note');if(note)note.id='colourNote'}
 // --- stroke ---
 modPill('strWidth','Width',{min:1,max:40,unit:' px',reset:4});modPill('strOff','Offset',{min:-40,max:40,unit:' px',reset:0});
 modPill('strVar','Variation',{min:0,max:100,unit:' %',reset:0});modPill('strVarScale','Var. scale',{min:20,max:600,step:10,unit:' px',reset:160});modPill('strSmooth','Smoothing',{min:0,max:6,unit:' px',reset:0});
 modPill('strOpacity','Stroke opacity',{min:0,max:100,unit:' %',reset:100});
 // --- transform ---
 modPill('xfX','Move X',{min:-100000,max:100000,unit:' px',reset:0});modPill('xfY','Move Y',{min:-100000,max:100000,unit:' px',reset:0});
 modPill('xfRot','Rotate',{min:-360,max:360,step:.1,decimals:1,unit:'°',reset:0});modPill('xfSX','Scale X',{min:1,max:10000,unit:' %',reset:100});modPill('xfSY','Scale Y',{min:1,max:10000,unit:' %',reset:100});
 {const sec=$('modSecXform'),pre=sec.querySelector('.pre');for(const id of ['xfX','xfY','xfRot','xfSX','xfSY']){const row=modPills.find(p=>p.input?.id===id)?.row;if(row&&pre)pre.before(row)}for(const p of sec.querySelectorAll('.canvas-dims'))p.hidden=true;const n=sec.querySelector('.mirror-note');if(n)n.textContent='Drag the box on the canvas to move, a corner to scale, the knob to rotate (Shift: 15° steps).'}
 {const sn=[...$('modSecStroke').querySelectorAll('.mirror-note')];if(sn[0]){sn[0].hidden=true;modPills.find(p=>p.input?.id==='strOff').row.title='Positive moves the stroke away from the source (a gap); negative moves it into the source.'}if(sn[1])sn[1].textContent='Outlines the visible shape of every layer in its scope.'}
 // --- gizmo opacity ---
 modPill('gizmoOpacity','Gizmo opacity',{min:20,max:100,step:5,unit:' %',reset:100});
 // --- order: shared options first, then the modifier's own settings, then actions, then gizmos ---
 const actions=document.createElement('div');actions.className='mod-actions';actions.append($('mirrorApplyMod'),$('modDelete'));
 const adv=document.createElement('details');adv.className='mod-adv';adv.id='modStrokeAdvanced';adv.innerHTML='<summary>More stroke options</summary>';
 const stroke=$('modSecStroke');for(const id of ['strVar','strVarScale','strJoin','strSmooth','strAA']){const el=$(id);const holder=el.closest('label')||el;const row=modPills.find(p=>p.input===el)?.row;adv.append(row||holder)}
 stroke.append(adv);
 const gizmoHead=[...body.children].find(e=>e.tagName==='H4'&&/Gizmo/i.test(e.textContent)),gizmoRow=modPills.find(p=>p.input?.id==='gizmoOpacity')?.row;
 const gizmo=document.createElement('details');gizmo.className='mod-gizmo';gizmo.innerHTML='<summary>Gizmo</summary>';if(gizmoRow)gizmo.append(gizmoRow);gizmoHead?.remove();
 body.append(actions,gizmo);
 colour.querySelector('#colourModifierHeading')?.classList.add('mod-h');
}
function modifierPanelSync(){
 const sc=modifierSel();for(const p of modPills)try{p.api.sync()}catch(_){}
 if(!sc)return;
 const sel=$('modScopeSelect'),att=sel.querySelector('option[value=attached]');
 if(sc.maskTarget){att.hidden=false;att.textContent='Attached: '+sc.maskTarget.name;sel.value='attached';sel.disabled=true}else{att.hidden=true;sel.value=sc.maskDirect?'direct':'stack';sel.disabled=false}
 if(document.activeElement!==$('modBlend'))$('modBlend').value=sc.blend&&sc.blend!=='normal'?sc.blend:'normal';
 // the stroke's own opacity only shows when it was changed; the shared Opacity is the main control
 const so=modPills.find(p=>p.input?.id==='strOpacity');if(so)so.row.hidden=(+so.input.value||100)>=100;
 {const n=$('modScopeNote');if(n&&!sc.maskTarget){n.textContent=sc.maskDirect?'Only the nearest layer below it.':sc.maskKind==='filter'?'Adjusts the combined stack below it.':'Every layer below it.';n.title='Layers inside an isolated group are skipped unless the modifier sits inside that group.'}}
 const rnd=!$('randomColourControls').hidden;$('modSecColour').dataset.random=rnd?'1':'0';$('colourNote')&&($('colourNote').textContent=rnd?'Each layer in the scope gets its own colour from the base, varied by the options above. Use the shuffle button for new colours.':'Fills the target\'s visible pixels with this colour. Transparency is kept.');const allBox=$('randomColourAll')?.closest('label');if(allBox)allBox.hidden=!rnd;
}
modifierPanelSetup();
{const base=syncMirrorPanel;syncMirrorPanel=function(){const r=base.apply(this,arguments);try{modifierPanelSync()}catch(_){}return r}}

