
/* ====== Build 198: Layer panel (F3) and granular instance sources ====== */
// A source can be picked down to one layer: "L<index>:<name>" for a layer or "G<index>:<name>" for a group, inside an artboard.
function resolveSourcePick(layerList,groupList,key){
 const m=/^([LG])(\d+):(.*)$/s.exec(key||'');if(!m)return null;const list=m[1]==='L'?layerList:groupList,at=list?.[+m[2]];
 return at&&at.name===m[3]?at:list?.find(n=>n.name===m[3])||null;
}
function pickInside(L,target){if(L===target||L.maskTarget===target)return true;if(!target._canvas)for(let G=L.group;G;G=G.group)if(G===target)return true;return false}
// the layers and groups of one artboard as an indented list, top of the stack first
function sourcePickItems(layerList,groupList){
 const kids=new Map(),top=[],minIndex=new Map();
 const index=n=>{if(minIndex.has(n))return minIndex.get(n);let v=n._canvas?layerList.indexOf(n):Infinity;if(!n._canvas)for(const c of kids.get(n)||[])v=Math.min(v,index(c));minIndex.set(n,v);return v};
 for(const G of groupList)kids.set(G,[]);
 for(const G of groupList)(G.group?kids.get(G.group)||top:top).push(G);
 for(const L of layerList){if(L.mask)continue;(L.group?kids.get(L.group)||top:top).push(L)}
 const out=[],walk=(nodes,depth)=>{for(const n of [...nodes].sort((a,b)=>index(b)-index(a))){const group=!n._canvas;out.push({key:(group?'G'+groupList.indexOf(n):'L'+layerList.indexOf(n))+':'+n.name,name:n.name,depth,group});if(group)walk(kids.get(n)||[],depth+1)}};
 walk(top,0);return out;
}
// the same list straight from a saved document record, without decoding any pixels
function sourcePickItemsFromRecord(doc){
 const groups=(doc?.groups||[]).map(g=>({name:String(g.name||'Group'),group:null})),layers=(doc?.layers||[]).map(l=>({name:String(l.name||'Layer'),mask:!!l.mask,group:null,_canvas:true}));
 (doc?.groups||[]).forEach((g,i)=>{groups[i].group=Number.isInteger(g.parent)?groups[g.parent]||null:null});(doc?.layers||[]).forEach((l,i)=>{layers[i].group=Number.isInteger(l.group)?groups[l.group]||null:null});
 return sourcePickItems(layers,groups);
}
async function fileSourceStructure(file){
 const head=new Uint8Array(await file.slice(0,16).arrayBuffer());let meta;
 if(isBung2Header(head)){const length=new DataView(head.buffer).getUint32(12,true);if(length<2||length>64*1024*1024)throw Error('Damaged project header');meta=JSON.parse(await file.slice(16,16+length).text())}else meta=JSON.parse(await file.text());
 const boards=meta?.format==='BungalowWorkspace'&&Array.isArray(meta.boards)?meta.boards.map(b=>({id:b.id,name:b.name,active:b.id===meta.active,doc:b.document})):[{id:null,name:'Document',active:true,doc:meta}];
 return boards.map(b=>({id:b.id,name:b.name,active:b.active,items:sourcePickItemsFromRecord(b.doc)}));
}
// ---------- the Layer panel ----------
const LayerPanel=(()=>{
 const panel=$('layerPropsPanel');if(!panel)return {};
 const body=panel.querySelector('.panel-body');let built=false,syncing=false,pending=0,fileInfo=null,fileInfoFor=null;
 const node=()=>activeStackNode?.()||AL;
 const el=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e};
 const row=(label,control)=>{const r=el('label','lp-row');r.append(el('span','',label),control);return r};
 const check=(label,on)=>{const l=el('label','t lp-check'),i=document.createElement('input');i.type='checkbox';i.onchange=()=>on(i.checked);l.append(i,label);l.input=i;return l};
 const kindOf=L=>L.instance?.type==='clone'?'layer':L.instance?.type==='file'?(L.instance.frame?.artboard?'artboard':'file'):null;
 const opt=(sel,items,value)=>{sel.replaceChildren(...items.map(([v,t])=>new Option(t,v)));if(value!==undefined)sel.value=value};
 function setName(n,value){
  value=value.trim().slice(0,80);if(!value||value===n.name)return;if(editBlocked())return;
  // v230: the F3 editor uses the same command/history boundary as rename.
  editLayerProperties([n],'name',{type:'set',value},()=>{if(n.th)n.th.title='Thumbnail: '+n.name;renderLayers()});
 }
 function build(){
  if(built)return;built=true;body.replaceChildren();
  const f={};
  f.kind=el('div','lp-kind');
  f.name=document.createElement('input');f.name.type='text';f.name.maxLength=80;f.name.onchange=()=>{const n=node();if(n)setName(n,f.name.value);sync(true)};f.name.onkeydown=e=>{e.stopPropagation();if(e.key==='Enter')f.name.blur();if(e.key==='Escape'){sync(true);f.name.blur()}};
  f.opacity=document.createElement('input');f.opacity.type='range';f.opacity.min=0;f.opacity.max=100;f.opacity.oninput=()=>{$('lop').value=f.opacity.value;$('lop').dispatchEvent(new Event('input',{bubbles:true}));f.opacityOut.textContent=f.opacity.value+'%'};f.opacity.onchange=()=>$('lop').dispatchEvent(new Event('change',{bubbles:true}));
  f.opacityOut=el('output','lp-out');const opacityBox=el('div','lp-opacity');opacityBox.append(f.opacity,f.opacityOut);
  f.blend=document.createElement('select');f.blend.append(...[...$('lbl').options].map(o=>new Option(o.text,o.value)));f.blend.onchange=()=>{$('lbl').value=f.blend.value;$('lbl').dispatchEvent(new Event('change',{bubbles:true}))};
  f.vis=check('Visible',()=>{const n=node();if(n._canvas)toggleLayerVisibility(n);else toggleStackFlag(n,'vis')});
  f.locked=check('Locked',()=>toggleStackFlag(node(),'locked'));
  f.alpha=check('Alpha lock',()=>toggleAlphaLock(node()));
  f.inherit=check('Inherit alpha',()=>toggleStackFlag(node(),'inheritAlpha'));
  const flags=el('div','lp-flags');flags.append(f.vis,f.locked,f.alpha,f.inherit);
  f.modifier=el('button','wide','Open modifier panel');f.modifier.onclick=()=>openModifierPanel(AL);
  const props=el('div','lp-section');props.append(el('h4','','Properties'),row('Name',f.name),row('Opacity',opacityBox),row('Blend',f.blend),flags,f.modifier);
  // ----- source -----
  f.srcKind=document.createElement('select');opt(f.srcKind,[['file','File'],['artboard','Artboard'],['layer','Layer in this artboard']]);
  f.fileName=el('span','lp-file');f.fileChoose=el('button','','Choose file…');
  f.fileBoard=document.createElement('select');f.fileLayer=document.createElement('select');
  f.board=document.createElement('select');f.boardLayer=document.createElement('select');f.layerSrc=document.createElement('select');
  f.fileRows=[row('File',(()=>{const b=el('div','lp-file-box');b.append(f.fileName,f.fileChoose);return b})()),row('Artboard in file',f.fileBoard),row('Layer in artboard',f.fileLayer)];
  f.boardRows=[row('Artboard',f.board),row('Layer in artboard',f.boardLayer)];f.layerRows=[row('Source layer',f.layerSrc)];
  f.srcNote=el('p','lp-note');
  const src=el('div','lp-section');f.src=src;src.append(el('h4','','Source'),row('Source',f.srcKind),...f.fileRows,...f.boardRows,...f.layerRows,f.srcNote);
  body.append(f.kind,props,src);panel.f=f;
  f.srcKind.onchange=()=>{panel.kind=f.srcKind.value;showKind()};
  f.fileChoose.onclick=chooseFile;f.fileBoard.onchange=()=>applyFilePick();f.fileLayer.onchange=()=>applyFilePick();
  f.board.onchange=()=>{fillBoardLayers();applyBoard()};f.boardLayer.onchange=applyBoard;f.layerSrc.onchange=applyClone;
 }
 const target=()=>{const L=AL;return L&&L.instance&&['file','clone'].includes(L.instance.type)?L:null};
 function showKind(){const f=panel.f,k=panel.kind||'file';for(const r of f.fileRows)r.hidden=k!=='file';for(const r of f.boardRows)r.hidden=k!=='artboard';for(const r of f.layerRows)r.hidden=k!=='layer'}
 function boardChoices(){return typeof relinkBoardChoices==='function'?relinkBoardChoices():[]}
 function fillBoardLayers(select=null){
  const f=panel.f,b=artboards.find(x=>x.id===f.board.value);if(!b){opt(f.boardLayer,[['','Whole artboard']]);return}
  const S=ArtboardWorkspace.state(b);opt(f.boardLayer,[['','Whole artboard'],...sourcePickItems(S.layers,S.groups).map(i=>[i.key,'\u00a0\u00a0'.repeat(i.depth)+(i.group?'▸ ':'')+i.name])],select??'');
 }
 async function chooseFile(){
  const L=target();if(!L||editBlocked())return;
  try{const picked=await pickFileLayerSource();if(!picked.file)return;const img=await decodeFileLayerSource(picked.file);if(!relinkSizeOk(img))throw Error('That image is too large for the memory budget');
   relinkSources([L],{kind:'file',file:{img,name:picked.file.name,handle:picked.handle,mtime:picked.file.lastModified,size:picked.file.size},embed:false})}
  catch(e){if(e.name!=='AbortError')toast('Could not open file: '+e.message)}
  sync(true);
 }
 async function readyFile(L){
  const h=L.instance.handle;if(!h)return null;
  if(await h.queryPermission({mode:'read'})!=='granted'&&await h.requestPermission({mode:'read'})!=='granted'){toast('Permission to read the file was declined');return null}
  return h.getFile();
 }
 async function loadFileInfo(L){
  const I=L.instance;if(fileInfoFor===I&&fileInfo)return fileInfo;fileInfo=null;fileInfoFor=I;
  if(!/\.(bung|llpaint)$/i.test(I.name||'')||!I.handle)return null;
  try{if(await I.handle.queryPermission({mode:'read'})!=='granted')return null;fileInfo=await fileSourceStructure(await I.handle.getFile())}catch(_){fileInfo=null}
  return fileInfo;
 }
 function fillFile(L,info){
  const f=panel.f,I=L.instance,pick=I.sourcePick&&I.sourcePick.file===I.name?I.sourcePick:null;
  f.fileName.textContent=I.embedded?'Embedded · '+(I.name||'image'):(I.name||'No file')+(I.handle?'':' · not linked');
  const granular=!!info&&info.length>0;f.fileRows[1].hidden=f.fileRows[2].hidden=!granular||panel.kind!=='file';
  if(!granular)return;
  opt(f.fileBoard,[['','Active artboard'],...(info.length>1?info.map(b=>[b.id,b.name]):[])],pick?.board||'');if(info.length<2)f.fileRows[1].hidden=true;
  const b=info.find(x=>x.id===(pick?.board||f.fileBoard.value))||info.find(x=>x.active)||info[0];
  opt(f.fileLayer,[['','Whole artboard'],...b.items.map(i=>[i.key,'\u00a0\u00a0'.repeat(i.depth)+(i.group?'▸ ':'')+i.name])],pick?.layer||'');
 }
 let applying=false;
 async function applyFilePick(){
  const L=target();if(!L||applying||editBlocked())return;applying=true;
  try{
   const f=panel.f,file=await readyFile(L);if(!file)return;
   const info=fileInfo||await fileSourceStructure(file),board=f.fileBoard.value||null,boardRec=info.find(x=>x.id===board)||info.find(x=>x.active)||info[0];
   if(f.fileBoard.value!==(board||'')||true){/* refill layers when the artboard changed */}
   const changedBoard=document.activeElement===f.fileBoard;if(changedBoard)opt(f.fileLayer,[['','Whole artboard'],...boardRec.items.map(i=>[i.key,'\u00a0\u00a0'.repeat(i.depth)+(i.group?'▸ ':'')+i.name])],'');
   const layer=f.fileLayer.value||null,pick={board:board,layer};
   const img=await compositeBungalowFile(file,board||layer?pick:null);if(!relinkSizeOk(img))throw Error('That selection is too large for the memory budget');
   relinkSources([L],{kind:'file',file:{img,name:file.name,handle:L.instance.handle,mtime:file.lastModified,size:file.size},embed:false,pick:board||layer?pick:null});
  }catch(e){toast('Could not use that selection: '+e.message)}
  finally{applying=false;sync(true)}
 }
 function applyBoard(){
  const L=target(),f=panel.f;if(!L||editBlocked())return;const b=artboards.find(x=>x.id===f.board.value);if(!b)return;
  try{
   const layer=f.boardLayer.value||null,image=Frame3D.boardImage(b,ArtboardLinks.exclusions(b),layer);if(!relinkSizeOk(image))throw Error('That artboard is too large for the memory budget');
   if(!ArtboardLinks.canLink(activeArtboardId,b.id))throw Error('This would create a circular artboard link');
   relinkSources([L],{kind:'artboard',board:b,image,layer});
  }catch(e){toast(e.message)}
  sync(true);
 }
 function applyClone(){
  const L=target(),f=panel.f;if(!L||editBlocked())return;const src=layers[+f.layerSrc.value];if(!src)return;
  if(L.instance.type==='clone'&&L.instance.src===src)return;relinkSources([L],{kind:'layer',src});sync(true);
 }
 async function syncSource(){
  const f=panel.f,L=target();f.src.hidden=!L;if(!L)return;
  const k=kindOf(L);if(!panel.kind||panel.lastLayer!==L){panel.kind=k;panel.lastLayer=L}f.srcKind.value=panel.kind;showKind();
  const I=L.instance;
  if(I.type==='file'&&k==='file'){fillFile(L,null);const info=await loadFileInfo(L);if(target()===L&&panel.kind==='file'&&info)fillFile(L,info)}
  const boards=boardChoices();opt(f.board,boards.map(b=>[b.id,b.name]));
  if(k==='artboard'&&I.frame?.artboard)f.board.value=I.frame.artboard;
  fillBoardLayers(k==='artboard'?I.frame?.layer:'');
  f.board.disabled=!boards.length;f.boardLayer.disabled=!boards.length;
  const group=typeof sharedSourceLayers==='function'?sharedSourceLayers(L):[L],choices=typeof relinkLayerChoices==='function'?relinkLayerChoices(group):[];
  opt(f.layerSrc,choices.map(c=>[String(layers.indexOf(c)),(c.group?'· ':'')+c.name]),I.type==='clone'&&layers.includes(I.src)?String(layers.indexOf(I.src)):undefined);
  if(I.type==='clone'&&!layers.includes(I.src))f.layerSrc.selectedIndex=-1;
  f.srcKind.querySelector('option[value=artboard]').disabled=!boards.length;
  f.srcNote.textContent=k==='file'&&I.embedded?'This image is embedded. Choose a file to link it again.':k==='artboard'&&I.frame?.layer?'Showing one layer of the artboard':'';
 }
 function sync(force=false){
  if(!panel.classList.contains('open')||syncing)return;if(!force){if(pending)return;pending=requestAnimationFrame(()=>{pending=0;sync(true)});return}
  syncing=true;try{
   build();const f=panel.f,n=node();
   if(!n){body.hidden=true;return}body.hidden=false;
   const isLayer=!!n._canvas,mod=isLayer&&n.mask&&isModifierKind(n.maskKind),type=!isLayer?'Group':mod?'Modifier':n.instance?({file:'File layer',clone:'Clone layer',shape:'Vector layer',text:'Text layer'}[n.instance.type]||'Layer'):n.mask?'Mask':n.reference?'Sketch layer':'Paint layer';
   f.kind.textContent=type;
   if(document.activeElement!==f.name)f.name.value=n.name;
   f.opacity.value=Math.round((n.op??1)*100);f.opacityOut.textContent=f.opacity.value+'%';f.blend.value=n.blend||'normal';
   f.vis.input.checked=!!n.vis;f.locked.input.checked=!!n.locked;f.alpha.input.checked=isLayer?!!n.alphaLock:nodeLayers(n).length>0&&nodeLayers(n).every(l=>l.alphaLock);f.inherit.input.checked=!!n.inheritAlpha;
   f.alpha.hidden=false;f.modifier.hidden=!mod;
   syncSource();
  }finally{syncing=false}
 }
 {const base=renderLayers;renderLayers=function(){const r=base.apply(this,arguments);try{sync()}catch(_){}return r}}
 return {sync,build};
})();
function toggleLayerPropsPanel(force){const p=$('layerPropsPanel'),open=typeof force==='boolean'?force:!p.classList.contains('open');p.classList.toggle('open',open);if(open){setPanelCollapsed('layerPropsPanel',false);schedulePanelLayout('layerPropsPanel');LayerPanel.sync(true)}}
ACTIONS.push({id:'layerPropsPanel',g:'UI',l:'Layer panel',k:['f3'],d:()=>toggleLayerPropsPanel()});for(const a of ACTIONS)if(!B[a.id])B[a.id]=[a.k?.[0]||'',a.k?.[1]||''];rebuildKM();   // F3 by default, remappable like every other shortcut
PALETTE_ACTIONS.push({id:'layerPropsPanel',words:'layer properties source file artboard clone name opacity blend lock alpha'});

