// Pure display geometry. Assistant data and snapping keep their original infinite rays.
const AssistantOverlayGeometry=(()=>{
 function clip(ax,ay,bx,by,rect){
  if(![ax,ay,bx,by,rect.left,rect.top,rect.right,rect.bottom].every(Number.isFinite)||rect.right<rect.left||rect.bottom<rect.top)return null;
  const dx=bx-ax,dy=by-ay;let lo=0,hi=1;
  for(const [p,q] of [[-dx,ax-rect.left],[dx,rect.right-ax],[-dy,ay-rect.top],[dy,rect.bottom-ay]]){
   if(p===0){if(q<0)return null;continue}const t=q/p;if(p<0){if(t>hi)return null;lo=Math.max(lo,t)}else{if(t<lo)return null;hi=Math.min(hi,t)}
  }
  return [{x:ax+lo*dx,y:ay+lo*dy},{x:ax+hi*dx,y:ay+hi*dy}];
 }
 function rays(v,width,height,pad=0){
  const x=v.x*width,y=v.y*height,radius=Math.hypot(Math.max(Math.abs(x),Math.abs(x-width)),Math.max(Math.abs(y),Math.abs(y-height)))+16,n=Math.max(2,Math.min(128,Math.round(v.lines)||16)),segments=[];
  const rect={left:-pad,top:-pad,right:width+pad,bottom:height+pad};
  for(let k=0;k<n;k++){const a=k*Math.PI*2/n,line=clip(x,y,x+Math.cos(a)*radius,y+Math.sin(a)*radius,rect);if(line)segments.push(line)}
  return {requested:n,segments};
 }
 return Object.freeze({clip,rays});
})();
