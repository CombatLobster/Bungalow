// Adjustment controls are moved into inline filter modifiers too: retain their IDs/handlers.
(function(global){
 const entries=[];let frame=0;
 const visible=el=>!document.hidden&&el.getClientRects().length>0;
 // v283: every pill is synced (14 controls, cheap); skipping hidden ones lost values set while a panel was still opening
 function sync(){frame=0;for(const {source,api}of entries){if(api.input.disabled!==source.disabled)api.input.disabled=source.disabled;const drag=api.root.querySelector('.compact-value-drag');if(drag.disabled!==source.disabled)drag.disabled=source.disabled;api.sync();if(source.disabled)api.root.querySelector('.compact-value-reset').disabled=true}}
 // v283: a timer backs up the frame callback (frames do not run while the page is hidden or throttled)
 function queue(){if(frame)return;frame=requestAnimationFrame(sync);setTimeout(()=>{if(frame){cancelAnimationFrame(frame);sync()}},120)}
 for(const source of document.querySelectorAll('#adjustmentPanel input[type=range],#modifierPanel input[type=range]')){
  if(source.dataset.pilled)continue;
  const row=source.closest('.r');if(!row)continue;
  const label=(row.querySelector('span')?.textContent||source.title||source.id).replace(/\s*\([^)]*\)\s*$/,'').trim(),unit=/Hue/.test(source.id)?'°':/Blur|Radius/.test(source.id)?'px':'%',min=Number(source.min||0),max=Number(source.max||100),dragStep=Number(source.step||1)/2,reset=Number(source.defaultValue||min);
  // A number source keeps existing event consumers but permits values finer than a range step.
  source.type='number';source.step='any';source.hidden=true;source.dataset.pilled='1';row.querySelector('output')?.setAttribute('hidden','');
  const parse=text=>{text=text.trim();if(text.endsWith(unit))text=text.slice(0,-unit.length).trim();return /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(text)?Number(text):NaN};
  const api=createCompactValueControl({id:'precise_'+source.id,label,get:()=>Number(source.value),set:value=>{source.value=Number(Math.max(min,Math.min(max,value)).toFixed(3));source.dispatchEvent(new Event('input',{bubbles:true}))},min,max,step:.01,dragStep,reset,digits:3,parse,format:value=>value+(unit==='°'?'':' ')+unit});
  api.root.classList.add('desktop-value','panel-value-pill');source.after(api.root);
  const commit=()=>source.dispatchEvent(new Event('change',{bubbles:true}));api.input.addEventListener('change',commit);api.root.addEventListener('valuecommit',commit);api.root.querySelector('.compact-value-reset').addEventListener('click',commit);
  entries.push({source,api});
 }
 for(const name of ['input','change'])document.addEventListener(name,e=>{if(e.target.closest?.('#modifierPanel,#adjustmentPanel'))queue()},true);
 const observer=new MutationObserver(records=>{if(records.some(r=>!(r.type==='attributes'&&r.attributeName==='disabled'&&r.target.closest('.compact-value'))))queue()});for(const id of ['modifierPanel','adjustmentPanel'])observer.observe($(id),{attributes:true,childList:true,subtree:true,attributeFilter:['class','style','hidden','disabled','open']});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0}else queue()});
 global.BungalowPanelValues={sync,queue,entries};queue();
 const style=document.createElement('style');style.textContent=`.r>.panel-value-pill{grid-column:1/-1;width:100%;min-width:0}
:is(#adjustmentPanel,#modifierPanel,#vectorControls) .desktop-value{display:flex;align-items:center;gap:0;min-width:0;border:1px solid var(--bd);border-radius:6px;background:var(--pn);height:28px;overflow:hidden}
:is(#adjustmentPanel,#modifierPanel,#vectorControls) .desktop-value>input{flex:1 1 0!important;width:auto;min-width:0;box-sizing:border-box;height:26px;padding:3px 5px;border:0;border-radius:0;background:transparent;color:var(--fg);font:inherit;font-variant-numeric:tabular-nums;text-align:right;appearance:textfield}
:is(#adjustmentPanel,#modifierPanel,#vectorControls) .desktop-value>button{height:26px!important;border:0;border-radius:0;background:transparent}
:is(#adjustmentPanel,#modifierPanel,#vectorControls) .desktop-value:focus-within{outline:2px solid var(--ac);outline-offset:1px}
#vectorControls .vector-num:not(:has(.compact-value)){display:none}#vectorControls .vector-wrap-exclude{display:flex;grid-column:1/-1;align-items:center;gap:6px;min-width:0}#vectorControls .vector-wrap-exclude input{width:14px;height:14px;margin:0;flex:none}
@container toolsettings (max-width:280px){#vectorControls .vector-num{grid-template-columns:minmax(0,1fr);gap:3px}}
`;document.head.append(style);
})(globalThis);
