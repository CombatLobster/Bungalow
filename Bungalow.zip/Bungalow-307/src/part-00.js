
/* Pen-only scroll grips. Native scrolling remains available for mouse/touch. */
(function(global){
 const selector='.p,.panel-body,.recent-projects,[style*="overflow"],#ll,#landing,#presetManagerList,#actionResults,#presetResults,#textureAssetGrid,#assistantList,#boxList,#exportBoardList,textarea';
 const entries=new Map();let pen=false,frame=0,drag=null,lastRefresh=0,surfaceSerial=0;
 const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
 function schedule(){if(pen&&!frame)frame=requestAnimationFrame(refresh)}
 function stop(){if(!drag)return;const d=drag;drag=null;d.controller.abort();d.track.classList.remove('dragging');try{d.track.releasePointerCapture(d.pointer)}catch(_){}schedule()}
 function remove(el){const entry=entries.get(el);if(!entry)return;for(const track of Object.values(entry)){if(drag?.track===track)stop();track.remove()}entries.delete(el)}
 function geometry(el,axis){const r=el.getBoundingClientRect(),style=getComputedStyle(el);if(!el.isConnected||!r.width||!r.height||style.visibility==='hidden'||style.display==='none')return null;
 const vertical=axis==='y',viewport=vertical?el.clientHeight:el.clientWidth,total=vertical?el.scrollHeight:el.scrollWidth,overflow=vertical?style.overflowY:style.overflowX;
 if(viewport<35||total<=viewport+1||!['auto','scroll'].includes(overflow))return null;
 const sx=r.width/(el.offsetWidth||r.width),sy=r.height/(el.offsetHeight||r.height),scale=vertical?sy:sx;
 const nativeV=Math.max(0,el.offsetWidth-el.clientWidth-(parseFloat(style.borderLeftWidth)||0)-(parseFloat(style.borderRightWidth)||0))*sx;
 const nativeH=Math.max(0,el.offsetHeight-el.clientHeight-(parseFloat(style.borderTopWidth)||0)-(parseFloat(style.borderBottomWidth)||0))*sy;
 const thickness=Math.max(20,16*scale),left=r.left+el.clientLeft*sx,top=r.top+el.clientTop*sy,length=viewport*scale;
 let clip={left:0,top:0,right:innerWidth,bottom:innerHeight},z=1;
 for(let parent=el;parent&&parent!==document.body;parent=parent.parentElement){const cs=getComputedStyle(parent),level=parseInt(cs.zIndex,10);if(Number.isFinite(level))z=Math.max(z,level+1);if(parent===el)continue;if(/auto|scroll|hidden|clip/.test(cs.overflowX+' '+cs.overflowY)){const pr=parent.getBoundingClientRect();clip={left:Math.max(clip.left,pr.left),top:Math.max(clip.top,pr.top),right:Math.min(clip.right,pr.right),bottom:Math.min(clip.bottom,pr.bottom)}}}
 const x=vertical?left+el.clientWidth*sx+nativeV-thickness:left,y=vertical?top:top+el.clientHeight*sy+nativeH-thickness,width=vertical?thickness:length,height=vertical?length:thickness;
 if(x+width<=clip.left||x>=clip.right||y+height<=clip.top||y>=clip.bottom)return null;
 const thumb=Math.min(length,Math.max(38*scale,length*viewport/total)),travel=Math.max(1,length-thumb),max=total-viewport,scroll=vertical?el.scrollTop:el.scrollLeft;
 return {vertical,x,y,width,height,length,thumb,travel,max,offset:travel*scroll/max,z,clip};
 }
 function make(el,axis){const track=document.createElement('div');track.className='pen-scroll-track';track.dataset.axis=axis;track.setAttribute('role','scrollbar');track.setAttribute('aria-orientation',axis==='y'?'vertical':'horizontal');track.setAttribute('aria-label',(axis==='y'?'Vertical':'Horizontal')+' scroll');track.tabIndex=0;if(!el.id)el.id='pen-scroll-surface-'+(++surfaceSerial);track.setAttribute('aria-controls',el.id);const thumb=document.createElement('div');thumb.className='pen-scroll-thumb';track.append(thumb);track._scrollElement=el;document.body.append(track);return track}
 function refresh(){frame=0;if(!pen||typeof drawing!=='undefined'&&drawing)return;lastRefresh=performance.now();const seen=new Set();
 for(const el of document.querySelectorAll(selector)){if(el.closest('.pen-scroll-track')||el.closest('#stage')||(!el.closest('.p,#landing')&&el.id!=='landing'))continue;for(const axis of ['y','x']){const g=geometry(el,axis);let entry=entries.get(el),track=entry?.[axis];if(!g){if(track){if(drag?.track===track)stop();track.remove();delete entry[axis]}continue}seen.add(el);if(!entry){entry={};entries.set(el,entry)}if(!track)entry[axis]=track=make(el,axis);const thumb=track.firstChild;
 Object.assign(track.style,{left:g.x+'px',top:g.y+'px',width:g.width+'px',height:g.height+'px',zIndex:String(g.z),clipPath:'inset('+Math.max(0,g.clip.top-g.y)+'px '+Math.max(0,g.x+g.width-g.clip.right)+'px '+Math.max(0,g.y+g.height-g.clip.bottom)+'px '+Math.max(0,g.clip.left-g.x)+'px)'});
 Object.assign(thumb.style,g.vertical?{top:g.offset+'px',left:'3px',height:g.thumb+'px',width:'calc(100% - 6px)'}:{left:g.offset+'px',top:'3px',width:g.thumb+'px',height:'calc(100% - 6px)'});track.setAttribute('aria-valuemin','0');track.setAttribute('aria-valuemax',String(Math.round(g.max)));track.setAttribute('aria-valuenow',String(Math.round(g.vertical?el.scrollTop:el.scrollLeft)));
 }}for(const el of entries.keys())if(!seen.has(el))remove(el);
 }
 function mode(on){if(pen===on)return;pen=on;document.body.classList.toggle('pen-scroll-mode',on);if(on)schedule();else for(const el of [...entries.keys()])remove(el)}
 function down(e){const track=e.target.closest?.('.pen-scroll-track');if(!track||e.button!==0)return;const el=track._scrollElement,axis=track.dataset.axis,g=geometry(el,axis);if(!g)return;e.preventDefault();e.stopImmediatePropagation();stop();track.focus({preventScroll:true});const pos=g.vertical?e.clientY:e.clientX,start=g.vertical?g.y:g.x,inside=e.target.closest('.pen-scroll-thumb');
 if(!inside){const value=clamp((pos-start-g.thumb/2)/g.travel,0,1)*g.max;if(g.vertical)el.scrollTop=value;else el.scrollLeft=value}
 const controller=new AbortController(),options={capture:true,signal:controller.signal};drag={track,el,axis,pointer:e.pointerId,start:pos,scroll:g.vertical?el.scrollTop:el.scrollLeft,ratio:g.max/g.travel,controller};track.classList.add('dragging');try{track.setPointerCapture(e.pointerId)}catch(_){}
 window.addEventListener('pointermove',ev=>{const d=drag;if(!d||ev.pointerId!==d.pointer)return;ev.preventDefault();ev.stopImmediatePropagation();const delta=(d.axis==='y'?ev.clientY:ev.clientX)-d.start;if(d.axis==='y')d.el.scrollTop=d.scroll+delta*d.ratio;else d.el.scrollLeft=d.scroll+delta*d.ratio;schedule()},{...options,passive:false});
 const end=ev=>{if(ev.pointerId!==drag?.pointer)return;ev.preventDefault();ev.stopImmediatePropagation();stop()};window.addEventListener('pointerup',end,options);window.addEventListener('pointercancel',end,options);window.addEventListener('blur',stop,{signal:controller.signal});schedule();
 }
 // Registered before the app's menu dismiss handlers, so dragging a menu's scrollbar does not close it.
 document.addEventListener('pointerdown',down,true);
 document.addEventListener('contextmenu',e=>{if(e.target.closest?.('.pen-scroll-track')){e.preventDefault();e.stopImmediatePropagation()}},true);
 window.addEventListener('pointermove',e=>{if(drag)return;if(penLike(e)){mode(true);if(!e.buttons&&performance.now()-lastRefresh>150)schedule()}else if(penMouse(e))mode(false)},{capture:true,passive:true});
 window.addEventListener('pointerdown',e=>{if(!drag&&penLike(e))mode(true)},{capture:true,passive:true});
 window.addEventListener('keydown',e=>{const track=e.target.closest?.('.pen-scroll-track');if(!track)return;const el=track._scrollElement,axis=track.dataset.axis,g=geometry(el,axis);if(!g)return;const key=e.key;let amount=0;if(key==='ArrowDown'||key==='ArrowRight')amount=40;if(key==='ArrowUp'||key==='ArrowLeft')amount=-40;if(key==='PageDown')amount=g.vertical?el.clientHeight:el.clientWidth;if(key==='PageUp')amount=-(g.vertical?el.clientHeight:el.clientWidth);if(key==='Home')amount=-Infinity;if(key==='End')amount=Infinity;if(key==='Escape'){e.preventDefault();e.stopImmediatePropagation();stop();if(el.id==='subtoolSelectorOptions')global.BungalowSubtools?.close(true);return}if(!amount)return;e.preventDefault();e.stopImmediatePropagation();if(g.vertical)el.scrollTop=clamp(el.scrollTop+amount,0,g.max);else el.scrollLeft=clamp(el.scrollLeft+amount,0,g.max);schedule()},true);
 window.addEventListener('pointerup',e=>{if(penLike(e))schedule()},{passive:true});
 document.addEventListener('scroll',schedule,{capture:true,passive:true});window.addEventListener('resize',schedule);window.addEventListener('blur',stop);
 new MutationObserver(records=>{if(pen&&records.some(r=>r.target.nodeType===1&&r.target.closest?.('.p,#landing')))schedule()}).observe(document.body,{childList:true,subtree:true});
 new MutationObserver(schedule).observe(document.body,{attributes:true,attributeFilter:['class']});
 global.BungalowPenScroll={refresh:schedule};
})(globalThis);
