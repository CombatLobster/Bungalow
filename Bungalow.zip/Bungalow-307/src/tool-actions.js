// Use the same subtool definitions and activation route as Tool Presets/loadouts.
// Brush and eraser presets stay in their dedicated browser.
(function(){
 const roots={brush:'brush',eraser:'eraser',fill:'fill',selection:'selection',transform:'transform',vectors:'vectors',text:'textTool',assistant:'assistantTool'};
 const aliases={
  'transform:transform':'transform-transform','transform:perspective':'transform-perspective','transform:warp':'transform-warp','transform:liquify':'transform-liquify','transform:artboard':'artboardTool',
  'text:annotation':'annotationTool','assistant:drawing:horizon':'assistHorizon','assistant:guides':'assistGuides','assistant:references':'assistReferences','assistant:vanishing':'assistVanishing'
 };
 let saved={};try{saved=JSON.parse(localStorage.getItem('llk')||'{}')}catch(_){}
 const registry=getActionRegistry();if(registry.has('vectors'))registry.get('vectors').l='Vectors · last subtool';
 const toolErase=()=>tool(true);
 function add(id,words,preset,run,label){
  if(!registry.has(id)){const action={id,g:'Subtools',l:label,k:[],d:run};ACTIONS.push(action);registry.set(id,action);const keys=saved[id];B[id]=Array.isArray(keys)?[typeof keys[0]==='string'?keys[0]:'',typeof keys[1]==='string'?keys[1]:'']:['','']}
  let item=PALETTE_ACTIONS.find(a=>a.id===id);if(!item){item={id,words:''};PALETTE_ACTIONS.push(item)}item.words+=' '+words;item.toolPreset=preset;if(run)item.run=run;
 }
 for(const [tool,id]of Object.entries(roots))add(id,'tool tools '+tool,{id:'tool:'+tool,tool},tool==='eraser'?()=>toolErase():null);
 for(const p of paletteSubtools()){
  if(p.subtool==='snap')continue; // merged into Transform, not another tool
  const alias=(p.tool==='fill'||p.tool==='selection')?p.tool+'_'+p.subtool:aliases[p.tool+':'+p.subtool];
  const id=alias&&registry.has(alias)?alias:p.id;
  add(id,'tool subtool '+p.tool+' '+p.subtool+' '+p.name,p,()=>activatePaletteSubtool(p),p.name);
 }
 // Merge existing aliases without presenting repeated rows for the same action.
 const unique=new Map();for(const item of PALETTE_ACTIONS){const prior=unique.get(item.id);if(prior){prior.words+=' '+item.words;if(item.toolPreset)prior.toolPreset=item.toolPreset}else unique.set(item.id,item)}PALETTE_ACTIONS.splice(0,PALETTE_ACTIONS.length,...unique.values());
 // Pins for late-registered subtools must survive the initial legacy pin filter.
 try{const ids=JSON.parse(localStorage.getItem('llpinnedactions')||'[]');if(Array.isArray(ids))pinnedActions=[...new Set(ids)].filter(id=>unique.has(id))}catch(_){}
 actionFavsDirty=true;rebuildKM();
})();
