/* v231: DOM-free layer-property transactions, the first engine boundary.
 * Records and patches contain only JSON values. IDs are supplied by the host;
 * the legacy adapter retains node references, selection and rendering duties.
 * No document mirror, pixel access, IPC or browser dependency lives here.
 */
const BungalowLayerEdit = (() => {
 'use strict';
 const defaults=Object.freeze({op:1,blend:'normal',vis:true,locked:false,alphaLock:false,inheritAlpha:false,reference:false,isolate:false,mask:false,name:'Layer'});
 function validate(key,value){
  if(key==='op'){if(typeof value!=='number'||!Number.isFinite(value)||value<0||value>1)throw new TypeError('Opacity must be between 0 and 1')}
  else if(key==='blend'){if(typeof value!=='string'||!value.length||value.length>80)throw new TypeError('Invalid blend mode')}
  else if(['vis','locked','alphaLock','inheritAlpha','reference','isolate','mask'].includes(key)){if(typeof value!=='boolean')throw new TypeError('Layer flags must be boolean')}
  else if(key==='name'){if(typeof value!=='string'||!value.trim())throw new TypeError('Layer name must not be blank')}
  else throw new TypeError('Unsupported layer property');
  return value;
 }
 function begin(key,records){
  validate(key,defaults[key]);
  const ids=new Set();
  const entries=records.map(({id,value})=>{
   if(typeof id!=='string'||!id||ids.has(id))throw new TypeError('Unique edit IDs required');
   ids.add(id);const before=validate(key,value??defaults[key]);
   return {id,before,after:before};
  });
  return {version:1,key,entries};
 }
 function update(edit,value){
  validate(edit.key,value); // validate before any mutation
  for(const entry of edit.entries)entry.after=value;
  return edit.entries.map(e=>({id:e.id,key:edit.key,value:e.after}));
 }
 // v229: Alt can enrol group descendants partway through a gesture.
 // Validate the full batch first, retaining every original value exactly once.
 function include(edit,records){
  const added=begin(edit.key,records).entries,ids=new Set(edit.entries.map(e=>e.id));
  edit.entries.push(...added.filter(e=>!ids.has(e.id)));
 }
 // v230: heterogeneous property batches (for example numbered names).
 // Reject unknown/duplicate IDs and invalid values before changing any entry.
 function updateEach(edit,records){
  const ids=new Set(edit.entries.map(e=>e.id)),values=new Map();
  for(const {id,value} of records){
   if(!ids.has(id)||values.has(id))throw new TypeError('Known unique edit IDs required');
   values.set(id,validate(edit.key,value));
  }
  for(const entry of edit.entries)if(values.has(entry.id))entry.after=values.get(entry.id);
  return edit.entries.map(e=>({id:e.id,key:edit.key,value:e.after}));
 }
 function finish(edit){
  const changed=edit.entries.filter(e=>e.before!==e.after);
  const patch=field=>changed.map(e=>({id:e.id,key:edit.key,value:e[field]}));
  return {version:1,undo:patch('before'),redo:patch('after')};
 }
 // v228: discrete property commands share the gesture patch format. Toggle
 // preserves mixed selection values; set applies one value to every record.
 function command(key,records,operation){
  const edit=begin(key,records);
  if(operation?.type==='set')update(edit,operation.value);
  else if(operation?.type==='setEach')updateEach(edit,operation.values);
  else if(operation?.type==='toggle'){
   if(!['vis','locked','alphaLock','inheritAlpha','reference','isolate','mask'].includes(key))throw new TypeError('Only flags can be toggled');
   for(const entry of edit.entries)entry.after=!entry.before;
  }else throw new TypeError('Unsupported layer edit operation');
  return finish(edit);
 }
 return Object.freeze({begin,include,update,updateEach,finish,command});
})();
if(typeof module!=='undefined'&&module.exports)module.exports=BungalowLayerEdit;
