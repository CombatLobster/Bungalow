
/* ====== Build 183: while the artboard tool is active, layer actions act on artboards ====== */
let artboardClipboard=null;
const boardsForAction=()=>{const sel=selectedBoardList();return sel.length?sel:artboards.filter(b=>b.id===activeArtboardId)};
const boardSize=b=>{const d=ArtboardWorkspace.dimensions(b);return {width:d.width,height:d.height}};
async function copyArtboards(cut=false){
 if(!artboardReady())return;stashActiveArtboard();
 const boards=boardsForAction();if(!boards.length){toast('No artboard selected');return}
 const bytes=boards.reduce((n,b)=>n+artboardLayerBytes(b.state.layers),0);
 if(memoryBudgetExceeded(memoryUsage().total+bytes)){toast('Copying exceeds the configured memory budget');return}
 setProjectBusy(true,'Copying '+(boards.length===1?'artboard':boards.length+' artboards')+'…');
 try{
  const items=[];for(const b of boards)items.push({name:b.name,x:b.x,y:b.y,...boardSize(b),state:await ArtboardWorkspace.clone(b)});
  artboardClipboard={items,cut};uiNotice((cut?'Cut ':'Copied ')+(boards.length===1?'“'+boards[0].name+'”':boards.length+' artboards'));
 }catch(error){toast('Could not copy: '+error.message);return}finally{setProjectBusy(false)}
 if(cut)await deleteSelectedArtboards({prompt:false});
}
// copies go beside the originals (or back where a cut came from), keep their arrangement and never overlap anything
async function addBoardCopies(items,label){
 if(!artboardReady())return;if(artboards.length+items.length>64){toast('A project supports up to 64 artboards');return}
 stashActiveArtboard();
 const stateOf=i=>i.state||i.board.state;
 if(residentArtboardLayers().length+items.reduce((n,i)=>n+stateOf(i).layers.length,0)>4096){toast('A workspace supports up to 4096 layers');return}
 if(memoryBudgetExceeded(memoryUsage().total+items.reduce((n,i)=>n+artboardLayerBytes(stateOf(i).layers),0))){toast('The copies exceed the configured memory budget');return}
 const gap=Math.max(0,Math.round(+$('artboardSnapGap')?.value||0)),x0=Math.min(...items.map(i=>i.x)),y0=Math.min(...items.map(i=>i.y)),w=Math.max(...items.map(i=>i.x+i.width))-x0,h=Math.max(...items.map(i=>i.y+i.height))-y0;
 const rects=items.map((it,i)=>({id:'copy'+i,x:it.x,y:it.y,width:it.width,height:it.height})),all=otherBoardRects([]),right=all.length?Math.max(...all.map(r=>r.x+r.width))+gap-x0:w+gap,bottom=all.length?Math.max(...all.map(r=>r.y+r.height))+gap-y0:h+gap;
 const offsets=[...(items===artboardClipboard?.items&&artboardClipboard.cut?[[0,0]]:[]),[w+gap,0],[0,h+gap],[right,0],[0,bottom]];
 const offset=offsets.find(([dx,dy])=>!overlapsOthers(rects.map(r=>({...r,x:r.x+dx,y:r.y+dy}))))||[right,0];
 setProjectBusy(true,label+'…');const made=[];
 try{const names=artboards.map(b=>b.name),gmap=new Map();for(const it of items){const state=it.state?await cloneArtboardState(it.state):await ArtboardWorkspace.clone(it.board),name=copyName(it.name,names).slice(0,120);names.push(name);made.push({id:crypto.randomUUID(),name,x:it.x+offset[0],y:it.y+offset[1],state,...(it.group?{group:gmap.get(it.group)||gmap.set(it.group,crypto.randomUUID()).get(it.group)}:{})})}}
 catch(error){toast('Could not copy artboards: '+error.message);return}finally{setProjectBusy(false)}
 insertBoardResources(made);
 uiNotice(made.length===1?'“'+made[0].name+'” added':made.length+' artboards added');
}
async function pasteArtboards(){if(!artboardClipboard?.items.length){toast('Copy an artboard first');return}await addBoardCopies(artboardClipboard.items,'Pasting')}
async function duplicateSelectedArtboards(){
 if(!artboardReady())return;stashActiveArtboard();const boards=boardsForAction();if(!boards.length){toast('No artboard selected');return}
 await addBoardCopies(boards.map(b=>({name:b.name,x:b.x,y:b.y,group:b.group,...boardSize(b),board:b})),'Duplicating');
}
async function renameActiveArtboard(){
 const board=artboards.find(b=>b.id===activeArtboardId);if(!board)return;if(board.locked){toast('Unlock the artboard first');return}
 const name=(await showPrompt('Artboard name',board.name))?.trim();if(name)renameArtboard(name,board.id);
}


// Delete / Backspace delete the selected artboards while the artboard tool is active (the layer action itself has no default key)
document.addEventListener('keydown',e=>{
 if(e.key!=='Delete'&&e.key!=='Backspace')return;if(e.defaultPrevented||e.ctrlKey||e.metaKey||e.altKey)return;
 if(!artboardToolActive()||appDialogOpen()||e.target.closest?.('input,textarea,select,[contenteditable=true]'))return;
 e.preventDefault();e.stopImmediatePropagation();deleteSelectedArtboards();
},true);
