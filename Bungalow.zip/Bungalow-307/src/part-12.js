/* v176: shared object storage. The active shape remains the existing editor's
 * record; immutable object arrays keep inactive geometry safe across history. */
function vectorObjectList(I){return I.vectorObjects?I.vectorObjects.map((s,i)=>i===(I.vectorIndex||0)?I.shape:s):[I.shape]}
function paintVectorObjects(g,I){for(const s of vectorObjectList(I))paintVectorShape(g,s)}
function vectorObjectBounds(I){let b=null;for(const s of vectorObjectList(I)){if(s.kind==='empty')continue;const r=vectorBounds(I,s);if(r)b=b?vectorUnion(b,r):r}return b}
// v178: creation always uses one shape/path per layer. Legacy collections still
// render and can be explicitly split, so older prototype files remain usable.
var VectorObjects=window.VectorObjects=(()=>{
 const panel=document.createElement('div');panel.className='vector-actions';panel.hidden=true;
 panel.innerHTML='<button id="vectorSplitLegacy" class="tone-create" title="Separate every object from this older vector layer into its own editable layer">Split legacy objects into layers</button>';$('vectorControls').prepend(panel);
 function sync(){panel.hidden=!(AL?.instance?.vectorObjects?.length>1);$('vectorSplitLegacy').disabled=!!(drawing||historyBusy||projectIOBusy||vectorDrag||vectorGizmoDrag||window.VectorBrush?.pending()||window.BungalowPen?.dragging())||!AL||layerLocked(AL)||groupLocked(AL?.group)}
 $('vectorSplitLegacy').onclick=()=>{if(canvasBusy()||layerLocked(AL)||groupLocked(AL?.group)||!AL?.instance?.vectorObjects)return;const L=AL,I=L.instance,objects=structuredClone(vectorObjectList(I)),index=layers.indexOf(L),added=objects.slice(1).map((shape,i)=>{const N=newLayer(L.name+' '+(i+2),null,sparseVectorsOn()&&nativeSparseActive());N.group=L.group;N.op=L.op;N.blend=L.blend;N.instance={...I,shape,vectorObjects:undefined,vectorIndex:undefined,xf:I.xf?[...I.xf]:null};return N});const apply=()=>{L.instance={...I,shape:objects[0],vectorObjects:undefined,vectorIndex:undefined};drawVectorLayer(L);added.forEach((N,i)=>{insertLayer(N,index+i+1);drawVectorLayer(N)});setStackSelection([L],{active:L});relayer();renderLayers()};apply();doH({bytes:added.reduce((n,L)=>n+layerRasterBytes(L),0),undo(){added.forEach(removeLayer);L.instance=I;drawVectorLayer(L);setStackSelection([L],{active:L});relayer();renderLayers()},redo:apply})};
 return {sync};
})();
