
/* ====== Build 165: File tab: resources the document uses + document details ====== */
const DOC_TYPES=[['default','Default'],['book','Book cover']];
var documentMeta=newDocumentMeta();
function newDocumentMeta(type='default'){const t=Date.now();return {title:'',type,author:'',notes:'',tags:[],book:null,export:null,created:t,modified:t}}
function sanitizeDocumentMeta(m){
 const d=newDocumentMeta();if(!m||typeof m!=='object')return d;const str=(v,n)=>typeof v==='string'?v.slice(0,n):'';
 return {title:str(m.title,200),type:DOC_TYPES.some(x=>x[0]===m.type)?m.type:'default',book:typeof sanitizeBook==='function'?sanitizeBook(m.book):null,author:str(m.author,120),notes:str(m.notes,4000),
  tags:Array.isArray(m.tags)?m.tags.filter(t=>typeof t==='string').map(t=>t.trim().slice(0,40)).filter(Boolean).slice(0,32):[],
  export:typeof sanitizeExportMemory==='function'?sanitizeExportMemory(m.export):null,created:Number.isFinite(m.created)?m.created:d.created,modified:Number.isFinite(m.modified)?m.modified:d.modified};
}
// the record that is saved inside the project file
function documentMetaRecord(){documentMeta.modified=Date.now();return structuredClone(documentMeta)}
function documentTypeForPreset(key){return 'default'}

// ---- fonts: is a family really installed (or loaded)? The Text tool's font list is only a set of candidates. ----
const GENERIC_FONTS=/^(serif|sans-serif|monospace|cursive|fantasy|system-ui|ui-serif|ui-sans-serif|ui-monospace|ui-rounded|math|emoji|fangsong)$/i;
let fontProbeContext=null;const fontProbeCache=new Map();
function fontInstalled(family){
 if(!family||GENERIC_FONTS.test(family))return true;
 if(fontProbeCache.has(family))return fontProbeCache.get(family);
 let ok=false;
 try{
  if(document.fonts)for(const f of document.fonts){if(f.status==='loaded'&&f.family.replace(/^["']|["']$/g,'')===family){ok=true;break}}
  if(!ok){const c=fontProbeContext||(fontProbeContext=document.createElement('canvas').getContext('2d')),text='mmmmmmmmmmlliWQ@0123456789',w=f=>{c.font='72px '+f;return c.measureText(text).width},q='"'+family.replace(/["\\]/g,'')+'"';ok=['monospace','serif','sans-serif'].some(g=>w(q+','+g)!==w(g))}
 }catch(_){ok=true}
 fontProbeCache.set(family,ok);return ok;
}
if(document.fonts?.addEventListener)document.fonts.addEventListener('loadingdone',()=>fontProbeCache.clear());
const fontFamilyOf=I=>String(I?.font||'').split(',')[0].trim().replace(/^["']|["']$/g,'');

// ---- what the document uses ----
function collectResources(){
 const groups=new Map(),cloneGroups=new Map(),fonts=new Map();
 for(const L of layers){
  const I=L.instance;if(!I)continue;
  if(I.type==='file'){const k=sourceKey(L);let g=groups.get(k);if(!g){g={key:k,layers:[]};groups.set(k,g)}g.layers.push(L)}
  else if(I.type==='clone'){const key=I.src||null;let g=cloneGroups.get(key);if(!g){g={src:I.src||null,ok:!!cloneSource(L),layers:[]};cloneGroups.set(key,g)}g.layers.push(L)}
  else if(I.type==='text'){const fam=fontFamilyOf(I)||'sans-serif';if(!fonts.has(fam))fonts.set(fam,{family:fam,layers:[],installed:fontInstalled(fam)});fonts.get(fam).layers.push(L)}
 }
 // a source used by several layers is listed once, with every layer it affects
 const files=[...groups.values()].map(g=>{
  const L=g.layers[0],I=L.instance,board=I.frame?.artboard||null,embedded=!board&&I.embedded===true;
  let status='ok';
  if(board)status=artboards.some(b=>b.id===board)?'ok':'missing';
  else if(!embedded)for(const x of g.layers){const J=x.instance,st=(J.missing||!J.img)?'missing':(J.stale||J.denied)?'unconnected':'ok';if(st==='missing')status='missing';else if(st==='unconnected'&&status!=='missing')status='unconnected'}
  const boardName=board?(artboards.find(b=>b.id===board)?.name||'removed artboard'):'';
  return {key:g.key,layers:g.layers,L,I,status,embedded,board,boardName,name:board?boardName:(I.name||'(unnamed file)'),path:I.sourcePath||'',live:!embedded&&!board&&g.layers.every(x=>!!x.instance.handle)&&status==='ok'};
 });
 const clones=[...cloneGroups.values()].map(g=>({layers:g.layers,L:g.layers[0],src:g.src,status:g.ok?'ok':'missing',source:g.src?.name||'(removed layer)'}));
 const fontList=[...fonts.values()].sort((a,b)=>a.family.localeCompare(b.family)).map(f=>({...f,status:f.installed?'ok':'missing'}));
 const attention=files.filter(x=>x.status!=='ok').length+clones.filter(x=>x.status!=='ok').length+fontList.filter(x=>x.status!=='ok').length;
 return {files,clones,fonts:fontList,attention,total:files.length+clones.length+fontList.length};
}
function resourceSignature(r){return JSON.stringify([r.files.map(x=>[x.key,x.layers.map(l=>l.name).join('|'),x.name,x.path,x.status,x.live,x.embedded,x.board]),r.clones.map(x=>[x.source,x.layers.map(l=>l.name).join('|'),x.status]),r.fonts.map(x=>[x.family,x.layers.length,x.status])])}
function showLayersInPanel(list){const nodes=list.filter(L=>layers.includes(L));if(!nodes.length)return;setStackSelection(nodes,{active:nodes[0],anchor:nodes[0]});for(const L of nodes)revealStackItem(L);relayer();renderLayers()}
function replaceFontEverywhere(oldFamily,newFamily){
 const all=layers.filter(L=>L.instance?.type==='text'&&fontFamilyOf(L.instance)===oldFamily),usable=all.filter(L=>!layerLocked(L)&&!groupLocked(L.group));
 if(!usable.length){toast(all.length?'Unlock the text layers first':'No text uses that font');return false}
 const changed=applyVectorPatches(usable.map(L=>({L,patch:{font:newFamily,fontFace:'',fontAxes:'',fontStyleName:''}})));
 fontProbeCache.clear();uiNotice((changed?'Replaced ':'No change · ')+oldFamily+' → '+newFamily+' on '+usable.length+' text layer'+(usable.length===1?'':'s')+(all.length>usable.length?' · '+(all.length-usable.length)+' locked skipped':''));return changed;
}
const fileTab={signature:'',replacing:null};
function fileTabVisible(){return $('docpanel').classList.contains('open')&&!$('filePage').hidden}
function iconFor(name){try{return BungalowIcons.node(name)}catch(_){return document.createElement('span')}}
function resourceRow({icon,title,sub,status,chip,chipTitle,actions=[],extra=null,note=null}){
 const row=document.createElement('div');row.className='res-row res-'+status;
 const head=document.createElement('div');head.className='res-head';
 const ic=document.createElement('span');ic.className='res-icon';ic.append(iconFor(icon));
 const main=document.createElement('div');main.className='res-main';const t=document.createElement('div');t.className='res-title';t.textContent=title;t.title=title;
 const meta=document.createElement('div');meta.className='res-meta';const c=document.createElement('span');c.className='res-chip';c.textContent=chip;if(chipTitle)c.title=chipTitle;meta.append(c);
 if(sub){const s=document.createElement('span');s.className='res-sub';s.textContent=sub;s.title=sub;meta.append(s)}
 main.append(t,meta);head.append(ic,main);row.append(head);if(note){const d=document.createElement('div');d.className='res-layers';d.textContent=note;d.title=note;row.append(d)}
 if(actions.length){const acts=document.createElement('div');acts.className='res-actions';for(const [label,fn,tip,primary] of actions){const b=document.createElement('button');b.type='button';b.textContent=label;if(tip)b.title=tip;if(primary)b.classList.add('res-primary');b.onclick=fn;acts.append(b)}row.append(acts)}
 if(extra)row.append(extra);return row;
}
function sectionHead(text,count){const h=document.createElement('div');h.className='res-group';const a=document.createElement('span');a.textContent=text;const b=document.createElement('span');b.className='res-n';b.textContent=count;h.append(a,b);return h}
async function afterRelink(){try{syncRelinkButton()}catch(_){}renderFileTab(true)}
function fontReplacePanel(family){
 const box=document.createElement('div');box.className='res-replace';
 const select=document.createElement('select');select.className='canvas-select';select.setAttribute('aria-label','Replacement for '+family);
 const used=collectResources().fonts.filter(f=>f.status==='ok').map(f=>f.family),names=[...new Set([...used,...(typeof availableTextFonts!=='undefined'?availableTextFonts:[]),'sans-serif','serif','monospace'])].filter(n=>n!==family&&fontInstalled(n)).sort((a,b)=>a.localeCompare(b));
 for(const n of names)select.add(new Option(n,n));
 const apply=document.createElement('button');apply.type='button';apply.textContent='Replace';apply.classList.add('res-primary');apply.disabled=!names.length;
 apply.onclick=()=>{if(select.value&&replaceFontEverywhere(family,select.value)){fileTab.replacing=null;renderFileTab(true)}};
 const cancel=document.createElement('button');cancel.type='button';cancel.textContent='Cancel';cancel.onclick=()=>{fileTab.replacing=null;renderFileTab(true)};
 box.append(select,apply,cancel);return box;
}
function renderResources(){
 const r=collectResources(),list=$('resList');list.replaceChildren();
 const need=r.attention,ok=r.total-need;
 $('resSummary').textContent=r.total?(need?need+' of '+r.total+' need attention':'All '+r.total+' resources are available'):'';
 $('resSummary').className='res-summary'+(r.total?(need?' bad':' ok'):'');
 $('fileResourcesCount').textContent=need?String(need):'';$('fileResourcesCount').hidden=!need;
 $('resEmpty').hidden=r.total>0;
 const needsLink=r.files.some(x=>x.status!=='ok');$('resRelinkAll').hidden=!needsLink;
  if(r.files.length){
  list.append(sectionHead('Files',r.files.length));
  for(const f of r.files){
   const n=f.layers.length,names=f.layers.map(L=>'“'+L.name+'”').join(', ');
   const chip=f.board?(f.status==='ok'?'Artboard':'Missing'):f.embedded?'Embedded':f.status==='ok'?(f.live?'Live':'Linked'):f.status==='missing'?'Missing':'Reconnect';
   const relink=['Relink…',()=>openRelinkDialog(f.L,{scope:'all'}),'Choose a different file, artboard or layer'+(n>1?' for all '+n+' layers that share this source':''),f.status==='missing'];
   const actions=f.board?[relink,['Go to artboard',()=>ArtboardLinks.goTo(f.L),'Switch to the source artboard']]
    :f.embedded?[relink]
    :f.status==='unconnected'?[['Reconnect',async()=>{for(const x of f.layers)await relinkFileLayer(x);afterRelink()},'Grant access and reload from the original location',true],relink]
    :f.status==='missing'?[relink]
    :[['Open',()=>openFileLayerSource(f.L),'Open the source file in a new window'],relink];
   actions.push(['Show'+(n>1?' all':''),()=>showLayersInPanel(f.layers),n>1?'Select all '+n+' layers that use this source':'Select this layer']);
   list.append(resourceRow({icon:f.board?'artboards':'file',title:f.name,sub:f.board?(f.status==='ok'?'Live link':'Source artboard removed'):f.embedded?'':f.path&&f.path!==f.name?f.path:'',status:f.status,chip,
    chipTitle:f.board?(f.status==='ok'?'Linked to this artboard; updates while it is active':'The source artboard was removed: the cached image is kept'):f.embedded?'Stored inside this document: nothing to find':f.status==='missing'?'The file can no longer be found':f.status==='unconnected'?'The file is known but this session has no access to it yet':f.live?'Connected and watched for changes':'Linked without live access',
    note:(n===1?'Layer: ':n+' layers: ')+names,actions}));
  }
 }
 if(r.fonts.length){
  list.append(sectionHead('Fonts',r.fonts.length));
  for(const f of r.fonts){
   const n=f.layers.length,editing=fileTab.replacing===f.family;
   list.append(resourceRow({icon:'text',title:f.family,sub:n+' text layer'+(n===1?'':'s')+(f.status==='missing'?' · a substitute font is shown':''),status:f.status,chip:f.status==='ok'?'Installed':'Missing',chipTitle:f.status==='ok'?'Available on this device':'Not installed here: text falls back to another font',
    actions:[['Replace…',()=>{fileTab.replacing=editing?null:f.family;renderFileTab(true)},'Use a different font for every layer that uses this one',f.status!=='ok'],['Select layers',()=>showLayersInPanel(f.layers),'Select the text layers that use this font']],extra:editing?fontReplacePanel(f.family):null}));
  }
 }
  if(r.clones.length){
  list.append(sectionHead('Clone sources',r.clones.length));
  for(const c of r.clones){
   const n=c.layers.length,names=c.layers.map(L=>'“'+L.name+'”').join(', '),ok=c.status==='ok';
   list.append(resourceRow({icon:'link',title:c.source,sub:ok?'Source layer':'Source layer was deleted',status:c.status,chip:ok?'Linked':'Missing',chipTitle:ok?'These clones mirror this layer':'The layer these clones mirrored no longer exists',
    note:(n===1?'Clone: ':n+' clones: ')+names,
    actions:[...(ok?[['Go to source',()=>showLayersInPanel([c.src]),'Select the source layer']]:[['Rasterize'+(n>1?' all':''),()=>rasterizeClones(c.layers),'Keep the current pixels as ordinary layers'+(n>1?' (one undo step)':''),true]]),['Show'+(n>1?' all':''),()=>showLayersInPanel(c.layers),n>1?'Select all '+n+' clones':'Select this clone']]}));
  }
 }
 fileTab.signature=resourceSignature(r);return r;
}
// ---- document details ----
const gcd=(a,b)=>b?gcd(b,a%b):a;
function documentFacts(){
 const dpi=documentDPI,inch=n=>n/dpi,kinds={paint:0,vector:0,text:0,file:0,clone:0,mask:0};
 for(const L of layers){const t=L.instance?.type;if(L.mask)kinds.mask++;else if(t==='shape')kinds.vector++;else if(t==='text')kinds.text++;else if(t==='file')kinds.file++;else if(t==='clone')kinds.clone++;else kinds.paint++}
 const g=gcd(DW,DH),parts=[['paint',kinds.paint],['vector',kinds.vector],['text',kinds.text],['linked',kinds.file],['clone',kinds.clone],['mask',kinds.mask]].filter(x=>x[1]).map(x=>x[1]+' '+x[0]);
 const when=t=>new Date(t).toLocaleString([], {dateStyle:'medium',timeStyle:'short'});
 let mem='';try{mem=(memoryUsage().total/1048576).toFixed(0)+' MB in memory'}catch(_){}
 return [
  ['File',(projectHasFile?projectFilename:'Not saved yet')+(projectDirty?' · unsaved changes':'')],
  ['Size',DW+' × '+DH+' px'],['Print size',inch(DW).toFixed(2)+' × '+inch(DH).toFixed(2)+' in · '+(inch(DW)*25.4).toFixed(1)+' × '+(inch(DH)*25.4).toFixed(1)+' mm'],
  ['Resolution',dpi+' DPI'],['Aspect ratio',(DW/g)+' : '+(DH/g)],
  ['Layers',layers.length+' layer'+(layers.length===1?'':'s')+(layerGroups.length?' · '+layerGroups.length+' group'+(layerGroups.length===1?'':'s'):'')+(parts.length?' ('+parts.join(', ')+')':'')+(mem?' · '+mem:'')],
  ['Created',when(documentMeta.created)],['Last saved',projectHasFile?when(documentMeta.modified):'Not saved yet']
 ];
}
function documentTypeChecks(type){
 const out=[],add=(ok,text)=>out.push({ok,text});
 if(type==='book'){const bk=documentMeta.book;
  if(bk){add(documentDPI>=300,documentDPI>=300?documentDPI+' DPI suits print':documentDPI+' DPI is low for print (300 or more is usual)');add(bk.bleed>=3-1e-6,bk.bleed>=3-1e-6?'Bleed is '+(+bk.bleed.toFixed(2))+' mm':'Bleed under 3 mm: most printers ask for at least 3 mm (0.125 in)');add(bk.spine>0,bk.spine>0?'Spine is '+(+bk.spine.toFixed(2))+' mm':'The spine has no width');if(bk.pages)add(bk.pages>=79,bk.pages>=79?bk.pages+' pages: spine text is allowed':bk.pages+' pages: KDP allows spine text from 79 pages')}}
 return out;
}
function syncDocumentForm(force=false){
 const m=documentMeta,set=(id,v)=>{const el=$(id);if(force||document.activeElement!==el)el.value=v};
 set('docTypeSelect',m.type);set('docTitle',m.title);set('docAuthor',m.author);set('docTags',m.tags.join(', '));set('docNotes',m.notes);
 $('bookCoverGroup').hidden=m.type!=='book';if(m.type==='book'&&typeof bookSync==='function')bookSync();
 const dl=$('docFacts');dl.replaceChildren();for(const [k,v] of documentFacts()){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=k;dd.textContent=v;dl.append(dt,dd)}
 const ul=$('docChecks');ul.replaceChildren();const checks=documentTypeChecks(m.type);
 for(const c of checks){const li=document.createElement('li');li.className=c.ok?'ok':'warn';li.textContent=c.text;ul.append(li)}
 ul.hidden=!checks.length;
}
function renderFileTab(force=false){
 const r=renderResources();syncDocumentForm(force);updateFileBadge(r);
}
function updateFileBadge(r=collectResources()){
 const n=r.attention,tab=$('docFile');tab.dataset.count=n?String(n):'';tab.classList.toggle('attention',n>0);
 tab.title=n?n+' resource'+(n===1?'':'s')+' need attention':'Resources and document details';
 $('documentMenu').classList.toggle('attention',n>0);
}
{ // wiring
 const typeOptions=DOC_TYPES.map(([v,l])=>new Option(l,v));$('docTypeSelect').replaceChildren(...typeOptions);
 const dirty=()=>{projectDirty=true};
 $('docTypeSelect').addEventListener('change',e=>{documentMeta.type=e.target.value;dirty();syncDocumentForm(true)});
 $('docTitle').addEventListener('input',e=>{documentMeta.title=e.target.value.slice(0,200);dirty()});
 $('docAuthor').addEventListener('input',e=>{documentMeta.author=e.target.value.slice(0,120);dirty()});
 $('docNotes').addEventListener('input',e=>{documentMeta.notes=e.target.value.slice(0,4000);dirty()});
 $('docTags').addEventListener('change',e=>{documentMeta.tags=sanitizeDocumentMeta({tags:e.target.value.split(',')}).tags;dirty();syncDocumentForm(true)});
 $('docFile').onclick=()=>{fontProbeCache.clear();renderFileTab(true);setDocumentTab('File')};
 $('resRelinkAll').onclick=async()=>{await relinkFileLayersFromFolder();afterRelink()};
 const baseToggle=toggleDocumentPanel;
 toggleDocumentPanel=function(open){const r=baseToggle.apply(this,arguments);if($('docpanel').classList.contains('open')&&!$('filePage').hidden)renderFileTab(true);return r};
 BackgroundTicker.add('file-resources',1200,()=>{
  const r=collectResources();updateFileBadge(r);
  if(fileTabVisible()&&resourceSignature(r)!==fileTab.signature&&!fileTab.replacing)renderFileTab();
 });
 updateFileBadge();
}

