
/* ====== Build 189: vector tools branch · gradient fill joins the Fill section ====== */
(()=>{
 const sel=$('vectorFillType');if(!sel||sel.dataset.gradient)return;sel.dataset.gradient='1';
 sel.add(new Option('Gradient','gradient'));
 const mode=$('vectorFillMode'),paint=$('vectorPaint');
 for(const el of [mode,paint]){const row=el?.closest('.vector-row');if(row)row.hidden=true}   // the Fill type and the colour toggles replace these two rows
 sel.addEventListener('change',()=>{mode.value=sel.value==='gradient'?'gradient':'solid';mode.dispatchEvent(new Event('change',{bubbles:true}))});
 const fill=$('vectorFillSection')?.querySelector('.vector-fields'),stroke=$('vectorStrokeSection')?.querySelector('.vector-fields'),grad=document.querySelector('#vectorControls .vector-gradient');
 if(fill&&grad)fill.append(grad);
 const move=(id,to)=>{const r=$(id)?.closest('.vector-row');if(r&&to)to.append(r)};
 move('vectorFillOpacity',fill);move('vectorStrokeOpacity',stroke);move('vectorStrokeAlign',stroke);
 BungalowVectors.sync(true);
})();

