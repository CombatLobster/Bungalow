/* v262: DOM-free pixel resource ledger (stage 5).
 * Describes every pixel resource and history snapshot as plain JSON so a native core can own them:
 *  - resources: {id:'res_<32hex>', kind:'raster'|'mask', width, height, storage:'dense'|'sparse', tileSize, bytes}
 *              ('mask' = the current selection mask, v259; 'image' = decoded source/retained images, v262)
 *  - snapshots: {id:'snap_<32hex>', resource, kind:'tiles', keys:['x:y',...], bytes}  tile sets kept by history
 *              {id, resource, kind:'region', rect:{x,y,w,h}, bytes}                   before/after region pairs (v258)
 *              {id, resource, kind:'surface', storage, width, height, bytes}          whole-surface states (v259)
 * Pixel payloads (canvases, tiles) never enter this module; the browser adapter holds them by ID.
 * Also provides the pure tile planner used by sparse storage and snapshots.
 */
const BungalowResources=(()=>{
 'use strict';
 const RES=/^res_[0-9a-f]{32}$/,SNAP=/^snap_[0-9a-f]{32}$/;
 const validResource=id=>typeof id==='string'&&RES.test(id),validSnapshot=id=>typeof id==='string'&&SNAP.test(id);
 const hex=random=>{let s='';for(let i=0;i<32;i++)s+=Math.floor(random()*16).toString(16);return s};
 // Allocation is injectable for tests; default uses crypto when present.
 function allocator(prefix,random){return ()=>{if(!random&&typeof crypto!=='undefined'&&crypto.getRandomValues){const b=crypto.getRandomValues(new Uint8Array(16));return prefix+[...b].map(x=>x.toString(16).padStart(2,'0')).join('')}return prefix+hex(random||Math.random)}}
 const posInt=v=>Number.isInteger(v)&&v>0&&v<=1e6,nonNeg=v=>Number.isFinite(v)&&v>=0;
 // Tiles covering rect inside a width x height surface (same semantics as the legacy sparseTileList).
 function tiles(rect,width,height,tileSize){
  if(!rect||![rect.x,rect.y,rect.w,rect.h].every(Number.isFinite))throw new TypeError('Invalid tile rect');
  if(!posInt(width)||!posInt(height)||!posInt(tileSize))throw new TypeError('Invalid tile surface');
  const s=tileSize,out=[],x0=Math.max(0,Math.floor(rect.x/s)*s),y0=Math.max(0,Math.floor(rect.y/s)*s),x1=Math.min(width,rect.x+rect.w),y1=Math.min(height,rect.y+rect.h);
  for(let y=y0;y<y1;y+=s)for(let x=x0;x<x1;x+=s)out.push({k:x+':'+y,x,y,w:Math.min(s,width-x),h:Math.min(s,height-y)});
  return out;
 }
 const tileKey=k=>typeof k==='string'&&/^\d+:\d+$/.test(k);
 function normaliseResource(r){
  if(!r||typeof r!=='object')throw new TypeError('Invalid resource record');
  if(r.kind!=='raster'&&r.kind!=='mask'&&r.kind!=='image')throw new TypeError('Unknown resource kind');
  if(!posInt(r.width)||!posInt(r.height))throw new TypeError('Invalid resource size');
  if(r.storage!=='dense'&&r.storage!=='sparse')throw new TypeError('Invalid resource storage');
  if(r.tileSize!==null&&!posInt(r.tileSize))throw new TypeError('Invalid tile size');
  if(!nonNeg(r.bytes))throw new TypeError('Invalid resource bytes');
  return Object.freeze({kind:r.kind,width:r.width,height:r.height,storage:r.storage,tileSize:r.tileSize??null,bytes:r.bytes});
 }
 function normaliseSnapshot(s){
  if(!s||typeof s!=='object')throw new TypeError('Invalid snapshot record');
  if(!validResource(s.resource))throw new TypeError('Invalid snapshot resource');
  const kind=s.kind??'tiles';if(!nonNeg(s.bytes))throw new TypeError('Invalid snapshot bytes');
  if(kind==='tiles'){if(!Array.isArray(s.keys)||!s.keys.every(tileKey)||new Set(s.keys).size!==s.keys.length)throw new TypeError('Invalid snapshot keys');return Object.freeze({resource:s.resource,kind,keys:Object.freeze([...s.keys]),bytes:s.bytes})}
  if(kind==='region'){const r=s.rect;if(!r||![r.x,r.y].every(Number.isInteger)||!posInt(r.w)||!posInt(r.h))throw new TypeError('Invalid snapshot rect');return Object.freeze({resource:s.resource,kind,rect:Object.freeze({x:r.x,y:r.y,w:r.w,h:r.h}),bytes:s.bytes})}
  if(kind==='surface'){if(s.storage!=='dense'&&s.storage!=='sparse')throw new TypeError('Invalid snapshot storage');if(!posInt(s.width)||!posInt(s.height))throw new TypeError('Invalid snapshot size');return Object.freeze({resource:s.resource,kind,storage:s.storage,width:s.width,height:s.height,bytes:s.bytes})}
  throw new TypeError('Unknown snapshot kind');
 }
 function createLedger(){
  const resources=new Map(),snapshots=new Map();
  function register(id,record){if(!validResource(id))throw new TypeError('Invalid resource ID');if(resources.has(id))throw new Error('Resource already registered');resources.set(id,normaliseResource(record));return resources.get(id)}
  function update(id,patch){const cur=resources.get(id);if(!cur)throw new Error('Unknown resource');const next=normaliseResource({...cur,...patch});resources.set(id,next);return next}
  // Releasing a resource also drops its snapshots unless keepSnapshots (v262: a GC'd node's history is unreachable too).
  function release(id,{keepSnapshots=false}={}){resources.delete(id);if(!keepSnapshots)for(const [k,s] of snapshots)if(s.resource===id)snapshots.delete(k)}
  function addSnapshot(id,record){if(!validSnapshot(id))throw new TypeError('Invalid snapshot ID');if(snapshots.has(id))throw new Error('Snapshot already registered');snapshots.set(id,normaliseSnapshot(record));return snapshots.get(id)}
  function updateSnapshot(id,patch){const cur=snapshots.get(id);if(!cur)throw new Error('Unknown snapshot');const next=normaliseSnapshot({...cur,...patch});snapshots.set(id,next);return next}
  function dropSnapshot(id){snapshots.delete(id)}
  function totals(){let rb=0,sb=0;for(const r of resources.values())rb+=r.bytes;for(const s of snapshots.values())sb+=s.bytes;return {resources:resources.size,resourceBytes:rb,snapshots:snapshots.size,snapshotBytes:sb}}
  // Snapshots may outlive a released resource (history keeps them); report, don't reject.
  function verify(){const issues=[];for(const [id,s] of snapshots)if(!resources.has(s.resource))issues.push({snapshot:id,issue:'snapshot-of-released-resource'});return issues}
  const toJSON=()=>({resources:Object.fromEntries(resources),snapshots:Object.fromEntries(snapshots)});
  return Object.freeze({register,update,release,get:id=>resources.get(id)||null,has:id=>resources.has(id),addSnapshot,updateSnapshot,dropSnapshot,snapshot:id=>snapshots.get(id)||null,totals,verify,toJSON});
 }
 return Object.freeze({validResource,validSnapshot,allocateResourceId:allocator('res_'),allocateSnapshotId:allocator('snap_'),allocator,tiles,createLedger,normaliseResource,normaliseSnapshot});
})();
if(typeof module!=='undefined'&&module.exports)module.exports=BungalowResources;
