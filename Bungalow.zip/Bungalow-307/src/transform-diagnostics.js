// Debug-only, bounded transform telemetry. Timings measure CPU/submission, not GPU completion.
const TransformDebug=(()=>{const stats={},events=[],last=new Map();return {
 record(kind,data={},ms=0){if(!debugMode)return;const now=performance.now(),row=stats[kind]||(stats[kind]={count:0,totalMs:0,maxMs:0});row.count++;row.totalMs+=ms;row.maxMs=Math.max(row.maxMs,ms);const event={kind,ms:+ms.toFixed(3),...data};events.push(event);if(events.length>60)events.shift();if(now-(last.get(kind)??-Infinity)>2000){last.set(kind,now);logMessage('debug','Transform',event)}},
 snapshot:(includeEvents=true)=>({timingNote:'CPU wall/submission time; no GPU completion measurement',stats:structuredClone(stats),...(includeEvents?{events:structuredClone(events)}:{})}),
 clear(){for(const key of Object.keys(stats))delete stats[key];events.length=0;last.clear()}
};})();
