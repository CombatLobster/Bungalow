
/* ====== Build 185: shared clipboard (other tabs, pasted images) · merge, group and clear act on artboards · hidden boards never overlap ====== */
const ARTBOARD_CLIP='BUNGALOW-ARTBOARDS:';
// ---------- artboard groups: boards that are selected, moved, copied and deleted together ----------
{const base=selectedBoardList;selectedBoardList=function(){const list=base.apply(this,arguments),groups=new Set(list.map(b=>b.group).filter(Boolean));return groups.size?artboards.filter(b=>list.includes(b)||groups.has(b.group)):list}}
function setBoardGroups(boards,values){
 commitBoardProperty(boards,'group',values.map(v=>v||null),()=>{renderArtboards();syncArtboardUi();updateArtboardWorkspace()});
}
function groupArtboards(){
 if(!artboardReady())return;const boards=selectedBoardList().filter(b=>!b.locked);
 if(boards.length<2){toast(selectedBoardList().some(b=>b.locked)?'Unlock the artboards first':'Select two or more artboards to group');return}
 const id=crypto.randomUUID();setBoardGroups(boards,boards.map(()=>id));uiNotice(boards.length+' artboards grouped');
}
function ungroupArtboards(){
 if(!artboardReady())return;const boards=selectedBoardList().filter(b=>b.group);if(!boards.length){toast('The selected artboards are not grouped');return}
 setBoardGroups(boards,boards.map(()=>undefined));uiNotice('Artboards ungrouped');
}
// ---------- merge: the selected artboards become one flattened artboard ----------
function removeBoardsNow(boards){deleteBoardResources(boards)}
function mergeSelectedArtboards(){
 if(!artboardReady())return;stashActiveArtboard();
 const boards=selectedBoardList().filter(b=>b.visible!==false&&!b.locked);if(boards.length<2){toast(selectedBoardList().some(b=>b.locked)?'Unlock the artboards first':'Select two or more artboards to merge');return}
 const rects=boards.map(artboardRect),U=artboardSelectionBounds(rects),W=Math.round(U.width),H=Math.round(U.height);
 if(W>8192||H>8192||W*H>33554432){toast('The merged artboard would be too large (8192 px per side, 32 million pixels)');return}
 if(memoryBudgetExceeded(memoryUsage().total+W*H*8)){toast('Merging exceeds the configured memory budget');return}
 const out=document.createElement('canvas');out.width=W;out.height=H;const g=out.getContext('2d');
 try{for(const b of boards){const r=artboardRect(b);g.drawImage(Frame3D.boardImage(b),Math.round(r.x-U.x),Math.round(r.y-U.y))}}catch(error){toast('Could not merge: '+error.message);return}
 const dpi=boards[0].state.dpi||documentDPI;let ok=false;
 groupedHistory(()=>{
  if(!createArtboard({width:W,height:H,dpi,white:false,x:Math.round(U.x),y:Math.round(U.y),fit:false,name:copyName('Merged',artboards.map(b=>b.name),'copy').replace(/ copy( \d+)?$/,m=>m.replace(' copy',''))}))return;
  installInitialLayerImage(AL,out);AL.name='Merged';applyL(AL);thumb(AL);renderLayers();removeBoardsNow(boards);ok=true;
 });
 if(ok)uiNotice(boards.length+' artboards merged');
}
// ---------- clear: the selected artboards become empty ----------
function blankStateFor(board){const old=board.state,cv=document.createElement('canvas');cv.width=old.width;cv.height=old.height;const L=newLayer('Layer 1',cv);return {...old,layers:[L],groups:[],active:L,selected:new Set([L]),anchor:L,selection:null,isolation:null,lcount:1,groupCount:0,thumbnailsReady:false}}
function swapBoardStates(pairs){
 stashActiveArtboard();const activeId=activeArtboardId;
 for(const {board,state} of pairs){board.state=state;board._previewCheck=true}
 const active=pairs.find(p=>p.board.id===activeId);if(active)ArtboardWorkspace.restore(active.board,artboardSharedView(active.board.id),true);
 artboardRevision++;renderArtboards();updateArtboardWorkspace();window.ArtboardLinks?.watch();window.ArtboardLinks?.flush(false,true);queueNativeSparseAdoption();refreshLayerMasks();updateStatus();
}
async function clearSelectedArtboards(){
 if(!artboardReady())return;stashActiveArtboard();
 const boards=selectedBoardList().filter(b=>!b.locked);if(!boards.length){toast(selectedBoardList().length?'Unlock the artboard first':'No artboard selected');return}
 const filled=[];for(const b of boards)if(!await boardIsEmpty(b))filled.push(b);
 if(filled.length&&!await showConfirm('Clear '+(boards.length===1?'“'+boards[0].name+'”':boards.length+' artboards')+'?\nUndo brings the artwork back.'))return;
 if(!artboardReady())return;stashActiveArtboard();
 const olds=boards.map(b=>({board:b,state:b.state})),news=boards.map(b=>({board:b,state:blankStateFor(b)}));
 swapBoardStates(news);
 doH({workspace:true,get bytes(){return olds.reduce((n,p)=>n+artboardLayerBytes(p.state.layers),0)},undo:()=>swapBoardStates(olds),redo:()=>swapBoardStates(news)});
 uiNotice(boards.length===1?'“'+boards[0].name+'” cleared':boards.length+' artboards cleared');
}
// ---------- hidden boards: bringing one back never leaves it on top of another ----------
{const base=toggleArtboardVisibility;toggleArtboardVisibility=function(id){
  const boards=id?artboards.filter(b=>b.id===id):selectedBoardList(),wasHidden=new Set(boards.filter(b=>b.visible===false).map(b=>b.id));let moved=[];
  groupedHistory(()=>{
   base.apply(this,arguments);
   const shown=boards.filter(b=>wasHidden.has(b.id)&&b.visible!==false);if(!shown.length)return;
   const recs=shown.map(artboardRect);if(!overlapsOthers(recs))return;
   const gap=Math.max(0,Math.round(+$('artboardSnapGap')?.value||0)),others=otherBoardRects(shown.map(b=>b.id)),right=Math.max(...others.map(r=>r.x+r.width))+gap,x0=Math.min(...recs.map(r=>r.x)),y0=Math.min(...recs.map(r=>r.y)),bottom=Math.max(...others.map(r=>r.y+r.height))+gap;
   const cand=[[right-x0,0],[0,bottom-y0],[right-x0,bottom-y0]].map(([dx,dy])=>recs.map(r=>({...r,x:r.x+dx,y:r.y+dy}))).find(c=>!overlapsOthers(c));
   if(cand&&moveBoards(cand))moved=shown;
  });
  if(moved.length)uiNotice(moved.length===1?'“'+moved[0].name+'” moved to free space':moved.length+' artboards moved to free space');
 }}
// ---------- the clipboard: copies travel as documents, pasted images become artboards ----------
async function encodeStateAsBung(state,name){
 projectSaveSerial++;const sink=projectSink(),meta=await encodeDocumentState(state,name,null,sink);meta.meta={...newDocumentMeta(),title:name};
 Object.defineProperty(meta,'__tiles',{value:{dataLength:sink.offset},configurable:true});validateProject(meta);pruneProjectTileCache();SourceLayers.pack(meta);
 const json=new TextEncoder().encode(JSON.stringify(meta)),head=new Uint8Array(16);head.set(BUNG2_MAGIC);new DataView(head.buffer).setUint32(12,json.length,true);
 return new Blob([head,json,...sink.parts],{type:'application/octet-stream'});
}
const blobToBase64=async blob=>{const buf=new Uint8Array(await blob.arrayBuffer());let bin='';for(let i=0;i<buf.length;i+=0x8000)bin+=String.fromCharCode(...buf.subarray(i,i+0x8000));return btoa(bin)};
async function copyArtboards(cut=false){
 if(!artboardReady())return;stashActiveArtboard();
 const boards=boardsForAction();if(!boards.length){toast('No artboard selected');return}
 if(memoryBudgetExceeded(memoryUsage().total+boards.reduce((n,b)=>n+artboardLayerBytes(b.state.layers),0))){toast('Copying exceeds the configured memory budget');return}
 // The copy is ready as soon as the boards are cloned. Turning them into documents for other tabs happens afterwards, in the
 // background, from the clone; the system clipboard write starts now (inside the gesture) and is filled in when that finishes.
 const token=crypto.randomUUID();let ready;const itemsP=new Promise(r=>ready=r);
 const portableP=itemsP.then(async items=>{
  const parts=[];let size=0;
  for(const it of items){const blob=await encodeStateAsBung(it.state,it.name),data=await blobToBase64(blob);size+=data.length;if(size>48e6)throw Error('too large');parts.push({name:it.name,x:it.x,y:it.y,width:it.width,height:it.height,bung:data})}
  return ARTBOARD_CLIP+token+'\n'+JSON.stringify({items:parts});
 }).catch(()=>null);
 const textP=portableP.then(txt=>txt||'BUNGALOW-LOCAL:'+token);
 try{if(window.ClipboardItem&&navigator.clipboard?.write)navigator.clipboard.write([new ClipboardItem({'text/plain':textP.then(t=>new Blob([t],{type:'text/plain'}))})]).catch(()=>{});else textP.then(t=>navigator.clipboard?.writeText(t)).catch(()=>{})}catch(_){}
 setProjectBusy(true,'Copying '+(boards.length===1?'artboard':boards.length+' artboards')+'…');
 try{
  const items=[];for(const b of boards)items.push({name:b.name,x:b.x,y:b.y,group:b.group,...boardSize(b),state:await ArtboardWorkspace.clone(b)});
  artboardClipboard={items,cut,token,pending:true};ready(items);
  portableP.then(txt=>{if(artboardClipboard?.token===token)artboardClipboard.pending=false;if(!txt)uiNotice('Too large to share with other tabs; still pastes here')});
  uiNotice((cut?'Cut ':'Copied ')+(boards.length===1?'“'+boards[0].name+'”':boards.length+' artboards'));
 }catch(error){ready([]);toast('Could not copy: '+error.message);return}finally{setProjectBusy(false)}
 if(cut)await deleteSelectedArtboards({prompt:false});
}
async function pasteImagesAsArtboards(blobs){
 if(!artboardReady())return;const images=[];
 for(const [i,blob] of blobs.entries()){try{const file=blob instanceof File?blob:new File([blob],'Pasted image '+(i+1)+'.png',{type:blob.type||'image/png'});const img=await decodeFileLayerSource(file),w=img.naturalWidth||img.width,h=img.naturalHeight||img.height;if(!(w>=1&&h>=1&&w<=8192&&h<=8192&&w*h<=33554432)){toast('That image is too large for an artboard (8192 px per side)');continue}images.push({img,w,h,name:(file.name.replace(/\.[^.]+$/,'')||'Pasted image').slice(0,80)})}catch(error){toast('Could not read the pasted image: '+error.message)}}
 if(!images.length)return;if(artboards.length+images.length>64){toast('A project supports up to 64 artboards');return}
 const gap=Math.max(0,Math.round(+$('artboardSnapGap')?.value||0)),all=artboards.filter(b=>b.visible!==false).map(artboardRect);let x=all.length?Math.max(...all.map(r=>r.x+r.width))+gap:0;const y=all.length?Math.min(...all.map(r=>r.y)):0,ids=[];
 groupedHistory(()=>{for(const it of images){if(!createArtboard({width:it.w,height:it.h,white:false,x,y,fit:false,name:it.name}))break;installInitialLayerImage(AL,it.img);AL.name=it.name;applyL(AL);thumb(AL);renderLayers();ids.push(activeArtboardId);x+=it.w+gap}});
 if(ids.length){commitBoards({selected:[...(ids)]});renderArtboards();fitArtboardWorkspace();drawArtboardHandles();uiNotice(ids.length===1?'Image pasted as an artboard':ids.length+' images pasted as artboards')}
}
function readClipboardPayload(e){
 const out={text:'',images:[]};const cd=e?.clipboardData;if(!cd)return out;
 try{out.text=cd.getData('text/plain')||''}catch(_){}
 out.images=[...(cd.items||[])].filter(i=>i.kind==='file'&&i.type.startsWith('image/')).map(i=>i.getAsFile()).filter(Boolean);return out;
}
async function pasteArtboards(payload=null){
 if(!artboardReady())return;
 if(artboardClipboard?.pending&&!payload?.text?.startsWith(ARTBOARD_CLIP)){await addBoardCopies(artboardClipboard.items,'Pasting');return}   // the other-tab copy is still being prepared; this tab already has the boards
 let text=payload?.text||'',images=payload?.images||[];
 if(!payload&&navigator.clipboard?.read){try{for(const item of await navigator.clipboard.read()){if(item.types.includes('text/plain'))text=await (await item.getType('text/plain')).text();const type=item.types.find(t=>t.startsWith('image/'));if(type)images.push(await item.getType(type))}}catch(_){}}
 if(text.startsWith(ARTBOARD_CLIP)){
  const nl=text.indexOf('\n'),token=text.slice(ARTBOARD_CLIP.length,nl);
  if(artboardClipboard?.token===token){await addBoardCopies(artboardClipboard.items,'Pasting');return}
  try{const {items}=JSON.parse(text.slice(nl+1)),files=items.map(i=>{const bin=atob(i.bung),bytes=new Uint8Array(bin.length);for(let k=0;k<bin.length;k++)bytes[k]=bin.charCodeAt(k);return new File([bytes],String(i.name||'Artboard').slice(0,100)+'.bung',{type:'application/octet-stream'})});await placeFilesAsArtboards(files);return}
  catch(error){toast('Could not paste the copied artboards: '+error.message);return}
 }
 if(images.length){await pasteImagesAsArtboards(images);return}
 if(artboardClipboard?.items.length){await addBoardCopies(artboardClipboard.items,'Pasting');return}
 toast('Copy an artboard first');
}

