/* Reference geometry only: DOM events and images remain adapter resources. */
const BungalowReferenceGeometry=(()=>{
function referenceMatrix(r){const m=r.matrix||[1,0,0,1],co=Math.cos(r.angle),si=Math.sin(r.angle);return [co*m[0]-si*m[1],si*m[0]+co*m[1],co*m[2]-si*m[3],si*m[2]+co*m[3]]}
function rescale(records,sx,sy){return records.map(r=>{const m=referenceMatrix(r);return {...r,x:r.x*sx,y:r.y*sy,w:r.w*sx,h:r.h*sy,angle:0,matrix:[m[0],m[1]*sy/sx,m[2]*sx/sy,m[3]]}})}
function drag(start,p,q,{mode,corner='se',shift=false,alt=false}){const r={...start,...(start.matrix?{matrix:start.matrix.slice()}:{})}, {x,y,w,h,angle}=start,cx=x+w/2,cy=y+h/2,startAngle=Math.atan2(p.y-cy,p.x-cx);
if(mode==='move'){r.x=x+q.x-p.x;r.y=y+q.y-p.y}else if(mode==='rotate'){let a=angle+Math.atan2(q.y-cy,q.x-cx)-startAngle;r.angle=shift?Math.round(a/(Math.PI/12))*Math.PI/12:a}else{const dx=q.x-p.x,dy=q.y-p.y;const matrix=referenceMatrix({...r,angle}),sx=corner.includes('w')?-1:1,sy=corner.includes('n')?-1:1,vx=matrix[0]*sx*w+matrix[2]*sy*h,vy=matrix[1]*sx*w+matrix[3]*sy*h;const k=alt?2:1,factor=Math.max(Math.max(1/w,1/h),Math.min(100,1+k*(vx*dx+vy*dy)/(vx*vx+vy*vy)));r.w=w*factor;r.h=h*factor;if(alt){r.x=x-(r.w-w)/2;r.y=y-(r.h-h)/2}else{const dcx=sx*(r.w-w)/2,dcy=sy*(r.h-h)/2;r.x=x+(matrix[0]*dcx+matrix[2]*dcy)-(r.w-w)/2;r.y=y+(matrix[1]*dcx+matrix[3]*dcy)-(r.h-h)/2}}return {x:r.x,y:r.y,w:r.w,h:r.h,angle:r.angle};}
return Object.freeze({matrix:referenceMatrix,rescale,drag});
})();if(typeof module!=='undefined')module.exports=BungalowReferenceGeometry;
