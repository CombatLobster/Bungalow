// Geometry only: source images and pixel buffers are never retained here.
var fileMeshCacheBytes = 0;
const FileMeshCache = (() => {
 const entries = new Map();
 const limit = 8 * 1024 * 1024;
 let hits = 0, misses = 0;

 function clear() {
  entries.clear();
  fileMeshCacheBytes = 0;
  memoryScanKey = null;
 }

 function get(key) {
  const entry = entries.get(key);
  if (!entry) { misses++; return null; }
  hits++;
  // Move the entry to the end of insertion order (most recently used).
  entries.delete(key);
  entries.set(key, entry);
  return entry.mesh;
 }

 function put(key, mesh) {
  const bytes = key.length * 2 + mesh.points.length * 96 + mesh.triangles.length * 64;
  if (bytes > limit) return mesh;
  while (entries.size >= 2 || fileMeshCacheBytes + bytes > limit) {
   const oldest = entries.keys().next().value;
   fileMeshCacheBytes -= entries.get(oldest).bytes;
   entries.delete(oldest);
  }
  entries.set(key, { mesh, bytes });
  fileMeshCacheBytes += bytes;
  memoryScanKey = null;
  return mesh;
 }

 addEventListener('bungalow-document-changed', clear);
 return {
  clear, get, put,
  inspect: () => ({ entries: entries.size, estimatedBytes: fileMeshCacheBytes, hits, misses, limit })
 };
})();
