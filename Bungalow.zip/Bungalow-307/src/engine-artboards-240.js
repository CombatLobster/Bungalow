/* Plain metadata command planning; document resources remain in the adapter. */
const BungalowArtboards=(()=>{
 function snapshot(boards){if(!Array.isArray(boards)||!boards.length)throw Error('Invalid artboards');const ids=new Set();return boards.map(b=>{if(!b||typeof b.id!=='string'||!b.id||ids.has(b.id)||typeof b.name!=='string'||typeof b.visible!=='boolean')throw Error('Invalid artboard');ids.add(b.id);return {id:b.id,name:b.name,visible:b.visible}})}
 function dispatch(boards,request){const before=snapshot(boards);let after=snapshot(before);
 if(request?.type==='rename'){const board=after.find(b=>b.id===request.id);if(!board)throw Error('Missing artboard');const name=String(request.name).trim().slice(0,120);if(name)board.name=name}
 else if(request?.type==='visibility'){if(!Array.isArray(request.ids)||request.ids.some(id=>!after.some(b=>b.id===id)))throw Error('Missing artboard');const chosen=after.filter(b=>request.ids.includes(b.id)),visible=chosen.some(b=>!b.visible);chosen.forEach(b=>b.visible=visible)}
 else if(request?.type==='reorder'){if(!Array.isArray(request.ids)||typeof request.after!=='boolean'||request.ids.some(id=>!after.some(b=>b.id===id))||!after.some(b=>b.id===request.target))throw Error('Invalid artboard move');if(!request.ids.includes(request.target)){const moving=after.filter(b=>request.ids.includes(b.id)),rest=after.filter(b=>!request.ids.includes(b.id)),index=rest.findIndex(b=>b.id===request.target);rest.splice(index+(request.after?1:0),0,...moving);after=rest}}
 else throw Error('Unknown artboard command');
 return {type:request.type,before,after,changed:JSON.stringify(before)!==JSON.stringify(after)};
 }
 return Object.freeze({snapshot,dispatch});
})();
if(typeof module!=='undefined')module.exports=BungalowArtboards;
