/* v285 (stage 7): retained vector layers rendered in the core. A recording 2D context runs the app's own vector painter
 * (withInstance + paintVectorObjects, src/vectors.js) and captures every fill, stroke and clip as a display list:
 * paths are flattened to device space as the canvas does (each point through the transform current when it is added;
 * arcs, ellipses and arcTo become cubic Béziers), strokes carry their transform so widths and dashes stay in user space,
 * gradients carry the transform current at fill time. The core rasterises the list with tiny-skia
 * (native/bungalow-core/src/vector.rs: render_list) into the layer's surface, so in core mode an edited vector layer
 * travels as a few kilobytes of geometry instead of its pixels.
 * Imported SVG shapes are traced from their path data (M L H V C S Q T A Z). Anything the list cannot express (images, conic gradients, patterns, other composite
 * modes, shadows, filters, text) marks the recording unsupported and the caller sends pixels as before. */
var NativeVector=window.NativeVector=(()=>{
 const stats={layers:0,fallbacks:0,reasons:{}};
 let colourCtx=null;
 // CSS colour → [r, g, b, alpha 0..1] using the browser's own parser.
 function parseColour(c){if(!colourCtx){const cv=document.createElement('canvas');cv.width=cv.height=1;colourCtx=cv.getContext('2d',{willReadFrequently:true})}const g=colourCtx;g.clearRect(0,0,1,1);g.fillStyle='#000';g.fillStyle=String(c);g.fillRect(0,0,1,1);const d=g.getImageData(0,0,1,1).data;return [d[0],d[1],d[2],d[3]/255]}
 const mul=(A,B)=>[A[0]*B[0]+A[2]*B[1],A[1]*B[0]+A[3]*B[1],A[0]*B[2]+A[2]*B[3],A[1]*B[2]+A[3]*B[3],A[0]*B[4]+A[2]*B[5]+A[4],A[1]*B[4]+A[3]*B[5]+A[5]];
 const inv=M=>{const det=M[0]*M[3]-M[1]*M[2];if(!det)return null;const a=M[3]/det,b=-M[1]/det,c=-M[2]/det,d=M[0]/det;return [a,b,c,d,-(a*M[4]+c*M[5]),-(b*M[4]+d*M[5])]};
 const ap=(M,x,y)=>[M[0]*x+M[2]*y+M[4],M[1]*x+M[3]*y+M[5]];
 const TAU=Math.PI*2;
 // SVG path data → calls on a path sink {M(x,y), L(x,y), C(...6), Z()} in the coordinates of matrix T (imported shapes).
 function traceSvg(d,T,sink){
  const tok=String(d).match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g)||[];let i=0,cmd='',x=0,y=0,sx=0,sy=0,cx=0,cy=0,qx=0,qy=0,prev='';
  const num=()=>{const t=tok[i];if(t===undefined||/[a-zA-Z]/.test(t))throw Error('bad path');i++;return +t};const flag=()=>{let t=tok[i];if(t===undefined)throw Error('bad path');if(/^[01]\d/.test(t)){tok.splice(i,1,t[0],t.slice(1));t=tok[i]}i++;return +t?1:0};
  const P=(px,py)=>ap(T,px,py);const M=(px,py)=>sink.M(...P(px,py)),L=(px,py)=>sink.L(...P(px,py)),C=(a,b,c,e,f,g)=>sink.C(...P(a,b),...P(c,e),...P(f,g));
  const arc=(x1,y1,rx,ry,phi,fa,fs,x2,y2)=>{if(!rx||!ry){L(x2,y2);return}rx=Math.abs(rx);ry=Math.abs(ry);const c=Math.cos(phi),s=Math.sin(phi),dx=(x1-x2)/2,dy=(y1-y2)/2,x1p=c*dx+s*dy,y1p=-s*dx+c*dy;let lam=x1p*x1p/(rx*rx)+y1p*y1p/(ry*ry);if(lam>1){rx*=Math.sqrt(lam);ry*=Math.sqrt(lam)}
   const num2=rx*rx*ry*ry-rx*rx*y1p*y1p-ry*ry*x1p*x1p,den=rx*rx*y1p*y1p+ry*ry*x1p*x1p,co=(fa===fs?-1:1)*Math.sqrt(Math.max(0,num2/den)),cxp=co*rx*y1p/ry,cyp=-co*ry*x1p/rx,ccx=c*cxp-s*cyp+(x1+x2)/2,ccy=s*cxp+c*cyp+(y1+y2)/2;
   const ang=(ux,uy,vx,vy)=>{const a=Math.atan2(ux*vy-uy*vx,ux*vx+uy*vy);return a};let t1=ang(1,0,(x1p-cxp)/rx,(y1p-cyp)/ry),dt=ang((x1p-cxp)/rx,(y1p-cyp)/ry,(-x1p-cxp)/rx,(-y1p-cyp)/ry);if(!fs&&dt>0)dt-=TAU;else if(fs&&dt<0)dt+=TAU;
   const n=Math.max(1,Math.ceil(Math.abs(dt)/(Math.PI/2)-1e-9)),st=dt/n,k=4/3*Math.tan(st/4),pt=a=>[ccx+rx*Math.cos(a)*c-ry*Math.sin(a)*s,ccy+rx*Math.cos(a)*s+ry*Math.sin(a)*c],dv=a=>[-rx*Math.sin(a)*c-ry*Math.cos(a)*s,-rx*Math.sin(a)*s+ry*Math.cos(a)*c];
   for(let j=0;j<n;j++){const a0=t1+st*j,a1=a0+st,p0=pt(a0),p1=pt(a1),d0=dv(a0),d1=dv(a1);C(p0[0]+d0[0]*k,p0[1]+d0[1]*k,p1[0]-d1[0]*k,p1[1]-d1[1]*k,p1[0],p1[1])}};
  while(i<tok.length){if(/[a-zA-Z]/.test(tok[i]))cmd=tok[i++];else if(!cmd)throw Error('bad path');const rel=cmd===cmd.toLowerCase(),C0=cmd.toUpperCase(),ox=rel?x:0,oy=rel?y:0;
   switch(C0){
    case 'M':{x=ox+num();y=oy+num();sx=x;sy=y;M(x,y);cmd=rel?'l':'L';break}
    case 'L':{x=ox+num();y=oy+num();L(x,y);break}case 'H':{x=ox+num();L(x,y);break}case 'V':{y=oy+num();L(x,y);break}
    case 'C':{const a=ox+num(),b=oy+num();cx=ox+num();cy=oy+num();x=ox+num();y=oy+num();C(a,b,cx,cy,x,y);break}
    case 'S':{const a=/[CS]/.test(prev)?2*x-cx:x,b=/[CS]/.test(prev)?2*y-cy:y;cx=ox+num();cy=oy+num();const ex=ox+num(),ey=oy+num();C(a,b,cx,cy,ex,ey);x=ex;y=ey;break}
    case 'Q':{qx=ox+num();qy=oy+num();const ex=ox+num(),ey=oy+num();C(x+2/3*(qx-x),y+2/3*(qy-y),ex+2/3*(qx-ex),ey+2/3*(qy-ey),ex,ey);x=ex;y=ey;break}
    case 'T':{if(/[QT]/.test(prev)){qx=2*x-qx;qy=2*y-qy}else{qx=x;qy=y}const ex=ox+num(),ey=oy+num();C(x+2/3*(qx-x),y+2/3*(qy-y),ex+2/3*(qx-ex),ey+2/3*(qy-ey),ex,ey);x=ex;y=ey;break}
    case 'A':{const rx=num(),ry=num(),ph=num()*Math.PI/180,fa=flag(),fs=flag(),ex=ox+num(),ey=oy+num();arc(x,y,rx,ry,ph,fa,fs,ex,ey);x=ex;y=ey;break}
    case 'Z':{sink.Z();x=sx;y=sy;break}
    default:throw Error('bad path')}
   prev=C0}
 }
 // Recording context. `W`, `H`: surface size.
 function recorder(W,H){
  let M=[1,0,0,1,0,0],path=[],cur=null,start=null,clip=null,unsupported=null;const stack=[],draws=[],clips=[];
  const nope=r=>{if(!unsupported)unsupported=r};
  const P={fillStyle:'#000',strokeStyle:'#000',lineWidth:1,lineCap:'butt',lineJoin:'miter',miterLimit:10,globalAlpha:1,globalCompositeOperation:'source-over',lineDashOffset:0,shadowBlur:0,shadowColor:'rgba(0,0,0,0)',shadowOffsetX:0,shadowOffsetY:0,filter:'none',imageSmoothingEnabled:true,imageSmoothingQuality:'low',font:'10px sans-serif',textAlign:'start',textBaseline:'alphabetic'};
  let dash=[];
  const moveU=(x,y)=>{const p=ap(M,x,y);path.push(0,p[0],p[1]);cur=[x,y];start=[x,y]};
  const lineU=(x,y)=>{if(!cur){moveU(x,y);return}const p=ap(M,x,y);path.push(1,p[0],p[1]);cur=[x,y]};
  const cubicU=(a,b,c,d,x,y)=>{if(!cur)moveU(a,b);const p1=ap(M,a,b),p2=ap(M,c,d),p=ap(M,x,y);path.push(4,p1[0],p1[1],p2[0],p2[1],p[0],p[1]);cur=[x,y]};
  // Elliptical arc as cubics (canvas sweep rules), joined to the current point with a line.
  function arcU(cx,cy,rx,ry,rot,a0,a1,ccw){
   if(rx<0||ry<0)throw new DOMException('negative radius','IndexSizeError');
   let sweep=a1-a0;if(!ccw){if(sweep>=TAU)sweep=TAU;else{sweep%=TAU;if(sweep<0)sweep+=TAU}}else{if(-sweep>=TAU)sweep=-TAU;else{sweep%=TAU;if(sweep>0)sweep-=TAU}}
   const cr=Math.cos(rot),sr=Math.sin(rot),pt=a=>{const x=rx*Math.cos(a),y=ry*Math.sin(a);return [cx+x*cr-y*sr,cy+x*sr+y*cr]},dv=a=>{const x=-rx*Math.sin(a),y=ry*Math.cos(a);return [x*cr-y*sr,x*sr+y*cr]};
   const p0=pt(a0);if(cur)lineU(p0[0],p0[1]);else moveU(p0[0],p0[1]);if(!sweep)return;
   const n=Math.max(1,Math.ceil(Math.abs(sweep)/(Math.PI/2)-1e-9)),step=sweep/n,k=4/3*Math.tan(step/4);
   for(let i=0;i<n;i++){const s=a0+step*i,e=a0+step*(i+1),ps=pt(s),pe=pt(e),ds=dv(s),de=dv(e);cubicU(ps[0]+ds[0]*k,ps[1]+ds[1]*k,pe[0]-de[0]*k,pe[1]-de[1]*k,pe[0],pe[1])}
  }
  const paintOf=style=>{if(typeof style==='string'){const c=parseColour(style);return {c}}if(style&&style.__rec)return style.ok?{g:{t:style.t,v:style.v,s:style.stops.slice().sort((a,b)=>a[0]-b[0])}}:(nope('gradient '+style.why),null);nope('pattern');return null};
  const common=()=>{if(rec.shadowBlur||rec.shadowOffsetX||rec.shadowOffsetY)if(parseColour(rec.shadowColor)[3]>0)nope('shadow');if(rec.filter&&rec.filter!=='none')nope('filter');const op=rec.globalCompositeOperation;if(op!=='source-over'&&op!=='destination-out')nope('composite '+op);return op==='destination-out'?'d':undefined};
  const devPath=()=>path.slice();
  // A recorded imported path ({__svg: d, T}): device-space ops through the current transform.
  const svgOps=o=>{const ops=[];const D=mul(M,o.T);traceSvg(o.__svg,D,{M:(x,y)=>ops.push(0,x,y),L:(x,y)=>ops.push(1,x,y),C:(a,b,c,d,e,f)=>ops.push(4,a,b,c,d,e,f),Z:()=>ops.push(2)});return ops};
  const geometry=a=>{if(a&&a.__svg!==undefined){try{return svgOps(a)}catch(e){nope('svg path');return null}}if(a&&typeof a==='object'){nope('Path2D');return null}return devPath()};
  const toUser=(ops,N)=>{const out=[];for(let i=0;i<ops.length;){const o=ops[i];if(o===2){out.push(2);i++;continue}const n=o===4?3:1;out.push(o);for(let j=0;j<n;j++){const p=ap(N,ops[i+1+j*2],ops[i+2+j*2]);out.push(p[0],p[1])}i+=1+n*2}return out};
  const rec={...P,__recorder:true,canvas:{width:W,height:H},
   save(){stack.push({M:M.slice(),clip,dash:dash.slice(),props:Object.fromEntries(Object.keys(P).map(k=>[k,rec[k]]))})},
   restore(){const s=stack.pop();if(!s)return;M=s.M;clip=s.clip;dash=s.dash;Object.assign(rec,s.props)},
   setTransform(a,b,c,d,e,f){if(a&&typeof a==='object')M=[a.a,a.b,a.c,a.d,a.e,a.f];else M=[a,b,c,d,e,f]},resetTransform(){M=[1,0,0,1,0,0]},
   transform(a,b,c,d,e,f){M=mul(M,[a,b,c,d,e,f])},translate(x,y){M=mul(M,[1,0,0,1,x,y])},scale(x,y){M=mul(M,[x,0,0,y,0,0])},rotate(r){const c=Math.cos(r),s=Math.sin(r);M=mul(M,[c,s,-s,c,0,0])},
   getTransform(){return new DOMMatrix(M)},
   beginPath(){path=[];cur=null;start=null},moveTo:moveU,lineTo:lineU,
   closePath(){if(!cur)return;path.push(2);cur=start?start.slice():null},
   bezierCurveTo:cubicU,
   quadraticCurveTo(cx,cy,x,y){if(!cur)moveU(cx,cy);const [x0,y0]=cur;cubicU(x0+2/3*(cx-x0),y0+2/3*(cy-y0),x+2/3*(cx-x),y+2/3*(cy-y),x,y)},
   arc(x,y,r,a0,a1,ccw=false){arcU(x,y,r,r,0,a0,a1,ccw)},ellipse(x,y,rx,ry,rot,a0,a1,ccw=false){arcU(x,y,rx,ry,rot,a0,a1,ccw)},
   arcTo(x1,y1,x2,y2,r){if(!cur){moveU(x1,y1);return}const [x0,y0]=cur,v1=[x0-x1,y0-y1],v2=[x2-x1,y2-y1],l1=Math.hypot(...v1),l2=Math.hypot(...v2),cross=v1[0]*v2[1]-v1[1]*v2[0];
    if(!r||!l1||!l2||Math.abs(cross)<1e-12){lineU(x1,y1);return}
    const ang=Math.acos(Math.max(-1,Math.min(1,(v1[0]*v2[0]+v1[1]*v2[1])/(l1*l2)))),t=r/Math.tan(ang/2),u1=[v1[0]/l1,v1[1]/l1],u2=[v2[0]/l2,v2[1]/l2],p1=[x1+u1[0]*t,y1+u1[1]*t],p2=[x1+u2[0]*t,y1+u2[1]*t];
    const bis=[u1[0]+u2[0],u1[1]+u2[1]],bl=Math.hypot(...bis),dist=r/Math.sin(ang/2),c=[x1+bis[0]/bl*dist,y1+bis[1]/bl*dist];
    const a0=Math.atan2(p1[1]-c[1],p1[0]-c[0]),a1=Math.atan2(p2[1]-c[1],p2[0]-c[0]);lineU(p1[0],p1[1]);arcU(c[0],c[1],r,r,0,a0,a1,cross>0)},
   rect(x,y,w,h){moveU(x,y);lineU(x+w,y);lineU(x+w,y+h);lineU(x,y+h);path.push(2);cur=[x,y];start=[x,y]},
   fill(a,b){const geo=geometry(a);const rule=a&&typeof a==='object'?b:a;const paint=paintOf(rec.fillStyle);const o=common();if(!paint||!geo||!geo.length)return;draws.push({k:'f',p:geo,m:[1,0,0,1,0,0],gm:M.slice(),rule:(rule||'nonzero')==='evenodd'?'evenodd':undefined,...paint,a:rec.globalAlpha,o,clip})},
   stroke(a){const geo=geometry(a);const paint=paintOf(rec.strokeStyle);const o=common();if(!paint||!geo||!geo.length||!(rec.lineWidth>0))return;const N=inv(M);if(!N){return}
    draws.push({k:'s',p:toUser(geo,N),m:M.slice(),gm:M.slice(),...paint,a:rec.globalAlpha,o,clip,w:rec.lineWidth,cap:rec.lineCap,join:rec.lineJoin,ml:rec.miterLimit,dash:dash.length?dash.slice():undefined,dof:rec.lineDashOffset||0})},
   clip(a,b){const geo=geometry(a);if(!geo)return;const rule=a&&typeof a==='object'?b:a;const prev=clip===null?[]:clips[clip];clips.push([...prev,{p:geo,m:[1,0,0,1,0,0],rule:rule==='evenodd'?'evenodd':undefined}]);clip=clips.length-1},
   fillRect(x,y,w,h){const sv=[path,cur,start];rec.beginPath();rec.rect(x,y,w,h);rec.fill();[path,cur,start]=sv},
   strokeRect(x,y,w,h){const sv=[path,cur,start];rec.beginPath();rec.rect(x,y,w,h);rec.stroke();[path,cur,start]=sv},
   clearRect(){nope('clearRect')},
   setLineDash(d){dash=Array.isArray(d)&&d.every(v=>Number.isFinite(v)&&v>=0)?d.slice():dash},getLineDash(){return dash.slice()},
   createLinearGradient(x0,y0,x1,y1){const g={__rec:true,ok:true,t:'l',v:[x0,y0,x1,y1],stops:[],addColorStop(t,c){const k=parseColour(c);g.stops.push([t,k[0],k[1],k[2],k[3]])}};if(x0===x1&&y0===y1){g.ok=false;g.why='degenerate'}return g},
   createRadialGradient(x0,y0,r0,x1,y1,r1){const g={__rec:true,ok:r0===0&&x0===x1&&y0===y1&&r1>0,why:'two-point',t:'r',v:[x1,y1,r1],stops:[],addColorStop(t,c){const k=parseColour(c);g.stops.push([t,k[0],k[1],k[2],k[3]])}};return g},
   createConicGradient(){return {__rec:true,ok:false,why:'conic',addColorStop(){}}},createPattern(){nope('pattern');return null},
   drawImage(){nope('drawImage')},putImageData(){nope('putImageData')},getImageData(){nope('getImageData');return new ImageData(1,1)},
   fillText(){nope('text')},strokeText(){nope('text')},measureText(){nope('text');return {width:0}},isPointInPath(){return false},
   result(){return unsupported?{unsupported}:{draws,clips}}};
  return rec;
 }
 // Display list for a retained vector (shape) layer, or {unsupported}.
 function record(L){
  const I=L?.instance;if(!I||I.type!=='shape')return {unsupported:'not a vector layer'};
  if(vectorObjectList(I).some(s=>s.kind==='brushstroke'))return {unsupported:'brush stroke'};
  const P=RasterResources.payload(L.rasterId),W=P?.sparse?.width||P?.canvas?.width||DW,H=P?.sparse?.height||P?.canvas?.height||DH,g=recorder(W,H);
  // Imported SVG shapes build a Path2D (importedPath in vectors.js); while recording they yield the path data and its matrix.
  const real=window.importedPath;window.importedPath=(s,unit=false)=>{const bw=s.bw>1e-6?s.bw:1,bh=s.bh>1e-6?s.bh:1,F=unit?[1/bw,0,0,1/bh,-s.bx/bw,-s.by/bh]:(()=>{const sx=s.bw>1e-6?s.w/s.bw:1,sy=s.bh>1e-6?s.h/s.bh:1;return [sx,0,0,sy,s.x-s.bx*sx,s.y-s.by*sy]})();return {__svg:s.d,T:instMul(F,s.m||[1,0,0,1,0,0])}};
  // Sparse vector layers are painted only inside their computed bounds (drawVectorSparse); the same clip keeps parity.
  try{if(L._sparse){const b=vectorObjectBounds(I);if(!b)return {draws:[],clips:[],w:W,h:H};g.beginPath();g.rect(b.x,b.y,b.w,b.h);g.clip();g.beginPath()}withInstance(g,I,()=>paintVectorObjects(g,I))}catch(e){return {unsupported:'error '+(e?.message||e)}}finally{window.importedPath=real}
  const r=g.result();if(r.unsupported){stats.fallbacks++;stats.reasons[r.unsupported]=(stats.reasons[r.unsupported]||0)+1}else stats.layers++;return {...r,w:W,h:H};
 }
 return {recorder,record,stats:()=>JSON.parse(JSON.stringify(stats))};
})();
