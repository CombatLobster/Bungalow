
/* ====== Build 192: Alt-click a context swatch to switch that channel off or on ====== */
for(const [id,channel] of [['lcFill','fill'],['lcStroke','stroke']])$(id)?.addEventListener('click',e=>{
 if(!e.altKey)return;e.preventDefault();e.stopImmediatePropagation();const sh=AL?.instance?.shape;if(sh&&window.VectorAppearance)VectorAppearance.set(channel,!vectorPaintState(sh)[channel]);
},true);

