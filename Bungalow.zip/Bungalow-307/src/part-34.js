
/* ====== Build 177: layer context area in the top bar · Alt for margins in the Guides tool · unit-agnostic guide and margin pills ====== */
// ---------- 1. unit-agnostic fields: type px, pt, pc, mm, cm, in or % and the value converts ----------
// The Units dropdown chooses how values are shown; a value can be typed in any unit (px, pt, pc, mm, cm, in, %) and is converted to it.
function unitAgnostic(extent=()=>Math.min(DW,DH)){
 const chosen=()=>$('layoutUnit')?.value||'mm',perUnit=u=>u==='percent'?extent()/100:u==='pt'?documentDPI/72:lengthPx(u),DIG={px:2,pt:2,mm:2,cm:3,in:3,percent:2};
 return {
  parse:text=>{const m=/^\s*([+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?)\s*(px|pt|pc|mm|cm|in|"|%|percent)?\s*$/i.exec(String(text));if(!m)return NaN;let u=(m[2]||chosen()).toLowerCase();if(u==='"')u='in';if(u==='%')u='percent';return parseFloat(m[1])*perUnit(u)},
  format:px=>{const u=chosen();return (+(px/perUnit(u)).toFixed(DIG[u]??2))+' '+(u==='percent'?'%':u)},
  unit:chosen,pxToUnit:(px,u)=>px/perUnit(u)
 };
}
const layoutField=unitAgnostic(),bleedField=layoutField,guideField=unitAgnostic(()=>$('guideAxis')?.value==='y'?DH:DW);
const layoutPillRows=[];
function layoutPill(id,label,{get,set,extent,max=100000,tip=''}){
 const F=id==='guide'?guideField:layoutField,row=document.createElement('div');row.className='mod-row layout-row';if(tip)row.title=tip;
 const cap=document.createElement('span');cap.className='desktop-value-label';cap.textContent=label;
 const api=createCompactValueControl({id:'layout_'+id,label,get,set:v=>set(Math.max(0,Math.min(max,v))),min:0,max,step:.001,dragStep:.5,reset:0,digits:3,parse:F.parse,format:F.format});
 api.root.classList.add('desktop-value','length-field');row.append(cap,api.root);layoutPillRows.push({api,row});return {row,api};
}
function layoutPanelSetup(){
 const page=$('layoutPage')||$('assistGuidesControls');if(!page||page.dataset.ready)return;page.dataset.ready='1';
 // margin: one value for every edge; the typed unit is remembered and written back to the existing control
 const marginLabel=$('layoutMargin').closest('label'),unitLabel=$('layoutUnit').closest('label');
 const margin=layoutPill('margin','Margin',{tip:'Inset on every edge of the canvas',get:()=>layoutPixels(canvasCoordinates.layout.margin,canvasCoordinates.layout.unit),
  set:px=>{const u=layoutField.unit(),v=layoutField.pxToUnit(px,u),digits={px:2,pt:2,mm:2,cm:3,in:3,percent:2}[u]??2;const lay=canvasCoordinates.layout;if(lay.unit===u&&Math.abs(lay.margin-+v.toFixed(digits))<1e-3)return;$('layoutUnit').value=u;$('layoutMargin').value=String(+v.toFixed(digits));$('layoutMargin').dispatchEvent(new Event('change',{bubbles:true}))}});
 {const holder=marginLabel.closest('.canvas-dims');holder.before(margin.row);holder.hidden=true}unitLabel.hidden=false;margin.row.before(unitLabel);unitLabel.addEventListener('change',()=>setTimeout(()=>{layoutPanelSync();renderGuideList()},0));   // the original inputs stay in the DOM (hidden): the existing code still reads and writes them
 // bleed: applies as soon as the value is committed
 const bleedUnit=$('bleedUnit').closest('label'),bleedAmount=$('bleedAmount').closest('label');
 const bleed=layoutPill('bleed','All sides',{tip:'Distance from the canvas edge to the trim line on all four sides',max:100000,get:()=>canvasCoordinates.bleed?canvasCoordinates.bleed.left*DW:0,
  set:px=>{const pref=bleedField.unit(),u=['mm','in','px'].includes(pref)?pref:pref==='percent'?'px':'mm';$('bleedUnit').value=u;$('bleedAmount').value=String(+(px/bleedPixelsPerUnit()).toFixed(4));$('bleedApply').click()}});
 bleedAmount.before(bleed.row);bleedAmount.hidden=true;bleedUnit.hidden=true;$('bleedApply').hidden=true;
 // individual guides: orientation + a position that accepts any unit
 const unitSel=$('guideUnit').closest('label');unitSel.hidden=true;$('guidePosition').closest('label').hidden=true;
 const axisExtent=()=>$('guideAxis').value==='x'?DW:DH,pos={px:0};
 const guide=layoutPill('guide','Position',{tip:'Distance from the left edge for vertical guides, or the top edge for horizontal guides',get:()=>pos.px,set:px=>{pos.px=px}});
 guide.api.root.addEventListener('valuecommit',()=>{});$('guideAdd').before(guide.row);
 $('guideAxis').addEventListener('change',()=>layoutPanelSync());
 $('guideAdd').onclick=()=>{const ext=axisExtent(),next=structuredClone(canvasCoordinates);if(!Number.isFinite(pos.px))return;next.guides.push({id:crypto.randomUUID(),axis:$('guideAxis').value,position:pos.px/ext});updateCanvasCoordinates(next)};
 
}
function layoutPanelSync(){for(const r of layoutPillRows)try{r.api.sync()}catch(_){}}
// each guide in the list is a pill too (same units as everywhere)
let guideEditBusy=false;
function renderGuideList(){
 if(guideEditBusy)return;const box=$('guideList');box.replaceChildren();
 canvasCoordinates.guides.forEach(guide=>{
  const row=document.createElement('div');row.className='mod-row guide-row';const cap=document.createElement('span');cap.className='desktop-value-label';cap.textContent=(guide.axis==='x'?'X · ':'Y · ')+(guide.name||(guide.axis==='x'?'Vertical':'Horizontal'));cap.title=cap.textContent;
  const ext=guide.axis==='x'?DW:DH,locked=!!(guide.fixed||guide.locked);
  const api=createCompactValueControl({id:'guide_'+guide.id,label:'Guide position',get:()=>guide.position*ext,set:px=>{const next=structuredClone(canvasCoordinates),g=next.guides.find(g=>g.id===guide.id);if(!g)return;if(Math.abs(g.position-px/ext)<1e-5)return;/* a re-rendered control normalises its value: not an edit */g.position=px/ext;guideEditBusy=true;try{updateCanvasCoordinates(next)}finally{setTimeout(()=>{guideEditBusy=false;renderGuideList()},0)}},min:-ext,max:ext*2,step:.001,dragStep:.5,reset:guide.position*ext,digits:3,parse:t=>unitAgnostic(()=>ext).parse(t),format:px=>unitAgnostic(()=>ext).format(px)});
  api.root.classList.add('desktop-value','length-field');api.root.querySelector('.compact-value-reset')?.setAttribute('hidden','');if(locked){api.input.disabled=true;api.root.title=(guide.fixed?'Fixed trim line':'Locked guide')}
  const del=document.createElement('button');iconButton(del,'close');del.className='mod-icon';del.disabled=locked;del.title=guide.fixed?'Fixed trim line':'Remove this guide';del.setAttribute('aria-label','Remove '+(guide.axis==='x'?'vertical':'horizontal')+' guide');
  del.onclick=()=>{const next=structuredClone(canvasCoordinates);next.guides=next.guides.filter(g=>g.id!==guide.id);updateCanvasCoordinates(next)};
  const line=document.createElement('div');line.className='guide-line';line.append(api.root,del);row.append(cap,line);box.append(row);
 });
 $('guidesClear').disabled=!canvasCoordinates.guides.some(g=>!g.fixed);
}
{const base=syncLayoutControls;syncLayoutControls=function(){const r=base.apply(this,arguments);try{layoutPanelSync()}catch(_){}return r}}
layoutPanelSetup();syncLayoutControls();
// ---------- 2. Guides tool + Alt: place or drag the margin instead of a guide ----------
function marginReadout(text,x,y){let el=$('marginReadout');if(!el){el=document.createElement('div');el.id='marginReadout';document.body.append(el)}el.textContent=text;el.style.left=(x+16)+'px';el.style.top=(y+16)+'px';el.hidden=false}
function assistMarginDown(e,p){
 const before=structuredClone(canvasCoordinates),layout=canvasCoordinates.layout,unit=layout.unit,f=layoutUnitFactor(unit),limit=Math.min(DW,DH)/2-1;
 const setFrom=(q,ev)=>{const inset=Math.max(0,Math.min(Math.min(q.x,DW-q.x,q.y,DH-q.y),limit)),v=inset/f;layout.margin=+(unit==='px'?Math.round(v):v).toFixed(unit==='in'?3:2);layout.visible=true;assistRedraw();marginReadout('Margin '+layout.margin+' '+(unit==='percent'?'%':unit),ev.clientX,ev.clientY)};
 setFrom(p,e);
 assistTrack(e,ev=>setFrom(screenToDoc(ev),ev),ev=>{const el=$('marginReadout');if(el)el.hidden=true;if(ev.type!=='pointerup'){assistRestore(before);return}if(assistCommit(before))uiNotice('Margin '+layout.margin+' '+(unit==='percent'?'%':unit))});
}
// ---------- 3. the layer context area at the right end of the top bar ----------
const layerContext={el:null,sig:''};
function layerContextKind(){
 const L=AL;if(!L)return null;
 if(L.instance?.frame)return 'frame3d';
 if(L.mask&&isModifierKind(L.maskKind))return 'modifier';
 if(L.instance?.type==='shape')return 'vector';
 if(!L.instance)return 'paint';
 return null;
}
function layerContextSetup(){
 const bar=$('bar');if(!bar||layerContext.el)return;
 const g=document.createElement('div');g.className='bar-group layer-context';g.id='layerContext';g.setAttribute('role','group');g.setAttribute('aria-label','Active layer');g.hidden=true;
 const swatch=(id,title)=>{const l=document.createElement('label');l.className='lc-swatch';l.id=id+'Wrap';l.title=title;const i=document.createElement('input');i.type='color';i.id=id;i.setAttribute('aria-label',title);const s=document.createElement('span');s.className='lc-cap';s.textContent=title.split(' ')[0];l.append(i,s);return l};
 const fill=swatch('lcFill','Fill colour'),stroke=swatch('lcStroke','Stroke colour');
 const mod=document.createElement('button');mod.id='lcModifier';mod.type='button';mod.title='Show the modifier panel';mod.setAttribute('aria-label','Show the modifier panel');{const d=BungalowIcons.paths.sliders||PIE_ICON_NEW.sliders;if(d)BungalowIcons.paths.sliders=d}mod.append(BungalowIcons.node('sliders'));mod.onclick=()=>{toggleModifierPanel(true);syncMirrorPanel?.()};
 const frameEdit=document.createElement('button');frameEdit.id='lcEditFrame';frameEdit.type='button';frameEdit.textContent='Edit 3D frame';frameEdit.title='Edit the selected layer’s perspective frame';frameEdit.onclick=()=>window.Frame3D?.edit(AL);
 g.append(fill,stroke,mod,frameEdit);$('mirrortool')&&g.append($('mirrortool'));{const tc=$('toolContext');document.body.append(g);g.classList.add('lc-pill');const place=()=>{const w=tc?tc.offsetWidth:0;g.style.left=(w?tc.offsetLeft+w+8:10)+'px';g.style.top=(tc&&tc.offsetHeight?tc.offsetTop:66)+'px';g.style.minHeight=(tc&&tc.offsetHeight?tc.offsetHeight:46)+'px'};if(tc){new ResizeObserver(place).observe(tc);new MutationObserver(place).observe(tc,{attributes:true,attributeFilter:['class','style','hidden']})}addEventListener('resize',place);place();layerContext.place=place}layerContext.el=g;
 // live colour tweaks go through the vector panel's own inputs, so history, validation and every selected shape behave as there
 const proxy=(inputId,panelId)=>{const input=$(inputId);let live=false;
  input.addEventListener('input',()=>{const p=$(panelId);if(!p)return;live=true;p.value=input.value;p.dispatchEvent(new Event('input',{bubbles:true}))});
  input.addEventListener('change',()=>{const p=$(panelId);if(!p)return;p.value=input.value;p.dispatchEvent(new Event('change',{bubbles:true}));live=false})};
 proxy('lcFill','vectorColour');proxy('lcStroke','vectorStrokeColour');
}
function layerContextUpdate(){
 layerContextSetup();const g=layerContext.el;if(!g)return;
 const kind=layerContextKind(),L=AL,s=L?.instance?.shape,mirrorOn=typeof mirrorDoc!=='undefined'&&!!mirrorDoc.on;
 const showMirror=kind==='paint'||mirrorOn;
 const vec=kind==='vector'&&!!s,line=vec&&s.kind==='line',ps=vec?vectorPaintState(s):{fill:false,stroke:false};
 const showFill=vec&&!line,showStroke=vec,fillOn=showFill&&ps.fill,strokeOn=showStroke&&ps.stroke,hexOr=v=>/^#[0-9a-f]{6}$/i.test(v)?v:'#000000';
 const sig=[kind,!!L?.locked,layerLocked(L),showMirror,showFill,showStroke,fillOn,strokeOn,s?.colour,s?.strokeColour,s?.kind,s?.paint].join('|');
 if(sig===layerContext.sig)return;layerContext.sig=sig;
 $('lcEditFrame').hidden=kind!=='frame3d';$('lcEditFrame').disabled=kind==='frame3d'&&layerLocked(L);
 $('lcFillWrap').hidden=!showFill;$('lcStrokeWrap').hidden=!showStroke;$('lcModifier').hidden=kind!=='modifier';
 $('lcFillWrap').classList.toggle('is-off',showFill&&!fillOn);$('lcStrokeWrap').classList.toggle('is-off',showStroke&&!strokeOn);
 const mt=$('mirrortool');if(mt)mt.hidden=!showMirror;
 if(showFill&&document.activeElement!==$('lcFill'))$('lcFill').value=hexOr(s.colour);
 if(showStroke&&document.activeElement!==$('lcStroke'))$('lcStroke').value=hexOr(line&&s.paint==='fill'&&!s.paintStates?s.colour:s.strokeColour);
 $('lcFillWrap').title='Fill colour'+(showFill&&!fillOn?' · off. Choose a colour to turn it on':'')+(showFill?' · Alt-click toggles':'');
 $('lcStrokeWrap').title=(line?'Line colour':'Stroke colour')+(showStroke&&!strokeOn?' · off. Choose a colour to turn it on':'')+(showStroke?' · Alt-click toggles':'');
 $('lcStrokeWrap').querySelector('.lc-cap').textContent=line?'Line':'Stroke';$('lcFillWrap').querySelector('.lc-cap').textContent='Fill';
 g.hidden=!(vec||kind==='modifier'||kind==='frame3d'||showMirror);
 layerContext.place?.();
}
$('mirrortool')?.addEventListener('click',()=>setTimeout(layerContextUpdate,0));BackgroundTicker.add('layer-context',150,layerContextUpdate);layerContextSetup();layerContextUpdate();
// refresh straight away when the selection or a shape changes (the ticker only catches anything else)
let layerContextQueued=0;const queueLayerContext=()=>{if(!layerContextQueued)layerContextQueued=requestAnimationFrame(()=>{layerContextQueued=0;layerContextUpdate()})};
for(const name of ['renderLayers','drawVectorLayer','relayer']){const base=window[name];if(typeof base==='function')window[name]=function(){const r=base.apply(this,arguments);queueLayerContext();return r}}

