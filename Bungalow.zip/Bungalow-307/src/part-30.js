
/* ====== Build 174: smarter copy names, clones grouped by source, one Open for documents and images ====== */
// "logo" → "logo copy" → "logo copy 2" → "logo copy 3": counts up from the highest existing numbered copy of the same base name.
function layerNameSet(){const set=new Set(layers.map(L=>L.name));if(typeof layerGroups!=='undefined')for(const G of layerGroups)set.add(G.name);return set}
function copyName(name,taken,word='copy'){
 const esc=s=>String(s).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),clean=String(name||'').trim()||'Layer',w=esc(word);
 const m=new RegExp('^(.*?)(?:\\s+'+w+'(?:\\s+\\d+)?)+$','i').exec(clean),base=((m?m[1]:clean).trim())||clean;
 const re=new RegExp('^'+esc(base)+'\\s+'+w+'(?:\\s+(\\d+))?$','i');let max=0;
 for(const n of taken)if(typeof n==='string'){const k=re.exec(n.trim());if(k)max=Math.max(max,k[1]?+k[1]:1)}
 return base+' '+word+(max?' '+(max+1):'');
}
// ---- one undo step for "act on every clone of this source" ----
// v236: grouping is journal-owned and defers pruning until the outer group
// closes, so large batches cannot lose their first actions during construction.
function groupedHistory(action){
 const token=documentHistory.beginGroup();historyGroupDepth++;let complete=false;
 try{action();complete=true}finally{
  historyGroupDepth--;
  if(complete){
   const ids=documentHistory.groupEntries(token),made=ids.map(id=>historyResources.get(id));
   if(made.length>1){
    const entry={workspace:made.some(it=>it.workspace),get bytes(){return made.reduce((n,it)=>n+(it.bytes||0),0)},async undo(){for(const it of [...made].reverse()){if(!it.workspace&&it.artboard&&it.artboard!==activeArtboardId)activateArtboard(it.artboard,true);await it.undo()}},async redo(){for(const it of made){if(!it.workspace&&it.artboard&&it.artboard!==activeArtboardId)activateArtboard(it.artboard,true);await it.redo()}}},scope=historyEntryScope(entry),result=documentHistory.collapseGroup(token,scope);
    entry.workspace=result.scope.workspace;if(result.scope.artboard)entry.artboard=result.scope.artboard;else delete entry.artboard;historyResources.set(result.id,entry);for(const id of result.children)historyResources.delete(id);projectDirty=true;editSerial=(editSerial|0)+1;
   }
  }
  syncHistoryView();if(!historyGroupDepth)trimHistoryBudget();
 }
}
function rasterizeClones(list){groupedHistory(()=>{for(const C of list)if(layers.includes(C)&&C.instance?.type==='clone')rasterizeInstance(C)});renderFileTab?.(true)}
// ---- Open: documents (Bungalow, Krita, Photoshop, OpenRaster) and images, detected by type ----
if($('importOpen'))$('importOpen').onclick=()=>openProject();

