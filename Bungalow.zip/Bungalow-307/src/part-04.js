

/* Gradient engine: colour maths, stop model, presets and a WebGL fill renderer.
   Ported from the Gradient fill tool prototype. Shared by Fill → Gradient and the Gradient modifier. */
(function(global){'use strict';
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const Col={
 s2l:c=>c<=0.04045?c/12.92:((c+0.055)/1.055)**2.4,
 l2s:c=>c<=0.0031308?c*12.92:1.055*c**(1/2.4)-0.055,
 enc(c,space){const [r,g,b,a]=c;if(space==='srgb')return [r,g,b,a];const lr=Col.s2l(r),lg=Col.s2l(g),lb=Col.s2l(b);if(space==='linear')return [lr,lg,lb,a];
  const l=Math.cbrt(0.4122214708*lr+0.5363325363*lg+0.0514459929*lb),m=Math.cbrt(0.2119034982*lr+0.6806995451*lg+0.1073969566*lb),s=Math.cbrt(0.0883024619*lr+0.2817188376*lg+0.6299787005*lb);
  return [0.2104542553*l+0.7936177850*m-0.0040720468*s,1.9779984951*l-2.4285922050*m+0.4505937099*s,0.0259040371*l+0.7827717662*m-0.8086757660*s,a]},
 dec(c,space){if(space==='srgb')return c;const [x,y,z,a]=c;let lr,lg,lb;if(space==='linear'){lr=x;lg=y;lb=z}
  else{const l=(x+0.3963377774*y+0.2158037573*z)**3,m=(x-0.1055613458*y-0.0638541728*z)**3,s=(x-0.0894841775*y-1.2914855480*z)**3;
   lr=4.0767416621*l-3.3077115913*m+0.2309699292*s;lg=-1.2684380046*l+2.6097574011*m-0.3413193965*s;lb=-0.0041960863*l-0.7034186147*m+1.7076147010*s}
  return [Col.l2s(clamp(lr,0,1)),Col.l2s(clamp(lg,0,1)),Col.l2s(clamp(lb,0,1)),a]},
 mix(a,b,u,space){if(u<=0)return a.slice();if(u>=1)return b.slice();const A=Col.enc(a,space),B=Col.enc(b,space);return Col.dec(A.map((v,i)=>v+(B[i]-v)*u),space)},
 hex(c,withAlpha){const h=v=>Math.round(clamp(v,0,1)*255).toString(16).padStart(2,'0');return '#'+h(c[0])+h(c[1])+h(c[2])+(withAlpha&&c[3]<1?h(c[3]):'')},
 parse(str){let s=String(str).trim().replace(/^#/,'');if(s.length===3||s.length===4)s=[...s].map(ch=>ch+ch).join('');if(!/^[0-9a-f]{6}([0-9a-f]{2})?$/i.test(s))return null;const n=i=>parseInt(s.slice(i,i+2),16)/255;return [n(0),n(2),n(4),s.length===8?n(6):1]},
 css:c=>`rgba(${Math.round(c[0]*255)},${Math.round(c[1]*255)},${Math.round(c[2]*255)},${+c[3].toFixed(3)})`
};
const L2S=(()=>{const t=new Float32Array(4098);for(let i=0;i<t.length;i++)t[i]=Col.l2s(Math.min(1,i/4096));return t})();
const l2sFast=x=>{x=x<=0?0:x>=1?1:x;const f=x*4096,i=f|0;return L2S[i]+(L2S[i+1]-L2S[i])*(f-i)};
const INTERP=[['linear','Linear'],['smooth','Smooth'],['easeIn','Ease in'],['easeOut','Ease out'],['step','Step']];
function shapeU(u,st){if(Math.abs(st.mid-0.5)>1e-4)u=u**(Math.log(0.5)/Math.log(st.mid));
 switch(st.interp){case 'smooth':return u*u*(3-2*u);case 'easeIn':return u*u;case 'easeOut':return 1-(1-u)**2;case 'step':return u<0.5?0:1;default:return u}}
let _id=0;
class Gradient extends EventTarget{
 constructor(list,space='oklab'){super();this.space=space;this.stops=[];this.load(list)}
 mk(s){const v=typeof s.v==='string'?Col.parse(s.v):s.v.slice();return {id:++_id,t:clamp(s.t,0,1),v,mid:s.mid??0.5,interp:s.interp||'linear'}}
 load(list){this.stops=list.map(s=>this.mk(s));this.changed()}
 changed(){this.stops.sort((a,b)=>a.t-b.t);this.dispatchEvent(new Event('change'))}
 get(id){return this.stops.find(s=>s.id===id)}
 index(id){return this.stops.findIndex(s=>s.id===id)}
 add(t,v){const [a]=this.segment(t),s=this.mk({t,v:v??this.sample(t),interp:a.interp});this.stops.push(s);this.changed();return s}
 segment(t){const st=this.stops,n=st.length;if(t<=st[0].t)return [st[0],st[0],0];if(t>=st[n-1].t)return [st[n-1],st[n-1],0];
  for(let i=0;i<n-1;i++){const a=st[i],b=st[i+1];if(t<=b.t){const sp=b.t-a.t;return [a,b,sp>1e-9?shapeU((t-a.t)/sp,a):1]}}return [st[n-1],st[n-1],0]}
 sample(t){const [a,b,u]=this.segment(t);return Col.mix(a.v,b.v,u,this.space)}
 // Stops are encoded once; each sample is a lerp in the blend space plus one decode (sRGB encode via a table).
 lut(n=1024){const out=new Uint8Array(n*4),st=this.stops,m=st.length,space=this.space,enc=st.map(s=>Col.enc(s.v,space));let seg=0;
  const put=(i,c)=>{out[i*4]=Math.round(c[0]*255);out[i*4+1]=Math.round(c[1]*255);out[i*4+2]=Math.round(c[2]*255);out[i*4+3]=Math.round(c[3]*255)};
  for(let i=0;i<n;i++){const t=i/(n-1);
   if(t<=st[0].t){put(i,st[0].v);continue}if(t>=st[m-1].t){put(i,st[m-1].v);continue}
   while(seg<m-2&&t>st[seg+1].t)seg++;const a=st[seg],b=st[seg+1],sp=b.t-a.t,u=sp>1e-9?shapeU((t-a.t)/sp,a):1;
   if(u<=0){put(i,a.v);continue}if(u>=1){put(i,b.v);continue}
   const A=enc[seg],B=enc[seg+1],x=A[0]+(B[0]-A[0])*u,y=A[1]+(B[1]-A[1])*u,z=A[2]+(B[2]-A[2])*u,al=A[3]+(B[3]-A[3])*u;let c;
   if(space==='srgb')c=[x,y,z,al];else if(space==='linear')c=[l2sFast(x),l2sFast(y),l2sFast(z),al];
   else{const l=(x+0.3963377774*y+0.2158037573*z)**3,mm=(x-0.1055613458*y-0.0638541728*z)**3,s2=(x-0.0894841775*y-1.2914855480*z)**3;
    c=[l2sFast(4.0767416621*l-3.3077115913*mm+0.2309699292*s2),l2sFast(-1.2684380046*l+2.6097574011*mm-0.3413193965*s2),l2sFast(-0.0041960863*l-0.7034186147*mm+1.7076147010*s2),al]}
   put(i,c)}
  return out}
 reverse(){const st=this.stops,n=st.length,seg=st.map(s=>({mid:s.mid,interp:s.interp})),flip={easeIn:'easeOut',easeOut:'easeIn'},out=st.slice().reverse();
  out.forEach((s,k)=>{s.t=1-s.t;const src=seg[n-k-2];if(src){s.mid=1-src.mid;s.interp=flip[src.interp]||src.interp}else{s.mid=0.5;s.interp='linear'}});this.stops=out;this.changed()}
 distribute(){const n=this.stops.length;this.stops.forEach((s,i)=>s.t=i/(n-1));this.changed()}
}
const PRESETS=[
 {name:'FG → BG',make:ed=>[{t:0,v:ed.fg},{t:1,v:ed.bg}],dyn:true},
 {name:'FG → Clear',make:ed=>[{t:0,v:ed.fg},{t:1,v:[ed.fg[0],ed.fg[1],ed.fg[2],0]}],dyn:true},
 {name:'Ember',make:()=>[{t:0,v:'#1d1a3a'},{t:.35,v:'#a8325e'},{t:.7,v:'#f39a3c'},{t:1,v:'#fff1c9'}]},
 {name:'Sea glass',make:()=>[{t:0,v:'#0b3a52'},{t:.5,v:'#3aa59c'},{t:1,v:'#e8f4d8'}]},
 {name:'Spectrum',make:()=>[{t:0,v:'#e8473c'},{t:.2,v:'#f2b33d'},{t:.4,v:'#8fd14f'},{t:.6,v:'#36b4c9'},{t:.8,v:'#5a5ce0'},{t:1,v:'#c84fd6'}]},
 {name:'Chrome',make:()=>[{t:0,v:'#f4f4f6'},{t:.45,v:'#7d8590',interp:'smooth'},{t:.5,v:'#2f343b'},{t:.55,v:'#b9c0ca',interp:'smooth'},{t:1,v:'#f9fafb'}]},
 {name:'Bands',make:()=>[{t:0,v:'#26323d',interp:'step'},{t:.33,v:'#5f7a8a',interp:'step'},{t:.66,v:'#b9cbd3',interp:'step'},{t:1,v:'#eef3f5'}]},
 {name:'Dusk',make:()=>[{t:0,v:'#0f1030'},{t:.5,v:'#7b3f8c'},{t:.8,v:'#f08a5d'},{t:1,v:'#ffd9a0'}]}
];
const TYPES=['linear','radial','angle','reflected','diamond'],REPEATS=['clamp','repeat','mirror'],SPACES=['oklab','linear','srgb'];
// Blend modes are the app's own list (registered at startup, same order as the compositor so indexes line up) plus Replace.
let blendList=['normal'];const setBlends=list=>{blendList=list.slice()},blendIndex=m=>m==='replace'?-1:Math.max(0,blendList.indexOf(m)),blendOk=m=>m==='replace'||blendList.includes(m);
const TYPE_ID={linear:0,radial:1,angle:2,reflected:3,diamond:4},REPEAT_ID={clamp:0,repeat:1,mirror:2};
// Serialisable settings, stored on gradient modifier layers. Coordinates are document pixels.
function defaults(w=1000,h=1000,fg='#14213d',bg='#fca311'){return {space:'oklab',stops:[{t:0,v:Col.parse(fg)||[0,0,0,1],mid:.5,interp:'linear'},{t:1,v:Col.parse(bg)||[1,1,1,1],mid:.5,interp:'linear'}],type:'linear',repeat:'clamp',aspect:1,a:{x:w*.2,y:h*.5},b:{x:w*.8,y:h*.5},opacity:1,mode:'normal',alphaLock:true,dither:true}}
const num=(v,d)=>Number.isFinite(+v)?+v:d;
// Configs are treated as immutable (edits assign a fresh object), so normalising is memoised on identity.
const normMemo=new WeakMap();
function normalise(c){if(c&&typeof c==='object'){const hit=normMemo.get(c);if(hit)return hit;const out=normaliseUncached(c);Object.defineProperty(out,'_immutable',{value:true});normMemo.set(c,out);return out}return normaliseUncached(c)}
function normaliseUncached(c){const d=defaults();if(!c||typeof c!=='object')return d;
 const stops=Array.isArray(c.stops)?c.stops.filter(s=>s&&Array.isArray(s.v)&&s.v.length===4&&s.v.every(Number.isFinite)).slice(0,64).map(s=>({t:clamp(num(s.t,0),0,1),v:s.v.map(x=>clamp(+x,0,1)),mid:clamp(num(s.mid,.5),.02,.98),interp:INTERP.some(([k])=>k===s.interp)?s.interp:'linear'})):[];
 const pt=(p,f)=>p&&Number.isFinite(+p.x)&&Number.isFinite(+p.y)?{x:+p.x,y:+p.y}:f;
 return {space:SPACES.includes(c.space)?c.space:'oklab',stops:stops.length>=2?stops.sort((a,b)=>a.t-b.t):d.stops,type:TYPES.includes(c.type)?c.type:'linear',repeat:REPEATS.includes(c.repeat)?c.repeat:'clamp',
  aspect:clamp(num(c.aspect,1),.1,4),a:pt(c.a,d.a),b:pt(c.b,d.b),opacity:clamp(num(c.opacity,1),0,1),mode:c.mode==='lock'?'normal':blendOk(c.mode)?c.mode:'normal',alphaLock:c.mode==='lock'?true:c.alphaLock===undefined?false:!!c.alphaLock,dither:c.dither!==false}}
function valid(c){return !!c&&typeof c==='object'&&Array.isArray(c.stops)&&c.stops.length>=2&&c.stops.length<=64&&c.stops.every(s=>s&&Array.isArray(s.v)&&s.v.length===4&&s.v.every(Number.isFinite)&&Number.isFinite(+s.t))&&!!c.a&&!!c.b&&Number.isFinite(+c.a.x)&&Number.isFinite(+c.b.y)}
const lutCache=new Map();
const keyMemo=new WeakMap();
function lutKey(c){const hit=keyMemo.get(c.stops);if(hit&&hit.space===c.space)return hit.key;const key=JSON.stringify([c.space,c.stops.map(s=>[s.t,s.v[0],s.v[1],s.v[2],s.v[3],s.mid,s.interp])]);if(Object.isFrozen?.(c.stops)||c._immutable)keyMemo.set(c.stops,{space:c.space,key});return key}
function lut(c){const key=lutKey(c);let hit=lutCache.get(key);if(!hit){hit=new Gradient(c.stops,c.space).lut();lutCache.set(key,hit);while(lutCache.size>16)lutCache.delete(lutCache.keys().next().value)}return hit}
// Where a point falls along the gradient (0..1), for gizmos and tests; mirrors the shader.
function paramAt(c,x,y){const dx=c.b.x-c.a.x,dy=c.b.y-c.a.y,len=Math.max(Math.hypot(dx,dy),1e-4),ax=dx/len,ay=dy/len,qx=x-c.a.x,qy=y-c.a.y,u=qx*ax+qy*ay,v=(qx*-ay+qy*ax)/c.aspect;let t;
 if(c.type==='linear')t=u/len;else if(c.type==='radial')t=Math.hypot(u,v)/len;else if(c.type==='angle'){t=Math.atan2(v,u)/(Math.PI*2);t-=Math.floor(t)}else if(c.type==='reflected')t=Math.abs(u)/len;else t=(Math.abs(u)+Math.abs(v))/len;
 if(c.type!=='angle'){if(c.repeat==='clamp')t=clamp(t,0,1);else if(c.repeat==='repeat')t-=Math.floor(t);else t=1-Math.abs(1-(t%2+2)%2)}return t}

// ---- WebGL renderer: gradient → LUT → per-pixel shader, combined with a source layer ----
const BLEND_GLSL=`
float gDodge(float b,float s){return b==0.?0.:s>=1.?1.:min(1.,b/(1.-s));}
float gBurn(float b,float s){return b>=1.?1.:s<=0.?0.:1.-min(1.,(1.-b)/s);}
float gChan(int m,float b,float s){
 if(m==1)return b*s;if(m==2)return b+s-b*s;
 if(m==3)return b<=.5?2.*b*s:1.-2.*(1.-b)*(1.-s);
 if(m==4)return min(b,s);if(m==5)return max(b,s);
 if(m==6)return gDodge(b,s);if(m==7)return gBurn(b,s);
 if(m==8)return s<=.5?2.*b*s:1.-2.*(1.-b)*(1.-s);
 if(m==9){float d=b<=.25?((16.*b-12.)*b+4.)*b:sqrt(b);return s<=.5?b-(1.-2.*s)*b*(1.-b):b+(2.*s-1.)*(d-b);}
 if(m==10)return abs(b-s);if(m==11)return b+s-2.*b*s;
 if(m==12)return min(1.,b+s);if(m==13)return max(0.,b+s-1.);
 if(m==14)return s<=.5?gBurn(b,2.*s):gDodge(b,2.*s-1.);
 if(m==15)return max(0.,b-s);if(m==16)return s<=0.?1.:min(1.,b/s);
 if(m==21)return b>=1.?1.:min(1.,s*s/(1.-b));
 return s;}
float gLum(vec3 c){return dot(c,vec3(.3,.59,.11));}
vec3 gClip(vec3 c){float l=gLum(c),n=min(min(c.r,c.g),c.b),x=max(max(c.r,c.g),c.b);if(n<0.)c=l+(c-l)*l/(l-n);if(x>1.)c=l+(c-l)*(1.-l)/(x-l);return c;}
vec3 gSetLum(vec3 c,float l){return gClip(c+(l-gLum(c)));}
float gSat(vec3 c){return max(max(c.r,c.g),c.b)-min(min(c.r,c.g),c.b);}
vec3 gSetSat(vec3 c,float s){float mx=max(max(c.r,c.g),c.b),mn=min(min(c.r,c.g),c.b);return mx>mn?(c-mn)*s/(mx-mn):vec3(0.);}
vec3 gBlend(int m,vec3 b,vec3 s){
 if(m==17)return gSetLum(gSetSat(s,gSat(b)),gLum(b));
 if(m==18)return gSetLum(gSetSat(b,gSat(s)),gLum(b));
 if(m==19)return gSetLum(s,gLum(b));
 if(m==20)return gSetLum(b,gLum(s));
 return vec3(gChan(m,b.r,s.r),gChan(m,b.g,s.g),gChan(m,b.b,s.b));}
// Gradient colour g (straight rgba) over premultiplied backdrop L. m: blend index, -1 = Replace. lock keeps the backdrop alpha.
vec4 gCombine(int m,bool lock,vec4 L,vec4 g,float op){
 float as=g.a*op;
 if(m<0&&!lock)return mix(L,vec4(g.rgb*g.a,g.a),op);
 vec3 cb=L.a>0.0001?L.rgb/L.a:vec3(0.0);vec3 B=m>0?gBlend(m,cb,g.rgb):g.rgb;
 if(lock)return vec4(mix(cb,B,as)*L.a,L.a);
 return vec4((1.-as)*L.rgb+(1.-L.a)*as*g.rgb+as*L.a*B,as+L.a*(1.-as));}
`;
const VS='attribute vec2 a;void main(){gl_Position=vec4(a,0.0,1.0);}';
const FS=`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec2 uSize;uniform vec2 uA;uniform vec2 uB;
uniform float uType;uniform float uRepeat;uniform float uAspect;uniform float uOpacity;uniform float uLock;uniform float uDither;uniform int uBlend;
uniform sampler2D uLut;uniform sampler2D uLayer;
float hsh(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}
${BLEND_GLSL}
void main(){
 vec2 p=vec2(gl_FragCoord.x,uSize.y-gl_FragCoord.y);
 vec4 L=texture2D(uLayer,p/uSize);
 vec2 d=uB-uA;float len=max(length(d),0.0001);vec2 ax=d/len;vec2 ay=vec2(-ax.y,ax.x);vec2 q=p-uA;
 float u=dot(q,ax);float v=dot(q,ay)/uAspect;float t;
 if(uType<0.5)t=u/len;else if(uType<1.5)t=length(vec2(u,v))/len;else if(uType<2.5)t=fract(atan(v,u)/6.2831853);else if(uType<3.5)t=abs(u)/len;else t=(abs(u)+abs(v))/len;
 if(uType<1.5||uType>2.5){if(uRepeat<0.5)t=clamp(t,0.0,1.0);else if(uRepeat<1.5)t=fract(t);else t=1.0-abs(1.0-mod(t,2.0));}
 vec4 g=texture2D(uLut,vec2((t*1023.0+0.5)/1024.0,0.5));
 vec4 res=gCombine(uBlend,uLock>0.5,L,g,uOpacity);
 if(uDither>0.5&&res.a>0.002){vec3 c=res.rgb/res.a;float a=res.a;float n1=(hsh(p)+hsh(p+17.0)-1.0)/255.0;float n2=(hsh(p+43.0)+hsh(p+91.0)-1.0)/255.0;c=clamp(c+n1,0.0,1.0);if(a<0.999)a=clamp(a+n2,0.0,1.0);res=vec4(c*a,a);}
 gl_FragColor=res;
}`;
class Renderer{
 constructor(){this.c=document.createElement('canvas');this.c.width=this.c.height=1;
  const gl=this.gl=this.c.getContext('webgl',{premultipliedAlpha:true,antialias:false,preserveDrawingBuffer:true});
  if(!gl){this.fail='WebGL is unavailable';return}
  const sh=(type,src)=>{const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))this.fail=gl.getShaderInfoLog(s)||'shader error';return s};
  const p=this.prog=gl.createProgram();gl.attachShader(p,sh(gl.VERTEX_SHADER,VS));gl.attachShader(p,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(p);
  if(!this.fail&&!gl.getProgramParameter(p,gl.LINK_STATUS))this.fail=gl.getProgramInfoLog(p)||'link error';if(this.fail)return;
  this.u={};for(const n of ['uSize','uA','uB','uType','uRepeat','uAspect','uOpacity','uLock','uDither','uBlend','uLut','uLayer'])this.u[n]=gl.getUniformLocation(p,n);
  gl.bindBuffer(gl.ARRAY_BUFFER,gl.createBuffer());gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
  const loc=gl.getAttribLocation(p,'a');gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);
  this.lutTex=this.tex(gl.LINEAR);this.layerTex=this.tex(gl.NEAREST);this.lutKey=null;this.layerSrc=null;
  this.c.addEventListener('webglcontextlost',e=>{e.preventDefault();this.fail='WebGL context lost'});
 }
 tex(filter){const gl=this.gl,t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);for(const [k,v] of [[gl.TEXTURE_MIN_FILTER,filter],[gl.TEXTURE_MAG_FILTER,filter],[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE]])gl.texParameteri(gl.TEXTURE_2D,k,v);return t}
 // Upload the source layer (any drawable); `force` re-uploads even if it is the same object (its pixels changed).
 setLayer(src,force=false){if(this.fail||(!force&&src===this.layerSrc))return;const gl=this.gl;gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,this.layerTex);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,src);this.layerSrc=src}
 setLut(c){if(this.fail)return;const key=lutKey(c);if(key===this.lutKey)return;const gl=this.gl;gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.lutTex);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1024,1,0,gl.RGBA,gl.UNSIGNED_BYTE,lut(c));this.lutKey=key}
 // Render cfg over the current layer texture into this.c (w×h). `scale`/`ox`/`oy` map document px to output px.
 render(c,w,h,{scale=1,ox=0,oy=0,dither=c.dither}={}){
  if(this.fail)return null;const gl=this.gl,u=this.u;if(this.c.width!==w||this.c.height!==h){this.c.width=w;this.c.height=h}this.setLut(c);
  gl.viewport(0,0,w,h);gl.useProgram(this.prog);gl.disable(gl.BLEND);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.lutTex);gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,this.layerTex);
  gl.uniform1i(u.uLut,0);gl.uniform1i(u.uLayer,1);gl.uniform2f(u.uSize,w,h);gl.uniform2f(u.uA,c.a.x*scale-ox,c.a.y*scale-oy);gl.uniform2f(u.uB,c.b.x*scale-ox,c.b.y*scale-oy);
  gl.uniform1f(u.uType,TYPE_ID[c.type]??0);gl.uniform1f(u.uRepeat,REPEAT_ID[c.repeat]??0);gl.uniform1f(u.uAspect,c.aspect||1);gl.uniform1f(u.uOpacity,c.opacity??1);gl.uniform1f(u.uLock,c.alphaLock?1:0);gl.uniform1i(u.uBlend,blendIndex(c.mode));gl.uniform1f(u.uDither,dither?1:0);
  gl.drawArrays(gl.TRIANGLES,0,3);return this.c;
 }
}
let shared=null;
function renderer(){if(!shared||shared.fail==='WebGL context lost')shared=new Renderer();return shared}
// CPU-path helper: recolour `src` (w×h, document scaled by `scale`) with the gradient, writing into ctx.
function drawInto(ctx,src,c,w,h,scale=1){const r=renderer();if(r.fail){ctx.drawImage(src,0,0);return false}r.setLayer(src,true);const out=r.render(c,w,h,{scale});ctx.save();ctx.globalCompositeOperation='copy';ctx.drawImage(out,0,0);ctx.restore();return true}
global.BungalowGradient={Col,Gradient,PRESETS,INTERP,TYPES,REPEATS,SPACES,TYPE_ID,REPEAT_ID,BLEND_GLSL,setBlends,blendIndex,blendOk,defaults,normalise,valid,lut,lutKey,paramAt,shapeU,Renderer,renderer,drawInto,clamp};
})(globalThis);
