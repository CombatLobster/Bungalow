/* v182: shared SVG geometry for Transform and Basic shapes. */
function gizmoOutlineMarkup(path){return '<path d="'+path+'" fill="none" stroke="#6da9e4" stroke-opacity=".65" stroke-width="1.5"/>'}
function gizmoCornerMarkup(p,rotate=false){return rotate?'<path d="M'+(p.x-5)+' '+(p.y+4)+' A6 6 0 1 1 '+(p.x+5)+' '+(p.y+4)+' M'+(p.x+5)+' '+(p.y+4)+'l-5 -1m5 1l1 -5" fill="none" stroke="#e69b36" stroke-width="2"><title>Rotate</title></path>':'<rect x="'+(p.x-6)+'" y="'+(p.y-6)+'" width="12" height="12" fill="white" stroke="#111"/>'}
function gizmoEdgeMarkup(p,skew=false){return skew?'<path d="M'+(p.x-6)+' '+p.y+'l6 -6 6 6 -6 6Z" fill="#ffc46b" stroke="#111"><title>Skew</title></path>':'<circle cx="'+p.x+'" cy="'+p.y+'" r="5" fill="white" stroke="#111"/>'}
function gizmoKnobMarkup(a,b){return '<path d="M'+a.x+' '+a.y+' L'+b.x+' '+b.y+'" stroke="white"/><circle cx="'+b.x+'" cy="'+b.y+'" r="6" fill="white" stroke="#111"/>'}
