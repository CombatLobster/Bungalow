

/* Seeded HSL palette variation; no pixel readback is needed for overlay rendering. */
(function(global){
const hex=/^#[0-9a-f]{6}$/i;
function valid(r){return !!r&&typeof r==='object'&&hex.test(r.base)&&['hue','saturation','lightness'].every(k=>typeof r[k]==='boolean')&&Number.isFinite(r.strength)&&r.strength>=0&&r.strength<=1&&Number.isInteger(r.seed)&&r.seed>=0&&r.seed<=4294967295&&Number.isInteger(r.index)&&r.index>=0&&r.index<1024}
function normalise(r){return valid(r)?{base:r.base.toLowerCase(),hue:r.hue,saturation:r.saturation,lightness:r.lightness,strength:r.strength,seed:r.seed,index:r.index}:null}
function colour(raw){const r=normalise(raw);if(!r)return '#3b82f6';if(!r.strength||!r.hue&&!r.saturation&&!r.lightness)return r.base;const rgb=[1,3,5].map(i=>parseInt(r.base.slice(i,i+2),16)/255),max=Math.max(...rgb),min=Math.min(...rgb),d=max-min,l=(max+min)/2,s=d?d/(1-Math.abs(2*l-1)):0;let h=0;if(d)h=60*(max===rgb[0]?((rgb[1]-rgb[2])/d)%6:max===rgb[1]?(rgb[2]-rgb[0])/d+2:(rgb[0]-rgb[1])/d+4);h=(h+360)%360;
let state=(r.seed^Math.imul(r.index+1,0x9e3779b9))>>>0;const random=()=>{state=(state+0x6d2b79f5)>>>0;let t=state;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296};const target=[random()*360,random(),random()],amount=r.strength,hh=r.hue?(h+(((target[0]-h+540)%360)-180)*amount+360)%360:h,ss=r.saturation?s+(target[1]-s)*amount:s,ll=r.lightness?l+(target[2]-l)*amount:l,c=(1-Math.abs(2*ll-1))*ss,x=c*(1-Math.abs((hh/60)%2-1)),m=ll-c/2,parts=hh<60?[c,x,0]:hh<120?[x,c,0]:hh<180?[0,c,x]:hh<240?[0,x,c]:hh<300?[x,0,c]:[c,0,x];return '#'+parts.map(v=>Math.round(Math.min(1,Math.max(0,v+m))*255).toString(16).padStart(2,'0')).join('')}
global.BungalowRandomColour={valid,normalise,colour};})(globalThis);
