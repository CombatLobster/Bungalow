/* v267: DOM-free authoritative document store (stage 4).
 * Slices owned as plain JSON:
 *  - selection (v248): ordered selected node IDs, range anchor, active node.
 *  - tree (v249): layer order, group order and the parent of every live node.
 *  - references (v250): floating reference order, selected reference, shown flag.
 *  - boards (v250): artboard order, active board, selected boards, range anchor.
 *  - document (v251): active document width, height and DPI.
 *  - props (v252): common properties of every live layer/group (PROP_KEYS); v263 adds mask/modifier
 *    content (mask, maskKind, maskDirect, preventTrim and the JSON configs maskFilter, maskTransform,
 *    maskMirror, maskColour, maskGradient, maskStroke, maskShadow); v264 adds `instance`, the layer content
 *    (text/shape/vector/file/clone/frame) encoded by engine-content-codec-264.js ($ref objects for resources).
 *  - boardProps / referenceProps (v253): artboard metadata (BOARD_KEYS) and floating
 *    reference geometry/appearance (REFERENCE_KEYS) for every member of those collections.
 *  - coordinates (v254): committed guides/grids/perspective/layout JSON (schema owned by
 *    CanvasCoordinates.validate in the adapter; the store deep-freezes and compares it).
 *  - parked (v255): one complete document per INACTIVE artboard {tree, selection, references,
 *    document, props, referenceProps, coordinates}, so the store owns every board, not just the active one.
 *  - session (v256): project save state {dirty, editSerial, filename, hasFile}.
 * The browser keeps only resource objects (canvases, images, board records). Legacy
 * variables AL / selectedStack / stackSelectionAnchor / layers / layerGroups / each
 * live node's `.group` / referenceImages / referenceSelected / referenceShown /
 * artboards / activeArtboardId / selectedArtboards / artboardSelectionAnchor / DW / DH /
 * documentDPI are
 * read-only projections refreshed from this store.
 * No DOM, no object references; every state is serialisable (Rust-ready).
 * v267: setTracer(fn) reports every outermost public mutation as fn(method, args, ok, error) after it runs, so a
 * native core (native/bungalow-core) can replay the same calls in shadow mode.
 */
const BungalowDocumentStore=(()=>{
 'use strict';
 const Nodes=typeof BungalowEngineNodes!=='undefined'?BungalowEngineNodes:require('./engine-node-identity-231.js');
 const Codec=typeof BungalowContentCodec!=='undefined'?BungalowContentCodec:require('./engine-content-codec-264.js');
 const EMPTY_SELECTION=Object.freeze({selected:Object.freeze([]),anchor:null,active:null});
 const EMPTY_TREE=Object.freeze({layers:Object.freeze([]),groups:Object.freeze([]),parents:Object.freeze({})});
 const id=(v,label)=>{if(v===null)return null;if(!Nodes.valid(v))throw new TypeError('Invalid '+label+' ID');return v};
 const sameList=(a,b)=>a.length===b.length&&a.every((v,i)=>v===b[i]);
 // References and artboards use opaque string IDs (UUIDs today).
 const key=(v,label)=>{if(v===null)return null;if(typeof v!=='string'||!v||v.length>256)throw new TypeError('Invalid '+label+' ID');return v};
 const keyList=(list,label,{dedupe=false}={})=>{if(!Array.isArray(list))throw new TypeError('Invalid '+label+' list');const seen=new Set(),out=[];for(const v of list){if(v===null)throw new TypeError('Invalid '+label+' ID');key(v,label);if(seen.has(v)){if(dedupe)continue;throw new TypeError('Duplicate '+label+' ID')}seen.add(v);out.push(v)}return Object.freeze(out)};
 const EMPTY_REFERENCES=Object.freeze({ids:Object.freeze([]),selected:null,shown:true});
 const EMPTY_BOARDS=Object.freeze({ids:Object.freeze([]),active:null,selected:Object.freeze([]),anchor:null});
 // ---- references slice ---- patch: {ids?, selected?, shown?}
 function normaliseReferences(patch,base){
  if(!patch||typeof patch!=='object')throw new TypeError('Invalid references patch');
  const shown=patch.shown===undefined?base.shown:patch.shown;if(typeof shown!=='boolean')throw new TypeError('Invalid references shown flag');
  return Object.freeze({ids:patch.ids===undefined?base.ids:keyList(patch.ids,'reference'),selected:patch.selected===undefined?base.selected:key(patch.selected,'reference'),shown});
 }
 const sameReferences=(a,b)=>a.selected===b.selected&&a.shown===b.shown&&sameList(a.ids,b.ids);
 // ---- boards slice ---- patch: {ids?, active?, selected?, anchor?}
 function normaliseBoards(patch,base){
  if(!patch||typeof patch!=='object')throw new TypeError('Invalid boards patch');
  return Object.freeze({ids:patch.ids===undefined?base.ids:keyList(patch.ids,'artboard'),active:patch.active===undefined?base.active:key(patch.active,'artboard'),selected:patch.selected===undefined?base.selected:keyList(patch.selected,'artboard',{dedupe:true}),anchor:patch.anchor===undefined?base.anchor:key(patch.anchor,'artboard')});
 }
 const sameBoards=(a,b)=>a.active===b.active&&a.anchor===b.anchor&&sameList(a.ids,b.ids)&&sameList(a.selected,b.selected);
 const EMPTY_DOCUMENT=Object.freeze({width:1920,height:1080,dpi:72});
 // ---- document slice ---- patch: {width?, height?, dpi?}
 function normaliseDocument(patch,base){
  if(!patch||typeof patch!=='object')throw new TypeError('Invalid document patch');
  const out={};for(const k of ['width','height','dpi']){const v=patch[k]===undefined?base[k]:patch[k];if(typeof v!=='number'||!Number.isFinite(v)||v<=0||v>1e6)throw new TypeError('Invalid document '+k);out[k]=v}
  return Object.freeze(out);
 }
 const sameDocument=(a,b)=>a.width===b.width&&a.height===b.height&&a.dpi===b.dpi;
 // ---- props slice ---- {[nodeId]:{key:value}} for live nodes. A missing key means "not set" (undefined).
 // v263: plain JSON value check (objects/arrays of JSON primitives, finite numbers), max depth 32.
 const plainJSON=(v,d=0)=>{if(d>32)return false;if(v===null||typeof v==='boolean'||typeof v==='string')return true;if(typeof v==='number')return Number.isFinite(v);if(Array.isArray(v))return v.every(x=>plainJSON(x,d+1));if(typeof v==='object'){const p=Object.getPrototypeOf(v);return (p===Object.prototype||p===null)&&Object.values(v).every(x=>x===undefined||plainJSON(x,d+1))}return false},JSONV=v=>v===null||(typeof v==='object'&&plainJSON(v));
 const BOOL=v=>typeof v==='boolean',PROP_KEYS=Object.freeze({vis:BOOL,locked:BOOL,alphaLock:BOOL,inheritAlpha:BOOL,reference:BOOL,collapsed:BOOL,isolate:BOOL,op:v=>typeof v==='number'&&Number.isFinite(v),blend:v=>typeof v==='string'&&v.length<=64,name:v=>typeof v==='string'&&v.length<=4096,rasterId:v=>typeof v==='string'&&/^res_[0-9a-f]{32}$/.test(v),
  // v263: mask/modifier content. JSON configs are plain data (deep-frozen in the store) or null.
  mask:BOOL,maskDirect:BOOL,preventTrim:BOOL,maskKind:v=>typeof v==='string'&&v.length<=32,maskFilter:JSONV,maskTransform:JSONV,maskMirror:JSONV,maskColour:JSONV,maskGradient:JSONV,maskStroke:JSONV,maskShadow:JSONV,
  instance:v=>v===null||(typeof v==='object'&&!Array.isArray(v)&&Codec.valid(v)), // v264: encoded layer content
  // v265: modifier target (node ID or 'orphan') and preserved out-of-bounds pixels (encoded, image $ref)
  maskTarget:v=>v===null||v==='orphan'||Nodes.valid(v),retained:v=>v===null||(typeof v==='object'&&!Array.isArray(v)&&Codec.valid(v))}); // rasterId (v257): the node's pixel resource
 const EMPTY_PROPS=Object.freeze({});
 const NUM=v=>typeof v==='number'&&Number.isFinite(v),STR=v=>typeof v==='string'&&v.length<=4096;
 const BOARD_KEYS=Object.freeze({name:STR,x:NUM,y:NUM,visible:BOOL,locked:BOOL,group:v=>v===null||typeof v==='string'&&v.length>0&&v.length<=256});
 const REFERENCE_KEYS=Object.freeze({name:STR,x:NUM,y:NUM,w:NUM,h:NUM,angle:NUM,op:NUM,saturation:NUM,vis:BOOL,matrix:v=>Array.isArray(v)&&v.length===4&&v.every(NUM),
  // v265: the reference image payload (data URL) and its natural size are document data owned by the store
  src:v=>typeof v==='string'&&/^data:image\//.test(v),nw:v=>Number.isInteger(v)&&v>0,nh:v=>Number.isInteger(v)&&v>0});
 // Record slices: slice -> {keys, id validator}. Values are JSON primitives or frozen arrays.
 const RECORD_SLICES=Object.freeze({props:{keys:PROP_KEYS,id:v=>id(v,'props')},boardProps:{keys:BOARD_KEYS,id:v=>key(v,'artboard')},referenceProps:{keys:REFERENCE_KEYS,id:v=>key(v,'reference')}});
 const deepFreeze=v=>{if(v===null||typeof v!=='object')return v;if(Array.isArray(v))return Object.freeze(v.map(deepFreeze));const o={};for(const [k,x] of Object.entries(v))if(x!==undefined)o[k]=deepFreeze(x);return Object.freeze(o)};
 const freezeValue=v=>v!==null&&typeof v==='object'?deepFreeze(v):v; // v263: deep copy + freeze (arrays and JSON objects)
 function normaliseRecord(values,base,KEYS=PROP_KEYS){if(!values||typeof values!=='object')throw new TypeError('Invalid property record');const out={...(base||{})};for(const [k,v] of Object.entries(values)){const ok=Object.prototype.hasOwnProperty.call(KEYS,k)&&KEYS[k];if(!ok)throw new TypeError('Unknown property '+k);if(v===undefined){delete out[k];continue}if(!ok(v))throw new TypeError('Invalid property '+k);out[k]=freezeValue(v)}return Object.freeze(out)}
 // patch: {set?:{id:{key:value|undefined}}, remove?:[id]}. Atomic.
 function normaliseProps(patch,base,slice='props'){
  const S=RECORD_SLICES[slice];if(!S)throw new TypeError('Unknown record slice');
  if(!patch||typeof patch!=='object')throw new TypeError('Invalid props patch');
  const next={...base},remove=patch.remove||[],set=patch.set||{};if(!Array.isArray(remove)||typeof set!=='object')throw new TypeError('Invalid props patch');
  for(const v of remove){S.id(v);delete next[v]}
  for(const [k,values] of Object.entries(set)){S.id(k);next[k]=normaliseRecord(values,next[k],S.keys)}
  return Object.freeze(next);
 }
 // ---- coordinates slice ---- plain JSON object, deep-frozen.
 function deepFreezeJSON(v,depth=0){if(depth>32)throw new TypeError('Coordinates too deep');if(v===null||typeof v==='boolean'||typeof v==='string')return v;if(typeof v==='number'){if(!Number.isFinite(v))throw new TypeError('Invalid coordinate number');return v}if(Array.isArray(v))return Object.freeze(v.map(x=>deepFreezeJSON(x,depth+1)));if(typeof v==='object'){const proto=Object.getPrototypeOf(v);if(proto!==Object.prototype&&proto!==null)throw new TypeError('Coordinates must be plain JSON');const o={};for(const [k,x] of Object.entries(v)){if(x===undefined)continue;o[k]=deepFreezeJSON(x,depth+1)}return Object.freeze(o)}throw new TypeError('Coordinates must be plain JSON')}
 function normaliseCoordinates(v){if(!v||typeof v!=='object'||Array.isArray(v))throw new TypeError('Invalid coordinates');return deepFreezeJSON(v)}
 const EMPTY_COORDINATES=Object.freeze({});
 const sameValue=(a,b)=>a===b||Array.isArray(a)&&Array.isArray(b)&&sameList(a,b)||!!a&&!!b&&typeof a==='object'&&typeof b==='object'&&!Array.isArray(a)&&!Array.isArray(b)&&JSON.stringify(a)===JSON.stringify(b);
 const sameRecord=(a,b)=>a===b||!!a&&!!b&&Object.keys(a).length===Object.keys(b).length&&Object.keys(a).every(k=>sameValue(a[k],b[k]));
 const sameProps=(a,b)=>Object.keys(a).length===Object.keys(b).length&&Object.keys(a).every(k=>sameRecord(a[k],b[k]));
 // Membership report for references/boards (does not throw).
 function verifyCollections(state){const issues=[],refs=new Set(state.references.ids),boards=new Set(state.boards.ids);if(state.references.selected!==null&&!refs.has(state.references.selected))issues.push({slice:'references',issue:'selected-missing'});if(state.boards.ids.length&&state.boards.active!==null&&!boards.has(state.boards.active))issues.push({slice:'boards',issue:'active-missing'});for(const id of state.boards.selected)if(!boards.has(id))issues.push({slice:'boards',id,issue:'selected-missing'});return issues}

 // ---- selection slice ----
 function normaliseSelection(patch,base){
  if(!patch||typeof patch!=='object')throw new TypeError('Invalid selection patch');
  const selected=patch.selected===undefined?[...base.selected]:patch.selected;
  if(!Array.isArray(selected))throw new TypeError('Invalid selected list');
  const seen=new Set(),list=[];
  for(const v of selected){if(v===null)throw new TypeError('Invalid selected ID');id(v,'selected');if(!seen.has(v)){seen.add(v);list.push(v)}}
  return Object.freeze({selected:Object.freeze(list),anchor:patch.anchor===undefined?base.anchor:id(patch.anchor,'anchor'),active:patch.active===undefined?base.active:id(patch.active,'active')});
 }
 const sameSelection=(a,b)=>a.anchor===b.anchor&&a.active===b.active&&sameList(a.selected,b.selected);

 // ---- tree slice ----
 // patch: {layers?, groups?, parents?:{id:parentId|null}}. Parents are kept only for live nodes;
 // a live node missing from `parents` keeps its previous parent (or null when new).
 function normaliseTree(patch,base){
  if(!patch||typeof patch!=='object')throw new TypeError('Invalid tree patch');
  const layers=patch.layers===undefined?base.layers:patch.layers,groups=patch.groups===undefined?base.groups:patch.groups;
  if(!Array.isArray(layers)||!Array.isArray(groups))throw new TypeError('Invalid tree order');
  const seen=new Set();
  for(const v of [...layers,...groups]){if(v===null)throw new TypeError('Invalid tree ID');id(v,'tree');if(seen.has(v))throw new TypeError('Duplicate tree ID');seen.add(v)}
  const given=patch.parents||{};if(typeof given!=='object')throw new TypeError('Invalid parents');
  const parents={};
  for(const v of seen){const p=Object.prototype.hasOwnProperty.call(given,v)?given[v]:Object.prototype.hasOwnProperty.call(base.parents,v)?base.parents[v]:null;id(p,'parent');if(p===v)throw new TypeError('Node cannot parent itself');parents[v]=p}
  // Reject cycles among live groups (dangling parents are reported by verifyTree, not rejected).
  for(const g of groups){const path=new Set([g]);for(let p=parents[g];p!==null&&p!==undefined&&Object.prototype.hasOwnProperty.call(parents,p);p=parents[p]){if(path.has(p))throw new TypeError('Group cycle');path.add(p)}}
  return Object.freeze({layers:Object.freeze([...layers]),groups:Object.freeze([...groups]),parents:Object.freeze(parents)});
 }
 const sameTree=(a,b)=>sameList(a.layers,b.layers)&&sameList(a.groups,b.groups)&&Object.keys(a.parents).length===Object.keys(b.parents).length&&Object.keys(a.parents).every(k=>a.parents[k]===b.parents[k]);
 // Structural health report for tests/diagnostics (does not throw).
 function verifyTree(tree){const issues=[],groups=new Set(tree.groups),layers=new Set(tree.layers);for(const [k,p] of Object.entries(tree.parents)){if(p===null)continue;if(layers.has(p))issues.push({id:k,issue:'layer-parent'});else if(!groups.has(p))issues.push({id:k,issue:'dangling-parent'})}return issues}

 // ---- parked documents (v255) ---- one full document per inactive artboard.
 const PARKED_PARTS=Object.freeze(['tree','selection','references','document','props','referenceProps','coordinates']);
 function normaliseParked(doc,base){
  if(!doc||typeof doc!=='object')throw new TypeError('Invalid parked document');const b=base||{};
  const part=(k,fn)=>doc[k]===undefined?(b[k]??fn(undefined)):fn(doc[k]);
  const out={tree:part('tree',v=>normaliseTree(v||{},EMPTY_TREE)),selection:part('selection',v=>normaliseSelection(v||{},EMPTY_SELECTION)),references:part('references',v=>normaliseReferences(v||{},EMPTY_REFERENCES)),document:part('document',v=>normaliseDocument(v||{},EMPTY_DOCUMENT)),props:part('props',v=>normaliseProps({set:v||{}},EMPTY_PROPS)),referenceProps:part('referenceProps',v=>normaliseProps({set:v||{}},EMPTY_PROPS,'referenceProps')),coordinates:part('coordinates',v=>v?normaliseCoordinates(v):EMPTY_COORDINATES)};
  for(const k of Object.keys(doc))if(!PARKED_PARTS.includes(k))throw new TypeError('Unknown parked part '+k);
  return Object.freeze(out);
 }
 function verifyParkedDoc(boardId,d){const issues=[];const live=new Set([...d.tree.layers,...d.tree.groups]);for(const k of live)if(!d.props[k])issues.push({board:boardId,id:k,issue:'node-without-props'});for(const k of Object.keys(d.props))if(!live.has(k))issues.push({board:boardId,id:k,issue:'props-without-node'});for(const k of d.references.ids)if(!d.referenceProps[k])issues.push({board:boardId,id:k,issue:'reference-without-record'});for(const x of verifyTree(d.tree))issues.push({board:boardId,...x});return issues}
 // ---- session slice (v256) ----
 const EMPTY_SESSION=Object.freeze({dirty:false,editSerial:0,filename:'painting.bung',hasFile:false});
 function normaliseSession(patch,base){if(!patch||typeof patch!=='object')throw new TypeError('Invalid session patch');const o={...base};for(const [k,v] of Object.entries(patch)){if(v===undefined)continue;if(k==='dirty'||k==='hasFile'){if(typeof v!=='boolean')throw new TypeError('Invalid session '+k)}else if(k==='editSerial'){if(!Number.isSafeInteger(v)||v<0)throw new TypeError('Invalid session editSerial')}else if(k==='filename'){if(v!==null&&(typeof v!=='string'||v.length>4096))throw new TypeError('Invalid session filename')}else throw new TypeError('Unknown session field '+k);o[k]=v}return Object.freeze(o)}
 function create(initial){
  let state=Object.freeze({revision:0,selection:EMPTY_SELECTION,tree:EMPTY_TREE,references:EMPTY_REFERENCES,boards:EMPTY_BOARDS,document:EMPTY_DOCUMENT,props:EMPTY_PROPS,boardProps:EMPTY_PROPS,referenceProps:EMPTY_PROPS,coordinates:EMPTY_COORDINATES,parked:Object.freeze({}),session:EMPTY_SESSION});const listeners=new Set();
  const set=(slice,value)=>{const prev=state;state=Object.freeze({...prev,revision:prev.revision+1,[slice]:value});for(const f of [...listeners])f(state,prev);return state};
  // Selection API (v248 shape kept: get() returns the selection slice plus revision).
  let cached=null;const view=()=>{if(!cached||cached.revision!==state.revision||cached.source!==state.selection){cached={revision:state.revision,source:state.selection,value:Object.freeze({revision:state.revision,...state.selection})}}return cached.value};
  function commit(patch){const next=normaliseSelection(patch,state.selection);if(!sameSelection(next,state.selection))set('selection',next);return view()}
  function prune(liveIds){const live=liveIds instanceof Set?liveIds:new Set(liveIds),s=state.selection;return commit({selected:s.selected.filter(v=>live.has(v)),anchor:s.anchor&&live.has(s.anchor)?s.anchor:null,active:s.active&&live.has(s.active)?s.active:null})}
  function replace(snapshot){set('selection',normaliseSelection(snapshot,EMPTY_SELECTION));return view()}
  function reset(){set('selection',EMPTY_SELECTION);set('tree',EMPTY_TREE);set('references',EMPTY_REFERENCES);set('boards',EMPTY_BOARDS);set('document',EMPTY_DOCUMENT);set('props',EMPTY_PROPS);set('boardProps',EMPTY_PROPS);set('referenceProps',EMPTY_PROPS);set('coordinates',EMPTY_COORDINATES);set('parked',Object.freeze({}));set('session',EMPTY_SESSION);return view()}
  // Tree API. replace:true starts from an empty tree (open/new/board switch): unknown parents come from the patch.
  function commitTree(patch,{replace:fresh=false}={}){const next=normaliseTree(patch,fresh?EMPTY_TREE:state.tree);if(!sameTree(next,state.tree))set('tree',next);return state.tree}
  function commitReferences(patch){const next=normaliseReferences(patch,state.references);if(!sameReferences(next,state.references))set('references',next);return state.references}
  function commitBoards(patch){const next=normaliseBoards(patch,state.boards);if(!sameBoards(next,state.boards))set('boards',next);return state.boards}
  function commitDocument(patch){const next=normaliseDocument(patch,state.document);if(!sameDocument(next,state.document))set('document',next);return state.document}
  // Generic record API (props, boardProps, referenceProps).
  function commitRecords(slice,patch){const next=normaliseProps(patch,state[slice],slice);if(!sameProps(next,state[slice]))set(slice,next);return state[slice]}
  // Fast single-value write used by live accessors.
  function setRecord(slice,recordId,k,value){const cur=state[slice]?.[recordId];if(!cur)throw new Error('Property write to a record outside the document');if(sameValue(cur[k],value)&&(value!==undefined||!(k in cur)))return state[slice];return commitRecords(slice,{set:{[recordId]:{[k]:value}}})}
  const record=(slice,recordId,k)=>state[slice][recordId]?.[k];
  const commitProps=patch=>commitRecords('props',patch),setProp=(nodeId,k,v)=>setRecord('props',nodeId,k,v),prop=(nodeId,k)=>state.props[nodeId]?.[k];
  // Props must exist exactly for live tree nodes.
  function verifyProps(){const live=new Set([...state.tree.layers,...state.tree.groups]),issues=[];for(const k of Object.keys(state.props))if(!live.has(k))issues.push({id:k,issue:'props-without-node'});for(const k of live)if(!state.props[k])issues.push({id:k,issue:'node-without-props'});return issues}
  // Parked documents: park replaces a board's document; parts patch merges per part.
  function park(boardId,doc){key(boardId,'artboard');const next=normaliseParked(doc,null);set('parked',Object.freeze({...state.parked,[boardId]:next}));return next}
  function commitParked(boardId,parts){const cur=state.parked[boardId];if(!cur)throw new Error('Board is not parked');const next=normaliseParked(parts,cur);set('parked',Object.freeze({...state.parked,[boardId]:next}));return next}
  function unpark(boardId){if(!state.parked[boardId])return null;const doc=state.parked[boardId],next={...state.parked};delete next[boardId];set('parked',Object.freeze(next));return doc}
  const parked=boardId=>state.parked[boardId]||null;
  const parkedRecord=(boardId,slice,recordId,k)=>state.parked[boardId]?.[slice]?.[recordId]?.[k];
  function setParkedRecord(boardId,slice,recordId,k,value){const cur=state.parked[boardId];if(!cur)throw new Error('Board is not parked');if(slice!=='props'&&slice!=='referenceProps')throw new TypeError('Unknown parked record slice');const rec=cur[slice][recordId];if(!rec)throw new Error('Property write to a record outside the parked document');if(sameValue(rec[k],value)&&(value!==undefined||!(k in rec)))return cur;const records=normaliseProps({set:{[recordId]:{[k]:value}}},cur[slice],slice);const next=Object.freeze({...cur,[slice]:records});set('parked',Object.freeze({...state.parked,[boardId]:next}));return next}
  function setParkedParent(boardId,nodeId,parentId){const cur=state.parked[boardId];if(!cur)throw new Error('Board is not parked');if(!Object.prototype.hasOwnProperty.call(cur.tree.parents,nodeId))throw new Error('Parent write to a node outside the parked document');if(cur.tree.parents[nodeId]===parentId)return cur;return commitParked(boardId,{tree:{layers:cur.tree.layers,groups:cur.tree.groups,parents:{...cur.tree.parents,[nodeId]:parentId}}})}
  // Parked boards must be known boards and never the active one; each document must be self-consistent.
  function verifyParked(){const issues=[],boards=new Set(state.boards.ids);for(const [k,d] of Object.entries(state.parked)){if(!boards.has(k))issues.push({board:k,issue:'parked-unknown-board'});if(k===state.boards.active)issues.push({board:k,issue:'active-board-parked'});issues.push(...verifyParkedDoc(k,d))}return issues}
  function commitSession(patch){const next=normaliseSession(patch,state.session);if(Object.keys(next).some(k=>next[k]!==state.session[k]))set('session',next);return state.session}
  function commitCoordinates(value){const next=normaliseCoordinates(value);if(JSON.stringify(next)!==JSON.stringify(state.coordinates))set('coordinates',next);return state.coordinates}
  // Collection records must exist exactly for collection members.
  function verifyRecords(){const issues=[],check=(slice,ids)=>{const live=new Set(ids);for(const k of Object.keys(state[slice]))if(!live.has(k))issues.push({slice,id:k,issue:'record-without-member'});for(const k of live)if(!state[slice][k])issues.push({slice,id:k,issue:'member-without-record'})};check('boardProps',state.boards.ids);check('referenceProps',state.references.ids);return issues}
  const snapshot=()=>JSON.parse(JSON.stringify({selected:state.selection.selected,anchor:state.selection.anchor,active:state.selection.active}));
  const snapshotDocument=()=>JSON.parse(JSON.stringify({selection:state.selection,tree:state.tree,references:state.references,boards:state.boards,document:state.document,props:state.props,boardProps:state.boardProps,referenceProps:state.referenceProps,coordinates:state.coordinates,parked:state.parked,session:state.session}));
  function restoreDocument(doc){const tree=normaliseTree(doc.tree||{},EMPTY_TREE),selection=normaliseSelection(doc.selection||{},EMPTY_SELECTION),references=normaliseReferences(doc.references||{},EMPTY_REFERENCES),boards=normaliseBoards(doc.boards||{},EMPTY_BOARDS),documentSize=normaliseDocument(doc.document||{},EMPTY_DOCUMENT);set('document',documentSize);set('props',normaliseProps({set:doc.props||{}},EMPTY_PROPS));set('boardProps',normaliseProps({set:doc.boardProps||{}},EMPTY_PROPS,'boardProps'));set('referenceProps',normaliseProps({set:doc.referenceProps||{}},EMPTY_PROPS,'referenceProps'));{const p={};for(const [k,d] of Object.entries(doc.parked||{}))p[key(k,'artboard')]=normaliseParked(d,null);set('parked',Object.freeze(p))}set('session',normaliseSession(doc.session||{},EMPTY_SESSION));set('coordinates',doc.coordinates?normaliseCoordinates(doc.coordinates):EMPTY_COORDINATES);set('tree',tree);set('selection',selection);set('references',references);set('boards',boards);return state}
  // v267: call tracing for native shadow mode. Only outermost calls are reported (nested public calls are not).
  let tracer=null,depth=0;
  const traced=(name,fn)=>function(...args){depth++;let ok=true,error=null;try{return fn.apply(this,args)}catch(e){ok=false;error=e&&e.message;throw e}finally{depth--;if(depth===0&&tracer){try{tracer(name,args,ok,error)}catch(_){}}}};
  const store={get:view,tree:()=>state.tree,state:()=>state,commit,prune,replace,reset,commitTree,references:()=>state.references,boards:()=>state.boards,commitReferences,commitBoards,document:()=>state.document,commitDocument,props:()=>state.props,prop,setProp,commitProps,verifyProps,records:slice=>state[slice],coordinates:()=>state.coordinates,commitCoordinates,session:()=>state.session,commitSession,park,commitParked,unpark,parked,parkedRecord,setParkedRecord,setParkedParent,verifyParked,record,setRecord,commitRecords,verifyRecords,verify:()=>verifyTree(state.tree),verifyCollections:()=>verifyCollections(state),subscribe(f){listeners.add(f);return()=>listeners.delete(f)},snapshot,snapshotDocument,restoreDocument,setTracer(f){tracer=typeof f==='function'?f:null}};
  for(const name of ['commit','prune','replace','reset','commitTree','commitReferences','commitBoards','commitDocument','commitProps','setProp','commitCoordinates','commitSession','park','commitParked','unpark','setParkedRecord','setParkedParent','setRecord','commitRecords','restoreDocument'])store[name]=traced(name,store[name]);
  if(initial)store.replace(initial);
  return Object.freeze(store);
 }
 return Object.freeze({create,normaliseSelection,normaliseTree,normaliseReferences,normaliseBoards,normaliseDocument,normaliseProps,PROP_KEYS,BOARD_KEYS,REFERENCE_KEYS,RECORD_SLICES,PARKED_PARTS,normaliseParked,normaliseSession,verifyTree,verifyCollections,normalise:normaliseSelection});
})();
if(typeof module!=='undefined'&&module.exports)module.exports=BungalowDocumentStore;
