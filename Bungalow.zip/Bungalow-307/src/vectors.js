
/* Basic vector geometry is retained independently of the layer's display cache. */
var VECTOR_KINDS=['rectangle','rounded','ellipse','triangle','diamond','polygon','star','line','arrow','heart','cross','grid'];
var VECTOR_KINDS_ALL=VECTOR_KINDS.concat('path'); // 'path' = imported SVG geometry, never offered for drawing
function validVectorGradient(gr){return !!gr&&['linear','radial','angle','reflected'].includes(gr.type)&&['a','b'].every(k=>gr[k]&&Number.isFinite(gr[k].x)&&Number.isFinite(gr[k].y)&&Math.abs(gr[k].x)<=1000&&Math.abs(gr[k].y)<=1000)&&['oklab','linear','srgb'].includes(gr.space)&&Array.isArray(gr.stops)&&gr.stops.length>=2&&gr.stops.length<=32&&gr.stops.every(st=>Number.isFinite(st.t)&&st.t>=0&&st.t<=1&&/^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(st.v)&&(st.mid===undefined||st.mid>=.02&&st.mid<=.98)&&(st.interp===undefined||['linear','smooth','easeIn','easeOut','step'].includes(st.interp)))}
function validImportedPath(s){return typeof s.d==='string'&&s.d.length>0&&s.d.length<=400000&&Array.isArray(s.m)&&s.m.length===6&&s.m.every(Number.isFinite)&&['bx','by','bw','bh'].every(k=>Number.isFinite(s[k]))&&s.bw>=0&&s.bh>=0}
// radius/sides/inner/flip/strokeAlign/fillMode/gradient/join/cap are optional so shapes saved before they existed still load.
function validVectorShape(s){if(!validVectorStroke(s))return false;if(s?.kind==='empty')return s.x===0&&s.y===0&&s.w===1&&s.h===1;if(s?.kind==='path'&&typeof s.d!=='string')return validVectorShape({...s,kind:'rectangle'})&&validPenPath(s);if(s?.kind==='brushstroke')return !!window.VectorBrush?.valid(s);const opt=(k,lo,hi)=>s[k]===undefined||Number.isFinite(s[k])&&s[k]>=lo&&s[k]<=hi;return !!s&&VECTOR_KINDS_ALL.includes(s.kind)&&['fill','stroke','both','none'].includes(s.paint)&&['x','y','w','h','strokeWidth'].every(k=>Number.isFinite(s[k])&&Math.abs(s[k])<=100000)&&(s.kind==='line'||s.kind==='path'?s.w>=0&&s.h>=0&&s.w+s.h>0:s.w>0&&s.h>0)&&s.strokeWidth>=0&&s.strokeWidth<=1000&&/^#[0-9a-f]{6}$/i.test(s.colour)&&/^#[0-9a-f]{6}$/i.test(s.strokeColour)&&opt('radius',0,100000)&&(s.sides===undefined||Number.isInteger(s.sides)&&s.sides>=3&&s.sides<=32)&&['xDivisions','yDivisions'].every(k=>s[k]===undefined||Number.isInteger(s[k])&&s[k]>=1&&s[k]<=256)&&opt('inner',.05,.95)&&opt('fillOpacity',0,1)&&opt('strokeOpacity',0,1)&&(s.flip===undefined||typeof s.flip==='boolean')&&(s.strokeAlign===undefined||['center','inside','outside'].includes(s.strokeAlign))&&(s.fillMode===undefined||['solid','gradient'].includes(s.fillMode))&&(s.gradient==null||validVectorGradient(s.gradient))&&(s.fillMode!=='gradient'||validVectorGradient(s.gradient))&&(s.join===undefined||['round','miter','bevel'].includes(s.join))&&(s.cap===undefined||['butt','round','square'].includes(s.cap))&&(s.kind!=='path'||validImportedPath(s))&&(s.wrapExclude===undefined||typeof s.wrapExclude==='boolean')}
// Outline of each basic shape inside its x/y/w/h box. A line runs corner to corner (flip = bottom-left to top-right).
function vectorPath(g,s){
 const {x,y,w,h}=s,cx=x+w/2,cy=y+h/2,TAU=Math.PI*2,P=(u,v)=>[x+u*w,y+v*h],poly=pts=>{pts.forEach(([px,py],i)=>i?g.lineTo(px,py):g.moveTo(px,py));g.closePath()};
 switch(s.kind){
 case 'path':tracePenPath(g,s);break;
  case 'ellipse':g.ellipse(cx,cy,w/2,h/2,0,0,TAU);break;
  case 'triangle':poly([[cx,y],[x+w,y+h],[x,y+h]]);break;
  case 'diamond':poly([[cx,y],[x+w,cy],[cx,y+h],[x,cy]]);break;
  case 'rounded':{const r=Math.max(0,Math.min(s.radius??24,w/2,h/2));g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath();break}
  case 'polygon':case 'star':{const n=Math.max(3,Math.min(32,Math.round(s.sides??5))),star=s.kind==='star',k=star?Math.max(.05,Math.min(.95,s.inner??.5)):1,m=star?n*2:n,pts=[];
   for(let i=0;i<m;i++){const a=-Math.PI/2+i*TAU/m,r=star&&i%2?k:1;pts.push([cx+Math.cos(a)*w/2*r,cy+Math.sin(a)*h/2*r])}poly(pts);break}
  case 'grid':{g.rect(x,y,w,h);for(let i=1;i<(s.xDivisions??4);i++){const X=x+w*i/(s.xDivisions??4);g.moveTo(X,y);g.lineTo(X,y+h)}for(let i=1;i<(s.yDivisions??4);i++){const Y=y+h*i/(s.yDivisions??4);g.moveTo(x,Y);g.lineTo(x+w,Y)}break}
  case 'line':{const[a,b]=s.flip?[P(0,1),P(1,0)]:[P(0,0),P(1,1)];g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);break}
  case 'arrow':{const hl=Math.min(w*.5,h*.6),bx=x+w-hl;poly([[x,y+h*.3],[bx,y+h*.3],[bx,y],[x+w,cy],[bx,y+h],[bx,y+h*.7],[x,y+h*.7]]);break}
  case 'cross':{const x1=x+w/3,x2=x+w*2/3,y1=y+h/3,y2=y+h*2/3;poly([[x1,y],[x2,y],[x2,y1],[x+w,y1],[x+w,y2],[x2,y2],[x2,y+h],[x1,y+h],[x1,y2],[x,y2],[x,y1],[x1,y1]]);break}
  case 'heart':{const c=(a,b,d,e,f,t)=>g.bezierCurveTo(...P(a,b),...P(d,e),...P(f,t));g.moveTo(...P(.5,1));c(.12,.8,0,.55,0,.32);c(0,.1,.15,0,.27,0);c(.4,0,.5,.12,.5,.28);c(.5,.12,.6,0,.73,0);c(.85,0,1,.1,1,.32);c(1,.55,.88,.8,.5,1);g.closePath();break}
  default:g.rect(x,y,w,h)}
}
// live=true while dragging: skips the thumbnail redraw (and its content-bounds scan) and clone sync; the final draw does them once.
// ---- imported paths, gradient fills, stroke position ----
const importedPathCache=new Map();
function importedBase(d){let p=importedPathCache.get(d);if(!p){p=new Path2D(d);importedPathCache.set(d,p);if(importedPathCache.size>96)importedPathCache.delete(importedPathCache.keys().next().value)}return p}
// Path2D of an imported shape in document space: the svg element's matrix, then its bounds fitted into the shape's box.
// unit=true gives box-relative (0..1) coordinates, which is what gradient fills are defined in.
function importedPath(s,unit=false){
 const bw=s.bw>1e-6?s.bw:1,bh=s.bh>1e-6?s.bh:1;
 const F=unit?[1/bw,0,0,1/bh,-s.bx/bw,-s.by/bh]:(()=>{const sx=s.bw>1e-6?s.w/s.bw:1,sy=s.bh>1e-6?s.h/s.bh:1;return [sx,0,0,sy,s.x-s.bx*sx,s.y-s.by*sy]})();
 const t=instMul(F,s.m||[1,0,0,1,0,0]),p=new Path2D();p.addPath(importedBase(s.d),{a:t[0],b:t[1],c:t[2],d:t[3],e:t[4],f:t[5]});return p;
}
const vectorGradientCache=new WeakMap();
// Sampled colour stops for a gradient (blend space, curves and midpoints honoured), cached per immutable gradient object.
function vectorGradientStops(gr){
 let hit=vectorGradientCache.get(gr);if(hit)return hit;
 const GK2=globalThis.BungalowGradient,G=new GK2.Gradient(gr.stops.map(st=>({t:st.t,v:st.v,mid:st.mid??.5,interp:st.interp||'linear'})));G.space=gr.space||'oklab';
 const ts=new Set();for(let i=0;i<=64;i++)ts.add(i/64);
 G.stops.forEach((st,i)=>{ts.add(st.t);const n=G.stops[i+1];if(n&&st.interp==='step'){const p=st.t+(n.t-st.t)*st.mid;ts.add(Math.max(0,p-1e-4));ts.add(Math.min(1,p+1e-4))}});
 hit=[...ts].sort((a,b)=>a-b).map(t=>[t,GK2.Col.css(G.sample(t))]);vectorGradientCache.set(gr,hit);return hit;
}
// CanvasGradient in box-relative coordinates (the caller scales the context to the shape's box).
function vectorGradientStyle(g,gr){
 const a=gr.a,b=gr.b,stops=vectorGradientStops(gr);let list=stops,grd;
 if(gr.type==='radial')grd=g.createRadialGradient(a.x,a.y,0,a.x,a.y,Math.max(Math.hypot(b.x-a.x,b.y-a.y),1e-6));
 else if(gr.type==='angle'&&g.createConicGradient)grd=g.createConicGradient(Math.atan2(b.y-a.y,b.x-a.x),a.x,a.y);
 else if(gr.type==='reflected'){grd=g.createLinearGradient(2*a.x-b.x,2*a.y-b.y,b.x,b.y);list=[...stops.slice().reverse().map(([t,c])=>[.5-t/2,c]),...stops.map(([t,c])=>[.5+t/2,c])]}
 else grd=g.createLinearGradient(a.x,a.y,b.x,b.y);
 for(const [t,c] of list)grd.addColorStop(Math.min(1,Math.max(0,t)),c);
 return grd;
}
// Fill and stroke, with the stroke centred on the outline, inside it or outside it.
function paintVectorShape(g,s){if(s.kind==='empty')return;
 if(s.kind==='brushstroke'){VectorBrush.paint(g,s);return}
 g.save();applyVectorStroke(g,s);
 const isPath=s.kind==='path'&&typeof s.d==='string',ps=vectorPaintState(s),line=s.kind==='line',rule=s.evenodd?'evenodd':'nonzero',geom=isPath?importedPath(s):null;
 if(!isPath){g.beginPath();vectorPath(g,s)}
 const fillNow=()=>{
  g.save();g.globalAlpha=s.fillOpacity??1;
  if(s.fillMode==='gradient'&&s.gradient&&s.w>0&&s.h>0){g.translate(s.x,s.y);g.scale(s.w,s.h);g.fillStyle=vectorGradientStyle(g,s.gradient);if(isPath)g.fill(importedPath(s,true),rule);else g.fill(rule)}
  else{g.fillStyle=s.colour;if(isPath)g.fill(geom,rule);else g.fill(rule)}
  g.restore();
 };
 const strokeNow=w=>{g.save();g.globalAlpha=(line&&s.paint==='fill'?s.fillOpacity:s.strokeOpacity)??1;g.lineWidth=w;g.strokeStyle=line&&s.paint==='fill'?s.colour:s.strokeColour;if(isPath)g.stroke(geom);else g.stroke();g.restore()};
 if(isPath){if(s.join&&s.strokeJoin===undefined)g.lineJoin=s.join;if(s.cap&&s.strokeCap===undefined)g.lineCap=s.cap}   // imported SVG paths keep their own caps and joins
 if(line){if(ps.stroke)strokeNow(Math.max(s.strokeWidth,1));g.restore();return}
 const hasFill=ps.fill,hasStroke=ps.stroke&&s.strokeWidth>0,align=s.kind==='grid'?'center':s.strokeAlign||'center';
 if(hasStroke&&align==='outside'){
  strokeNow(s.strokeWidth*2);g.save();g.globalCompositeOperation='destination-out';g.fillStyle='#000';if(isPath)g.fill(geom,rule);else g.fill(rule);g.restore();if(hasFill)fillNow();
 }else{
  if(hasFill)fillNow();
  if(hasStroke){if(align==='inside'){g.save();if(isPath)g.clip(geom,rule);else g.clip(rule);strokeNow(s.strokeWidth*2);g.restore()}else strokeNow(s.strokeWidth)}
 }
 g.restore();
}
function defaultVectorGradient(){let a='#3b82f6',b='#ffffff';try{a=col.value;b=hex(...colourSlots[1])}catch(_){}return {type:'linear',a:{x:.5,y:0},b:{x:.5,y:1},space:'oklab',stops:[{t:0,v:a,mid:.5,interp:'linear'},{t:1,v:b,mid:.5,interp:'linear'}]}}
// geometry (box-relative) for a gradient type and angle in degrees
function vgGeometry(type,deg){const r=deg*Math.PI/180,dx=Math.cos(r),dy=Math.sin(r);
 if(type==='radial')return {a:{x:.5,y:.5},b:{x:.5+dx*.7071,y:.5+dy*.7071}};
 if(type==='angle')return {a:{x:.5,y:.5},b:{x:.5+dx*.5,y:.5+dy*.5}};
 const L=(Math.abs(dx)+Math.abs(dy))/2;
 if(type==='reflected')return {a:{x:.5,y:.5},b:{x:.5+dx*L,y:.5+dy*L}};
 return {a:{x:.5-dx*L,y:.5-dy*L},b:{x:.5+dx*L,y:.5+dy*L}}}
const VECTOR_GRADIENT_UI=`<canvas class="vg-bar" aria-label="Gradient stops"></canvas>
<div class="vg-grid"><label>Stop position (%)<input class="vg-pos" type="number" min="0" max="100" step="1"></label><label>Stop colour<input class="vg-col" type="color"></label></div>
<label>Stop opacity<input class="vg-alpha" type="range" min="0" max="100"></label>
<div class="vg-grid"><label>Type<select class="vg-type"><option value="linear">Linear</option><option value="radial">Radial</option><option value="angle">Angle</option><option value="reflected">Reflected</option></select></label><label class="vg-angle-row">Angle<input class="vg-angle" type="range" min="0" max="359"></label></div>
<div class="vg-grid"><label>Blend in<select class="vg-space"><option value="oklab">OKLab</option><option value="linear">Linear RGB</option><option value="srgb">sRGB</option></select></label><label>Preset<select class="vg-preset"><option value="">Choose…</option><option value="fgbg">Colour → background</option><option value="fgclear">Colour → transparent</option><option value="sunset">Sunset</option><option value="ocean">Ocean</option><option value="spectrum">Spectrum</option><option value="chrome">Chrome</option></select></label></div>
<div class="vector-actions"><button type="button" class="vg-add">Add stop</button><button type="button" class="vg-del">Remove stop</button><button type="button" class="vg-rev">Reverse</button></div><p class="vector-status"></p>
`;
// ---- Shapes on sparse layers ----
// A shape is rasterised into a scratch canvas the size of its own bounds and written only into the 256px tiles it covers,
// so a small shape costs a few tiles instead of a document-sized canvas. Nothing here touches L.cv / L.ctx (that would thaw
// the layer); if something else thaws it, drawVectorLayer falls back to the dense path below.
// Turn off with localStorage.llSparseVectors='off'.
const vectorScratch=document.createElement('canvas');
function sparseVectorsOn(){try{return localStorage.getItem('llSparseVectors')!=='off'}catch(_){return true}}
// Document-space bounds of the transformed shape plus its stroke, clipped to the document (null = nothing visible).
function vectorBounds(I,s){const paint=vectorPaintState(s);if(!paint.stroke&&(!paint.fill||s.kind==='line'))return null;
 const cx=DW/2,cy=DH/2,sx=I.flipH?-1:1,sy=I.flipV?-1:1,M=instMul(I.xf||[1,0,0,1,0,0],[sx,0,0,sy,cx+(I.dx||0)-sx*cx,cy+(I.dy||0)-sy*cy]);
 let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
 for(const [px,py] of [[s.x,s.y],[s.x+s.w,s.y],[s.x,s.y+s.h],[s.x+s.w,s.y+s.h]]){const X=M[0]*px+M[2]*py+M[4],Y=M[1]*px+M[3]*py+M[5];x0=Math.min(x0,X);x1=Math.max(x1,X);y0=Math.min(y0,Y);y1=Math.max(y1,Y)}
 const sw=vectorPaintState(s).stroke?(s.kind==='line'?Math.max(s.strokeWidth,1):s.strokeWidth):0,reach=s.kind==='line'?.5:(s.strokeAlign==='outside'?1:s.strokeAlign==='inside'?0:.5)*(s.join==='miter'?4:1),padX=sw*reach*vectorStrokeExtent(s)*Math.hypot(M[0],M[2])+2,padY=sw*reach*vectorStrokeExtent(s)*Math.hypot(M[1],M[3])+2;
 const x=Math.max(0,Math.floor(x0-padX)),y=Math.max(0,Math.floor(y0-padY)),r=Math.min(DW,Math.ceil(x1+padX)),b=Math.min(DH,Math.ceil(y1+padY));
 return r>x&&b>y?{x,y,w:r-x,h:b-y}:null;
}
const vectorUnion=(a,b)=>{const x=Math.min(a.x,b.x),y=Math.min(a.y,b.y);return {x,y,w:Math.max(a.x+a.w,b.x+b.w)-x,h:Math.max(a.y+a.h,b.y+b.h)-y}};
// Replace `rect` with `src` (positioned at ox,oy; null = just clear). Existing tiles are reused, tiles the shape no longer
// touches are cleared and pruned at idle, so dragging does not churn canvases.
function vectorWriteSparse(L,rect,src,ox,oy){
 const store=L._sparse,keys=[],S=store.tileSize,candidates=new Map();
 // Clear populated old tiles, then write only tiles covered by the new surface.
 // The empty rectangle between distant positions never needs to be enumerated.
 for(const k of store.tiles.keys()){const [x,y]=k.split(':').map(Number);if(x<rect.x+rect.w&&x+S>rect.x&&y<rect.y+rect.h&&y+S>rect.y)candidates.set(k,{k,x,y})}
 if(src){const x=Math.max(rect.x,ox),y=Math.max(rect.y,oy),right=Math.min(rect.x+rect.w,ox+src.width),bottom=Math.min(rect.y+rect.h,oy+src.height);if(right>x&&bottom>y)for(const t of sparseTileList(store,{x,y,w:right-x,h:bottom-y}))candidates.set(t.k,t)}
 for(const t of candidates.values()){ 
  const touches=!!src&&t.x<ox+src.width&&t.x+S>ox&&t.y<oy+src.height&&t.y+S>oy,tile=sparseTile(store,t.x,t.y,touches);if(!tile)continue;tile.__occ=null;
  const ix0=Math.max(t.x,rect.x),iy0=Math.max(t.y,rect.y),ix1=Math.min(t.x+tile.width,rect.x+rect.w),iy1=Math.min(t.y+tile.height,rect.y+rect.h);if(ix1<=ix0||iy1<=iy0)continue;
  const g=tile.getContext('2d');g.save();g.globalCompositeOperation='source-over';g.globalAlpha=1;g.clearRect(ix0-t.x,iy0-t.y,ix1-ix0,iy1-iy0);
  if(src){const sx0=Math.max(ix0,ox),sy0=Math.max(iy0,oy),sx1=Math.min(ix1,ox+src.width),sy1=Math.min(iy1,oy+src.height);if(sx1>sx0&&sy1>sy0)g.drawImage(src,sx0-ox,sy0-oy,sx1-sx0,sy1-sy0,sx0-t.x,sy0-t.y,sx1-sx0,sy1-sy0)}
  g.restore();keys.push(t.k);
 }
 sparsePruneLater(store,keys);
}
function drawVectorSparse(L,I,s,live){
 const next=vectorObjectBounds(I),prev=L._vecRect===undefined?{x:0,y:0,w:DW,h:DH}:L._vecRect;let src=null; // undefined = unknown extent (loaded or duplicated layer): clear everything once
 if(next){const c=vectorScratch;if(c.width!==next.w)c.width=next.w;if(c.height!==next.h)c.height=next.h;const g=c.getContext('2d');g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);g.translate(-next.x,-next.y);withInstance(g,I,()=>paintVectorObjects(g,I));src=c}
 const rect=prev&&next?vectorUnion(prev,next):(prev||next);
 if(rect)vectorWriteSparse(L,rect,src,next?next.x:0,next?next.y:0);
 L._vecRect=next;if(src&&src.width*src.height>4e6)src.width=src.height=1;
 if(!rect)return true;
 if(live){ // mark only the changed region; thumbnails, clones and the layer list wait for the final draw
  const d=L.compositeDirty;if(d!==null)L.compositeDirty=d?vectorUnion(d,rect):{...rect};
  L.maskRevision=(L.maskRevision||0)+1;scheduleLayerMasks();
 }else thumb(L,rect);
 return true;
}
// live=true while dragging: skips the thumbnail redraw (and its content-bounds scan) and clone sync; the final draw does them once.
// The Transform tool lifts a copy of each selected layer. Vector and text layers are edited as data (colour, stroke...), so after
// such an edit the lifted copy is rebuilt from the layer's new pixels and the preview updates while transforming.
var transformRefreshSet=new Set(),transformRefreshAll=false,transformRefreshFrame=0;
function queueTransformSourceRefresh(L){
 if(typeof transformSession==='undefined'||!transformSession||transformSession.crop||!transformSession.items)return;
 if(L&&!transformSession.items.some(i=>i.layer===L))return;
 if(L)transformRefreshSet.add(L);else transformRefreshAll=true;
 if(!transformRefreshFrame)transformRefreshFrame=requestAnimationFrame(()=>{transformRefreshFrame=0;const list=transformRefreshAll?null:[...transformRefreshSet];transformRefreshSet.clear();transformRefreshAll=false;refreshTransformInstanceSources(list)});
}
function refreshTransformInstanceSources(only){
 const t=transformSession;if(!t||t.crop||!t.items)return;let changed=false;
 for(const item of t.items){
  const L=item.layer;if(!L?.instance||only&&!only.includes(L))continue;
  const full=mk(),g=full.getContext('2d');if(L._sparse)sparseDraw(g,L._sparse);else g.drawImage(L._canvas||L.cv,0,0);
  const b=t.bounds;item.selected=full;item.source=patch(full,b.x-(item.originX||0),b.y-(item.originY||0),b.width,b.height);
  let fast=item.source;if(Math.max(item.source.width,item.source.height)>1024){fast=document.createElement('canvas');const r=1024/Math.max(item.source.width,item.source.height);fast.width=Math.max(1,Math.round(item.source.width*r));fast.height=Math.max(1,Math.round(item.source.height*r));fast.getContext('2d').drawImage(item.source,0,0,fast.width,fast.height)}
  item.fastSource=fast;item.bicubicResult=null;changed=true;
 }
 if(changed)updateTransformPreview();
}
function drawVectorLayer(L,live=false){
 if(L.instance?.shape?.kind==='brushstroke'&&!VectorBrush.ready(L))return;
 queueWrappedTextRefresh();
 if(vectoring)startVectorGizmo();
 const I=L.instance,s=I.shape;
 queueTransformSourceRefresh(L);
 if(L._sparse&&drawVectorSparse(L,I,s,live))return;
 const g=L.ctx;clearLayerPixels(L);
 withInstance(g,I,()=>paintVectorObjects(g,I));
 if(live){L.compositeDirty=null;L.maskRevision=(L.maskRevision||0)+1;scheduleLayerMasks();return}
 instanceTouched(L);
}
// ---- icons for the shape list ----
const VECTOR_ICONS={grid:'M4 4h16v16H4zM9 4v16M15 4v16M4 9h16M4 15h16',rectangle:'M4 6h16v12H4z',rounded:'M8 5h8a4 4 0 0 1 4 4v6a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4V9a4 4 0 0 1 4-4z',ellipse:'M12 5c4.4 0 8 3 8 7s-3.6 7-8 7-8-3-8-7 3.6-7 8-7z',triangle:'M12 4 21 19H3z',diamond:'M12 3 21 12l-9 9-9-9z',polygon:'M12 3l8.5 6.2-3.2 10H6.7L3.5 9.2z',star:'M12 3l2.8 5.9 6.4.9-4.6 4.5 1.1 6.4L12 17.6l-5.7 3.1 1.1-6.4-4.6-4.5 6.4-.9z',line:'M5 19 19 5',arrow:'M4 9.5h9V5l7 7-7 7v-4.5H4z',heart:'M12 20 4.5 12.5C1.5 9 3.5 4.5 7.5 4.5c2 0 3.5 1 4.5 2.5 1-1.5 2.5-2.5 4.5-2.5 4 0 6 4.5 3 8z',cross:'M9 4h6v5h5v6h-5v5H9v-5H4V9h5z',path:'M4 18C8 4 16 20 20 6M4 18h.01M20 6h.01'};
function vectorShapeIcon(kind){return svgNode("svg",{"class":"preset-ico","viewBox":"0 0 24 24","aria-hidden":"true"},[svgNode("path",{"d":VECTOR_ICONS[kind]||VECTOR_ICONS.rectangle},[])])}

// ---- shared helpers for editing shapes and text together ----
function selectedVectorObjects(includeLocked=false){return layers.filter(L=>selectedStack.has(L)&&(L.instance?.type==='shape'&&!['empty','brushstroke'].includes(L.instance.shape.kind)||L.instance?.type==='text')&&(includeLocked||!layerLocked(L)&&!groupLocked(L.group)))}
// The colour that is actually visible: a line or outline-only shape shows its stroke colour, everything else its fill.
function vectorColourKey(s){return s.kind==='line'?(s.paint==='fill'?'colour':'strokeColour'):(s.paint==='stroke'?'strokeColour':'colour')}
// entries: [{L, patch}]. Shapes patch their shape record, text patches its style keys. One undo step, one redraw per layer.
function applyVectorPatches(entries){
 flushPendingHistoryControls();
 const items=entries.filter(({L,patch})=>{const cur=L.instance.type==='shape'?L.instance.shape:L.instance;return Object.keys(patch).some(k=>cur[k]!==patch[k])});
 if(!items.length)return false;
 const before=items.map(({L})=>L.instance.type==='shape'?{...L.instance.shape}:textStyleOf(L.instance)),after=items.map(({patch},i)=>({...before[i],...patch}));
 const apply=values=>{items.forEach(({L},i)=>{const I=L.instance;if(I.type==='shape'){I.shape={...values[i]};drawVectorLayer(L)}else{Object.assign(I,values[i]);delete I.bbox;drawTextLayer(L)}});renderLayers();BungalowVectors.sync();if(AL?.instance?.type==='text')loadTextUI(AL.instance);if(typeof syncTextToolSettings==='function')syncTextToolSettings()};
 apply(after);doH({bytes:0,undo:()=>apply(before),redo:()=>apply(after)});return true;
}
// Smart fill on shapes and text: recolour with the current colour. Returns false when the active layer is not a vector object.
function smartFillVectors(){
 if(AL?.instance?.shape?.kind==='brushstroke'){toast('Vector brush strokes retain their captured colour; rasterise to recolour');return true}
 if(!AL?.instance||!['shape','text'].includes(AL.instance.type))return false;
 let list=selectedVectorObjects();
 if(!list.length){toast('Layer “'+AL.name+'” is locked');return true}
 const c=col.value,changed=applyVectorPatches(list.map(L=>({L,patch:L.instance.type==='shape'?(vectorColourKey(L.instance.shape)==='colour'?{colour:c,fillMode:'solid'}:{strokeColour:c}):{colour:c}})));
 addRecent();uiNotice(changed?'Colour applied to '+list.length+' vector object'+(list.length>1?'s':''):'Already that colour');return true;
}
// ---- copy / paste style ----
var copiedVectorStyle=null;
function copyVectorStyle(){
 if(typeof flushTextStyleEdit==='function')flushTextStyleEdit();
 const list=selectedVectorObjects(true),L=list.includes(AL)?AL:list[0];
 if(!L){toast('Select a shape or text object first');return}
 const I=L.instance;
 if(I.type==='shape'){const s=I.shape;copiedVectorStyle={type:'shape',paint:s.paint,colour:s.colour,strokeColour:s.strokeColour,strokeWidth:s.strokeWidth,paintStates:s.paintStates,...vectorStrokeStyle(s),strokeAlign:s.strokeAlign||'center',fillOpacity:s.fillOpacity??1,strokeOpacity:s.strokeOpacity??1,fillMode:s.fillMode||'solid',gradient:s.gradient||null,visible:s.fillMode==='gradient'&&vectorColourKey(s)==='colour'&&s.gradient?s.gradient.stops[0].v.slice(0,7):s[vectorColourKey(s)]}}
 else{const style=textStyleOf(I);copiedVectorStyle={type:'text',style,visible:style.colour};copiedTextStyle=style}
 toast((I.type==='shape'?'Shape':'Text')+' style copied');BungalowVectors.sync();
}
function pasteVectorStyle(){
 const c=copiedVectorStyle;if(!c){toast('Copy a style first');return}
 const targets=selectedVectorObjects();if(!targets.length){toast('Select a shape or text object to paste onto');return}
 const changed=applyVectorPatches(targets.map(L=>{const I=L.instance;let patch;
  if(I.type==='shape')patch=c.type==='shape'?{paint:c.paint,colour:c.colour,strokeColour:c.strokeColour,strokeWidth:c.strokeWidth,paintStates:c.paintStates,...vectorStrokeStyle(c),strokeAlign:c.strokeAlign,fillOpacity:c.fillOpacity??1,strokeOpacity:c.strokeOpacity??1,fillMode:c.fillMode,...(c.gradient?{gradient:c.gradient}:{})}:{[vectorColourKey(I.shape)]:c.visible,...(vectorColourKey(I.shape)==='colour'?{fillMode:'solid'}:{})};
  else patch=c.type==='text'?{...c.style}:{colour:c.visible};
  return {L,patch}}));
 uiNotice(changed?'Style pasted onto '+targets.length+' object'+(targets.length>1?'s':''):'Nothing to change');
}
// ---- snapping while drawing ----
const vectorSnapCanvas=document.createElement('canvas');vectorSnapCanvas.id='vectorSnapGuides';vectorSnapCanvas.setAttribute('aria-hidden','true');
vectorSnapCanvas.className='vector-canvas-overlay vector-snap-overlay';wrap.append(vectorSnapCanvas);
// gx / gy: document coordinates of the snapped vertical / horizontal line (null = none). Lines follow the view rotation.
function showVectorSnap(gx,gy){
 const c=vectorSnapCanvas,dpr=devicePixelRatio||1,w=wrap.clientWidth,h=wrap.clientHeight;
 if(c.width!==Math.round(w*dpr)||c.height!==Math.round(h*dpr)){c.width=Math.round(w*dpr);c.height=Math.round(h*dpr)}
 const g=c.getContext('2d');g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,w,h);if(gx==null&&gy==null)return;
 const line=(a,b)=>{const p=gradToWrap(a),q=gradToWrap(b);g.beginPath();g.moveTo(p.x,p.y);g.lineTo(q.x,q.y);g.lineWidth=3;g.strokeStyle='rgba(0,0,0,.45)';g.stroke();g.lineWidth=1;g.strokeStyle=gradCss('--ac')||'#3b82f6';g.stroke()};
 if(gx!=null)line({x:gx,y:0},{x:gx,y:DH});if(gy!=null)line({x:0,y:gy},{x:DW,y:gy});
}
const ALIGN_OPS=[['left','Align left','alignLeft'],['centre-x','Align horizontal centres','alignCentreX'],['right','Align right','alignRight'],['top','Align top','alignTop'],['centre-y','Align vertical centres','alignCentreY'],['bottom','Align bottom','alignBottom'],['distribute-x','Distribute horizontally','distributeX'],['distribute-y','Distribute vertically','distributeY']];
// Visual bounds of a shape in document space (stroke included, no anti-alias margin), used for align / distribute.
function vectorVisualBounds(I,s){
 const m=instanceMatrix(I);let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
 for(const [px,py] of [[s.x,s.y],[s.x+s.w,s.y],[s.x,s.y+s.h],[s.x+s.w,s.y+s.h]]){const p=m.transformPoint(new DOMPoint(px,py));x0=Math.min(x0,p.x);x1=Math.max(x1,p.x);y0=Math.min(y0,p.y);y1=Math.max(y1,p.y)}
 const sw=vectorPaintState(s).stroke?(s.kind==='line'?Math.max(s.strokeWidth,1):s.strokeWidth):0,reach=s.kind==='line'?.5:(s.strokeAlign==='outside'?1:s.strokeAlign==='inside'?0:.5),padX=sw*reach*vectorStrokeExtent(s)*Math.hypot(m.a,m.c),padY=sw*reach*vectorStrokeExtent(s)*Math.hypot(m.b,m.d);
 return {x:x0-padX,y:y0-padY,width:x1-x0+2*padX,height:y1-y0+2*padY};
}

// ---- the colour picker recolours the selected shapes, like it does for text ----
var vectorColourEdit=null,vectorColourFrame=0,vectorColourPending=null,vectorColourTimer=0;
function recolourVectorsLive(colour){
 if(!/^#[0-9a-f]{6}$/i.test(colour))return;
 const targets=selectedVectorObjects().filter(L=>L.instance.type==='shape').map(L=>({L,I:L.instance}));
 const prior=vectorColourPending?.targets||vectorColourEdit?.targets;
 if(prior&&(prior.length!==targets.length||prior.some((t,i)=>t.L!==targets[i].L||t.I!==targets[i].I)))flushVectorColourEdit();
 if(vectoring&&window.BungalowVectors){const d=BungalowVectors.defaults;d[vectorColourKey(d)]=colour}
 if(!targets.length){BungalowVectors.sync();return}
 // Capture recipients now: a later selection change must not redirect a queued colour.
 vectorColourPending={colour,targets};if(!vectorColourFrame)vectorColourFrame=requestAnimationFrame(applyVectorColourFrame);
 clearTimeout(vectorColourTimer);vectorColourTimer=setTimeout(flushVectorColourEdit,450);
}
function applyVectorColourFrame(){
 vectorColourFrame=0;const pending=vectorColourPending;vectorColourPending=null;if(!pending)return;
 const targets=pending.targets.filter(({L,I})=>layers.includes(L)&&L.instance===I&&!layerLocked(L)&&!groupLocked(L.group));if(!targets.length)return;
 if(vectorColourEdit&&(targets.length!==vectorColourEdit.targets.length||targets.some((t,i)=>t.L!==vectorColourEdit.targets[i].L||t.I!==vectorColourEdit.targets[i].I)))flushVectorColourEdit();
 const keepsGradient=I=>I.shape.fillMode==='gradient'&&vectorColourKey(I.shape)==='colour',changed=targets.some(({I})=>!keepsGradient(I)&&I.shape[vectorColourKey(I.shape)]!==pending.colour);if(!changed)return;
 if(!vectorColourEdit)vectorColourEdit={targets,before:targets.map(({I})=>({...I.shape}))};
 for(const {L,I} of targets){if(keepsGradient(I))continue;/* gradient fills keep their gradient */I.shape={...I.shape,[vectorColourKey(I.shape)]:pending.colour};drawVectorLayer(L,true)}
 BungalowVectors.sync();
}
function flushVectorColourEdit(){
 clearTimeout(vectorColourTimer);vectorColourTimer=0;
 if(vectorColourFrame){cancelAnimationFrame(vectorColourFrame);vectorColourFrame=0}if(vectorColourPending)applyVectorColourFrame();
 const edit=vectorColourEdit;vectorColourEdit=null;if(!edit)return;
 const after=edit.targets.map(({I})=>({...I.shape}));
 if(!edit.before.some((b,i)=>JSON.stringify(b)!==JSON.stringify(after[i])))return;
 const apply=values=>{edit.targets.forEach(({L,I},i)=>{if(L.instance!==I)return;I.shape={...values[i]};drawVectorLayer(L)});renderLayers();BungalowVectors.sync()};
 edit.targets.forEach(({L,I})=>{if(L.instance===I)drawVectorLayer(L)});renderLayers();doH({bytes:0,undo:()=>apply(edit.before),redo:()=>apply(after)});
}
const flushVectorEdits=()=>{flushVectorColourEdit();if(window.BungalowVectors?.flush)BungalowVectors.flush()};
addEventListener('pointerdown',flushVectorEdits,true);
addEventListener('keydown',()=>{if(window.BungalowVectors?.flush)BungalowVectors.flush()},true);
addEventListener('blur',flushVectorColourEdit);
for(const id of ['dock','palettePanel','pop'])for(const type of ['pointerup','change'])$(id)?.addEventListener(type,()=>queueMicrotask(flushVectorColourEdit));

// ---- on-canvas transform gizmo for the active shape: move, resize, rotate ----
const VG_HANDLES={nw:[0,0],n:[.5,0],ne:[1,0],e:[1,.5],se:[1,1],s:[.5,1],sw:[0,1],w:[0,.5]};
// New local box when handle (fx,fy) is dragged to local point p. ctrl = resize about the centre, shift = keep corner proportions.
function vgResizeBox(R,fx,fy,p,{ctrl=false,shift=false}={},min=1){
 const cx=R.x+R.w/2,cy=R.y+R.h/2,sx=fx===0?-1:fx===1?1:0,sy=fy===0?-1:fy===1?1:0,ax=fx===0?R.x+R.w:R.x,ay=fy===0?R.y+R.h:R.y;
 let w=R.w,h=R.h;
 if(sx)w=ctrl?2*Math.max(min/2,sx*(p.x-cx)):Math.max(min,sx*(p.x-ax));
 if(sy)h=ctrl?2*Math.max(min/2,sy*(p.y-cy)):Math.max(min,sy*(p.y-ay));
 if(shift&&sx&&sy&&R.w>0&&R.h>0){const k=Math.max(w/R.w,h/R.h);w=Math.max(min,R.w*k);h=Math.max(min,R.h*k)}
 return {x:ctrl?cx-w/2:sx===1?ax:sx===-1?ax-w:R.x,y:ctrl?cy-h/2:sy===1?ay:sy===-1?ay-h:R.y,w,h};
}
// The instance matrix is xf · (offset/flip about the page centre), so a rotation about document point C goes in front of xf.
function vgRotateXf(before,C,d){const cos=Math.cos(d),sin=Math.sin(d);return instMul([cos,sin,-sin,cos,C.x-(cos*C.x-sin*C.y),C.y-(sin*C.x+cos*C.y)],before||[1,0,0,1,0,0])}
const vectorGizmoCanvas=document.createElement('canvas');vectorGizmoCanvas.id='vectorGizmo';vectorGizmoCanvas.setAttribute('aria-hidden','true');
vectorGizmoCanvas.className='vector-canvas-overlay';wrap.append(vectorGizmoCanvas);
var vectorGizmoMode='scale',vectorBasicHover=null,vectorGizmoDrag=null,vectorGizmoFrame=0,vectorGizmoVisible=false;
function vectorGizmoTarget(){const L=AL;return vectoring&&!previewMode&&!document.body.classList.contains('nui')&&!vectorDrag&&L?.instance?.type==='shape'&&!['empty','brushstroke'].includes(L.instance.shape.kind)&&layerVisible(L)&&(referenceLayersVisible||!referenceTagged(L))&&layers.includes(L)&&selectedStack.has(L)&&!layerLocked(L)&&!groupLocked(L.group)?L:null}
function vectorGizmoGeometry(L){
 const I=L.instance,s=I.shape,m=instanceMatrix(I),P=(x,y)=>{const p=m.transformPoint(new DOMPoint(x,y));return {x:p.x,y:p.y}},cx=s.x+s.w/2,cy=s.y+s.h/2;
 const pts={nw:P(s.x,s.y),n:P(cx,s.y),ne:P(s.x+s.w,s.y),e:P(s.x+s.w,cy),se:P(s.x+s.w,s.y+s.h),s:P(cx,s.y+s.h),sw:P(s.x,s.y+s.h),w:P(s.x,cy)},c=P(cx,cy);
 const dx=pts.n.x-c.x,dy=pts.n.y-c.y,l=Math.hypot(dx,dy)||1,off=28/Math.max(z,.001); // rotate handle: 28 screen px beyond the top edge, away from the centre
 const gr=s.fillMode==='gradient'&&s.gradient&&s.w>0&&s.h>0?{a:P(s.x+s.gradient.a.x*s.w,s.y+s.gradient.a.y*s.h),b:P(s.x+s.gradient.b.x*s.w,s.y+s.gradient.b.y*s.h)}:null;
 return {pts,c,grad:gr,rot:{x:pts.n.x+dx/l*off,y:pts.n.y+dy/l*off}};
}
function vectorPoint(e){const p=screenToDoc(e);return [p.x,p.y]}
// Same picking rule as the Transform tool: the nearest handle within 18 px (22 for a pen). The gradient handles and the move node win ties.
function vectorGizmoHit(e){
 const multi=vectorMultiSelection();if(multi.length)return vectorMultiHit(e,multi);
 const L=vectorGizmoTarget();if(!L)return null;
 const g=vectorGizmoGeometry(L),[px,py]=vectorPoint(e),limit=penLike(e)?22:18,cands=[];
 if(g.grad){cands.push([g.grad.a,{L,type:'ga'},4],[g.grad.b,{L,type:'gb'},4])}
 cands.push([g.rot,{L,type:'rotate'},0],[g.c,{L,type:'move'},4]);
 for(const [k,[fx,fy]] of Object.entries(VG_HANDLES))cands.push([g.pts[k],{L,type:vectorGizmoMode==='rotate-skew'?(fx!==.5&&fy!==.5?'rotate':'skew'):'resize',fx,fy},0]);
 let best=null,score=Infinity;
 for(const [p,hit,bias] of cands){const d=Math.hypot(p.x-px,p.y-py)*z;if(d<=limit&&d-bias<score){score=d-bias;best=hit}}
 return best;
}
function vectorGizmoPointerDown(e){
 const multi=vectorMultiSelection();if(multi.length)return vectorMultiDown(e,multi);
 const hit=vectorGizmoHit(e);if(!hit)return false;e.preventDefault();
 flushVectorColourEdit();const L=hit.L,I=L.instance,B={shape:{...I.shape},xf:I.xf?[...I.xf]:null},m0=instanceMatrix(I),inv0=m0.inverse(),[sx0,sy0]=vectorPoint(e);
 const C=m0.transformPoint(new DOMPoint(B.shape.x+B.shape.w/2,B.shape.y+B.shape.h/2)),minSize=B.shape.kind==='line'?0:1;
 const targets=globalSnapOn?prepareSnapTargets({items:[{layer:L}]}):null,snapTo=(x,y,ev)=>targets?snapTextPoint(x,y,targets,ev):{x,y};
 const controller=new AbortController(),options={capture:true,signal:controller.signal},drag=vectorGizmoDrag={hit,moved:false,angle0:Math.atan2(sy0-C.y,sx0-C.x)};let frame=0;
 const redraw=()=>{frame=0;drawVectorLayer(L,true)},restore=()=>{I.shape={...B.shape};I.xf=B.xf?[...B.xf]:null};
 const finish=(cancel=false)=>{
  if(vectorGizmoDrag!==drag)return;vectorGizmoDrag=null;controller.abort();if(typeof modeCursor==='function')modeCursor();showVectorSnap(null,null);if(frame){cancelAnimationFrame(frame);frame=0}
  try{if(wrap.hasPointerCapture(e.pointerId))wrap.releasePointerCapture(e.pointerId)}catch(_){}
  if(cancel){restore();if(drag.moved)drawVectorLayer(L);BungalowVectors.sync();return}
  if(!drag.moved){vectorGizmoMode=vectorGizmoMode==='scale'?'rotate-skew':'scale';startVectorGizmo();return;}
  drawVectorLayer(L);const A={shape:{...I.shape},xf:I.xf?[...I.xf]:null},apply=st=>{I.shape={...st.shape};I.xf=st.xf?[...st.xf]:null;drawVectorLayer(L);renderLayers();BungalowVectors.sync()};
  doH({bytes:0,undo:()=>apply(B),redo:()=>apply(A)});renderLayers();BungalowVectors.sync();
 };
 drag.cancel=()=>finish(true);wrap.setPointerCapture(e.pointerId);if(typeof modeCursor==='function')modeCursor();
 window.addEventListener('pointermove',ev=>{
  if(ev.pointerId!==e.pointerId)return;ev.preventDefault();ev.stopImmediatePropagation();
  const [mx,my]=vectorPoint(ev);if(!drag.moved&&Math.hypot(mx-sx0,my-sy0)*z<3)return;drag.moved=true;
  const S=I.shape;let gx=null,gy=null;
  if(hit.type==='move'){
   let dx=mx-sx0,dy=my-sy0;if(ev.shiftKey){if(Math.abs(dx)>Math.abs(dy))dy=0;else dx=0}
   const q=snapTo(C.x+dx,C.y+dy,ev);if(Math.abs(q.x-(C.x+dx))>1e-6){dx=q.x-C.x;gx=q.x}if(Math.abs(q.y-(C.y+dy))>1e-6){dy=q.y-C.y;gy=q.y}
   S.x=B.shape.x+inv0.a*dx+inv0.c*dy;S.y=B.shape.y+inv0.b*dx+inv0.d*dy;
  }else if(hit.type==='ga'||hit.type==='gb'){
   const q=snapTo(mx,my,ev),p=inv0.transformPoint(new DOMPoint(q.x,q.y));if(Math.abs(q.x-mx)>1e-6)gx=q.x;if(Math.abs(q.y-my)>1e-6)gy=q.y;
   S.gradient={...B.shape.gradient,[hit.type==='ga'?'a':'b']:{x:B.shape.w>0?(p.x-B.shape.x)/B.shape.w:.5,y:B.shape.h>0?(p.y-B.shape.y)/B.shape.h:.5}};
  }else if(hit.type==='resize'){
   const q=snapTo(mx,my,{altKey:false,shiftKey:ev.shiftKey,ctrlKey:ev.ctrlKey,metaKey:ev.metaKey});if(Math.abs(q.x-mx)>1e-6)gx=q.x;if(Math.abs(q.y-my)>1e-6)gy=q.y;
   const box=vgResizeBox(B.shape,hit.fx,hit.fy,inv0.transformPoint(new DOMPoint(q.x,q.y)),{ctrl:ev.altKey,shift:ev.shiftKey||(typeof $==='function'&&!!$('transformRatioLock')?.checked)},minSize);if(box.w+box.h<=1e-6)return;Object.assign(S,box);
  }else if(hit.type==='skew'){const p=inv0.transformPoint(new DOMPoint(mx,my)),q=inv0.transformPoint(new DOMPoint(sx0,sy0)),cx=B.shape.x+B.shape.w/2,cy=B.shape.y+B.shape.h/2,horizontal=hit.fy!==.5,k=horizontal?(p.x-q.x)/Math.max(1,B.shape.h)*(hit.fy===0?-1:1):(p.y-q.y)/Math.max(1,B.shape.w)*(hit.fx===0?-1:1),v=ev.shiftKey?Math.round(k*10)/10:k,A=horizontal?[1,0,v,1,-v*cy,0]:[1,v,0,1,0,-v*cx],m=[m0.a,m0.b,m0.c,m0.d,m0.e,m0.f],inv=[inv0.a,inv0.b,inv0.c,inv0.d,inv0.e,inv0.f];I.xf=instMul(instMul(instMul(m,A),inv),B.xf||[1,0,0,1,0,0]);
  }else{
   let d=Math.atan2(my-C.y,mx-C.x)-drag.angle0;if(ev.shiftKey)d=Math.round(d/(Math.PI/12))*(Math.PI/12);I.xf=vgRotateXf(B.xf,C,d);
  }
  showVectorSnap(gx,gy);startVectorGizmo();if(!frame)frame=requestAnimationFrame(redraw);
 },options);
 window.addEventListener('pointerup',ev=>{if(ev.pointerId!==e.pointerId)return;ev.preventDefault();ev.stopImmediatePropagation();finish()},options);
 window.addEventListener('pointercancel',ev=>{if(ev.pointerId===e.pointerId)finish(true)},options);
 window.addEventListener('lostpointercapture',ev=>{if(ev.pointerId===e.pointerId)finish(true)},options);
 window.addEventListener('blur',()=>finish(true),options);
 window.addEventListener('keydown',ev=>{if(ev.key==='Escape'){ev.preventDefault();ev.stopImmediatePropagation();finish(true)}},options);
 return true;
}
function vectorGizmoDraw(){
 const multi=vectorMultiSelection();if(multi.length){vectorGizmoVisible=true;return vectorMultiDraw(multi)}
 const c=vectorGizmoCanvas,dpr=devicePixelRatio||1,w=wrap.clientWidth,h=wrap.clientHeight;
 if(c.width!==Math.round(w*dpr)||c.height!==Math.round(h*dpr)){c.width=Math.round(w*dpr);c.height=Math.round(h*dpr)}
 const g=c.getContext('2d');g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,w,h);
 vectorBasicOverlay.replaceChildren();if(window.BungalowPen?.active()){vectorGizmoVisible=true;BungalowPen.draw(g);return}
 const L=vectorGizmoTarget();vectorGizmoVisible=!!L;if(!L)return;
 const geo=vectorGizmoGeometry(L),W=p=>gradToWrap(p),pts=['nw','ne','se','sw'].map(k=>W(geo.pts[k])),path=pts.map((p,i)=>(i?'L':'M')+p.x+' '+p.y).join(' ')+' Z';let markup=gizmoOutlineMarkup(path);for(const p of pts)markup+=gizmoCornerMarkup(p,vectorGizmoMode==='rotate-skew');for(const k of ['n','e','s','w'])markup+=gizmoEdgeMarkup(W(geo.pts[k]),vectorGizmoMode==='rotate-skew');markup+=gizmoKnobMarkup(W(geo.pts.n),W(geo.rot));const centre=W(geo.c);markup+='<circle cx="'+centre.x+'" cy="'+centre.y+'" r="7" fill="white" stroke="#111"/><path d="M'+(centre.x-4)+' '+centre.y+'h8M'+centre.x+' '+(centre.y-4)+'v8" stroke="#111"/>';const hover=vectorGizmoDrag?.hit||vectorBasicHover;if(hover&&hover.L===L){const key=Object.keys(VG_HANDLES).find(k=>VG_HANDLES[k][0]===hover.fx&&VG_HANDLES[k][1]===hover.fy),p=W(hover.type==='move'?geo.c:key?geo.pts[key]:geo.rot);markup+='<circle class="vector-handle-hover" cx="'+p.x+'" cy="'+p.y+'" r="10"/>'}vectorBasicOverlay.innerHTML=markup;
{const acc=gradCss('--ac')||'#3b82f6',stroke=()=>{g.lineWidth=3;g.strokeStyle='rgba(0,0,0,.45)';g.stroke();g.lineWidth=1;g.strokeStyle=acc;g.stroke()};   // gradient handles, drawn over the shape box
 if(geo.grad){
  const a=W(geo.grad.a),b=W(geo.grad.b);g.beginPath();g.moveTo(a.x,a.y);g.lineTo(b.x,b.y);g.setLineDash([5,4]);stroke();g.setLineDash([]);
  g.beginPath();g.arc(a.x,a.y,6,0,7);g.fillStyle=acc;g.fill();g.lineWidth=2;g.strokeStyle='#fff';g.stroke();
  g.beginPath();g.moveTo(b.x,b.y-7);g.lineTo(b.x+7,b.y);g.lineTo(b.x,b.y+7);g.lineTo(b.x-7,b.y);g.closePath();g.fillStyle='#fff';g.fill();g.lineWidth=2;g.strokeStyle=acc;g.stroke();
 }}
}
// Basic shapes uses the Transform handle glyphs and an extra centre grab point.
const vectorBasicOverlay=document.createElementNS('http://www.w3.org/2000/svg','svg');vectorBasicOverlay.classList.add('vector-basic-overlay');vectorBasicOverlay.setAttribute('aria-hidden','true');wrap.append(vectorBasicOverlay);
function vectorBasicCursor(){const h=vectorGizmoDrag?.hit||vectorBasicHover;if(!h||!vectorGizmoDrag&&h.L!==vectorGizmoTarget())return 'crosshair';if(h.type==='move')return vectorGizmoDrag?'grabbing':'grab';if(h.type==='rotate')return 'url("data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"><path d="M5 9a8 8 0 1 1 0 8M5 3v6h6" fill="none" stroke="white" stroke-width="4"/><path d="M5 9a8 8 0 1 1 0 8M5 3v6h6" fill="none" stroke="black" stroke-width="2"/></svg>')+'") 12 12, crosshair';if(h.type==='skew')return h.fy!==.5?'ew-resize':'ns-resize';const L=h.L,g=vectorGizmoGeometry(L),p=g.pts[Object.keys(VG_HANDLES).find(k=>VG_HANDLES[k][0]===h.fx&&VG_HANDLES[k][1]===h.fy)],a=gradToWrap(p),b=gradToWrap(g.c),angle=Math.atan2(a.y-b.y,a.x-b.x),axis=((Math.round(angle/(Math.PI/4))%4)+4)%4;return ['ew-resize','nwse-resize','ns-resize','nesw-resize'][axis]}
wrap.addEventListener('pointermove',e=>{if(!vectoring||$('vectorMode').value!=='basic'||vectorGizmoDrag)return;vectorBasicHover=vectorGizmoHit(e);if(typeof modeCursor==='function')modeCursor();startVectorGizmo()},{passive:true});wrap.addEventListener('pointerleave',()=>{vectorBasicHover=null});
// One scheduled redraw per change; no animation loop while the tool is idle.
function vectorMultiSelection(){return typeof vectorMultiTargets==='function'?vectorMultiTargets():[]}
function startVectorGizmo(){if(vectorGizmoFrame||!vectorMultiSelection().length&&!vectorGizmoVisible&&!vectorGizmoTarget()&&!window.BungalowPen?.active())return;vectorGizmoFrame=requestAnimationFrame(()=>{vectorGizmoFrame=0;vectorGizmoDraw()})}
new ResizeObserver(startVectorGizmo).observe(wrap);
new MutationObserver(startVectorGizmo).observe(document.body,{attributes:true,attributeFilter:['class']});
new MutationObserver(startVectorGizmo).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
// ---- deforming vector layers without rasterising ----
// Outline of each basic shape as SVG path data in the shape's own (local) space.
function vectorShapePathData(s){
 const {x,y,w,h}=s,cx=x+w/2,cy=y+h/2,f=n=>+(+n).toFixed(4),P=(u,v)=>f(x+u*w)+' '+f(y+v*h),poly=pts=>'M'+pts.map(p=>f(p[0])+' '+f(p[1])).join('L')+'Z';
 switch(s.kind){
  case 'ellipse':return `M${f(x)} ${f(cy)}A${f(w/2)} ${f(h/2)} 0 1 0 ${f(x+w)} ${f(cy)}A${f(w/2)} ${f(h/2)} 0 1 0 ${f(x)} ${f(cy)}Z`;
  case 'triangle':return poly([[cx,y],[x+w,y+h],[x,y+h]]);
  case 'diamond':return poly([[cx,y],[x+w,cy],[cx,y+h],[x,cy]]);
  case 'rounded':{const r=Math.max(0,Math.min(s.radius??24,w/2,h/2));return r>0?`M${f(x+r)} ${f(y)}H${f(x+w-r)}A${f(r)} ${f(r)} 0 0 1 ${f(x+w)} ${f(y+r)}V${f(y+h-r)}A${f(r)} ${f(r)} 0 0 1 ${f(x+w-r)} ${f(y+h)}H${f(x+r)}A${f(r)} ${f(r)} 0 0 1 ${f(x)} ${f(y+h-r)}V${f(y+r)}A${f(r)} ${f(r)} 0 0 1 ${f(x+r)} ${f(y)}Z`:poly([[x,y],[x+w,y],[x+w,y+h],[x,y+h]])}
  case 'polygon':case 'star':{const n=Math.max(3,Math.min(32,Math.round(s.sides??5))),star=s.kind==='star',k=star?Math.max(.05,Math.min(.95,s.inner??.5)):1,m=star?n*2:n,pts=[];for(let i=0;i<m;i++){const a=-Math.PI/2+i*Math.PI*2/m,r=star&&i%2?k:1;pts.push([cx+Math.cos(a)*w/2*r,cy+Math.sin(a)*h/2*r])}return poly(pts)}
  case 'grid':{let d=poly([[x,y],[x+w,y],[x+w,y+h],[x,y+h]]);for(let i=1;i<(s.xDivisions??4);i++)d+='M'+P(i/(s.xDivisions??4),0)+'L'+P(i/(s.xDivisions??4),1);for(let i=1;i<(s.yDivisions??4);i++)d+='M'+P(0,i/(s.yDivisions??4))+'L'+P(1,i/(s.yDivisions??4));return d}
  case 'line':return s.flip?`M${P(0,1)}L${P(1,0)}`:`M${P(0,0)}L${P(1,1)}`;
  case 'arrow':{const hl=Math.min(w*.5,h*.6),bx=x+w-hl;return poly([[x,y+h*.3],[bx,y+h*.3],[bx,y],[x+w,cy],[bx,y+h],[bx,y+h*.7],[x,y+h*.7]])}
  case 'cross':{const x1=x+w/3,x2=x+w*2/3,y1=y+h/3,y2=y+h*2/3;return poly([[x1,y],[x2,y],[x2,y1],[x+w,y1],[x+w,y2],[x2,y2],[x2,y+h],[x1,y+h],[x1,y2],[x,y2],[x,y1],[x1,y1]])}
  case 'heart':return `M${P(.5,1)}C${P(.12,.8)} ${P(0,.55)} ${P(0,.32)}C${P(0,.1)} ${P(.15,0)} ${P(.27,0)}C${P(.4,0)} ${P(.5,.12)} ${P(.5,.28)}C${P(.5,.12)} ${P(.6,0)} ${P(.73,0)}C${P(.85,0)} ${P(1,.1)} ${P(1,.32)}C${P(1,.55)} ${P(.88,.8)} ${P(.5,1)}Z`;
  default:return poly([[x,y],[x+w,y],[x+w,y+h],[x,y+h]]);
 }
}
// Matrix that carries an imported path's own coordinates into the shape's box (the same one importedPath uses).
function importedFitMatrix(s){const sx=s.bw>1e-6?s.w/s.bw:1,sy=s.bh>1e-6?s.h/s.bh:1;return [sx,0,0,sy,s.x-s.bx*sx,s.y-s.by*sy]}
// Map a shape through the Transform session's deformation (perspective / warp / liquify, plus its scale / rotate / skew).
// Returns the new shape (a path in document coordinates) and the new instance, or null if the result would be unusable.
function deformShapeToPath(shape,I,t,keepStrokes){
 if(shape.kind==='path'&&typeof shape.d!=='string')return null;
 const s=shape.kind==='grid'?{...shape,strokeAlign:'center'}:shape,b=t.bounds,im=instanceMatrix(I),inst=[im.a,im.b,im.c,im.d,im.e,im.f];
 const d=s.kind==='path'?s.d:vectorShapePathData(s),M=s.kind==='path'?instMul(inst,instMul(importedFitMatrix(s),s.m||[1,0,0,1,0,0])):inst;
 const phi=p=>transformDeformPoint(t,(p[0]-b.x)/b.width,(p[1]-b.y)/b.height);
 const dd=t.deform,curved=!!dd&&(dd.mode==='warp'||dd.mode==='liquify'||dd.warp.data.some(v=>v)||dd.flow.data.some(v=>v)),step=curved?6:Infinity;
 let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity,count=0,out='';
 for(const sp of svgPathSubpaths(d,M)){
  const pts=[];for(let i=0;i<sp.pts.length;i++){const a=sp.pts[i],c=sp.pts[i+1]||(sp.closed?sp.pts[0]:null);pts.push(a);if(c&&step<Infinity){const len=Math.hypot(c[0]-a[0],c[1]-a[1]),n=Math.min(64,Math.floor(len/step));for(let k=1;k<=n;k++)pts.push([a[0]+(c[0]-a[0])*k/(n+1),a[1]+(c[1]-a[1])*k/(n+1)])}}
  const mapped=pts.map(phi);if(!mapped.length)continue;
  out+=mapped.map((p,i)=>{if(!Number.isFinite(p.x)||!Number.isFinite(p.y))throw new Error('deformation produced an invalid point');x0=Math.min(x0,p.x);x1=Math.max(x1,p.x);y0=Math.min(y0,p.y);y1=Math.max(y1,p.y);count++;return (i?'L':'M')+(+p.x.toFixed(2))+' '+(+p.y.toFixed(2))}).join('')+(sp.closed?'Z':'');
 }
 if(!count||!(x1-x0>=0)||!(y1-y0>=0))return null;
 // stroke: constant on-canvas width, or scaled by how much the deformation scales the shape around its centre
 const line=s.kind==='line',eff=(line?Math.max(s.strokeWidth,1):s.strokeWidth)*instanceScale(I).u,cx=b.x+b.width/2,cy=b.y+b.height/2,e=Math.max(1,Math.min(b.width,b.height)/50);
 const ev=(dx,dy)=>phi([cx+dx,cy+dy]),A=ev(e,0),B=ev(-e,0),C=ev(0,e),D=ev(0,-e),jx=[(A.x-B.x)/(2*e),(A.y-B.y)/(2*e)],jy=[(C.x-D.x)/(2*e),(C.y-D.y)/(2*e)],det=Math.abs(jx[0]*jy[1]-jx[1]*jy[0]),scale=Math.sqrt(det)||1;
 const bx=x0,by=y0,bw=x1-x0,bh=y1-y0,ns={...s,kind:'path',d:out,m:[1,0,0,1,0,0],bx,by,bw,bh,x:bx,y:by,w:bw,h:bh,flip:false,strokeWidth:Math.min(1000,+(eff*(keepStrokes?1:scale)).toFixed(3))};
 if(line){ns.paint='stroke';ns.strokeColour=s.paint==='fill'?s.colour:s.strokeColour;ns.strokeOpacity=(s.paint==='fill'?s.fillOpacity:s.strokeOpacity)??1;ns.cap=s.cap||'round';ns.fillMode='solid';ns.strokeAlign='center'}
 if(s.fillMode==='gradient'&&s.gradient&&s.w>0&&s.h>0){const mp=u=>{const L=[s.x+u.x*s.w,s.y+u.y*s.h],P=phi([inst[0]*L[0]+inst[2]*L[1]+inst[4],inst[1]*L[0]+inst[3]*L[1]+inst[5]]);return {x:bw>1e-6?(P.x-bx)/bw:.5,y:bh>1e-6?(P.y-by)/bh:.5}};ns.gradient={...s.gradient,a:mp(s.gradient.a),b:mp(s.gradient.b)}}
 if(s.kind==='path'&&!s.gradient)delete ns.gradient;
 if(!validVectorShape(ns))return null;
 return {shape:ns,instance:{...I,shape:ns,xf:null,flipH:false,flipV:false,dx:0,dy:0}};
}
function deformVectorLayer(t,item,keepStrokes){
 try{const L=item.layer,r=deformShapeToPath(L.instance.shape,L.instance,t,keepStrokes);return r?{L,beforeInstance:L.instance,afterInstance:r.instance}:null}catch(e){console.warn('Vector deformation fell back to pixels:',e.message);return null}
}
function vectorTool(){if(canvasBusy())return;tool(false);BungalowVectors.defaults.colour=col.value;vectoring=true;syncTools();modeCursor();startVectorGizmo();uiNotice('Vectors · drag to draw · handles move, resize and rotate the selected shape · Shift keeps proportions · Esc cancels')}
function vectorPointerDown(e){
 if(e.button!==0||canvasBusy())return;e.preventDefault();
 if(window.BungalowPen?.active()){BungalowPen.pointerDown(e);return}
 if(vectorGizmoPointerDown(e))return;
 if(!isCanvasPoint(e))return;
 if(layerLocked(AL)||groupLocked(AL?.group)){toast('Unlock the destination first');return}
 const sparseShape=sparseVectorsOn()&&nativeSparseActive();if(residentArtboardLayers().length>=4096||memoryBudgetExceeded(memoryUsage().total+(sparseShape?SPARSE_LAYER_TILE*SPARSE_LAYER_TILE*16:DW*DH*4))){toast('Shape exceeds the configured memory budget');return}
 closeTextEditor();const [rx,ry]=vectorPoint(e),snapTargets=globalSnapOn?prepareSnapTargets({items:[]}):null,snapTo=(px,py,ev)=>snapTargets?snapTextPoint(px,py,snapTargets,ev):{x:px,y:py},p0=snapTo(rx,ry,e),x=p0.x,y=p0.y,previous=AL,selection=new Set(selectedStack),index=layers.indexOf(AL)+1,L=newLayer('Vector '+$('vectorShape').selectedOptions[0].textContent.toLowerCase(),null,sparseShape);
 L.group=AL?.group||null;L.instance={type:'shape',shape:{...BungalowVectors.defaults,...vectorNewPaint(BungalowVectors.defaults.kind,BungalowVectors.defaults),x,y,w:1,h:1},flipH:false,flipV:false,dx:0,dy:0,xf:null};L._vecRect=null;
 const controller=new AbortController(),options={capture:true,signal:controller.signal};let frame=0,inserted=false;
 const redraw=()=>{frame=0;drawVectorLayer(L,true)};
 const show=()=>{setStackSelection([L],{active:L,anchor:L});relayer();renderLayers()};
 const finish=(cancel=false)=>{if(!vectorDrag)return;const drag=vectorDrag;vectorDrag=null;controller.abort();showVectorSnap(null,null);if(frame)cancelAnimationFrame(frame);try{if(wrap.hasPointerCapture(e.pointerId))wrap.releasePointerCapture(e.pointerId)}catch(_){}
  if(cancel||!drag.moved){if(inserted){removeLayer(L);setStackSelection([...selection],{active:previous});relayer();renderLayers()}return}
  drawVectorLayer(L);show();doH({bytes:layerRasterBytes(L),undo(){removeLayer(L);setStackSelection([...selection].filter(n=>layers.includes(n)||layerGroups.includes(n)),{active:layers.includes(previous)?previous:AL});relayer();renderLayers()},redo(){insertLayer(L,index);show()}});
 };
 // The layer is only added once the pointer actually moves, so a plain click costs nothing.
 const insert=()=>{if(inserted)return;inserted=true;insertLayer(L,index);show()};
 vectorDrag={layer:L,moved:false,cancel:()=>finish(true),insert};wrap.setPointerCapture(e.pointerId);
 window.addEventListener('pointermove',ev=>{if(ev.pointerId!==e.pointerId)return;ev.preventDefault();ev.stopImmediatePropagation();const [mx,my]=vectorPoint(ev),q=snapTo(mx,my,ev),px=q.x,py=q.y;showVectorSnap(Math.abs(px-mx)>1e-6?px:null,Math.abs(py-my)>1e-6?py:null);let dx=px-x,dy=py-y;const s=L.instance.shape,isLine=s.kind==='line';if(e.shiftKey||ev.shiftKey){if(isLine){const l=Math.hypot(dx,dy),a=Math.round(Math.atan2(dy,dx)/(Math.PI/12))*(Math.PI/12);dx=Math.cos(a)*l;dy=Math.sin(a)*l}else{const n=Math.max(Math.abs(dx),Math.abs(dy));dx=(dx<0?-1:1)*n;dy=(dy<0?-1:1)*n}}s.x=Math.min(x,x+dx);s.y=Math.min(y,y+dy);s.w=isLine?Math.abs(dx):Math.max(1,Math.abs(dx));s.h=isLine?Math.abs(dy):Math.max(1,Math.abs(dy));s.flip=(dx<0)!==(dy<0);vectorDrag.moved=isLine?Math.hypot(dx,dy)>=1:Math.abs(dx)>=1&&Math.abs(dy)>=1;if(vectorDrag.moved)insert();if(!frame)frame=requestAnimationFrame(redraw)},options);
 window.addEventListener('pointerup',ev=>{if(ev.pointerId!==e.pointerId)return;ev.preventDefault();ev.stopImmediatePropagation();finish()},options);
 window.addEventListener('pointercancel',ev=>{if(ev.pointerId===e.pointerId)finish(true)},options);
 window.addEventListener('lostpointercapture',ev=>{if(ev.pointerId===e.pointerId)finish(true)},options);
 window.addEventListener('blur',()=>finish(true),options);
 window.addEventListener('keydown',ev=>{if(ev.key==='Escape'){ev.preventDefault();ev.stopImmediatePropagation();finish(true)}},options);
}
(function(global){
 const defaults={kind:'rectangle',paint:'both',colour:col.value,strokeColour:'#000000',strokeWidth:2,radius:24,sides:5,inner:.5,xDivisions:4,yDivisions:4,flip:false,strokeAlign:'center',fillMode:'solid',fillOpacity:1,strokeOpacity:1,gradient:defaultVectorGradient()},KIND_LABELS={rounded:'Rounded rectangle',cross:'Plus',both:'Fill + stroke',path:'Imported path',solid:'Solid colour',gradient:'Gradient',center:'Centred',inside:'Inside',outside:'Outside'},RANGES={strokeWidth:[0,1000,.1],radius:[0,100000,1],sides:[3,32,1],inner:[.05,.95,.05]},
  SPECIFIC=['radius','sides','inner','xDivisions','yDivisions'],SPECIFIC_TITLES={grid:'Grid divisions',rounded:'Rounded rectangle options',polygon:'Polygon options',star:'Star options'},section=document.createElement('section');
 section.id='vectorControls';section.hidden=true;
 // Shape picker on top, then settings every shape has, then a group that only appears for shapes with their own parameters.
 section.innerHTML='<details open><summary>Basic shapes</summary><div class="vector-fields vector-top"></div><h4 class="vector-group">Geometry</h4><div class="vector-fields vector-universal"></div><div class="vector-specific" hidden><h4 class="vector-group"></h4><div class="vector-fields vector-specific-fields"></div></div><h4 class="vector-group">Align</h4><div class="vector-align"></div><div class="vector-actions"><button type="button" id="vectorCopyStyle" title="Copy the colours and stroke of the selected shape, or the attributes of a text object">Copy style</button><button type="button" id="vectorPasteStyle" title="Paste the copied style onto the selected shapes and text">Paste style</button></div><div class="vector-status" id="vectorSelectionCount"></div><div class="vector-actions" id="vectorSelectionStatus"><button type="button" id="vectorPlaceSvg" title="Place an SVG file as editable shapes">Place SVG…</button><button type="button" id="vectorPasteSvg" title="Paste SVG markup from the clipboard (Ctrl+V also works)">Paste SVG</button></div></details>';
 $('brushControls').before(section);
 const alignRow=section.querySelector('.vector-align'),top=section.querySelector('.vector-top'),universal=section.querySelector('.vector-universal'),specific=section.querySelector('.vector-specific'),specificFields=specific.querySelector('.vector-fields'),specificTitle=specific.querySelector('h4'),
  specs=[['vectorShape','Shape','kind',VECTOR_KINDS_ALL],['vectorPaint','Paint','paint',['fill','stroke','both','none']],['vectorFillMode','Fill','fillMode',['solid','gradient']],['vectorColour','Fill colour','colour','color'],['vectorFillOpacity','Fill opacity','fillOpacity','number'],['vectorStrokeColour','Stroke colour','strokeColour','color'],['vectorStrokeOpacity','Stroke opacity','strokeOpacity','number'],['vectorStrokeWidth','Stroke width','strokeWidth','number'],['vectorStrokeAlign','Stroke position','strokeAlign',['center','inside','outside']],['vectorWidth','Width','w','number'],['vectorHeight','Height','h','number'],['vectorRadius','Corner radius','radius','number'],['vectorSides','Sides / points','sides','number'],['vectorInner','Star depth','inner','number'],['vectorXDivisions','X divisions','xDivisions','number'],['vectorYDivisions','Y divisions','yDivisions','number']];
 const gradBlock=document.createElement('div');gradBlock.className='vector-gradient';gradBlock.hidden=true;gradBlock.innerHTML=VECTOR_GRADIENT_UI;
 for(const [op,label,icon] of ALIGN_OPS){const b=document.createElement('button');b.type='button';b.title=label;b.setAttribute('aria-label',label);b.append(BungalowIcons.node(icon));b.onclick=()=>layoutSelectedObjects(op);alignRow.append(b)}
 const targets=()=>[...selectedStack].filter(L=>L.instance?.type==='shape'&&!['empty','brushstroke'].includes(L.instance.shape.kind)&&!layerLocked(L));
  // Numeric settings use the full value control (type with units, drag to scrub, reset). The top bar gets more instances of the same controls.
 const FIELD={xDivisions:{lo:1,hi:256,step:1,drag:.1,int:true,reset:4},yDivisions:{lo:1,hi:256,step:1,drag:.1,int:true,reset:4},strokeWidth:{lo:0,hi:1000,step:.1,drag:.05,len:true,reset:2,sc:'u',max:1000},w:{lo:1,hi:100000,step:1,drag:.5,len:true,reset:100,sc:'x',max:100000},h:{lo:1,hi:100000,step:1,drag:.5,len:true,reset:100,sc:'y',max:100000},radius:{lo:0,hi:100000,step:1,drag:.5,len:true,reset:24,sc:'u',max:100000},sides:{lo:3,hi:32,step:1,drag:.05,int:true,reset:5},inner:{lo:.05,hi:.95,step:.05,drag:.0025,reset:.5,digits:2},fillOpacity:{lo:0,hi:1,step:.01,drag:.0025,pct:true,reset:1},strokeOpacity:{lo:0,hi:1,step:.01,drag:.0025,pct:true,reset:1}},
  FALLBACK={fillOpacity:1,strokeOpacity:1,radius:24,sides:5,inner:.5,strokeWidth:2},lengthF=lengthField('vector'),numeric={};let instances=[];
 const scaleOf=(L,key)=>FIELD[key].sc?instanceScale(L.instance)[FIELD[key].sc]:1;
 const fieldValue=key=>{const L=targets()[0],sh=L?.instance.shape||defaults;return (sh[key]??FALLBACK[key]??FIELD[key].reset)*(L?scaleOf(L,key):1)};
 // one live edit, one undo step: edits are applied while typing / scrubbing and recorded together once things settle
 let sEdit=null,sTimer=0;
 function liveShapes(list,fn){
  if(!list.length)return;
  if(sEdit&&(list.length!==sEdit.layers.length||list.some((L,i)=>L!==sEdit.layers[i])))flushShapeEdit();
  if(!sEdit)sEdit={layers:list,before:list.map(L=>({...L.instance.shape}))};
  for(const L of list){L.instance.shape=fn(L.instance.shape,L);drawVectorLayer(L,true)}
  clearTimeout(sTimer);sTimer=setTimeout(flushShapeEdit,450);
 }
 function flushShapeEdit(){
  clearTimeout(sTimer);sTimer=0;const e=sEdit;sEdit=null;if(!e)return;
  const after=e.layers.map(L=>({...L.instance.shape})),differs=(a,b)=>{for(const k of new Set([...Object.keys(a),...Object.keys(b)]))if(a[k]!==b[k])return true;return false};
  if(!e.before.some((b,i)=>differs(b,after[i])))return;
  const apply=v=>{e.layers.forEach((L,i)=>{L.instance.shape={...v[i]};drawVectorLayer(L)});renderLayers();sync()};
  e.layers.forEach(L=>drawVectorLayer(L));renderLayers();doH({bytes:0,undo:()=>apply(e.before),redo:()=>apply(after)});
 }
 function setField(key,value){
   if(window.BungalowPen?.strokeStyle()&&!['kind','w','h'].includes(key)){defaults[key]=value;BungalowPen.setStrokeStyle({[key]:value});sync();return}
  if(FIELD[key].int)value=Math.round(value);
  if(key!=='w'&&key!=='h')defaults[key]=value;
  liveShapes(targets(),(sh,L)=>{const local=FIELD[key].sc?Math.min(FIELD[key].max,Math.max(key==='w'||key==='h'?.001:0,value/scaleOf(L,key))):value;return sh[key]===local?sh:{...sh,[key]:local}});sync();
 }
 function makeField(key,id,label){
  const f=FIELD[key],fmt=f.len?lengthF:f.pct?percentField():plainField(f.int?0:f.digits??2);
  const api=createCompactValueControl({id,label,get:()=>fieldValue(key),set:v=>setField(key,v),min:f.lo,max:f.hi,step:f.step,dragStep:f.drag,reset:f.reset,digits:f.len?5:f.pct?4:f.digits??4,parse:fmt.parse,format:fmt.format});api.input.addEventListener('change',flushShapeEdit);api.root.addEventListener('valuecommit',flushShapeEdit);api.root.querySelector('.compact-value-reset').addEventListener('click',flushShapeEdit);return api;
 }
 for(const [id,label,key,type]of specs){
  const compact=type==='number',row=document.createElement(compact?'div':'label');row.className='vector-row'+(compact?' vector-num':'');
  if(compact){const cap=document.createElement('span');cap.className='desktop-value-label';cap.textContent=label;row.append(cap);const api=makeField(key,id,label);api.root.classList.add('desktop-value');numeric[key]=api;row.append(api.root)}
  else{
   row.append(document.createTextNode(label));const input=document.createElement(Array.isArray(type)?'select':'input');input.id=id;input.setAttribute('aria-label',label);
   if(Array.isArray(type))for(const v of type)input.add(new Option(KIND_LABELS[v]||v[0].toUpperCase()+v.slice(1),v));else input.type=type;
   input.onchange=()=>{flushPendingHistoryControls();const value=input.value;defaults[key]=value;if(key==='kind'&&value==='grid'){defaults.paint='stroke';defaults.strokeAlign='center'}const selected=targets(),changed=selected.filter(L=>L.instance.shape[key]!==value);if(changed.length){const before=changed.map(L=>({...L.instance.shape})),after=before.map(s=>({...s,[key]:value,...(key==='kind'&&value==='grid'?{paint:'stroke',strokeAlign:'center',xDivisions:s.xDivisions??defaults.xDivisions,yDivisions:s.yDivisions??defaults.yDivisions}:{}),...(key==='fillMode'&&value==='gradient'&&!s.gradient?{gradient:defaults.gradient}:{})}));if(after.some(s=>!validVectorShape(s))){sync(true);return}const apply=values=>{changed.forEach((L,i)=>{L.instance.shape={...values[i]};drawVectorLayer(L)});renderLayers();sync()};apply(after);doH({bytes:0,undo:()=>apply(before),redo:()=>apply(after)})}sync()};
   row.append(input);if(id==='vectorShape')input.querySelector('option[value="path"]').disabled=true;
  }
  (key==='kind'?top:SPECIFIC.includes(key)?specificFields:universal).append(row);if(key==='fillMode')universal.append(gradBlock)}
 
 const wrapRow=document.createElement('label');wrapRow.className='vector-row vector-wrap-exclude';wrapRow.title='Keep this shape visible, but let wrapped text pass through it';const wrapInput=document.createElement('input');wrapInput.type='checkbox';wrapInput.id='vectorWrapExclude';wrapRow.append(wrapInput,document.createTextNode(' Exclude from text wrap'));universal.append(wrapRow);
 wrapInput.onchange=()=>{const selected=targets(),value=wrapInput.checked,before=selected.map(L=>({...L.instance.shape})),after=before.map(sh=>({...sh,wrapExclude:value}));if(!selected.length)return;const apply=values=>{selected.forEach((L,i)=>{L.instance.shape={...values[i]};drawVectorLayer(L)});renderLayers();sync()};apply(after);doH({bytes:0,undo:()=>apply(before),redo:()=>apply(after)})};
 // ---- gradient fill editor: stop bar, stop fields, type, angle, presets ----
 let refreshGradientUI=()=>{};
 function liveGradient(next){defaults.gradient=next;liveShapes(targets().filter(L=>L.instance.shape.fillMode==='gradient'),sh=>({...sh,gradient:next}));refreshGradientUI()}
 function initGradientUI(){
  const q=s=>gradBlock.querySelector(s),bar=q('.vg-bar'),posIn=q('.vg-pos'),colIn=q('.vg-col'),alphaIn=q('.vg-alpha'),typeSel=q('.vg-type'),angleIn=q('.vg-angle'),spaceSel=q('.vg-space'),presetSel=q('.vg-preset'),PAD=9,GK2=globalThis.BungalowGradient;
  let selStop=0,dragging=null;
  const cur=()=>targets()[0]?.instance.shape.gradient||defaults.gradient;
  const parse=v=>({hex:v.slice(0,7),a:v.length>7?parseInt(v.slice(7,9),16)/255:1}),join=(hexv,a)=>a>=.996?hexv:hexv+Math.round(Math.min(1,Math.max(0,a))*255).toString(16).padStart(2,'0');
  const sortStops=gr=>({...gr,stops:gr.stops.slice().sort((a,b)=>a.t-b.t)}),edit=next=>liveGradient(sortStops(next));
  const angleOf=gr=>Math.round(((Math.atan2(gr.b.y-gr.a.y,gr.b.x-gr.a.x)*180/Math.PI)%360+360)%360);
  const swapStop=(gr,old,neu)=>({...gr,stops:gr.stops.map(s=>s===old?neu:s)});
  const sampler=gr=>{const G=new GK2.Gradient(gr.stops.map(s=>({t:s.t,v:s.v,mid:s.mid??.5,interp:s.interp||'linear'})));G.space=gr.space;return G};
  const checker=(()=>{const c=document.createElement('canvas');c.width=c.height=8;const x=c.getContext('2d');x.fillStyle='#c9c9c9';x.fillRect(0,0,8,8);x.fillStyle='#8f8f8f';x.fillRect(0,0,4,4);x.fillRect(4,4,4,4);return c})();
  const xOf=t=>PAD+t*((bar.clientWidth||240)-2*PAD),tOf=x=>Math.min(1,Math.max(0,(x-PAD)/Math.max(1,(bar.clientWidth||240)-2*PAD)));
  let lastDrawKey='';
  function draw(){
   const gr=cur(),W=bar.clientWidth||240,H=44,r=devicePixelRatio||1;const acc=gradCss('--ac')||'#3b82f6',drawKey=JSON.stringify([gr,selStop,W,r,acc]);if(drawKey===lastDrawKey)return;lastDrawKey=drawKey;if(bar.width!==Math.round(W*r)||bar.height!==Math.round(H*r)){bar.width=Math.round(W*r);bar.height=Math.round(H*r)}
   const g=bar.getContext('2d'),pat=g.createPattern(checker,'repeat');g.setTransform(r,0,0,r,0,0);g.clearRect(0,0,W,H);
   g.fillStyle=pat;g.fillRect(PAD,4,W-2*PAD,20);const G=sampler(gr),n=Math.max(1,W-2*PAD);for(let x=0;x<n;x++){g.fillStyle=GK2.Col.css(G.sample(x/Math.max(1,n-1)));g.fillRect(PAD+x,4,1,20)}
   g.lineWidth=1;g.strokeStyle='rgba(128,128,128,.6)';g.strokeRect(PAD-.5,3.5,W-2*PAD+1,21);
   gr.stops.forEach((s,i)=>{const x=xOf(s.t),sel=i===selStop;g.beginPath();g.moveTo(x,26);g.lineTo(x+5,32);g.lineTo(x-5,32);g.closePath();g.fillStyle=sel?acc:'#ccc';g.fill();
    g.fillStyle=pat;g.fillRect(x-7,33,14,10);g.fillStyle=GK2.Col.css(GK2.Col.parse(s.v));g.fillRect(x-7,33,14,10);g.lineWidth=sel?2:1;g.strokeStyle=sel?acc:'rgba(128,128,128,.8)';g.strokeRect(x-7,33,14,10)});
  }
  new ResizeObserver(draw).observe(bar);
  refreshGradientUI=()=>{
   const gr=cur();selStop=Math.min(Math.max(selStop,0),gr.stops.length-1);const s=gr.stops[selStop],p=parse(s.v);
   if(document.activeElement!==posIn)posIn.value=Math.round(s.t*100);if(document.activeElement!==colIn)colIn.value=p.hex;if(document.activeElement!==alphaIn)alphaIn.value=Math.round(p.a*100);
   typeSel.value=gr.type;spaceSel.value=gr.space;if(document.activeElement!==angleIn)angleIn.value=angleOf(gr);q('.vg-angle-row').hidden=gr.type==='radial';
   q('.vg-del').disabled=gr.stops.length<=2;draw();
  };
  bar.addEventListener('pointerdown',e=>{
   const r=bar.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top,gr=cur();let hit=-1;
   gr.stops.forEach((s,i)=>{if(Math.abs(xOf(s.t)-x)<=9&&y>=22)hit=i});
   if(hit<0){const t=tOf(x),v=GK2.Col.hex(sampler(gr).sample(t),true),ns={t,v,mid:.5,interp:'linear'},next=sortStops({...gr,stops:[...gr.stops,ns]});selStop=next.stops.indexOf(ns);edit(next);return}
   e.preventDefault();selStop=hit;dragging={stop:gr.stops[hit]};bar.setPointerCapture(e.pointerId);refreshGradientUI();
  });
  bar.addEventListener('pointermove',e=>{
   if(!dragging)return;const r=bar.getBoundingClientRect(),gr=cur(),moved={...dragging.stop,t:tOf(e.clientX-r.left)},next=sortStops(swapStop(gr,dragging.stop,moved));dragging.stop=moved;selStop=next.stops.indexOf(moved);edit(next);
  });
  const endDrag=()=>{dragging=null};bar.addEventListener('pointerup',endDrag);bar.addEventListener('pointercancel',endDrag);
  const upd=patch=>{const gr=cur(),old=gr.stops[selStop],neu={...old,...patch(old)},next=sortStops(swapStop(gr,old,neu));selStop=next.stops.indexOf(neu);edit(next)};
  posIn.addEventListener('input',()=>{const v=parseFloat(posIn.value);if(Number.isFinite(v))upd(()=>({t:Math.min(1,Math.max(0,v/100))}))});
  colIn.addEventListener('input',()=>upd(s=>({v:join(colIn.value.toLowerCase(),parse(s.v).a)})));
  alphaIn.addEventListener('input',()=>upd(s=>({v:join(parse(s.v).hex,alphaIn.value/100)})));
  typeSel.addEventListener('change',()=>{const gr=cur();edit({...gr,type:typeSel.value,...vgGeometry(typeSel.value,angleOf(gr))})});
  angleIn.addEventListener('input',()=>{const gr=cur();edit({...gr,...vgGeometry(gr.type,+angleIn.value)})});
  spaceSel.addEventListener('change',()=>edit({...cur(),space:spaceSel.value}));
  const PRESETS={fgbg:()=>[[0,hex(...colourSlots[0])],[1,hex(...colourSlots[1])]],fgclear:()=>{const c=hex(...colourSlots[0]);return [[0,c],[1,c+'00']]},
   sunset:()=>[[0,'#1d1a3a'],[.4,'#a8325e'],[.75,'#f39a3c'],[1,'#fff1c9']],ocean:()=>[[0,'#0b3a52'],[.5,'#3aa59c'],[1,'#e8f4d8']],
   spectrum:()=>[[0,'#e8473c'],[.2,'#f2b33d'],[.4,'#8fd14f'],[.6,'#36b4c9'],[.8,'#5a5ce0'],[1,'#c84fd6']],chrome:()=>[[0,'#f4f4f6'],[.45,'#7d8590'],[.5,'#2f343b'],[.55,'#b9c0ca'],[1,'#f9fafb']]};
  presetSel.addEventListener('change',()=>{const f=PRESETS[presetSel.value];presetSel.value='';if(!f)return;selStop=0;edit({...cur(),stops:f().map(([t,v])=>({t,v,mid:.5,interp:'linear'}))})});
  q('.vg-add').addEventListener('click',()=>{const gr=cur(),st=gr.stops;let bi=0,bg=-1;for(let i=0;i<st.length-1;i++)if(st[i+1].t-st[i].t>bg){bg=st[i+1].t-st[i].t;bi=i}const t=(st[bi].t+st[bi+1].t)/2,ns={t,v:GK2.Col.hex(sampler(gr).sample(t),true),mid:.5,interp:'linear'},next=sortStops({...gr,stops:[...st,ns]});selStop=next.stops.indexOf(ns);edit(next)});
  q('.vg-del').addEventListener('click',()=>{const gr=cur();if(gr.stops.length<=2)return;const st=gr.stops.filter((_,i)=>i!==selStop);selStop=Math.min(selStop,st.length-1);edit({...gr,stops:st})});
  q('.vg-rev').addEventListener('click',()=>{const gr=cur();selStop=gr.stops.length-1-selStop;edit({...gr,stops:gr.stops.map(s=>({...s,t:1-s.t,mid:.5}))})});
 }
 function sync(force=false){window.VectorAppearance?.sync();window.VectorStroke?.sync();window.VectorObjects?.sync();window.BungalowPen?.sync();if(vectorGizmoDrag&&(!vectoring||!layers.includes(vectorGizmoDrag.hit.L)||AL!==vectorGizmoDrag.hit.L||!selectedStack.has(AL)||!layerVisible(AL)||layerLocked(AL)))vectorGizmoDrag.cancel();startVectorGizmo();if(!vectoring&&vectorDrag)vectorDrag.cancel();section.hidden=!vectoring;if(!vectoring)return;const selected=targets(),s=selected[0]?.instance.shape||defaults;
  for(const [id,,key]of specs){const api=numeric[key];if(api){api.sync();if(key==='w'||key==='h'){const off=!selected.length;api.input.disabled=off;api.root.querySelector('.compact-value-drag').disabled=off;if(off)api.root.querySelector('.compact-value-reset').disabled=true}}else{const input=$(id);if(key==='w'||key==='h')input.min=s.kind==='line'?0:1;if(force||document.activeElement!==input)input.value=s[key]??''}}
  instances=instances.filter(a=>a.root.isConnected);for(const a of instances)a.sync();
  {const k=s.kind,vis={radius:k==='rounded',sides:k==='polygon'||k==='star',inner:k==='star',xDivisions:k==='grid',yDivisions:k==='grid'};let any=false;for(const [id,,key]of specs)if(key in vis){$(id).closest('.vector-row').hidden=!vis[key];any=any||vis[key]}specific.hidden=!any;specificTitle.textContent=SPECIFIC_TITLES[k]||''}
  wrapInput.checked=!!s.wrapExclude;wrapInput.disabled=!selected.length;
  $('vectorCopyStyle').disabled=!selectedVectorObjects(true).length;$('vectorPasteStyle').disabled=!copiedVectorStyle||!selectedVectorObjects().length;
  {const many=selectedStackNodes().length>=2;for(const b of alignRow.children)b.disabled=!many}{const gm=(s.fillMode||'solid')==='gradient';{const ft=$('vectorFillType');if(ft&&ft.value!==(gm?'gradient':'flat'))ft.value=gm?'gradient':'flat'}$('vectorColour').closest('.vector-row').hidden=gm;gradBlock.hidden=!gm;$('vectorStrokeAlign').closest('.vector-row').hidden=s.kind==='line'||s.kind==='grid';if(gm)refreshGradientUI()}/* v283: the count has its own element; writing it into the SVG button row removed Place/Paste SVG */$('vectorSelectionCount').textContent=selected.length?selected.length+' shape'+(selected.length===1?'':'s')+' selected':'';global.BungalowSubtools?.sync()}
 $('vectorPlaceSvg').onclick=()=>pickSvgFiles();$('vectorPasteSvg').onclick=()=>pasteSvgFromClipboard();
 $('vectorCopyStyle').onclick=()=>{copyVectorStyle();sync()};$('vectorPasteStyle').onclick=()=>pasteVectorStyle();
 initGradientUI();
 $('vectorstool').onclick=vectorTool;$('vectorMode').onchange=()=>vectorTool();
 const pathOption=new Option('Bézier path','path');pathOption.disabled=true;$('vectorShape').add(pathOption);
 global.BungalowVectors={defaults,sync,flush:flushShapeEdit,flushColour:flushVectorColourEdit,scheduleGizmo:startVectorGizmo,field(key,label){const api=makeField(key,'context_vector_'+key,label);api.root.classList.add('desktop-value');instances.push(api);return api}};sync();
})(globalThis);
