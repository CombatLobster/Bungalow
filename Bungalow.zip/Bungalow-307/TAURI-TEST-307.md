# Running the native core in Tauri (v307)

The command file is still `native/tauri/bungalow_core_command-291.rs` (unchanged since v291).

This guide covers Windows 10/11. It includes the fixes found during the first desktop run (v272). If you already set this up for v272, go straight to **Updating**.

## 1. One-time setup
1. Install Rust from https://rustup.rs and accept the defaults.
2. Install the Tauri CLI. It compiles from source and takes 5 to 10 minutes:
   ```powershell
   cargo install tauri-cli --version "^2" --locked
   ```
   This setup assumes Tauri v2. Check that `src-tauri\Cargo.toml` has `tauri = "2..."`.

## 2. Add the core to the shell
1. Copy `native\bungalow-core` from the zip into your project, next to `src-tauri`:
   ```powershell
   Copy-Item -Recurse '<unzipped>\native\bungalow-core' '<project>\bungalow-core'
   ```
2. In `src-tauri\Cargo.toml`, add these under `[dependencies]`. The path must point at the folder you just copied.
   ```toml
   bungalow-core = { path = "../bungalow-core" }
   serde_json = "1"
   ```
   Then add this at the end of the same file. It optimises the core in dev builds; without it, `cargo tauri dev` runs the core unoptimised.
   ```toml
   [profile.dev.package.bungalow-core]
   opt-level = 3
   ```
3. Copy the command file in under the plain name:
   ```powershell
   Copy-Item '<unzipped>\native\tauri\bungalow_core_command-291.rs' '<project>\src-tauri\src\bungalow_core_command.rs'
   ```
4. Register the command in `src-tauri\src\lib.rs`. `main.rs` only calls `<your lib name>::run();`.
   ```rust
   mod bungalow_core_command;
   use bungalow_core_command::{bungalow_core, bungalow_core_bin, bungalow_core_raw, CoreState};

   #[cfg_attr(mobile, tauri::mobile_entry_point)]
   pub fn run() {
       tauri::Builder::default()
           .manage(CoreState::default())
           .invoke_handler(tauri::generate_handler![bungalow_core, bungalow_core_bin, bungalow_core_raw /*, your existing commands */])
           .run(tauri::generate_context!())
           .expect("error while running tauri application");
   }
   ```
   `.manage(...)` must be part of the builder chain; a separate line on its own gives "expected item, found `.`". Only one `invoke_handler` is allowed, so if you already have one, add `bungalow_core` to its list.
5. Put the new frontend where Tauri serves it from: the folder named by `build.frontendDist` in `src-tauri\tauri.conf.json`. Copy the zip's `index.html` and `src\` there, or rerun your build step. If `NativeShadow` is undefined in the console, the app is still serving an old copy.

## 3. Run
```powershell
cd <project>\src-tauri
cargo tauri dev
```

## Updating to a new version
1. Replace `<project>\bungalow-core` with the zip's `native\bungalow-core`.
2. Copy `index.html` and `src\` into the folder `frontendDist` points to.
3. Rerun `cargo tauri dev`. The command file doesn't change between versions unless the release notes say so.

**v291 changes the command file.**
- Copy `native\tauri\bungalow_core_command-291.rs` over `src-tauri\src\bungalow_core_command.rs`.
- Add `bungalow_core_raw` to the `use` line and to `generate_handler![...]` (step 2.4).
- The commands are now `async`, so the core no longer runs on the window's main thread.
- `bungalow_core_raw` sends pixels and files as bytes in both directions.
- This was compile-checked against Tauri 2.12.5.

## 4. Shadow mode (checking the core against the app)
Shadow mode makes the core mirror every change and compare against the app. It is slow by design, so use it for checking, not for painting.
1. Open dev tools: right-click in the window and choose Inspect, or press F12.
2. In the Console, run `localStorage.bungalowNativeShadow = 'full'` (`'1'` skips the compositor check), then reload with Ctrl+R.
3. Work for a few minutes. Since v273, include modifier layers: colour, transform and adjustment layers, plus filter layers.
4. Run `NativeShadow.stats()`.
   - `enabled: true` means the core is connected.
   - `divergences: []` and `errors: []` mean the core matched the app.
   - `composite.reasons` lists documents the core skipped (unsupported modifiers such as mirror or blur). That is expected.
   - If anything shows up under divergences or errors, right-click the output, choose Copy object, and send it.
5. To turn it off, run `localStorage.removeItem('bungalowNativeShadow')` and reload.

## 4b. Core mode (v291: on by default in Tauri)
Since v291, core mode is on in Tauri without any setting. It runs in **lazy** mode: the app paints as usual, and the core only receives the tiles that changed, in small batches, once you pause. Saving and autosave go through the core. `localStorage.bungalowNativeCore` overrides this:
- `'0'` turns core mode off.
- `'1'` or `'lazy'` is the same as the default. (v299: the per-edit `'eager'` mode was removed; an old `'eager'` setting now means lazy.)

Check it in the Console: `NativeShadow.lazy()` should be `true`, and `NativeShadow.transport()` should be `'raw'`. If the transport says `'json'` or `'binary'`, the v291 command file isn't in place yet. `NativeShadow.pending()` shows the tiles still waiting to be sent.

Since v299 the core brush engines and the core-drawn display are gone, so `bungalowNativeBrush`, `bungalowNativeSketch`, `bungalowNativeBristle` and `bungalowNativeDisplay` do nothing. You can remove them.

## 5. v307 check (clone sources park)
1. Copy `index.html` and `src\`, then rebuild with `cargo tauri dev`. The core and command file are unchanged.
2. Make a clone of a large layer, select another layer, and set "Park inactive layers above" low (0.25 GiB). The source layer can now be parked (`LayerParking.stats().parkedNow`).
3. Move or transform the clone. It keeps its pixels for a moment, then redraws in the new place once its source has loaded. The result should be the same as before.
4. Paint on the source (select it first). The clone should follow as before.

## 5b. v306 check (WinTab)
1. Copy `index.html` and `src\`. `src\wintab-input.js` is replaced by `src\wintab-input-306.js`; delete the old file if you copy over the top. Rebuild with `cargo tauri dev`. The core and command file are unchanged.
2. Turn Windows Ink off in the tablet driver, then turn on Preferences > Tablet > "Use WinTab".
3. **Fast strokes with varying pressure:** the width should change smoothly along the stroke, not in steps.
4. **Press, hold the pen still for a second, then lift:** there should be no blob or size jump at the end.
5. **Quick taps and the start of strokes:** the first dab should be visible, with no missing start.
6. **Flip to the eraser end:** it should erase, as it does with Windows Ink.
7. **Toggle "Use WinTab" off and on quickly a few times,** then draw. Pressure should still work, with no doubled behaviour.
8. If tilt leans the wrong way, use "Invert tilt X/Y" (both now have tooltips).
