import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
html=html.replace(/<script src="\.\/src\/([^"/]+)"><\/script>/g,(_,name)=>'<script>'+fs.readFileSync(path.join(root,'src',name),'utf8')+'</script>');
const output=path.join(root,'Bungalow-native-307.html');fs.writeFileSync(output,html);console.log(output);
