# Bungalow v307

Open `index.html` (or `Bungalow-native-307.html`, the single-file build from `node build.mjs`).
Desktop (Tauri) with the Rust core: `TAURI-TEST-307.md` (v307 check, plus the v306 WinTab check). Core-owned layers
plan: `PLAN-CORE-OWNED-LAYERS-300.md`.

## v307
- **Clone sources can be parked.** A clone whose source is parked keeps its pixels when it needs redrawing (moved,
  transformed). It redraws exactly once the source is back (`SourceLayers.draw` in `src/part-05.js`). The core composites
  clones from its own copy of the source, so display and export are unaffected.
- **Paint masks are not parked:** they are stored as full canvases, not tiles. Parking them first needs tiled storage
  for masks.
- Test: tests/clone-parking-307.cjs.

## v306 (WinTab, still to be desktop-tested)
- Per-event interpolated pen samples; holding the pen still keeps WinTab data; zero-pressure first contact fixed;
  eraser end; start/stop race fixed. `src/wintab-input-306.js` replaces `src/wintab-input.js`.

## Layout
- `src/`: app. Native-core glue: `native-shadow-307.js`, `layer-parking-307.js`, `native-vector-285.js`. Pen: `wintab-input-306.js`.
- `native/bungalow-core/`: Rust core (`cargo test --release`).
- `native/tauri/bungalow_core_command-291.rs`: Tauri command file (unchanged since v291).
- `tests/`: browser tests (`node tests/<name>.cjs`; native ones need `cargo build --release --bin bungalow-core-server`).
